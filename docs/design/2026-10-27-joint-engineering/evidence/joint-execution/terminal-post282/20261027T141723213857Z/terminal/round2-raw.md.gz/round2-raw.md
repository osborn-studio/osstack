VERDICT: PASS

This is a static review of the diff and the excerpts provided. I did not execute anything, did not see the full suite, and did not see the collaborator test files.

## Claims checked against the code

- **Start, no terminal.** After the loop, `daemon.ts:669` throws if `terminalCompleted` is false, so `settled` stays false. The `finally` at `:722` then aborts, calls `confirmAdapterStopped`, and either releases or retains. `confirmAdapterStopped` returns false when there is no verifier, so the lease is retained. The iterator is fully consumed first, but the stop check is still requested.
- **Start, completed then late failed or throw.** A failed terminal throws at `:664`. A post-terminal iterator throw lands in the `catch`. In both cases `settled` is still false, so stop confirmation is requested.
- **Start, completed but no native id.** `settled = true` (`:670`) comes before the native-id throw (`:671`), so that failure releases without stop proof. This matches the changeset and the final test.
- **Send.** Moving `settled = true` to `:1049` closes the terminal-free hole. A failed terminal returns inside the loop and a throw lands in the inner catch, so both leave `settled` false. A DB-commit failure after completion still releases without stop proof, which is consistent with a completed invocation. Early returns such as a native-session mismatch or protected metadata also leave `settled` false, which is unchanged from before.
- **Response ordering.** Both handlers `await` the cleanup in `finally` before the response resolves. The tests that assert `cleanupAttempts` and drain state right after the RPC are therefore deterministic.
- **Built-in Codex.** `runSession` emits `completed` only after `await closed`, so a completed terminal means the process has closed. The adapter has no `confirmStopped`, so a completed stream releases. A terminal-free stream cannot normally occur.
- **Replay, persistence and cleanup separation.** The receipt paths, `markMessageFailed` and `reportSessionCleanupFailure` are untouched. The tests assert that restart replay does not re-invoke the adapter and that persisted state is unchanged.

## Findings

No P0, P1 or P2 blocking findings.

**Non-blocking test notes (P2-level, not blocking):**
1. A `session.terminal` with state `cancelled` (not `failed`) on start without an abort is not exercised. It takes the same `!== "completed"` branch as `failed`, so the risk is low.
2. I could not verify the collaborator and `attention.answer` routes. Both use `executeReservedSessionTurn`, and any fixture there that exhausts without a terminal and has no `confirmStopped` will now retain its lease. The shown engineering fixture always emits a terminal or throws, and it has a verifier, so those tests are unaffected. Please confirm the collaborator tests from the focused run.
3. Style only: the new tests have double blank lines and some very long lines. Behavior is unaffected.

## Correcting the prior audit and host dispositions

- **Prior P2-1 (confirmed-stop branch untested) is stale.** The late-fault matrix in this diff covers `stopUnconfirmed` true and false for both routes. The `false` cases assert `cleanupAttempts === 1` and `drained: true`. Host disposition 1 is accurate.
- **Prior P2-2 (evidence validation and 1s timeout untested) is wrong.** The second test in `adapter-lifecycle.test.ts` covers whitespace evidence, a missing verifier and a hung verifier at 1000ms. Host disposition 2 is accurate, so this is not a missing test.
- **Dispositions 3 and 4** are fair. An abort after completion forces stop verification (`:722`, `:1097`) as before, and extra events or repeated completed terminals are accepted as before. Neither was introduced by this PR.

## Inherited, not regressions

- A failed or cancelled terminal from built-in Codex, such as `codex_nonzero_exit`, retains the lease permanently because there is no verifier. DEBT02 owns recovery.
- Replaying a failed Session start returns RPC `ok: true` with `state: failed`. The changeset documents this.
- A crash mid-start leaves the session in `starting`, and replay returns that state. This is not new.
- Trusting a completed terminal plus normal exhaustion as proof of exit rests on the trusted adapter, which is the stated model. Same-process restart tests do not qualify cross-process holds, and the changeset says so.

## Scope

The PR does not add recovery, qualification, provider stop authentication or a schema change. The code and changeset match those claims.

END_AUDIT