from pathlib import Path
import subprocess,json,gzip,hashlib,os,datetime
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/terminal-post282');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-terminal-post282-20261027');dest=root/'docs/implementation/joint-terminal-post282'
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_HOME']=str(out/'home');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack';env.pop('OSSTACK_SOCKET',None)
checks=[]
for label,cmd in [('docs-hygiene',['pnpm','--filter','@osstack/governance','exec','vitest','run','src/knowledge-hygiene/osstack-config.test.ts']),('lint-docs',['pnpm','lint'])]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 checks.append({'name':label,'command':cmd,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':label+'.log','log_sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()});print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
meta={'code_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Final evidence additions; product/test sources unchanged','checks':checks}
(out/'documentation-checks.json').write_text(json.dumps(meta,indent=2)+'\n')
manifest=json.loads((dest/'archive-manifest.json').read_text())
for name in ['docs-hygiene.log','lint-docs.log','documentation-checks.json']:
 data=(out/name).read_bytes();path=name if name.endswith('.json') else name+'.gz';encoded=data if name.endswith('.json') else gzip.compress(data,mtime=0);(dest/path).write_bytes(encoded)
 manifest['files'].append({'source':name,'path':path,'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest(),'raw_bytes':len(data),'raw_sha256':hashlib.sha256(data).hexdigest()})
(dest/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths=set()
for row in manifest['files']:
 assert row['path'] not in paths;paths.add(row['path']);p=dest/row['path'];data=p.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];raw=gzip.decompress(data) if p.name.endswith('.gz') else data;assert len(raw)==row['raw_bytes'] and hashlib.sha256(raw).hexdigest()==row['raw_sha256']
actual={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file()};assert actual==paths|{'README.md','archive-manifest.json'}
binding=json.loads((dest/'audit-code-binding.json').read_text())
for filekey,hashkey in [('raw_report','raw_report_sha256'),('input','input_sha256'),('raw_response','raw_response_sha256')]:assert hashlib.sha256(gzip.decompress((dest/binding[filekey]).read_bytes())).hexdigest()==binding[hashkey]
print(json.dumps({'archive_files_verified':len(paths),'full_manifest_coverage':True,'audit_hashes_verified':True}))
