# Independent two-PR composition validation

PASS for the requested bounded composition. No source edits, branch publication, PR changes, OSStack writes, default-home access or runtime gate qualification occurred.

## Exact objects and published-head equivalence

A fresh detached worktree at the required hidden root began at 177176f2c6ceb247f3c4050783487c7fa45aeb5e and merged bc25b1cf1889f89178f29a309d7b8c6191d01d40 without conflict. The temporary code composition commit is e1f0a529aa88d299955c97bb35feeb2fed5445bf, with those exact two parents, tree 3803c36ccf151ada32d2d4c0b92cfd63c310c59a.

After code checks, merged final broker publication head 9cb4b63fce98ee6c0261b5ba3fe5e740aea9418c. The second temporary commit is cc79b13de0c778a6d4a27da49e6adaed13df2f7e (parents e1f0a529 and 9cb4b63f), tree 228b2a0b9ae6708bc68bb3019921198484538320. Its only difference from the tested code composition is 179 docs/implementation/joint-broker-spec evidence files. Independently executing git merge-tree --write-tree on the two actual published heads 177176f2 and 9cb4b63f returned exactly that final tree. Thus code checks apply by exact unchanged code, while final document hygiene actually ran with both published archives present.

Both local commits are preserved in composition.bundle, independently verified by git bundle verify. They were not pushed and no named branch was created or modified. composition-object.json and final-composition-object.json retain full hashes/parent arrays and archive path list.

## Actual execution

- Node v22.22.1; fresh pnpm install --frozen-lockfile completed. node_modules belongs to this worktree, not a symlink to a worker checkout.
- pnpm build completed for the workspace. The generated tracked packages/knowledge/dist files were deliberately retained through all tests, as requested. Their hashes and patch are recorded; no generated output was committed.
- Python joint design and execution-ledger tests: 241 passed.
- Core broker/home recovery specification tests: 105 passed (91 broker, 14 home).
- Protocol joint foundation/reference/JSON/admission/schema tests: 87 passed across five files.
- Governance osstack-config document hygiene on the final published archive composition: 1 passed.

All recorded commands exited 0 and every stdout/stderr hash was verified. These are fresh runs in the composition worktree, not inherited worker outcomes. No full repository test suite was run. Shared build dependencies remained available until the final test finished. All pnpm commands used explicit scratch OSSTACK_HOME/OSSTACK_SCRATCH_ROOT and removed OSSTACK_SOCKET from their environment.

## Cleanup and limits

Before cleanup, the only tracked working-tree differences were four expected knowledge build artifacts; their patch/hashes were retained. Removed this self-created worktree (force needed only for those generated files) and pruned Git worktree metadata. The directory and registration are absent. No other worktree was altered.

Passing this composition means the named source and archived design candidates merge cleanly and the listed cross-file checks pass. It does not issue J01/J11/J17 runtime acceptance, authenticate a separate review principal, approve or merge GitHub PRs, or replace revalidation after later main/code changes. Build warnings, if any, remain in raw logs rather than being hidden.
