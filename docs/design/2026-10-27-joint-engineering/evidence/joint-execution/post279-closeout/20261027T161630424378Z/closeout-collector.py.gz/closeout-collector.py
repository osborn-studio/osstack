from pathlib import Path
import json,hashlib,subprocess,datetime,sys,shutil,tomllib,os,stat
W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-nextwave-control')
D=W/'docs/design/2026-10-27-joint-engineering'
S=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-nextwave-20261028/control')
BASE='d3fa7ef681efc79a5fb2dff92172ef1be0978774'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=W)
def h(b): return hashlib.sha256(b).hexdigest()
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','origin/main').decode().strip()==BASE
assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
old=(D/'execution-ledger.json').read_bytes();d=json.loads(old);start=now()
E=D/'evidence/joint-execution/post279-closeout'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');E.mkdir(parents=True,exist_ok=False)
def record(p): return {'path':str(p.relative_to(D)),'sha256':h(p.read_bytes())}
prev=E/('ledger-before-'+h(old)+'.json');prev.write_bytes(old);d['checkpoint_history'].append(record(prev))
fields='number,url,state,isDraft,baseRefName,headRefName,headRefOid,mergedAt,mergeCommit,mergeable,mergeStateStatus,reviewDecision,statusCheckRollup'
for i,pr in enumerate(d['prs']):
 p=json.loads(subprocess.check_output(['gh','pr','view',str(pr['number']),'--repo','osborn-studio/osstack','--json',fields]));p['observed_at']=now();d['prs'][i]=p
p=next(x for x in d['prs'] if x['number']==279)
assert p['state']=='MERGED' and p['mergeCommit']['oid']==BASE and p['headRefOid']=='3a5841eb9c4673c6e2ac924520b0acaf1c749956'
for name in ['check','graph-macos-fixtures (22)','graph-macos-fixtures (24)','graph-runtime-matrix (20.6.0)','graph-runtime-matrix (22.23.1)']:
 c=[x for x in p['statusCheckRollup'] if x['name']==name];assert len(c)==1 and c[0]['conclusion']=='SUCCESS' and c[0]['status']=='COMPLETED'
part=next(x for x in d['handoff']['successor_deliveries'] if x['pr']==279)
part.update(state='merged',merge_sha=BASE,head_sha=p['headRefOid'])
part['previous_observation']={**record(prev),'scope':'Immutable pre-merge observation; original tested base remains ede5aadc.'}
code=part['code_sha'];head=part['head_sha'];git('merge-base','--is-ancestor',code,head)
paths=git('diff','--name-only',code,head).decode().splitlines();assert all(x.startswith(('docs/','.changeset/')) for x in paths)
diff=git('diff','--no-ext-diff','--no-renames',code,head);f=E/'terminal-code-to-merged-head.diff';f.write_bytes(diff)
part['code_head_proof']={'code_sha':code,'head_sha':head,'changed_paths':paths,'diff_path':str(f.relative_to(D)),'diff_sha256':h(diff),'net_diff_empty':not diff}
part['merge_readiness']={'ci':'passed_at_observation','approval':'APPROVED','mergeable':'MERGED','merge_state':'MERGED','observed_at':p['observed_at']}
part['merge_scope']='Merged terminal-fence slice only; historical tests retain code/base binding; no DEBT02 or milestone qualification.'
d['main_sha']=BASE;d['observed_at']=now();d['handoff']['successor_obligations']['279']='Merged; terminal-fence component closed. Cross-process DEBT02 remains separate.'
helper=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/session-debt-20261026/ledger.py');helperbytes=helper.read_bytes();assert h(helperbytes)=='b1449d7b95df5012c9889d4afb2517f42fc7dc72c125948ba1018fbc40379e1e'
ns={'__name__':'ledger_helper','__file__':str(helper)};exec(compile(helperbytes,str(helper),'exec'),ns);rpc=ns['rpc']
sock=Path('/tmp/osstack-debt-ledger.sock');st=sock.lstat();assert stat.S_ISSOCK(st.st_mode) and st.st_uid==os.getuid() and stat.S_IMODE(st.st_mode)==0o600
m=d['management'];m['board_snapshots']=[]
for board in ['joint-firstmate-pstack','firstmate-upgrade-roadmap','session-pilot-debt']:
 r=rpc('kanban.board',{'board':board,'include_archived':True});f=E/(board+'.json');write(f,r);m['board_snapshots'].append(record(f))
 if board=='session-pilot-debt': assert next(c for col in r['columns'] for c in col['cards'] if c['card_id']=='card_d1a582eb')['status']=='done'
m['snapshot']=m['board_snapshots'][0]['path'];m['snapshot_sha256']=m['board_snapshots'][0]['sha256']
config=Path('/Users/osborn/.codex/automations/osstack/automation.toml');cfg=tomllib.loads(config.read_text());assert cfg['id']=='osstack' and cfg['status']=='ACTIVE'
write(S/'automation-receipt.json',{'base_sha':BASE,'observed_at':now(),'config_sha256':h(config.read_bytes()),'tool_result':json.loads((S/'automation-tool-result.json').read_text()),'config':cfg,'scope':'owner-observed persisted config, not scheduler execution proof'})
write(S/'board-final-receipts.json',{'base_sha':BASE,'observed_at':now(),'board_snapshots':m['board_snapshots'],'scope':'read-only post-closeout observations; no whole milestone completion'})
m['receipts']=[]
for name in ['subagent-dispatch-receipts.json','terminal-preflight-receipt.json','board-final-receipts.json','automation-receipt.json']:
 f=E/name;shutil.copyfile(S/name,f);m['receipts'].append(record(f))
f=E/'ledger-rpc-helper.py';f.write_bytes(helperbytes);m['rpc_helper']={**record(f),'socket':str(sock),'scope':'pinned helper bytes and observed socket; no development CLI/default DB'}
m['socket_observation']={'uid':st.st_uid,'mode':oct(stat.S_IMODE(st.st_mode)),'observed_at':now()}
m['heartbeat'].update(base_sha=BASE,updated_at=cfg['updated_at'],observed_at=now(),config_sha256=h(config.read_bytes()),queue='N0 gate layers and JP-17a offline broker fixtures; no runtime qualification')
m['evidence_scope']='Post-#279 merge checkpoint. Prior test/audit inputs remain pinned to their original code/base. Fresh three-board snapshots and bounded closeout receipts.'
d['next_batch']={'id':'joint-nextwave-20261028','base_sha':BASE,'runtime_enabled':False,'workers':[{'agent':'loader_adversarial','scope':'N0 gate-layer design and validator; preserves JA01/JA02/legacy/release','branch':'codex/joint-gate-layers'},{'agent':'terminal_preflight','scope':'JP-17a offline broker SQL/held-orphan candidate only','branch':'codex/joint-broker-spec'},{'agent':'cleanup_regression','scope':'independent frozen counterexamples and candidate verification; scratch only'}],'shared_owner':'root: execution ledger, execution.md, project-operations.md and PR publishing','full_regression_queue':'root single queue','qualification':'all new gates specified_not_run; broker deployment not qualified'}
d['observation_window']={'started_at':start,'finished_at':now(),'scope':'Sequential live forge/board observations; no atomic cross-service snapshot claim.'}
assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
assert (D/'execution-ledger.json').read_bytes()==old
write(E/'observation.json',{'main_sha':BASE,'prs':d['prs'],'window':d['observation_window']})
tmp=D/'execution-ledger.json.tmp';write(tmp,d);tmp.replace(D/'execution-ledger.json')
write(S/'closeout-result.json',{'evidence':str(E),'base':BASE,'ledger_sha256':h((D/'execution-ledger.json').read_bytes())})
print(E)
