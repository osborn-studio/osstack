VERDICT: PASS

This is a static review of the supplied diff and context only. I executed nothing and did not infer that the full suite passes. I found no confirmed P0, P1 or P2 issues.

## Claims checked against code

1. **Start rejects an exhausted stream with no completed terminal.** Confirmed at `daemon.ts:663-669`. `terminalCompleted` is set only by a completed terminal, and the throw precedes `settled = true`. The `finally` at `722-725` then aborts and calls `confirmAdapterStopped`. It releases only on confirmation and otherwise calls `retain`.
2. **Send sets `settled` only after verification.** Confirmed at `1043-1049`. The failed-terminal return (`1009-1015`), the no-terminal return, the native-id mismatch and metadata-leak returns, and the `catch` all leave `settled` false. The `finally` at `1097-1100` therefore requests stop confirmation.
3. **Completed-then-failed or completed-then-throw fails and requests stop confirmation.** Confirmed on both routes.
   - Start: the late failed terminal throws at `664`, and a late iterator throw lands in `catch`.
   - Send: the failed terminal returns before `settled`, and a late iterator throw lands in the `catch` at `1050`.
   - In every case `settled` is still false.
4. **Normal completion releases without a stop verifier.** Confirmed. `settled` is true and the signal is not aborted, so `lease.release()` runs directly.
   - The built-in Codex adapter has no `confirmStopped`, so `confirmAdapterStopped` returns false (`adapter-lifecycle.ts`).
   - Any abnormal Codex exit emits a failed terminal and so retains admission. That is the intended fail-closed behaviour and predates this PR.
   - Codex emits its completed terminal only after `await closed` (`codex-cli.ts:483-505`), so for the shipped adapter a completed terminal does follow process exit.
5. **Persistence, replay and cleanup separation are intact.**
   - The failure-state write is unchanged, and cleanup failure still goes only to the diagnostic path (`reportSessionCleanupFailure`).
   - Replay returns before any adapter call (`552-567`, `791-832`).
   - The diff adds no schema, recovery or verifier authority. The verifier stays adapter-owned and is never fed by worker input.
6. **Start `settled = true` before the native-id check (`670-671`).** This is a deliberate separation of invocation from result, and it is documented in the changeset. The completed terminal plus normal exhaustion is the trusted proof of invocation end. The new test covers it, asserting `stopChecks` is empty, cleanup is 1, state is failed with a null native id, and drain is clear.
7. **Native-id uniqueness (prior finding 3).** I agree with the rejection: the schema context states there is no UNIQUE constraint, so the Codex start fixture reusing `private-native` is not a collision.

## Inherited limitations and non-blocking notes (not regressions)

- **Completed terminal as proof of exit.** Treating a completed terminal as proof of exit for adapters other than Codex trusts the adapter. This matches the PR's stated trust model, and live provider stop behaviour is explicitly unqualified.
- **Post-`settled` failures release without stop proof.**
  - Start: the native-id check and the DB transaction.
  - Send: the `completeInboundTurn` transaction, where the `catch` marks the message failed, `started` is true, and `settled` is true.
  - This matches the documented model and the new missing-native-id test, but send has no equivalent regression test, for example a trigger on `session_turns`.
- **Cancel or drain after completion.** If the signal is aborted after `settled` (for example by drain), the `controller.signal.aborted` clause still routes to stop confirmation, and Codex would retain. This is inherited, and no test covers it.
- **Events after a completed terminal.** Non-failing events after the completed terminal, such as a second completed terminal or extra messages, are accepted on both routes. This is harmless but untested.
- **Fixture cleanup.** `releaseFixtures` calls the original `lock.release()` in `afterEach` even after the wrapper already released it in the `failCleanup: false` cases. This passes only if the lock's release is idempotent. I could not verify that from the supplied text. The host reports the Codex cases passing, so I treat it as a test-hygiene note.
- **Restart tests.** They are same-process only and do not qualify cross-process retained holds. The PR already states that DEBT02/J12 own this.
- **Start replay.** Replay returning `ok: true` for a failed snapshot is inherited and documented.

I accept all six host dispositions.

END_AUDIT