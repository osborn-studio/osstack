VERDICT: PASS

Static review of the supplied diff and context only. I executed nothing, and I did not infer that the full suite passes. No P0 or P1 findings.

## Claims checked against code

- **Start rejects exhausted streams without a completed terminal.** Confirmed at `daemon.ts:663-669`. `terminalCompleted` is set only for a completed terminal, and the throw comes before `settled = true`. The `finally` at `daemon.ts:722-725` then aborts, calls `confirmAdapterStopped`, and either releases or calls `retain`.
- **Send sets `settled` only after verification.** Confirmed at `daemon.ts:1043-1049`. The no-terminal return and the failed-terminal return at `1009-1015` both leave `settled` false, so the `finally` at `1097-1100` requests stop confirmation.
- **Completed-then-failed or completed-then-throw fails and requests stop confirmation.** Confirmed on both paths.
  - Start: the failed terminal throws at `664`, and a loop throw goes to `catch`. `settled` stays false in both cases.
  - Send: a failed terminal returns from inside the `try`, and a loop throw goes to `catch`. `settled` stays false in both cases.
- **Normal completion releases without a stop verifier.** Confirmed, since `settled` is true, the signal is not aborted, and `lease.release()` runs directly. Codex has no `confirmStopped`, so `confirmAdapterStopped` returns false. That is the intended fail-closed behaviour for any abnormal Codex exit, and it predates this PR.
- **Persistence, replay and cleanup separation are intact.** The failure-state write is untouched, and the cleanup `catch` still only reports a diagnostic. Replay goes through the existing-session and existing-message paths without invoking the adapter.
- **Scope.** The diff touches no schema, recovery path or verifier authority. The verifier stays adapter-owned (`confirmAdapterStopped(adapter, runId)`) and is never fed by worker input.

## P2 / test blind spots

1. **Start sets `settled = true` before the native-session-id check (`daemon.ts:670-671`).** If an adapter emits a completed terminal but no `native_session_id`, start throws after `settled`, so the lease is released with no stop proof. Send behaves the same way for post-`settled` failures such as a DB transaction error, so this is consistent with existing semantics and not a regression. The new tests never cover the case, and the changeset's wording is silent on it.
   - Minimal correction: either document that a completed terminal is trusted as proof of exit, or move `settled = true` below the native-id check.
   - Test to add: a completed terminal with no native id, asserting either `stopChecks` or release, whichever the maintainers choose.
2. **Vacuous assertion in the built-in Codex test.** `expect(adapter.stopChecks).toEqual([])` inspects the unused `ReceiptAdapter`, not the registered `CodexCliAdapter`. The `"confirmStopped" in registered` check and `cleanupAttempts === 1` carry the real weight. Drop the assertion or replace it with one tied to the registered adapter.
3. **Possible native-id collision in the Codex start test.** The fake binary emits `thread_id: "private-native"`, the same value the seeded `session` row uses. If `agent_sessions.native_session_id` has a uniqueness constraint, the Codex start case would fail at `recordNativeSession`. I could not verify this from the supplied text, so use a distinct id for the start route if the column is unique.
4. **Late-failure and no-terminal start tests skip some state checks.**
   - The `afterTerminal` cases for start and send check only the response, `stopChecks`, `cleanupAttempts` and drain. They do not assert session state, run outcome or kanban status.
   - The no-terminal start test checks session state, run outcome and turn count, but not the kanban card.
5. **Inherited behaviour that the tests normalise: start replay returns `ok: true` for a `failed` or `starting` snapshot.** This is documented in the changeset and is not a regression, but clients that check only `ok` can misread a failed start.
6. **Restart tests are not cross-process qualification.** The restart in the unconfirmed case reuses the same process and the same lock file. The in-memory quarantine lost on a real process restart is exactly the DEBT02/J12 scope, as the PR states.

END_AUDIT