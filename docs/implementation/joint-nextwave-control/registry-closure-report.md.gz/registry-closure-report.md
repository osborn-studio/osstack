**Audit of a679485f: schema_spec_digest catalog correction**

**Scope:** I audited only the supplied diff and file excerpts. The working directory isn't a git repository, so I couldn't inspect the commit, `reference-vectors.json`, `joint-reference-vectors.py` or the manifest directly.

**Confirmed**
- **Code includes both digests.** `schemaSpecDigest` in `packages/protocol/src/joint-lifecycle.ts` hashes `source_schema_digest` and `target_schema_digest` under `osstack.joint.schema-spec.v1`. `MigrationSpec` requires both as strict `Digest` fields, so parsing fails if either is absent.
- **Registry now matches.** The catalog `input` for `schema_spec_digest` now lists the same fields as the code: `schema_change_id`, source/target schema numbers, `ddl_digest`, `fixture_digest`, `source_schema_digest`, `target_schema_digest`, and sorted expected lineage tables. The "no future receipt" exclusion still agrees with the code, which hashes only those fields.
- **Prose agrees.** `operator-recovery-schema.md` already says the digest covers "the source/target schema catalog digests", which matches both the code and the corrected catalog line.
- **No runtime change.** The diff touches one string value in `digest-catalog.json`. The domain string, algorithm and field order in code are untouched.

**Blocking issues:** None confirmed.

**Optional suggestions**
1. I couldn't see whether the `schemaSpecDigest` vector in `reference-vectors.json` and the independent Python script include both catalog digests. The doc says they are regenerated from `manifest.spec`. Run `joint-reference-vectors.py --check` as a final confirmation.
2. Consider a small test that compares the field names in the catalog `input` text against `MigrationSpec` keys. That would catch this kind of drift mechanically.
3. In `OracleLifecycle.superRefine`, `v.status === 'executed' &&` is redundant inside an `if (v.status === 'executed')` block. It's harmless and unrelated to this change.

VERDICT: PASS
END_AUDIT