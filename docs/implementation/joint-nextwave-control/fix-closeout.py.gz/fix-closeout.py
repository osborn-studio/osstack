from pathlib import Path
import json,subprocess,hashlib,datetime
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-nextwave-control');s=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-nextwave-20261028/control');dpath=w/'docs/design/2026-10-27-joint-engineering/execution-ledger.json';d=json.loads(dpath.read_text());e=Path(json.loads((s/'closeout-result.json').read_text())['evidence'])
def git(*args):return subprocess.check_output(['git',*args],cwd=w).decode().strip()
part=next(x for x in d['handoff']['successor_deliveries'] if x['pr']==279);p=next(x for x in d['prs'] if x['number']==279)
part['merge_readiness']['mergeable']=p['mergeable'];part['merge_readiness']['merge_state']=p['mergeStateStatus'];part['merge_readiness']['approval']=p['reviewDecision']
base=d['main_sha'];head=part['head_sha'];code=part['code_sha']
git('merge-base','--is-ancestor',head,base)
parents=git('show','-s','--format=%P',base).split();assert parents==[part['base_sha'],head]
base_tree=git('rev-parse',base+'^{tree}');head_tree=git('rev-parse',head+'^{tree}');assert base_tree==head_tree
paths=git('diff','--no-renames','--name-only',code,head).splitlines();assert paths==part['code_head_proof']['changed_paths'];assert all(p.startswith(('docs/','.changeset/')) for p in paths)
proof={'merge_sha':base,'parents':parents,'head_sha':head,'merge_tree':base_tree,'head_tree':head_tree,'equal_trees':True,'head_is_ancestor_of_merge':True,'no_rename_paths_match_recorded':True,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'actual local Git object checks; does not claim tests re-executed on merge'}
f=e/'merge-content-proof.json';f.write_text(json.dumps(proof,indent=2)+'\n');part['merge_content_proof']={'path':str(f.relative_to(dpath.parent)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
dpath.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(s/'control-audit-dispositions.json').write_text(json.dumps({'P2-1':'Confirmed. Copied actual GitHub mergeable/mergeStateStatus/reviewDecision; MERGED only belongs to state.','P2-2':'Confirmed missing check. Actual object check: PR head ancestor, exact [ede5,3a5841] parents, merge tree equals PR head; proof archived and hash-bound.','P2-3':'Confirmed generic guard weakness; actual no-renames paths exactly equal already recorded paths. No hidden runtime change in this candidate. One-off historical collector kept immutable; correction script and Git proof retained.','scope':'Retained all original audit opinions; no synthetic audit pass.'},indent=2)+'\n')
print(json.dumps(proof,indent=2))
