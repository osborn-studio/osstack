from pathlib import Path
import subprocess,json,os,datetime,hashlib
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-nextwave-control');s=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-nextwave-20261028/control')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack';env['OSSTACK_HOME']=str(s/'test-home');env.pop('OSSTACK_SOCKET',None)
subprocess.run(['node','--input-type=module','-e',"const m=await import('./packages/knowledge/dist/index.js');if(typeof m.executionContextDigest!=='function'||typeof m.assembleExecutionContext!=='function')process.exit(1)"],cwd=w,env=env,check=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (s/'test-full-final.log').open('w') as out:p=subprocess.run(['pnpm','test'],cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
r={'candidate_sha':sha,'command':['pnpm','test'],'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'log':'test-full-final.log','log_sha256':hashlib.sha256((s/'test-full-final.log').read_bytes()).hexdigest()};(s/'full-validation-final.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(p.returncode)
