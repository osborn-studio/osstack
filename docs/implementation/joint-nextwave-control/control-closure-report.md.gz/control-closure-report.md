# Audit: #279 closeout and next-batch dispatch (re-audit after corrections)

I audited only the supplied text. I ran nothing and did not recompute any hash.

## Confirmed blocking findings

**P0: none. P1: none. P2: none.**

## Prior P2s: resolved in the resulting ledger

- **P2-1 (synthetic merge fields):**
  - The delta shows `mergeable: UNKNOWN`, `merge_state: UNKNOWN` and `approval: APPROVED`.
  - These now match the raw PR record. `MERGED` appears only in `state`.
- **P2-2 (tested code bound to main):**
  - `merge-content-proof.json` shows parents exactly `[ede5aadc, 3a5841eb]`.
  - It shows the merge tree and head tree both equal to `307218fd…`, and the head as an ancestor of the merge.
  - The proof is hash-bound in `merge_content_proof`, and its scope states that tests were not re-executed.
  - `execution.md` ("通过 GitHub 和 Git 对象核实") is now backed by that proof.
  - Resulting binding: main's tree equals the PR head's tree. The head equals `cb76` plus a docs/`.changeset` delta. The 6293/5/0 run and the Sonnet audit stay bound to `cb76` and `ede5aadc`.
- **P2-3 (rename-blind guard):**
  - The correction script re-ran `--no-renames --name-only` and asserted equality with the recorded `changed_paths`.
  - It also asserted the `docs/` and `.changeset/` prefix rule on that list.
  - `no_rename_paths_match_recorded: true` is recorded in the proof.
  - Leaving the one-off historical collector unchanged is acceptable, as you stated.

## Re-verified sound

- **Merge and CI binding:**
  - The ledger asserts `state=MERGED`, `mergeCommit=d3fa7ef` and `headRefOid=3a5841eb`.
  - The five required checks are each SUCCESS and COMPLETED, and the skipped paid DeepSeek smoke is not counted.
- **Ledger preservation:**
  - The pre-collector ledger is saved as `ledger-before-e4ade…` and appended to `checkpoint_history`.
  - The `previous_delivery` pointer to `acb1331…` is retained.
  - The old 279 "ready at 3202b790" state exists only in the preserved files. That is correct historical handling.
- **Current vs historical:**
  - `base_sha=ede5aadc` and `code_sha=cb76` sit beside the new `merge_sha` and `head_sha`.
  - `merge_scope` and the `execution.md` section disclaim re-execution on the new main.
  - The observation window disclaims atomic cross-service snapshots, and `execution.md` says the old local checkout is not authoritative.
- **No false qualification:**
  - `runtime_enabled` is false in the ledger and in `next_batch`.
  - All new gates are `specified_not_run`, and the broker is "not qualified".
  - The `card_d1a582eb` comment limits closure to the terminal fence.
  - DEBT02, J01/J11/J12 and the milestone are not closed.
  - The heartbeat remains owner-observed config, not scheduler proof.
  - Per your statement, the new candidates have independent future audits.
- **Worker scope:** Branches and the root-owned ledger, PR and regression queue are consistent across the ledger, `project-operations.md` and the dispatch comments 344 and 345. The scratch-only role is stated for `cleanup_regression`.

## Optional future suggestions (not blocking)

- **Correction provenance:**
  - The correction script and `control-audit-dispositions.json` live only in the scratch directory.
  - The collector-output ledger hash is in scratch `closeout-result.json`.
  - Copy these into the evidence directory with hashes, so the in-place correction is reproducible from the repo.
  - The script's final `dpath.write_text` was not atomic, unlike the collector's. This is harmless for a one-off.
- **Concrete worker paths:**
  - Exclusive write paths are given as prose ("相关规范", "专属测试").
  - Add explicit path globs per worker, and put the root branch `codex/joint-nextwave-control` into `next_batch`.
  - Dispatch comment 344 omits "legacy" from the preserved obligations, which the ledger and `project-operations.md` include.
- **Naming:** `terminal-preflight-receipt.json` covers the terminal closeout, while `terminal_preflight` is also the broker worker's name. This could confuse a reader.
- **Carried over from the prior audit:**
  - Give `cleanup_regression` its own card or receipt, and add card and comment IDs to `next_batch.workers`.
  - Read the automation config once and reuse the bytes.
  - Derive the required checks from branch protection, and confirm the approval applies to the final head.
  - Mark the older "待用户审批合并" paragraph in `execution.md` as historical.
  - Assert that the new cards exist in the board snapshots.

VERDICT: PASS
END_AUDIT