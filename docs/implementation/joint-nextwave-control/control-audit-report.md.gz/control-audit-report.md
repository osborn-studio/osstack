# Audit: #279 closeout and next-batch dispatch

This audit covers only the supplied text. I did not open the diff file or the evidence files, and I ran nothing.

## Confirmed blocking findings

**P0: none. P1: none.**

**P2-1: `merge_readiness` has synthetic values in GitHub-style fields.**
- The ledger sets `mergeable: "MERGED"` and `merge_state: "MERGED"`.
- The raw observation stored in the same ledger has `mergeable: UNKNOWN` and `mergeStateStatus: UNKNOWN`.
- `MERGED` is not a valid value for either GitHub field, and it contradicts the raw record.
- Fix: copy the raw values, or use an explicit label such as `"n/a_after_merge"`. Keep `state: MERGED` as the merge indicator.

**P2-2: "Verified via Git objects" is overstated, and the tested-code-to-main binding is unchecked.**
- The collector verified three things:
  - GitHub's `mergeCommit` equals BASE.
  - The remote `main` tip equals BASE, both before and after.
  - `cb76` is an ancestor of the PR head.
- It never verified that BASE contains the PR content.
  - It did not check that BASE's parent is `ede5aadc`.
  - It did not check tree equality or ancestry between BASE and `3a5841eb`.
- `execution.md` says the merge was confirmed "通过 GitHub 和 Git 对象核实".
- Fix, in either of two ways:
  - Run `git rev-parse d3fa7ef^ d3fa7ef^{tree} 3a5841eb^{tree}`, or `git merge-base --is-ancestor 3a5841eb d3fa7ef`, and record the result in the proof.
  - Reword the prose to "GitHub 报告，远端 main tip 一致".

**P2-3: the docs-only guard is rename-blind.**
- The guard is `git diff --name-only code head` followed by a prefix check.
- That command applies default rename detection, so a move from a code path into `docs/` lists only the destination.
- The recorded `changed_paths` can therefore hide a deletion outside `docs/` or `.changeset/`. The full diff was taken with `--no-renames`, so the two views can disagree.
- Impact is unconfirmed, because the diff content was not supplied.
- Fix: run `git diff --name-only --no-renames cb76… 3a5841eb…`, compare it with the recorded `changed_paths`, and assert the prefix rule on that list. If the lists match, change nothing except a note.

## Verified sound

- **Merge and CI binding:**
  - `state=MERGED`, `mergeCommit=BASE` and `headRefOid=3a5841eb` are asserted.
  - Each of the five required checks is asserted exactly once as SUCCESS and COMPLETED.
  - The skipped paid DeepSeek smoke is explicitly not counted as a pass.
- **Ledger preservation:**
  - The old bytes are copied into a hash-named file and appended to `checkpoint_history`.
  - Bytes are re-verified before replacement, and the replacement is atomic.
  - The earlier pointer chain (`e4ade…` to `acb1331…`) is retained through `previous_observation` and `previous_delivery`.
- **Current vs historical snapshots:**
  - `base_sha=ede5aadc` and `code_sha=cb76` stay on the 279 entry beside the new `merge_sha`.
  - `merge_scope` and the new `execution.md` section state that 6293/5/0 and the Sonnet audit are not re-run on the new main.
  - The observation window disclaims an atomic cross-service snapshot.
- **No false qualification:**
  - `runtime_enabled` is false.
  - All new gates are `specified_not_run`, and the broker is "not qualified".
  - DEBT02, J01/J11/J12 and the milestone are explicitly not closed.
  - The heartbeat is labelled owner-observed config, not scheduler proof.
- **Worker scope:**
  - Branches, exclusive paths and root ownership of the ledger, PR and regression queue are consistent across the ledger, `project-operations.md` and the dispatch receipts.
  - JA01/JA02 and legacy/release obligations are preserved, and there are no overlapping write paths.

## Optional future suggestions (not blocking)

- `cleanup_regression` has no card or comment receipt of its own. It appears only inside the other two dispatch bodies. Add a card, or note this. Also put card and comment IDs into `next_batch.workers`.
- Read the automation config once and reuse the bytes. The ledger takes `updated_at` from an earlier read than `config_sha256`, which is a small race if the heartbeat rewrites its own config.
- Derive the "required checks" from branch protection rather than a hard-coded list, and confirm the approval applies to the final head.
- Mark the older `execution.md` paragraph ("待用户审批合并") as historical.
- Assert that the new-batch cards exist in the board snapshots.

## Correction path

P2-1 and P2-2 need a small edit to the candidate ledger and `execution.md`. P2-3 needs one verification command. The candidate is unpublished, so amending it in place is fine. Its pre-edit ledger already sits in `ledger-before-e4ade…`.

VERDICT: REVISE
END_AUDIT