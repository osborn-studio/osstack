# Verdict: REVISE

This is a static read of the supplied source only. I ran no exporter, tests or hosts. The one blocker is a small, mechanical attribution error. Everything else is optional.

## Confirmed blockers

**B1. `sources.md` says a source is "linked above" when it is not.**
- The new parallel-work paragraph credits "shared-state separation and actual-result verification from the principles linked above."
- Shared-state separation is linked above, in the architecture list. The actual-result principle, `principle-prove-it-works/SKILL.md`, is not linked anywhere in `sources.md`.
- The concise-report paragraph also names "Prove It Works" as plain text with no link.
- The link exists only inside `parallel-work.md`, so the provenance file cross-references something it doesn't contain.
- **Fix:** add the pinned `principle-prove-it-works` link in the parallel-work paragraph and the concise-report paragraph, or in the shared list. The URL is already in `parallel-work.md`.

## What I checked and found sound

- **Authority (NX01):**
  - The guide applies only to an authorized coordinator and uses only actual host tools.
  - A delegate gains no spawn right.
  - Direct work is allowed when delegation is unavailable.
  - Races, fixed models, retries and ledgers are explicitly not imported.
  - The agent paragraph and the guide agree with each other and with the mode router's thirteen-method statement.
- **Coverage and dropout (NX02):**
  - Each area has a deliverable, predicate, surface, prerequisites and owner.
  - A dropped lane stays a named gap with a next owner or trigger, and another worker's pass does not erase it.
  - The brief template stands without the parent chat.
- **Resources (NX03):**
  - The overlap list includes build outputs, fixtures, ports and branches.
  - "A promise in a brief is not a lock."
  - No second ledger is introduced.
- **Candidate and surface match (NX04):** completion messages are pointers, an older head or parser-only test cannot satisfy a CLI requirement, and a different model or chat is not independence.
- **Liveness and composition (NX05):**
  - A timeout does not establish that a process stopped.
  - Identifiers and obligations are kept, and a possibly live resource is not reassigned.
  - Green slices do not prove the combination, and affected checks are rerun on the composed artifact.
- **Brevity (NX06):** failed, blocked, unknown and not-run results stay visible, there is no universal cap, and the examples are labeled as not from a run.
- **Trigger rerun and fresh forge (NX07/08):**
  - The example keeps the plan as `not_run`.
  - It invents no SHA.
  - It binds the rerun to the resulting candidate and build.
  - After an authorized push it requires a fresh snapshot, including base.
  - Approval is not carried forward, and merge stays human-reserved.
- **Metadata-only commit (NX09):** the original execution binding is preserved and the old log is not relabeled.
- **Host claims (NX10):** no text claims a host improvement, and historical failures are explicitly unchanged.
- **Negative export (NX12):** the exporter test for a deleted linked guide depends on the agent link, which is present.

## Optional suggestions

1. **Reachability.**
   - The only inbound link to `parallel-work.md` is in `osstack-agent`, whose description targets delegates. The mode router, which is the coordinator's route, has no link.
   - The D2a graph test can pass transitively mode → agent → guide, and it accepts a path through a sibling entry's copy.
   - I can't confirm from supplied source that `osstack-help` and `setup-osstack` reach mode or agent, so the D2a run is the authority on that.
   - A coordinator-side link in the mode router's delegation sentence would fix discoverability, but that is a root-owned file outside slice A.
2. **Limit versus visibility.** `evidence.md` has two absolute rules, "check against the hard limit" and "keep failed/unknown visible", with no precedence. This is the 578>500 failure shape.
   - Suggested rule: compress structure first, never drop a failure or unknown classification, and if both can't fit, say so and point to the record.
   - Also say what to do when no real retained path exists: state that, and don't invent a link.
3. **Shared observation time.** `pr-readiness` says to state observation time once. If one PR's read failed or happened later, that would mask it. Say "once if identical, otherwise per row."
4. **"Compact report" versus user format.** `pr-readiness` still says "Return a compact report." Add "unless the user asks for more detail," or link to the new evidence section.
5. **Reuse condition.** "Record the comparison before reusing" doesn't say what happens if the comparison shows a relevant difference. Add "otherwise treat as `not_run`." Also clarify that "record the resulting candidate ID only when it exists" refers to the ID of the executed build, not the later source commit needed for the comparison.
6. **Dropout takeover.** Before reassigning a dropped worker's scope, inspect its uncommitted changes and owned resources. Today only the timeout paragraph says so.
7. **"Fourteenth" count.** "Fourteenth named method" in the agent entry adds another hard-coded count that will drift.
8. **Template overlap.** The two compact row templates, in `evidence.md` and `pr-readiness`, overlap and could drift.
9. **"Writing the reply section".** I can't verify this source claim, because the mode-router text wasn't supplied.

## Not established by this review

- NX11 needs an actual two-host export with hash, link and cross-host comparison. I only read the code.
- Nothing here shows that a host will follow the wording.
- The frozen criteria are not an authenticated gate.
- The prior Codex LIMITED and Claude FAILED 578>500 results are untouched.
- `EXPORT.md` and the source-root `SKILL.md` router weren't supplied, so I couldn't check whether they enumerate references or counts that the new guide affects.