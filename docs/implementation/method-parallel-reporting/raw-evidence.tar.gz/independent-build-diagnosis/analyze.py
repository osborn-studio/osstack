from pathlib import Path
import re,json,hashlib,datetime,subprocess,collections
p=Path(__file__).parent;r=p.parent;w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-post299-retarget');h=lambda b:hashlib.sha256(b).hexdigest()
for f in ['full.log','generated-dist.patch','rebuild-knowledge.log']:(p/f).write_bytes((r/f).read_bytes())
s=(p/'full.log').read_text();s=s[s.index('packages/cli test:  FAIL '):];blocks=[]
for b in re.split(r'packages/cli test: ⎯[^\n]*\[\d+/88\][^\n]*\n',s):
 titles=re.findall(r'packages/cli test:  FAIL  ([^\n]+)',b)
 if not titles:continue
 sig=[needle for needle in ["does not provide an export named 'assembleExecutionContext'",'executionContextDigest) is not a function','executionContextDigest is not a function'] if needle in b]
 blocks.append({'titles':titles,'test_count':len(titles),'classification':'explicit_missing_export_in_failure_block' if sig else 'indirect_failure_cause_not_proven_from_this_block','missing_export_signatures':sig,'raw_block_sha256':h(b.encode()),'raw_block':b})
assert len(blocks)==53 and sum(x['test_count'] for x in blocks)==88
(p/'failure-blocks.json').write_text(json.dumps(blocks,indent=2)+'\n')
files=['packages/knowledge/src/index.ts','packages/knowledge/src/context-budget.ts','packages/knowledge/dist/index.js','packages/knowledge/dist/index.d.ts','packages/knowledge/dist/index.js.map','packages/knowledge/dist/index.d.ts.map','packages/knowledge/dist/context-budget.js','packages/knowledge/package.json'];bindings=[]
for f in files:
 b=(w/f).read_bytes();name=f.replace('/','__');(p/name).write_bytes(b);bindings.append({'path':f,'bytes':len(b),'sha256':h(b),'copy':name})
src=(w/files[0]).read_text();dist=(w/'packages/knowledge/dist/index.js').read_text();impl=(w/'packages/knowledge/dist/context-budget.js').read_text()
for symbol in ['assembleExecutionContext','executionContextDigest']:
 assert symbol in src and re.search(r'export\s*\{[^}]*\b'+symbol+r'\b[^}]*\}\s*from\s*["\']./context-budget.js',dist,re.S)
 assert re.search(r'export (?:async )?function '+symbol+r'\b',impl)
old=subprocess.check_output(['git','show','45fe453ba09932dd5602d7da317844ff1750554b:packages/knowledge/dist/index.js'],cwd=w);(p/'tracked-old-index.js').write_bytes(old);assert b'assembleExecutionContext' not in old and b'executionContextDigest' not in old
patch=(p/'generated-dist.patch').read_text();assert '+export { assembleExecutionContext, executionContextDigest, ExecutionContextBudgetError } from "./context-budget.js";' in patch
counts=collections.Counter()
for b in blocks:counts[b['classification']]+=b['test_count']
report={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'failed_run_candidate':'45fe453ba09932dd5602d7da317844ff1750554b','cli_totals':{'failed':88,'passed':2677,'skipped':5},'failure_detail_blocks':53,'classification_counts':counts,'classification_scope':'All88 FAIL titles mapped once to their53 emitted diagnostic blocks; counts are tests, not repeated error lines.','build_evidence':{'tracked_old_index_lacks_both_exports':True,'saved_patch_adds_both_exports':True,'current_dist_reexports_match_src_names':True,'current_context_budget_dist_defines_both_functions':True,'current_file_bindings':bindings,'rebuild_log':(p/'rebuild-knowledge.log').read_text()},'conclusions':['The tracked index.js is stale against current source; restoring it removes exports required by CLI code. Saved generated-dist.patch records the missing re-export difference.','75 failed tests have an explicit missing-export signature in their shared diagnostic block.13 remaining tests show downstream state/exit/transport assertions without enough failure-block evidence to assign the same cause.','Current rebuilt dist statically contains and reexports both functions consistent with src. This is not an independent compiler reproduction or successful test rerun.','Root reports restoring4 tracked generated files after build; that operation timing is owner-reported, not directly reconstructed from this log. It is consistent with the preserved patch and import failures.','Keep initial failed full-suite record; later focused/full success must be separately SHA/build-bound, never overwrite the failure.'],'no_execution':'Read-only logs/source/dist, no product imports, models, full suites, rebuilds or repository changes by this reviewer.'};(p/'report.json').write_text(json.dumps(report,indent=2)+'\n');manifest={'members':[{'path':x.name,'bytes':x.stat().st_size,'sha256':h(x.read_bytes())} for x in sorted(p.iterdir()) if x.is_file() and x.name!='manifest.json']};(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'classification':counts,'report_sha256':h((p/'report.json').read_bytes()),'manifest_sha256':h((p/'manifest.json').read_bytes())},indent=2))
