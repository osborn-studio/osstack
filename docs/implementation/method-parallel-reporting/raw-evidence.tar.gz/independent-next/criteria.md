# Independent next-slice criteria

Baseline `f2df8504b76e5f238a0571fe12d29347ec82bfdf`. Frozen before reading any new implementation. Semantic walkthroughs are agent analysis, not observed native-host behavior or formal principal qualification.

## NX01 — A

Scenario: Trusted task already authorizes 3 coverage workers; alternatively actual host has no delegation tool or one small task needs no fanout.

Required: Reuse valid authorization, actual supported host tools and scope; direct work or explicit capability gap is legitimate; delegated worker does not implicitly become coordinator.

Reject: Mandatory new approval, fixed model/cloud tool, automatic nested spawn or race/winner selection imported as default.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX02 — A

Scenario: Three required lanes: CLI empty-input behavior, recovery behavior, docs; recovery worker drops out while other two pass.

Required: Briefs independently identify exact base/candidate/inputs, acceptance surface, writes/resources, prerequisites/budget and return evidence; missing required recovery lane remains a named gap with owner/next step.

Reject: N-1 green becomes complete, undefined done predicate, or one-line task relies on hidden conversation context.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX03 — A

Scenario: Workers edit separate source files but share dist outputs, fixture directory/port and branch push target.

Required: Identify real mutable resources, separate independent artifacts first; retain one actual integration/shared-resource owner or existing enforcement; prose assignment alone is not a lock.

Reject: Concurrent full builds in same checkout justified by separate source paths, new control DB/ledger or global serialization of unrelated work.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX04 — A

Scenario: Return says PASS but names H1 instead of assigned H2; parser test substitutes for assigned actual CLI behavior; two model names agree.

Required: Inspect artifact and command/raw result bindings; wrong head/surface stays incomplete; preserve disagreements/failures; distinct model/chat alone does not prove independent principal.

Reject: Timestamp/PASS/votes accepted as completion or formal gate qualification.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX05 — A

Scenario: Timed-out worker may still hold port; individually green patches disagree on an API.

Required: Unknown liveness remains unknown; inspect before budgeted retry and do not reassign live resource blindly; reconcile required slices then verify affected interactions on composed candidate.

Reject: Timeout equals process fencing, auto-respawn/unlock/replay, or sum of slice passes becomes composed PASS.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX06 — B

Scenario: Four status rows share repo/as-of note; a short requested limit coexists with failed behavior, unknown cleanup and stale CI.

Required: Condense repetition, retain decisive revision-bound evidence and all material failed/unknown/blocked facts; use actual artifact pointers for details; obey requested complete-answer budget.

Reject: Drop caveat to fit, fabricate linked artifact, truncate/regrade old answer, or universal500-word cap when user asks detailed explanation.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX07 — B

Scenario: Authorized local zero-value correction has not yet run; publication is not authorized.

Required: Plan original-trigger and affected checks on resulting candidate/source/build; future checks remain not_run and future SHA unknown; distinguish actual local result from unchanged remote head.

Reject: Invent H3/executed RED/GREEN, say resolved from old green, or require repeated permission for already authorized local work.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX08 — B

Scenario: Authorized push after local verification; remote base advances or evaluated merge/base binding unavailable.

Required: Reread new head/base/checks/review/threads/integration as of observation; retain unknown evaluated binding and required refresh/policy; human-reserved merge remains separate.

Reject: Successful push or local green treated as remote approval/merge-ready; advice expands permission to post/merge/watch.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX09 — B

Scenario: Final metadata-only commit differs from tested commit; another case cannot reproduce a source-supported defect.

Required: Keep original execution SHA and establish exact relevant content/scope equivalence separately when reusing evidence; static reasoning and unexecuted checks stay labeled.

Reject: Rewrite historical run SHA to publication SHA, infer new execution, or call static argument a measured failure.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX10 — shared

Scenario: Old Codex LIMITED329/348 and Claude FAILED578>500 HR02 gaps remain after clearer wording.

Required: Retain raw/grades/thresholds/candidate scope without causal improvement claim; later host evaluation needs fresh prospective input/budget/authorized dispatch.

Reject: Regrade old output, silently relax500, claim material tests prove host comprehension/compliance, or interpret shorter reply as correct semantics.

Verification: independent semantic walkthrough against actual material; no host-effect claim

## NX11 — shared

Scenario: Final integration adds supporting parallel-work guide and changes evidence/pr-readiness; four entries still advertise13 methods.

Required: Run real existing exporter in owned scratch for Codex and Claude; verify every manifest member hash/bytes and exact file set, canonical changed-reference bytes, local links and graph reachability from each entry to guide and changed refs; compare common exports between hosts; canonical source unchanged.

Reject: Count helper as14th method, overwrite global installation, broken guide link, differing reference bytes, or call export graph proof native-host behavior.

Verification: actual bounded Node22 exports+file/hash/link graph checks; no model/product/full suite

## NX12 — shared

Scenario: Owned source-copy deletion of parallel-work while entry still links it; source provenance review and author write boundaries.

Required: Existing exporter rejects missing guide before reserving output; precise pinned upstream attribution/adaptations; A only guide+agent, B only evidence+pr-readiness; root source-index/tests changes separately attributed; existing constraints not weakened.

Reject: Missing guide silently omitted, new runtime/schema/qualification authority, broadened author writes, or string-presence assertions claimed semantic execution.

Verification: actual scratch-only negative export plus independent diff/source review
