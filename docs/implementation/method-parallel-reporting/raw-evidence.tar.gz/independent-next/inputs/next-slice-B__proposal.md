# Proposed next slice: concise results that keep verification bound to the change

Status: read-only proposal for root authorization. No source, score, threshold, host input or runtime changed. No new model call. Baseline inspection uses actual fetched main `7d3fc2bfc39cbb8afc382973cc17be4c60a29f70` and the PR-readiness source candidate `95a33e371464fe48bf063afe17ed650852e925d5`; the latter is a candidate, not silently treated as merged main.

## Why this is useful

The latest four-case probe used real Codex/Claude CLI consumption of a synthetic status fixture. Claude's578-word final violated its500-word hard cap. Codex's329-word answer met it. Independent HR02 also retained a narrower gap: both planned B's correction without explicit new-candidate verification binding; Claude additionally omitted an explicit same-trigger rerun. These facts do not establish that the method text caused the behavior. The method already requires that binding. A clearer output shape is a bounded improvement hypothesis, not proof of improved host efficacy.

The earlier task-framing probe produced439 Claude words but had comparison/deliverable limitations. Reducing word count alone therefore is insufficient. Keep the decision and its evidence in the brief response; move duplicate context and detailed logs into the existing artifact record. Do not drop failed attempts, unresolved approval or unknown cleanup to meet a cap.

The four entries route into13 methods. Mode and agent already consume evidence.md; the methods already prescribe method-specific deliverables. A second reporting method, new entry, new CLI or mandatory new document would duplicate that structure. The current evidence record has many fields useful for an artifact, but does not plainly separate that durable record from the short user-facing report. PR-readiness lists what to report but lacks a compact row and a follow-up-check phrasing example.

## Smallest proposed product diff

Only two existing references:

1. `osstack-methods-skill/references/evidence.md`: add a short section separating the concise user-facing result from the detailed retained record. Honor a requested format/length; otherwise state outcome, concrete support tied to the observed revision, and the next action/owner or remaining limit. For several items, use one row/item and a common scope note once. Before sending, remove repeated facts and ensure the shortened answer still names failed/unknown/blocked observations. Respect any explicit hard limit across the complete answer. Do not install an unconditional500-word product default or claim wording can guarantee model compliance.
2. `osstack-methods-skill/references/pr-readiness.md`: add one compact row template at the report section, and a compact correction-plan example. The example must retain “fix within existing authority → recheck the original trigger on the new candidate and record its identity/result → if publication is authorized, reread remote head/base/checks/review/integration; otherwise report local result separately.” Keep a planned result as not_run; never fill a future SHA or report a resolved finding before evidence exists. An unknown evaluated base stays unknown. As-of head/base/time and human-only merge should be shared scope notes, not repeated under each bullet.

Proposed row shape (guidance, not a parser/schema):

`Item / observed head+base / status and decisive evidence / next action + owner + verification target / remaining limit or artifact`

Optional compact B teaching example, explicitly synthetic and unexecuted:

“B is blocked at H2: the unit log and patch support zero→default. Maintainer plans the authorized correction, then reruns the zero trigger and affected tests on H3, recording H3/build and outcomes. H3 is a future identifier, not a completed fix. Remote state remains H2 until an authorized publication and fresh forge observation.”

The exact wording should avoid presenting H3 as a real preselected commit. A production example can instead say “the resulting candidate” to prevent that confusion.

## Source adaptations and exclusions

At pstack pin `99b609a72323b70204eab407c622f436e858e112`, poteto-mode's Writing the reply explicitly combines short sentences with retaining the playbook's content, consumer impact and evidence/labels alongside claims. Opening a PR describes a one-minute briefing and sends detailed verification to a linked artifact. Prove It Works requires actual artifact checks and retained reproducible outputs; Sequence verifiable units brackets the change with checks; Babysit rereads status after a push and rejects untrusted comments as authority. These are the source-backed practices to adapt.

Do not import pstack's punctuation bans, fixed model choices, auto-Ready, automatic PR creation, reset/rebase rules or implied polling. Its guard-context principle supports scope control, not a new universal word count. Precise SHA/known source ranges are in test-contract.json. Add/update source attribution only if root separately grants that shared-file write; references already link the existing attribution file.

## Verification and division of ownership

Root can authorize this as a two-reference documentation slice. A owns its separate method/source work; B does not write root SKILL, four entries, EXPORT, package, CI, ledger or routes. Root owns any final source-index integration and existing exporter test changes. No write begins from this proposal alone.

Verify two kinds of claims separately. Actual export/link tests can prove both hosts receive exact changed reference bytes and all four entry paths remain reachable. A small reviewed positive/negative text matrix can check the instructions retain all required facts under a compact format. That matrix is author-generated teaching data, not model performance evidence. Existing export tests should be used rather than inventing a general report validator. Static source/word checks do not prove comprehension or future hard-limit compliance.

Any later host effect test must be a new prospectively frozen experiment, independently scored with one bounded call per host only when root explicitly dispatches. Do not rerun the old four cases to rewrite the earlier failures or raise500. This small material change can ship honestly as clearer guidance before such evidence, with no claim of measured improvement.
