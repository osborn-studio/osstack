# Next slice: coverage delegation and verification handoff

Recommendation: add a small coordinator-facing `parallel-work.md` supporting guide, linked from the existing `osstack-agent` entry. This is a gap inside delegated work, not a duplicate of the thirteen implemented methods. It is also not an orchestration runtime or a fourteenth advertised top-level method yet.

Baseline facts: main `7d3fc2bfc39cbb8afc382973cc17be4c60a29f70` has merged #299. The thirteen-method reference inspected here is pending #300 at `0e5d2c9800ddc657c11580a5e80ff4d7ea342bf7`; root is still handling retarget/revalidation. Recheck the chosen base at implementation dispatch. Exact source/candidate hashes are in source-map.json.

## Why this slice has value

The user priority list asks for swarm coverage, one coordinating entry and separate engineering/verification work. Today `osstack-agent` tells an already assigned worker how to act; feature step3 already requires exclusive slices and shared-state ownership. Code-review handles finding quality; session-continuity handles resumption and live ownership. Repeating those instructions adds little.

The missing thin layer is a concrete coordinator sequence: declare which required coverage each worker owns, provide complete input/candidate and verification expectations, prevent resource collisions, account for every returned/blocked/missing slice, and decide what composed verification remains before integrating. A required lane that drops out cannot silently disappear when another lane passes. A result for another head or a parser-only test cannot satisfy the assigned CLI predicate. Separate outputs avoid unnecessary shared writes; ownership prose does not enforce a lock.

## Original sources and extraction

At pstack `99b609a72323b70204eab407c622f436e858e112`:

- `pstack/skills/swarm/SKILL.md`: use the coverage-partition shape, standalone brief, exact SHA/method and explicit gaps. Defer competing solution races and winner selection to a later dedicated slice. Do not copy default Grok/Cursor cloud settings, mandatory spawning or automatic respawn.
- `pstack/skills/poteto-mode/playbooks/orchestrate.md`: reuse one integration owner, dependency context relay, bounded active work, per-result accounting and risk-scaled verification. Do not install orch, a parallel ledger, standing watchers, automatic merge, a compulsory no-code coordinator or nested agents.
- `pstack/skills/principle-separate-before-serializing-shared-state/SKILL.md`: enumerate real shared files/branches/fixtures/ports/build outputs, separate them first, leave necessary shared mutation to the actual existing owner/mechanism.
- `pstack/skills/principle-prove-it-works/SKILL.md`: verify the returned actual artifact, not a PASS word or fresh timestamp.

Preserve source attribution inline in the new guide, with fixed URLs and the MIT copyright holder. The joint map associates coverage parallelism with PS05/J17/J18 and independent review with PS06. This guide implements none of their admission/runtime/principal gates.

## Exactly two author files

1. New `osstack-methods-skill/references/parallel-work.md`: a concise reusable procedure and compact brief/result example.
2. `osstack-methods-skill/entries/osstack-agent/SKILL.md`: one link that explicitly distinguishes coordinator planning from the already-delegated worker wrapper. No implicit role switch or permission to spawn.

The existing source→mode→agent navigation makes the guide reachable. The exporter automatically copies every shared reference into each of four bundles. Keep the thirteen named-method count and existing selector descriptions honest: this author slice is a supporting guide, not a newly advertised method selector. If root wants a fully routed fourteenth method, it must separately assign the shared root/mode/help/setup/source/EXPORT/test metadata work; do not hide that larger change inside this two-file boundary.

No runtime, CLI, CI/package, central ledger, production exporter, existing method bodies or shared tests are edited by this author. Evidence and independent probes stay in owned scratch. This avoids conflicts while root closes #300 and future host work reads fixed source objects.

## Minimum usable content

- Start with trusted task scope and actual host/delegation availability. Existing authorization remains valid; unavailable tools are a capability gap, not an invented native agent or model. If one worker suffices, do it directly.
- Define required slices and acceptance surfaces before dispatch. A short brief names goal, exact inputs/base/candidate, allowed writes/resources, prerequisites, expected checks, time/resource budget and result fields. Do not copy secrets or require a ceremony for a one-command task.
- Assign distinct artifacts and resources. Keep shared build outputs, worktree/branch mutation and final integration under one owner where necessary. Do not run full builds in parallel against a shared mutable checkout.
- Keep verifier expectations independent of the submitted result where practical. A different chat/model is not authenticated independence; disclose reused expectations and unavailable identity. Reserve formal qualification for actual existing contracts.
- Collect each slice's actual candidate, output hashes, raw checks, failures/limits and resource state. Stale or incomplete returns retain an explicit gap; inspect before any retry and respect the real remaining budget. A timed-out worker is not proved stopped, so do not give its live resource to a replacement blindly.
- Reconcile all required coverage, resolve review disagreements by evidence, and recheck interactions on the composed candidate. Individual green results are not a composed pass. Root keeps publication/human-merge authority and one authoritative task record.

## Future executable acceptance

Before implementation, C freezes independent cases. Afterward, use Node22 existing real exporter on both layouts, verify per-member bytes/hashes, all four entries' path to the guide, local link targets and unchanged canonical sources. Remove the new guide only in an owned scratch source copy and observe failure before output creation. Reuse the existing exporter suite; do not introduce a schema validator or phrase-presence tests that pretend prose is runtime enforcement.

Independent static scenarios should cover shared-path/port collisions, stale-head return, missing required lane, wrong verification surface, already-authorized delegation, unavailable actual tools, timeout-with-unknown-liveness, and individually green but incompatible outputs. Clearly label these walkthroughs as such. A later actual delegate experiment can establish observed briefing/result use only after separate authorization and frozen input/budget; it is not included here. No models or test suites were run by this preflight.

## Decision requested from root

Approve the two-file supporting-guide boundary or explicitly expand to a fully routed fourteenth method. Confirm the actual implementation base after #300 changes. Then request independent prefreeze. This document is scheduling input only and does not itself authorize implementation, prove acceptance or lower any frozen gate.
