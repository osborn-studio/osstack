# PR300 CI repair archive check

Archive integrity passes: all 45 members match the manifest by exact name set, byte length and SHA-256. No duplicate, link or unsafe path members were found. Archive SHA-256: `71b630b7cd9cf3299d8e17d9b41630b8e78b776d4e927dfa59579d16f7189582`.

The actual Sonnet binding records `claude-sonnet-5-5`, exit 0, and the saved prompt/response hashes match. The report is exactly the response result. All three supplied source hashes match Git candidate `9432d319f4b3c0882e229a490d8f0592e06e624e`, and full source content is in the prompt. PASS is a static review; it does not certify test execution.

Both copies of the original CI log are identical and preserve the expected-false-to-be-true assertion failure. The original static counterexample and later real compiled-component fixture are retained, including source/build bindings, command, stdout, report and DB artifact. The observed first page omits s0000, the second contains it, exact lookup preserves the item, and total is 101. This deliberately constructed fixture does not reconstruct the random CI database. This check did not execute the fixture or open the DB.

The 26-test log names the integrated method-post299-retarget checkout. Both repaired test files and both production source files are byte-identical at 9432d319 and root `bd43cafdc163de6cc6b2a29793ad0f6e2303088b`. Do not relabel this as a whole-tree 9432 test run. Traceability limit: the archive contains only the focused log, without a standalone argv/head/exit receipt. Exact bd43 attribution for that run comes from root's supplied context; the C build-source binding also names bd43 but belongs to the separate counterexample run. An optional additive note can preserve this distinction without fabricating a contemporaneous receipt.

README has no confirmed overclaim: it already says integrated checkout/same repaired bytes, separates historical retarget checks, treats the auditor's probability estimate as unmeasured, and does not assert fresh published-head CI or full regression has passed. No archived bytes, repository files, ledger or PR were changed. No model or test suite was run. Exact details and member checks are in report.json and checked-members.json.

The first local validation attempt expected the manifest key `members`; this archive uses `files`. That harness-only KeyError occurred before validation results were written. The saved verifier reads the actual schema and then completed successfully. It did not modify or repair the archive.
