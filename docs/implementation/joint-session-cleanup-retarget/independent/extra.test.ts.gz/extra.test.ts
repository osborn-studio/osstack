import { execFileSync } from "node:child_process";
import { mkdirSync, realpathSync, rmSync } from "node:fs";
import { connect } from "node:net";
import { join } from "node:path";
import type { AgentSessionEvent, AgentSessionInput, SessionCapableAdapter } from "@osstack/agents";
import * as autonomy from "@osstack/autonomy";
import { createScratchDir, insertRun, insertTask, openDb, SessionRepository } from "@osstack/core";
import { encodeFrame, FrameDecoder, type HermesEvent } from "@osstack/hermes-adapter";
import { afterEach, expect, it, vi } from "vitest";
import { startDaemon, type DaemonHandles } from '/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-cleanup-ready/packages/cli/src/daemon.ts';
import { healthyAutonomyHealth } from '/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-cleanup-ready/packages/cli/src/test-healthy-autonomy.ts';

class ReceiptAdapter implements SessionCapableAdapter {
  readonly id = "receipt-fixture";
  readonly display_name = "In-process receipt fixture";
  readonly cost_tier = "low" as const;
  readonly resumed: AgentSessionInput[] = [];
  readonly started: string[] = [];
  failStart = false;
  failResume = false;
  failStop = false;
  stopUnconfirmed = false;
  capabilities() { return []; }
  async isAvailable() { return { available: true, status: "available" as const, last_checked_at: Date.now() / 1000 }; }
  async *invoke(): AsyncIterable<HermesEvent> { yield* []; }
  sessionCapabilities() { return { resume: true, snapshot: true }; }
  async *startSession(task: { prompt: string }): AsyncIterable<AgentSessionEvent> {
    this.started.push(task.prompt);
    yield { type: "native_session.started", native_session_id: "private-started-native" };
    if (this.failStart) throw new Error("injected lost start response");
    yield { type: "assistant.message", message_id: "start-reply", text: "Session started" };
    yield { type: "session.terminal", state: "completed" };
  }
  async confirmStopped() {
    if (this.failStop) throw new Error("injected stop verifier failure");
    if (this.stopUnconfirmed) return { stopped: false as const };
    return { stopped: true as const, evidence: "fixture has no external producer" };
  }
  async *resumeSession(input: AgentSessionInput): AsyncIterable<AgentSessionEvent> {
    this.resumed.push(input);
    yield { type: "native_session.started", native_session_id: input.native_session_id };
    if (this.failResume) throw new Error("injected lost execution response");
    yield { type: "assistant.message", message_id: "reply", text: "Instruction complete" };
    yield { type: "session.terminal", state: "completed" };
  }
}

type Response = { ok: boolean; result?: Record<string, unknown>; error?: { code: string } };
let root: string | undefined;
let socket: string;
let daemon: DaemonHandles | undefined;
let adapter: ReceiptAdapter;
const releaseFixtures: Array<() => Promise<void>> = [];
let admissionBlocked: (() => Promise<void>) | undefined;
let unblockAdmission: (() => void) | undefined;
let cleanupAttempts = 0;
const request = {
  session_id: "session", runtime_id: "receipt-fixture", turn_id: "turn",
  message_id: "instruction", expected_version: 1, text: "Continue the task", requested_by: "owner",
};

function rpc(method: string, params: unknown = {}): Promise<Response> {
  return new Promise((resolve, reject) => {
    const sock = connect(socket);
    const decoder = new FrameDecoder();
    const timer = setTimeout(() => { sock.destroy(); reject(new Error("RPC timeout")); }, 5_000);
    sock.on("connect", () => sock.write(encodeFrame({ id: 1, method, params })));
    sock.on("error", error => { clearTimeout(timer); reject(error); });
    sock.on("data", chunk => {
      const frames = decoder.push(chunk);
      if (frames.length === 0) return;
      clearTimeout(timer); sock.end(); resolve(frames[0] as Response);
    });
  });
}

async function boot() {
  daemon = await startDaemon({ socketPath: socket, adapters: [adapter], autonomyHealth: async () => {
    await admissionBlocked?.();
    return healthyAutonomyHealth();
  } });
}

async function fixture() {
  root = await createScratchDir("tests", "send-receipt");
  socket = join(root, "d.sock");
  const repo = join(realpathSync(root), "repo");
  mkdirSync(repo);
  execFileSync("git", ["init", "--quiet", repo]);
  vi.stubEnv("OSSTACK_HOME", root);
  vi.stubEnv("OSSTACK_SOCKET", socket);
  vi.stubEnv("OSSTACK_UPDATE_CHECK", "0");
  vi.stubEnv("OSSTACK_DASHBOARD_PORT", "0");
  vi.stubEnv("OSSTACK_ATTENTION", "1");
  vi.stubEnv("OSSTACK_ENGINEERING", "0");
  adapter = new ReceiptAdapter();
  cleanupAttempts = 0;
  await boot();
  const db = openDb({ path: daemon!.dbPath });
  try {
    insertTask(db, daemon!.dbPath, { task_id: "task", title: "Receipt fixture", created_at: 1 });
    insertRun(db, daemon!.dbPath, { run_id: "run", task_id: "task", session_id: "session", agent_id: adapter.id,
      capability_id: "code", phase: "execute", started_at: 1 });
    const sessions = new SessionRepository(db, daemon!.dbPath);
    sessions.createSession({ session_id: "session", task_id: "task", run_id: "run", agent_id: adapter.id,
      request_sha256: "a".repeat(64), native_session_id: "private-native", repo_path: repo, state: "idle",
      resume_supported: true, version: 1, updated_at: 1 });
    sessions.appendTurn({ turn_id: "turn", session_id: "session", ordinal: 1, state: "idle", assistant_text: "Ready",
      decision: null, created_at: 1, updated_at: 1 });
  } finally { db.close(); }
  // Fail only the physical cleanup boundary. Admission, SQLite transactions,
  // framing and replay use the real implementations and the real writer lock.
  const acquire = autonomy.acquireRepoWriteLock;
  vi.spyOn(autonomy, "acquireRepoWriteLock").mockImplementation(async (...args) => {
    const lock = await acquire(...args);
    releaseFixtures.push(() => lock.release());
    return { ...lock, release: async () => { cleanupAttempts++; throw new Error("injected physical cleanup failure"); } };
  });
}

function persisted() {
  const db = openDb({ path: daemon!.dbPath });
  try {
    const sessions = new SessionRepository(db, daemon!.dbPath);
    return {
      message: sessions.getMessage(request.message_id),
      snapshot: sessions.latestSnapshot(request.session_id),
      turns: (db.prepare("SELECT count(*) AS count FROM session_turns").get() as { count: number }).count,
    };
  } finally { db.close(); }
}

afterEach(async () => {
  unblockAdmission?.(); unblockAdmission = undefined; admissionBlocked = undefined;
  await daemon?.close(); daemon = undefined;
  // Test-owned lock cleanup only. This does not claim a product recovery route.
  for (const release of releaseFixtures.splice(0)) await release();
  vi.restoreAllMocks(); vi.unstubAllEnvs();
  if (root) rmSync(root, { recursive: true, force: true });
  root = undefined;
});


import { SupervisionService } from '/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-cleanup-ready/packages/cli/src/supervision-service.ts';

it("settled scan rejection preserves committed start and cleanup hold", async () => {
  await fixture();
  const original = SupervisionService.prototype.requestScan;
  const scan = vi.spyOn(SupervisionService.prototype, "requestScan").mockImplementation(function(reason) {
    if (reason === "session.start.settled") return Promise.reject(new Error("injected scan rejection"));
    return original.call(this, reason);
  });
  const params = {request_id:"scan-reject",agent_id:adapter.id,repo_path:join(realpathSync(root!),"repo"),title:"Start",prompt:"PRIVATE_PROMPT"};
  expect(await rpc("session.start",params)).toMatchObject({ok:true,result:{state:"idle",version:3,assistant_text:"Session started"}});
  expect(scan.mock.calls.filter(([reason])=>reason === "session.start.settled")).toHaveLength(1);
  expect(await rpc("health")).toMatchObject({ok:true,result:{active_runs:0,execution_lease_holds:1}});
  expect(await rpc("session.start",params)).toMatchObject({ok:true,result:{state:"idle",version:3}});
  expect(adapter.started).toHaveLength(1);
});

it.each(["timeout","empty_evidence"])("untrusted stop receipt %s retains hold and blocks fresh start", async mode => {
  await fixture(); adapter.failStart=true;
  vi.spyOn(adapter,"confirmStopped").mockImplementation(mode === "timeout"
    ? ()=>new Promise(()=>{})
    : async()=>({stopped:true as const,evidence:"   "}));
  const params={request_id:"unconfirmed-stop",agent_id:adapter.id,repo_path:join(realpathSync(root!),"repo"),title:"Start",prompt:"PRIVATE_PROMPT"};
  expect(await rpc("session.start",params)).toMatchObject({ok:false,error:{code:"agent_failed"}});
  expect(cleanupAttempts).toBe(0);
  expect(await rpc("health")).toMatchObject({ok:true,result:{active_runs:0,execution_lease_holds:1}});
  expect(await rpc("session.start",{...params,request_id:"fresh-start"})).toMatchObject({ok:false,error:{code:"agent_failed"}});
  expect(adapter.started).toHaveLength(1);
  expect(await rpc("session.start",params)).toMatchObject({ok:true,result:{state:"failed"}});
  expect(adapter.started).toHaveLength(1);
});
