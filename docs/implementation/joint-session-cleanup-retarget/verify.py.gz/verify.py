from pathlib import Path
import subprocess,json,os,datetime,hashlib,sys
kind=sys.argv[1];r=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-'+kind+'-ready');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-loader-cleanup-20261027')
env=dict(os.environ,PATH='/opt/homebrew/opt/node@22/bin:'+os.environ['PATH'],OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack',OSSTACK_HOME=str(out/(kind+'-test-home')))
result={'code_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':[]}
for label,cmd in [('final-frozen-build',['pnpm','build']),('final-frozen-typecheck',['pnpm','typecheck:check']),('final-frozen-lint',['pnpm','lint']),('final-frozen-inventory',['node','scripts/generate-inventory.mjs','--check']),('final-frozen-tests',['pnpm','test'])]:
 with (out/(kind+'-'+label+'.log')).open('w') as f: p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 result['checks'].append({'name':label,'command':cmd,'exit_code':p.returncode,'log':kind+'-'+label+'.log','sha256':hashlib.sha256((out/(kind+'-'+label+'.log')).read_bytes()).hexdigest()})
 (out/(kind+'-verification.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(label,p.returncode,flush=True)
 if p.returncode: raise SystemExit(p.returncode)
result['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/(kind+'-verification.json')).write_text(json.dumps(result,indent=2)+'\n')
