**Verdict: PASS (static only).** I found no confirmed correctness, security or regression blockers in the six supplied blobs or the integration diff.

I did not recompute the SHA-256 hashes or tree IDs, so I took the supplied head/base/tree metadata (`tree_unchanged`, `base_tree_equals_305`) as given. I made no runtime claims and no CI-success claim. The fresh validation in progress remains the gate for runtime behavior.

## What I checked

**Input and output safety (`maintain-skills-check-map.mjs`)**
- `parseOptions` accepts only `--map` and `--output`, rejects duplicates, odd argv and relative paths, and exposes no scope or command.
- `mapBytes` opens with `O_NOFOLLOW|O_NONBLOCK`, requires a regular file, and caps the read at 64 KiB. A symlink, FIFO or directory is refused before any drive.
- `validateMap` is a closed schema with exactly five unique stable IDs. Order is irrelevant and every refusal is `map_*`.
- Output is resolved through `realpath` of its parent and must be strictly inside `realpath(scratchRoot())`. Acquisition is a non-recursive `mkdir`, and every write uses `wx` or mode 0600. An existing directory or symlink yields EEXIST without being touched.

**Result integrity**
- Failure precedence is correct: the first failure stays in `failure` and later ones go to `subsequent_failures`.
- A non-`passed` journey can never produce exit 0.
- The `journey_incomplete` check requires all five IDs in order, with verification, driver exit, sealed evidence and cleanup all passing.
- Receipt identity is checked before comparison, and the map is re-read at closeout.
- A map change or a failed snapshot write cannot upgrade a result, and `status` and `exit_code` are always reset to blocked/2 by `fail`.
- The combined-failure regression is fixed: `fail` is called from three sites that all append rather than overwrite.

**Tests**
- I counted 24: 1 CLI parse, 1 valid map, 1 stale-then-corrected, 1 wrong-status, 1 row-order, 7 invalid-map variants, 1 oversized/UTF-8/directory/symlink, 1 existing output, 1 map-changed, 1 failed journey, 1 not-run/unknown cleanup, 1 stubbed real `runJourney`, 1 CLI invalid input, and 5 closeout-diagnostic tests. This matches the README's 24, with the last five being the "added" ones.
- Walking each assertion against the code, the expected failure strings and `subsequent_failures` arrays line up. That covers `map_after:ENOENT`, `map_changed` then `map_after:EEXIST`, `ENOENT` from the missing manifest, and `journey_result_identity`.
- The CLI-entry guard won't fire under `node --test`, since `argv[1]` is the test file.

**CI and scratch (`ci.yml`, `scratch.mjs`)**
- I read `scratch.mjs`. `scratchRoot()` defaults to `tmpdir()/osstack`, and `createScratchDir` does a recursive `mkdir`.
- So the `pnpm test:skills-map` step, which sets no `OSSTACK_SCRATCH_ROOT`, is safe. Its `setup()` creates the root, and `runMaintenance`'s `realpath(scratchRoot())` then succeeds.
- The smoke step sets the env explicitly and runs `mkdir -p …/runtime`, and the output path is fresh per runner. Both match the helper.
- The new steps sit after the existing journey steps and before projection, after `pnpm -r build`. `package.json` aliases match the CI invocations. The upload action uses the same pinned SHA as the neighbouring steps. The new step is not gated on `heavy_smoke`, which is appropriate for a script change.

## Optional improvements (not blockers)

1. The `map_inside_output` check is vacuous, since the output does not exist yet at that point. It is harmless.
2. `map_after:` also labels a failed `map-after.json` snapshot write, not just a failed re-read. The text is slightly misleading but unambiguous in tests.
3. A missing scratch root surfaces as a raw `realpath` ENOENT. A dedicated reason such as `scratch_root_missing` would be clearer. The README already instructs creating it.
4. A failure between `mkdir` and the `try` block (the `map-before.json` write) leaves an empty owned directory and no `maintenance.json`. The CLI still exits 2.
5. Receipt identity compares `JSON.stringify` output, so it depends on key order. That is fine while `runJourney` writes the same object it returns, but it is brittle if serialization ever changes.
6. The README has two documentation risks:
   - It links `evidence/archive-receipt.json` and `evidence/raw-verification.tar.gz`, which are not among the supplied blobs, so I cannot confirm the links resolve.
   - It hard-codes historical commits, counts and "remaining steps" text that go stale at merge. A one-line "historical, at authoring time" label would help.
7. The step duplicates a full five-case journey already run just before it. That is intentional as an independent fresh run. It adds job time against the 35-minute budget, so keep an eye on it.
8. Setting `OSSTACK_SCRATCH_ROOT` on the contracts step would match its neighbours. This is cosmetic, as the default is safe.

## Not verified

I did not see `method-verification-journey.mjs` or `lib/skills-check-verification.mjs`. Two things depend on them: that `runJourney(…, { invoke: undefined })` falls back to the real driver, and the `sha256` export. Test 18 and the historical alias runs cover both. The fresh validation should confirm them. Statements about earlier full and targeted runs stay historical.