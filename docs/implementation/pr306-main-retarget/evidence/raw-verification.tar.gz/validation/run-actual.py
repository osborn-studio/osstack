import runpy,json
v=runpy.run_path(str(__import__('pathlib').Path(__file__).parent/'run-validation.py'))
W,R,sha,record,git=[v[k] for k in ['W','R','sha','record','git']]
original=W/'docs/implementation/skills-check-map-maintenance/map.json'
raw=original.read_bytes();m=json.loads(raw)
map_path=R/'maintained-map.json'
next(f for f in m['features'] if f['case_id']=='missing-ref')['expected_product_exit']=0
wrong=(json.dumps(m,indent=2)+'\n').encode();map_path.write_bytes(wrong)
(R/'map-red-before.json').write_bytes(wrong)
record('actual-map-red',['pnpm','smoke:skills-map','--map',str(map_path),'--output',str(R/'red-output')],1)
assert map_path.read_bytes()==wrong and original.read_bytes()==raw
red=json.loads((R/'red-output/maintenance.json').read_text())
assert red['status']=='mismatch' and red['exit_code']==1 and red['map']['unchanged'] is True
assert [r['case_id'] for r in red['rows'] if not r['matches']]==['missing-ref']
assert red['journey']['status']=='passed' and red['execution_path']=='runJourney'
next(f for f in m['features'] if f['case_id']=='missing-ref')['expected_product_exit']=1
right=(json.dumps(m,indent=2)+'\n').encode();map_path.write_bytes(right)
(R/'map-green-before.json').write_bytes(right)
record('actual-map-green',['pnpm','smoke:skills-map','--map',str(map_path),'--output',str(R/'green-output')],0)
assert map_path.read_bytes()==right and original.read_bytes()==raw
assert json.loads(wrong)['features'][1] | {'expected_product_exit':1} == json.loads(right)['features'][1]
redmap=json.loads(wrong);redmap['features'][1]['expected_product_exit']=1;assert redmap==json.loads(right)
green=json.loads((R/'green-output/maintenance.json').read_text())
assert green['status']=='consistent' and green['exit_code']==0 and green['map']['unchanged'] is True
assert all(r['matches'] for r in green['rows']) and green['journey']['status']=='passed'
for rec in [red,green]:
 assert [(f['case_id'],f['product_exit'])for f in rec['journey']['features']]==[('healthy',0),('missing-ref',1),('drift',2),('mixed',1),('empty',0)]
 assert all(f['driver_exit']==0 and f['cleanup']['fixture_removed'] for f in rec['journey']['features'])
 assert rec['journey']['receipt_matches_returned'] is True and rec['model_calls']==0 and rec['formal_gate_pass'] is False
summary={'code_sha':git('rev-parse','HEAD'),'original_repo_map_sha256':sha(raw),'original_repo_map_unchanged':True,'red_input_sha256':sha(wrong),'green_input_sha256':sha(right),'only_map_delta':'features[missing-ref].expected_product_exit:0→1','red':red,'green':green,'limits':['Deliberately stale map; two fresh real five-case journeys. No product source changed.','Consistent map is finite scenario agreement, not proof of source-review completeness or full maintenance clean.','No model or authenticated producer or full descendant termination attestation.']}
(R/'actual-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('actual RED1→map-only→GREEN0 confirmed')
