# PR306 retarget local evidence

Verified422 listed files against hashes and sizes. Raw logs independently confirm263 focused tests(24+43+88+94+14),241 documentation tests and1 hygiene test. Commands bind958eb722 and expected exit codes.

Real same pnpm entry with two fresh outputs preservesRED1 andGREEN0. Only missing-ref map expectation changes0→1; each run has product0/1/2/1/0 and driver0, exact semantic statuses and retained manifests. Ten fixture directories are absent now. Map bytes stay unchanged within each run, and source/build bindings match.

1483 source snapshot members match current files; four generated knowledge dist files were saved with hashes and restored to958 Git bytes only after validation. No new tests/model or whole-suite run performed here. Final CI40920378111 remains a separate gate.
