from pathlib import Path
import json,hashlib,re,subprocess
r=Path(__file__).parent;v=r.parent/'validation';w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr306-main-retarget');sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text());head='958eb72295937b96ee8affc32fa87910bbdde512'
assert sha((v/'summary.json').read_bytes())=='0d7263467781fa94ca1d779952fcc1f282e17d1648c501f364a0af257bd6feb7';assert sha((v/'manifest.json').read_bytes())=='cb777f504a52e0c3d2e974c9be30e51fb7f91ecfea060201d43f4c02ba5f0158';manifest=load(v/'manifest.json');assert len(manifest['files'])==422
for f in manifest['files']:
 b=(v/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
counts={}
for name in ['maintenance-tests','journey-tests','projector-tests','export-tests','reader-tests']:
 text=(v/(name+'.stdout')).read_text();c={k:int(re.findall(r'^# '+k+r' (\d+)$',text,re.M)[-1]) for k in ['tests','pass','fail','skipped']};counts[name]=c;assert c['tests']==c['pass'] and c['fail']==c['skipped']==0
assert sum(c['pass'] for c in counts.values())==263
assert re.search(r'Ran 241 tests in .*\n\nOK', (v/'docs.stderr').read_text());assert re.search(r'Tests\s+1 passed \(1\)',(v/'hygiene.stdout').read_text())
commands=[]
for p in v.glob('*.command.json'):
 c=load(p);stem=p.name.removesuffix('.command.json');assert c['code_sha']==head;assert c['stdout_sha256']==sha((v/(stem+'.stdout')).read_bytes()) and c['stderr_sha256']==sha((v/(stem+'.stderr')).read_bytes());assert c['exit']==c['expected_exit'];commands.append({'file':p.name,'exit':c['exit'],'argv':c['argv']})
def checkmanifest(p):
 for f in load(p)['files']:
  b=(p.parent/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
runs=[]
for phase,exit in [('red',1),('green',0)]:
 base=v/(phase+'-output');m=load(base/'maintenance.json');j=load(base/'journey/journey.json');assert m['exit_code']==exit and m['execution_path']=='runJourney';assert m['map']['unchanged'] and sha((base/'map-before.json').read_bytes())==m['map']['before_sha256']==m['map']['after_sha256'];assert m['journey']['receipt_matches_returned'];assert sha((base/'journey/journey.json').read_bytes())==m['journey']['receipt_sha256'];assert sha((base/'journey/journey-manifest.json').read_bytes())==m['journey']['manifest_sha256'];checkmanifest(base/'journey/journey-manifest.json')
 for f in j['features']:
  p=base/'journey/cases'/f['case_id']/'manifest.json';checkmanifest(p);assert sha(p.read_bytes())==f['manifest_sha256'];assert f['cleanup']['fixture_removed'] and not Path(f['cleanup']['fixture_path']).exists()
 assert [f['product_exit'] for f in j['features']]==[0,1,2,1,0];assert [f['product_status'] for f in j['features']]==['healthy','failed','drift','failed','empty'];assert all(f['driver_exit']==0 and f['verification']=='passed' for f in j['features']);runs.append({'phase':phase,'exit':m['exit_code'],'status':m['status'],'binding':j['features'][0]['bindings'],'fixtures_absent':5})
red=load(v/'red-output/map-before.json');green=load(v/'green-output/map-before.json');delta=[(i,k,a[k],b[k]) for i,(a,b) in enumerate(zip(red['features'],green['features'])) for k in a if a[k]!=b[k]];assert delta==[(1,'expected_product_exit',0,1)];assert runs[0]['binding']==runs[1]['binding'];ca=load(v/'actual-map-red.command.json')['argv'];cb=load(v/'actual-map-green.command.json')['argv'];assert ca[:-1]==cb[:-1] and ca[-1]!=cb[-1]
before=load(v/'before-source.json');after=load(v/'after-source.json');assert before['head']==after['head']==head;assert len(before['files'])==1483;assert after['source_equal_before'] and after['no_tests_after_restore'];restores=after['restored_only'];assert len(restores)==4
for f in before['files']:
 b=(w/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
for f in restores:
 p=f['path'];saved=v/'generated-before-restore'/Path(p).name;b=saved.read_bytes();assert sha(b)==f['generated_sha256'] and len(b)==f['generated_bytes'];git=subprocess.check_output(['git','show',head+':'+p],cwd=w);assert sha(git)==f['head_blob_sha256'] and (w/p).read_bytes()==git
for p in ['scripts/maintain-skills-check-map.mjs','scripts/maintain-skills-check-map.test.mjs','package.json']:
 assert (w/p).read_bytes()==subprocess.check_output(['git','show',head+':'+p],cwd=w)
report={'status':'local_evidence_verified_no_confirmed_issue','head':head,'manifest_sha256':sha((v/'manifest.json').read_bytes()),'manifest_files':422,'counts':counts,'focused_pass':263,'docs_pass':241,'hygiene_pass':1,'commands':commands,'actual_runs':runs,'only_map_delta':delta,'source_snapshot_members_verified_current':1483,'generated_dist':restores,'limits':['Read-only verification of A executed evidence, no new product/test/model run.','Fresh final CI40920378111 is separate and still pending; cancelled40917058847 is not classified as a failing-test rerun.','Source/build equality and observed fixture absence retain original non-authentication/non-descendant limits.','No old host experiments rerun or regraded.']}
(r/'local-evidence-report.json').write_text(json.dumps(report,indent=2)+'\n');(r/'local-evidence-report.md').write_text('# PR306 retarget local evidence\n\nVerified422 listed files against hashes and sizes. Raw logs independently confirm263 focused tests(24+43+88+94+14),241 documentation tests and1 hygiene test. Commands bind958eb722 and expected exit codes.\n\nReal same pnpm entry with two fresh outputs preservesRED1 andGREEN0. Only missing-ref map expectation changes0→1; each run has product0/1/2/1/0 and driver0, exact semantic statuses and retained manifests. Ten fixture directories are absent now. Map bytes stay unchanged within each run, and source/build bindings match.\n\n1483 source snapshot members match current files; four generated knowledge dist files were saved with hashes and restored to958 Git bytes only after validation. No new tests/model or whole-suite run performed here. Final CI40920378111 remains a separate gate.\n');print(json.dumps({'status':'verified','report_sha256':sha((r/'local-evidence-report.json').read_bytes())}))
