# PR306 retarget Git proof

Verified main e79fc926 has the same31a72ebd tree as merged PR305 b0ea4e78. New958eb722 has parents old30638a6f358 and actualmain e79fc926; its356296e4 tree equals old306 and the independent merge-tree result. Complete old/new binary diffs are identical and retarget head-delta is empty.

115 paths differ from main. Retarget adds no code changes, but existing PR306 includes package.json aliases, CI wiring, maintenance script/test and one shared method reference. No packages/* implementation, lock/schema/shared-runtime contract change.

RT01–07 freeze binds next local/CI/archive observations. Tree equality does not relabel previous tests as fresh execution.
