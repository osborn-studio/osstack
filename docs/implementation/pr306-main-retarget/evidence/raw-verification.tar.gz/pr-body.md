## What changes

Add a reusable comparison between a separately maintained five-case skills-check map and a fresh execution of the existing full journey. A stale expectation produces `mismatch`/1; matching verified observations produce `consistent`/0; invalid inputs, incomplete evidence and changed inputs produce `blocked`/2. The tool preserves prior evidence and never edits the map automatically.

Wire the command into the existing maintenance reference, package aliases and CI with retained artifacts. No new method, daemon or host experiment is introduced. This is a bounded PS09/J06 slice, not completion of general-project maintenance or any formal J gate.

## Evidence and validation

- Original candidate: real injected map drift → mismatch → only the map cell corrected → same entry with fresh output → consistent. Independent full-five and refusal/seam checks retained.
- Sonnet 5.5 found diagnostic loss under combined failures. Five added regressions failed before the repair; all 24 maintenance tests then passed. Primary and subsequent failures, partial journey metadata and declared test seams are now preserved.
- Root combined standalone suite: 263 passed. Full root4cc package suite: 22 packages, 7144 passed / 5 skipped / 0 failed, with four fresh generated files and tracked bytes unchanged. Actual final pnpm alias reproduced map RED/1 → map-only correction → GREEN/0.
- Original audits, failures and exact candidate bindings remain in `docs/implementation/skills-check-map-maintenance/evidence`.

This delivery is queued after #305 for root integration; the standalone maintenance tool itself uses the already merged #304 journey and does not require the packet projector. Keep Draft until the parent is merged and the actual main candidate has been validated. User approval and merge remain required.


## Actual-main revalidation

PR305 is merged at `e79fc92687c144969ad91242a979d904f2b2acdf`. This PR now targets `main` at head `958eb72295937b96ee8affc32fa87910bbdde512`; its tree and complete change set match the previous candidate. Fresh Node22 validation passed 263 focused tests, 241 documentation checks and hygiene. Two fresh runs of the same pnpm maintenance command reproduced intentional map drift (exit1), then consistency (exit0) after only correcting the map. Actual Claude CLI Sonnet5.5 static review returned PASS with optional suggestions; raw feedback is preserved. New CI `40920378111` is running; the PR remains Draft until all five applicable checks pass. Earlier CI on the superseded head was cancelled to release the queue; this is not a failed-test rerun. User retains approval and merge.
