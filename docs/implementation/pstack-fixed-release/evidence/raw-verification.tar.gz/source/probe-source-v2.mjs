import {inspectGitSource} from '/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-maintenance-health/packages/skill-registry/dist/source-snapshot.js';
import {writeFileSync} from 'node:fs';
const results=[];
for(const subdir of ['pstack','pstack/skills/statechart']){
 const start=new Date().toISOString();
 try { const result=inspectGitSource({gitBinary:'/usr/bin/git',repositoryPath:'/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-stage-acceptance-20261030/upstream-refresh/cursor-plugins',repository:'https://github.com/cursor/plugins',commit:'c742dd61706fbacc1b95f1a20b7b988cf096ce6c',subdir,licensePaths:['pstack/LICENSE']}); results.push({subdir,start,result}); }
 catch(error){results.push({subdir,start,error:{name:error.name,code:error.code,message:error.message}});}
}
writeFileSync(new URL('./source-inspector-probe.json',import.meta.url),JSON.stringify(results,null,2));
console.log(JSON.stringify(results.map(x=>({subdir:x.subdir,error:x.error,count:x.result?.files.length,pin:x.result?.pin})),null,2));
