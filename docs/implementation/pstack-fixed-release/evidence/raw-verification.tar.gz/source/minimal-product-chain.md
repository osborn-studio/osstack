# 固定 pstack 发布并让一个真实 bugfix 经 OSStack 完整执行

本报告为熟悉上下文的分析者对当前源码的只读核对，不是 fresh cold 验收，也不是新执行结果。未运行产品、模型、测试或 W19 实验；未修改仓库、pin、卡片或 PR。核对时当前工作树 HEAD 为 `431f1cd189ed3921df750072deee56123de4d729`；工作区可能包含协调者并行修改，以下结论绑定列出的源码接口，不把 HEAD 当全部字节证明。

## 建议决策

把目标明确为两个可交付物：**固定来源的方法包，可立即在实际任务中使用；一个通过 OSStack deliver 入口完成的真实本地 bugfix。** 不把原生 slash 注册、两宿主对比、全部联合里程碑、Firstmate 深运行或平台生产率证明设成这两个交付物的前置。

协调者提供的新来源核对：`cursor/plugins` commit `c742dd61706fbacc1b95f1a20b7b988cf096ce6c` 的 `pstack/plugin.json` 为 `0.15.36`，pstack 子树与 `4dd1d058` 相同，tree 前缀 `4719e1c4`，573 路径。本报告未独立重新读取该外部库；最终 lock 应使用协调者核实的完整 tree hash、完整 commit、版本和原始许可证。`/statechart` 公告只列候选，须读该 pin 的实际 skill、依赖和命令后再决定采用；不从公告推断功能完成，不让它拖延 bug-fix 首期。

原 `docs/reports/2026-10-26-pstack/evidence/source-lock.json` 与 `osstack-methods-skill/references/sources.md` 仍是 **0.15.32 / 99b609a72323b70204eab407c622f436e858e112**。新建新版 lock 和差异清单，保留旧 pin 与所有历史成绩。一个发布使用一个明确来源 pin；同一 skill 不能混读两个版本。第一批明确采用 bug-fix 及其必要方法引用、evidence、模式路由/帮助、许可证；其他能力注明“尚未采用”，不把独立改写称为原版逐字安装。

## 当前已有内容与真正缺口

| 层 | 可复用文件/API | 已有事实 | 最小缺口 |
| --- | --- | --- | --- |
| 轻量来源登记 | `packages/skill-registry/src/manifest.ts` 的 `SkillSource`、`readManifest/writeManifest/addSource` | origin/ref/blessed_sha/auto_minor；默认 auto_minor=false | 这是追踪清单，不是 immutable adoption snapshot、依赖闭包或执行许可；固定 commit 并保持禁止自动晋升 |
| 固定 Git 源读取 | `packages/skill-registry/src/source-snapshot.ts` 的 `inspectGitSource`，子路径导出 `@osstack/skill-registry/source-snapshot` | 读取 Git 对象，license/content/file 摘要，返回 `source_inspection`；禁止执行源命令，`dependency_resolution:not_performed` | 不能直接冒充 `SourceSnapshot`；尚缺采用集合/引用闭包。旧 source-lock 是 partial clone，读取器拒绝 PARTIAL_STORE；新完整镜像可消除此项但仍有573路径超过FILE_LIMIT512问题 |
| Snapshot/recipe/proposal | `packages/protocol/src/joint-evidence.ts`：`SourceSnapshot/sourceSnapshotDigest/MethodInput/CheckRegistry`；`method-binding.ts`：`MethodRecipe/MethodProposal/methodRecipeDigest/methodProposalDigest/verifyBindingAgainst` | 严格形状与摘要交叉绑定；recipe仅bug_fix，三角色，local_verified，publication none；proposal executable=false | 源码搜索中 recipe/proposal 非测试消费者只在 protocol 内部；尚无实际源码闭包编译器、用户命令或 host admission 消费链 |
| 方法发布 | `scripts/lib/osstack-method-export.mjs`：`exportMethods/parseExportOptions`；`scripts/export-osstack-methods.mjs` | 四入口，每项 source/output hash，manifest，project-local Codex/Claude布局，不安装全局 | 更新采用材料并生成新版本 bundle；固定源Git lock与导出manifest不是同一摘要，需要显式关联 |
| 材料读取 | `scripts/read-method-material.mjs`；`osstack-methods-skill/references/host-usage.md` | 有界分页、同文件hash、EOF；显式读可立即用 | 完整读取不等于应用；需要真实任务工具轨迹/补丁/RED→GREEN |
| 最短执行路径 | `packages/cli/src/deliver-command.ts:handleDeliverCommand`；`bin.ts` 已接 host deps | 现成 `deliver --autonomy guarded-local`；V2 `--contract`；`--execution-context`；`--verify`；local candidate proof | 没有现成 `--method bug-fix`。最先可由现有host显式读固定方法，再发真实deliver；要承诺“一步且不可遗漏方法”需补狭窄method绑定/材料注入 |
| 上下文与收据 | `execution-context.ts:createExecutionContextAdapters/createPinnedLocalContextLoader`，`execution-context-host.ts:createHostExecutionContext/persistExecutionContextReceipt` | prepared/adapter_observed 收据，scope/hash/expiry，现config为knowledge pack，不是任意Markdown输入 | mandatory方法材料接入、角色材料装配、最终同步版本/权限检查；当前validateContextSync仅拿assembly.selected，不能宣称已验证mandatory method |
| 本地交付权威 | `@osstack/core` 的 `freezeDeliveryContract/assertDeliveryContractAdmission/assertDeliveryContractPaths`；`delivery-contract-host.ts` 的 `captureDeliveryCandidate/createDeliveryVerificationFence/buildDeliveryVerificationReceipt/verifyPersistedDeliveryReceipt` | 能复用现有候选/检查/路径/receipt链 | 把固定方法与任务、原复现及候选绑定入同一次交付，完成判据消费原始检查而非自然语言自报 |
| Graph可复用接口 | `graph-contract-host.ts:createGraphContractHostResolvers`，`graph-execution-context.ts:prepareGraphExecutionContext`，现有Graph action/broker | 已有执行与授权边界 | GraphChangesetInvocationHost明确写着“非RPC或注册executor”；createChangesetProposalClient是proposal客户端，不是自动修复产品入口。不要为了首个bugfix另造第二执行器或第二账本 |

来源读取的573/512限制应成为一个有界实现单元：建议先明确 adoption 文件集合和引用边，读取同一固定对象的选定文件并保留未采用清单；或将总文件预算作为经过测试的显式选项，仍保留每blob/总bytes/treebytes/时间预算。不得把 FILE_LIMIT 随手调大后声称闭包安全，不得将整个子树截断至前512文件并宣称完整。当前 `inspectGitSource` 没有“任意path集合”参数；采用集合选择需要真实新增实现，不能写成已存在接口。

## 最短交付路线：先可用，再把重复手工接线做成产品

**阶段1：固定方法包，用户今天能用。** 新版来源锁定后，更新独立改写的 bug-fix/路由/必要引用与来源说明，导出四入口；在一个已授权宿主中明确读取 mode、bug-fix、evidence，保存所用 manifest/hash。用户可直接说：“读取这份固定 OSStack 方法的 bug-fix 和 evidence；在指定仓库修复这个错误，先复现，写回归，最小修复，同入口重验，保留原失败与补丁。”无需等待原生目录发现、自动主控或多个模型比较。结果如实记为显式材料使用。

**阶段2：一个真实 bugfix 走现有 OSStack deliver。** 在干净隔离目标仓库、独立 OSSTACK_HOME、显式 scratch、已配置adapter/profile/policy的环境下，实际使用 `deliver --autonomy guarded-local --auto-agent --workspace ... --verify ... --json`。如果声明V2交付合同，则使用现有 `--contract`，由host已注册的verify命令、路径和budget约束，不添加与合同冲突的CLI参数。此阶段验收实际代码修复，不把计划/schema/export成功当任务完成。方法读取可以先由宿主显式完成；必须在记录里说明是否由调用者手工传入，不能冒称强制recipe准入。

**阶段3：只补一步入口缺失。** 为用户提供单一 `method bug-fix` 之类的入口是拟新增接口，名称需要实现时冻结；当前不可执行。它做：读取固定release/采用recipe → 形成不可执行proposal → 展示真实路径/命令/budget → 通过现有host授权/交付合同 → 按builder/reviewer/verifier角色注入固定材料 → 复用deliver/现有adapter → 汇聚原复现、候选、独立检查和cleanup → 输出 local_verified 或具体blocked/failed/unknown。只需bug-fix一种recipe，不引入全方法自动规划。拟新增文件可放 `packages/skill-registry/src/method-recipe.ts`、`packages/cli/src/method-command.ts`、`packages/cli/src/method-context-host.ts`；接入点为bin lazy dispatch和existing execution-context/DeliverCommandDeps，而不是启动另一后台控制器。

若阶段3选择正式联合 `MethodBinding(mode:trial|qualified)` 路线，必须尊重现有合同：`trialBudgetIssues`当前无条件包含 `adapter_invocations_unattested`，不能伪造profile或删校验让trial运行；须实现对应计数/授权与root admission消费后再声称trial合格。最快的阶段1/2是现有授权下普通assisted/guarded-local使用，**不颁联合trial/qualified资格**。若改变旧设计的前置，须明确记录为缩窄产品交付范围，而非把未完成J项标完成。

现有 `osstack engineering adopt/observe/decide` 是会话采用 pilot，完成级别仅 `observed_turn`，不能取代代码交付。`osstack start/control approve` 管合同生命周期，approve输出deliver命令但不会自动执行。这两点应在用户教程中直说，避免让用户误以为发任务后已全程托管。

## 一次真实 bugfix 的可操作验收

优先选用户当前未修的真实小缺陷，有明确复现入口、局部源码、可固定输入与至少一个合法控制。若暂没有，已有 `docs/implementation/pstack-delivery-reconciliation/next-real-task.md` 给出历史真实 packet checker 漏检；它基于1038dc9a，三源文件与固定incident/两个control，只修checker并新增回归。可用作历史真实缺陷的独立修复演示，但不能当新发现或新增生产修复；无需照搬其中双宿主/独立性资格要求作为首个产品可用门槛。不要使用W19故意注入工具错误冒称真实产品bug。

验收只要求一个支持宿主、一个task、一个候选；不要求两模型擂台或全仓full：

1. 在首次修复前保留真实入口的错误结果，确认是行为失败而非缺模块、权限拒绝或未执行。记录源码/fixture/方法/运行时版本。
2. 由OSStack实际调用的builder写回归并在旧代码获得行为RED；宿主轨迹必须有实际执行，不能由协调者代跑后写成模型实测。
3. 产生最小可审阅patch；目标输入/方法材料/允许路径之外保持不变。仅改期望让测试绿不合格。
4. 同输入、同CLI在候选GREEN；合法控制仍通过；影响相关focused测试通过。若产品有必须构建项，运行对应构建，不机械要求全部联合测试。
5. 检查最终实际候选，而非先前中间patch；独立验证步骤可复用现有verifier角色/受信检查命令。角色材料消费与配置身份分开，缺少身份认证如实说明。
6. 失败与成功都有stdout/stderr/exit、源码/输入绑定、method/export hash、patch与cleanup记录；输出local_verified只覆盖这个任务，无自动merge/发布。
7. 一次缺方法/摘要漂移的入口测试必须在模型调用前拒绝（阶段3强制绑定范围）；一次取消/未知结果保持原事实且不盲目重复调用。无需为此先实现所有崩溃/远端/恢复平台能力。

最小任务验收可压成：**原bug实测失败 + OSStack实际调用代理修复 + 同入口通过 + 合法控制不退化 + 固定方法/候选/日志可追溯**。复现不成立就保留结论并选下一个真实缺陷，不能偷偷改成容易的合成实验。

## 当前现成CLI怎样直接用（本报告未执行）

所有路径/变量须换成真实授权值；执行类命令使用独立OSSTACK_HOME、scratch和目标checkout，不能指向默认/保留服务home。以下参数来自当前源码/教程，省略号不是命令。

| 用途 | 现成入口 | 结果边界 |
| --- | --- | --- |
| 导出方法 | `pnpm export:methods --host codex --output /absolute/existing-parent/new-bundle --dry-run`；审阅后同命令去掉dry-run；claude同理 | 导出四入口，不安装全局，不保证原生slash发现 |
| 读材料 | `node scripts/read-method-material.mjs --file /absolute/material.md --start 1 --lines 60`；后页带首次sha与next_start | EOF是完整页读取，不证明理解或应用 |
| 选固定验证场景 | `node scripts/method-feature-map.mjs --index docs/verification/features/index.json --query maintenance --limit 1`；query可journey/packet | 返回材料，不执行驱动 |
| 固定五例驱动 | `node scripts/method-verification-journey.mjs --output "$new_output" --scope full` | 实际本地skills-check五例；需要构建，输出必须新建 |
| 地图对照 | `node scripts/maintain-skills-check-map.mjs --map "$absolute_map" --output "$new_output"` | 实际full5；0一致/1期望不符/2阻塞，不自动修复 |
| 保留证据投影 | `node scripts/project-method-journey-evidence.mjs --input "$journey" --output "$new_packet" --scope full`；`node scripts/project-method-journey-evidence.mjs --check "$new_packet"` | 不重驱；检查字节/语义，不认证producer |
| 有限health | `node scripts/method-control-health.mjs --config "$absolute_config" --as-of "$utc_time"` | 显式attempts，查询exit0不是健康；无周期/通知 |
| 现有本地交付 | `osstack deliver "具体缺陷、固定方法位置与验收条件" --workspace "$target_repo" --auto-agent --autonomy guarded-local --verify "$registered_check" --json` | 需要真实profile/adapter/policy；当前没有method flag。V2合同可用--contract，existing context仅knowledge/source，不能直接塞SKILL.md |
| Graph（已有受信配置时） | `osstack graph validate --spec "$spec"`；`osstack graph run --request "$request"`；`status/result/contract --run "$run" --scope "$scope"` | 不会替你配置host/grant/recipe；run exit0是ack，不是交付完成 |

## 来源能力与OSStack自加设计分开

pstack来源提供方法/技能/原则与宿主工作流：bug复现、区分原因、回归、小修复、同表面验证、证据/清理等。0.15.36的statechart是否提供何种产物，需要在该pin原文核对，本报告不推测。OSStack现有四入口是独立改写，不能把所有上游58技能、旧方法数量或新版573路径视为已吸收能力。

OSStack自加的是：SourcePin/Snapshot、recipe/proposal/Binding/TrialPermit/SupportProfile、受信host admission、local_verified、原始对象摘要、身份与资格门槛、联合J/JA里程碑，以及固定skills-check地图/旅程/投影/health。这些提升可追溯性与执行控制，但不是上游使用pstack必须先完成的条件。首个真实修复仅需要与其实际声明匹配的安全和检查；不声称正式资格即可避免用全联合项目拖延正常方法使用，且不得绕过已有host实际权限/隔离/预算。

建议停止线：固定一个版本、发布可读方法包、通过一个真实OSStack bugfix闭环，就交用户使用和反馈。后续依真实任务反复出现的手工接线优先补产品，不新增无关平台、后台循环或Firstmate深运行作为本轮目标。

## 本次读取关键字节

记录时间：2026-10-30T08:21:02.966595+00:00。仓库根：`/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/pstack-maintenance-health`。只读源码推导不冒充运行结果。

| 文件 | SHA-256 |
| --- | --- |
| `packages/skill-registry/src/source-snapshot.ts` | `20424f25582f3b944116530906548aa110dcde0d9e9fb0d0e492116fab75b033` |
| `packages/skill-registry/src/manifest.ts` | `dc70df8caa70530a6d9714fa4ea6418770c36f16fdd2535a64535bf4649f3cb6` |
| `packages/protocol/src/method-binding.ts` | `6c6c9a1530269be698b13f8e34aa635bba84cf522e605a17ce9a11f6534c800c` |
| `packages/protocol/src/joint-evidence.ts` | `364593f6bfdc1d65f7e4c09b7f63b7211ce9305961c5660ae985aad4bdf4a1cb` |
| `packages/protocol/src/joint-shapes.ts` | `8056649a4f5a6b6f3e75d188da8cf342fc01ccc2bfe5fa5ff7d718582e5a052b` |
| `packages/cli/src/deliver-command.ts` | `bfc9d583b6c9e35f9019a510df104401ebc79c3373e89097162d705cff0cf006` |
| `packages/cli/src/execution-context.ts` | `aa5298f4ccef92779fd012ec6fed61adef96a805282a19ded76f6a0093afb7f6` |
| `packages/cli/src/execution-context-host.ts` | `149ac22d6d8190e5ca24208e431f74945881d7b8116f097df3985ed2835ef314` |
| `packages/cli/src/graph-changeset-invocation.ts` | `78162de838d990ef2c47b8f999f9c9f6f270ff250951b09130f21d71ca5412ea` |
| `scripts/lib/osstack-method-export.mjs` | `7ac7278d1d0e5672bda5965b2bb4ae584b3f3bd6bc3fa928e36a4ea31fb3f805` |
