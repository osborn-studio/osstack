# W01 独立有限检查

在作者实现前冻结 contract 对应的41个来源输入及1个顶层manifest输入，保留旧manifest/watcher原字节；再加入同一脚本的5项往返/旧YAML/无额外效果/watcher检查，共47项。

- 旧源码：2通过、45行为失败，Node退出1。两个通过项为 watcher 在 auto_minor=false/true 下都不自动采纳。
- 新源码：47通过、0失败，Node退出0；manifest SHA d775042ab6befbb09b4e2c363bd8e1240b6ad1cf89a1891072bfd5acf5024795。
- 输入及脚本未改变，watcher前后字节相同。没有产品仓库写入。

`freeze.json`记录冻结时间、contract/旧源/vector摘要；`vectors.json`为原输入；`check.cjs`为同一检查脚本。`old.command.json`/`new.command.json`保存实际argv、cwd、必要环境、起止时间及退出码，旁边stdout/stderr保留原输出；每阶段results.json逐项记录。`receipt.json`给出汇总与边界。

TS用当前仓库TypeScript在内存转CommonJS，在VM中加载真实zod/js-yaml，未执行构建产物。manifest读写限定自有阶段scratch的显式路径；watcher的child_process.spawn被拦截，模拟git ls-remote输出，未调用真实git/网络或默认home。此项证明当前逻辑保持只报告不采纳，不是网络进程集成测量。

路径逃逸值被拒；合法symlink-looking/shell-looking字符串作为数据原样保留，schema parse没有fs/child_process效果。未把该检查扩张为任意文件系统symlink-race隔离证明。package_version是独立标签，与ref/blessed_sha分别保留；不认证标签与上游commit一致。

本次不是安装、激活、snapshot引用闭包、完整技能消费或正式运行资格。包typecheck及作者focused测试由作者/root另行记录，本报告不冒称执行。没有W19重跑、全仓测试或默认服务home操作。
