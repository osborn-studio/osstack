# W01 source registration author evidence

The two-file change records a relative Git subtree (default `.`) and an independent package version label (default null). It rejects unknown manifest/source fields. Valid old sources retain ref, blessed SHA and auto_minor semantics. The subtree validator matches existing source-snapshot path rules; no source inspector budgets or consumers changed. This is registration only, not subtree ingestion, watcher adoption, runtime activation, or formal qualification.

Exact same focused tests: old source 43 failed/9 passed; new source 52 passed (46 manifest + 6 watcher). Round trips use explicit scratch YAML paths; watcher tests intercept subprocesses. Initial `pnpm test -- ...` forwarded a separator and also collected the package source-snapshot suite, whose unbuilt dependency imports failed; raw logs remain. Corrected `pnpm exec vitest run` selects only the two intended suites and supplies the behavioral RED/GREEN.

Initial target typecheck lacked core/protocol declarations. Frozen dependency install and only these two dependency builds completed; final target typecheck passed. Initial install missing-bin warnings and failed checks are retained. No whole-repository test, model, DB, network Git check, commit or PR was executed. All checks use explicit OSSTACK_HOME and scratch root; no default control-plane home is touched.

Independent reviewer owns separate frozen old/new vectors. This author package does not claim those results. Source remains uncommitted for root integration.
