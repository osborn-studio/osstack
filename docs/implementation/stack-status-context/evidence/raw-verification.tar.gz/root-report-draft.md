## Bounded execution and attribution

Author60495 changes stack.ts and stack.test.ts; root6f74 cherry-pick is byte-identical, rootbda adds a patch changeset. Same33 tests on old source produced12 failures/21 passes, then all33 passed after the fix; the original107-test GitHub package grew to125 for that branch. Root composition includes the previous candidate-snapshot tool, so root GitHub count170 is a different package population, not125 relabeled.

The independent36 frozen classification vectors had old27pass/9fail then new36pass. Undefined input is a separate control. A three-PR real API call with an injected read-only runner verifies success/failure/pending propagation, drift issue kinds, topology and exactlythree expected argv calls. No actual GitHub, stack CLI or database access occurred. Existing CheckRun neutral/skipped semantics remain unchanged; unknown or missing legacy states are pending.

Actual Sonnet5.5 static PASS confirms scoped logic and tests, with optional suggestions retained. Its known pre-existing CheckRun conclusion/status gaps are outside this fix and not claimed resolved. The author changed two source paths; root adds release metadata and evidence. The audit has no runtime authority and doesn't replace test receipts.

Downstream source inspection shows new CLI cards store ci_state and a provenance comment, and runbook displays stored CI. Existing cards are skipped, so this repair does not refresh historical cards. A card's initial ready column is separate from its CI checklist, which remains pending; no automatic merge/CI-green consequence is claimed. detectDrift semantics were exercised offline, but no production CLI caller was found by the bounded source search.
