from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path(__file__).parent;pin='6c9a3e8f11f2664f15b4ce4a26c5014d68fdcd4b';repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack'
paths=['packages/github/src/stack.ts','packages/github/src/index.ts','packages/cli/src/stack-cli.ts','packages/cli/src/bin.ts','packages/core/src/kanban/repository.ts']
bind=[]
for f in paths:
 b=subprocess.check_output(['git','show',pin+':'+f],cwd=repo);p=r/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);bind.append({'path':f,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
a=['git','grep','-n','detectDrift',pin,'--','packages'];p=subprocess.run(a,cwd=repo,capture_output=True);(r/'detectDrift-references.txt').write_bytes(p.stdout);(r/'detectDrift-references-command.json').write_text(json.dumps({'argv':a,'exit_code':p.returncode},indent=2)+'\n')
(r/'report.md').write_text('''# StatusContext downstream source proof

Fixed main **6c9a3e8f11f2664f15b4ce4a26c5014d68fdcd4b**. This is static Git-source analysis only: no product import, classification execution, GitHub request, CLI invocation or DB access. It does not duplicate C’s behavioral classification tests.

## Actual ingestion and persistence path

1. `packages/github/src/stack.ts:70–73` accepts only optional `conclusion` and `status` in `RollupCheck`; a GitHub StatusContext `state` is not represented. Lines83–95 parse each row and treat missing conclusion as pending. **Static consequence:** a state-only SUCCESS, FAILURE or ERROR context is collapsed to pending; success appears still pending, and real failure loses its failing classification. CheckRun failures in the same array still take priority at85–88, so do not describe every mixed input as pending or claim this specific defect turns failure green.
2. `stack.ts:106–115` actually requests `gh pr view ... --json ...statusCheckRollup...`. Lines118–130 put the mapper result into `StackNode.ciState`; line163 returns that model. Topology/order is independently derived from branch names at141–154, not CI state.
3. `packages/cli/src/bin.ts:988–995` resolves a local state DB and dynamically loads `handleStackCommand`; `stack-cli.ts:41–45` routes ingest. `stack-cli.ts:128–131` invokes `ingestStack`; line139 opens the guarded DB after ingestion succeeds.
4. For a new card only (`stack-cli.ts:159–160` skips existing cards), lines163–179 call `KanbanRepository.createCard`, persisting `meta.ci_state=node.ciState` at174. Lines185–188 also store the same value in the ingestion provenance comment. `packages/core/src/kanban/repository.ts:83–112` preserves input.meta and writes it into `kanban_cards.meta`. Thus the misclassification has a real persistence call path, not merely a test-only field. **No actual stored card was inspected or modified in this task.**
5. `stack-cli.ts:181–182` seeds verification checklist items, but `repository.ts:220` defaults them to pending. `stack-cli.ts:168` creates the card with status ready regardless of CI state. This code does **not** automatically mark the “CI green” checklist passed based on `ci_state`; “ready” card status is not proof of CI readiness. Re-ingest skips existing cards and does not refresh their metadata, so fixing classification alone cannot be claimed to repair historical stored cards.

## Display and drift consumers

- `stack-cli.ts:456–473` runbook reads cards in topology order, parses stored meta at469/447–450, and renders `ci_state` at421–425. A misclassified snapshot can therefore be shown as `ci: pending` in the merge runbook. No fresh forge observation happens in this display path.
- `stack-cli.ts:217–244` board rendering shows title/type and checklist pass counts; it does **not** directly print the CI meta string. Avoid claiming this bug changes board pass-count display.
- `stack.ts:202` exported `detectDrift` consumes a supplied model. Lines237–242 emit `ci_failing` only for failure;245–250 emit `ci_pending` only for pending;263 computes clean from all accumulated issues. Hence a state-only failure is represented as pending drift rather than failing drift; a state-only success can introduce false pending drift. Other conflict/orphan findings remain independent.
- Search of all tracked packages at this pin finds `detectDrift` definition and tests/changelogs only, with public export through `packages/github/src/index.ts:5`. **No production CLI caller of detectDrift was found.** Do not say `stack ingest` invokes it or automatically blocks/merges PRs based on it. It is an available library consumer with test coverage, not an observed live control path.

## Impact limits

Supported source-level impact: wrong coarse CI metadata and provenance text on newly ingested cards, misleading stored runbook CI label, and incorrect drift issue kind when the exported drift function is used. Not demonstrated here: a real user's affected DB row, current forge condition, automatic PR merge/approval, runtime watcher behavior, or stored-data backfill. The narrow fix should be verified at the mapper/ingest-model boundary; any historical metadata refresh is separate authorized work.
''')
report={'pin':pin,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':bind,'analysis':'Static call-chain and consumer review only; no function/test/CLI/DB execution.','findings':['State-only StatusContext state omitted; null conclusion causes pending','ingestStack ciState flows to new-card meta and provenance comment','Existing cards skipped on re-ingest','Runbook reads stored ci_state; board prints checklist counts instead','detectDrift exported but no production caller found in tracked packages','No automatic CI-green checklist promotion or PR merge demonstrated']}
(r/'source-bindings.json').write_text(json.dumps(report,indent=2)+'\n')
fs=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(r.rglob('*'))if p.is_file() and p.name!='manifest.json'];(r/'manifest.json').write_text(json.dumps({'files':fs},indent=2)+'\n')
for n in ['report.md','manifest.json']:print(n,hashlib.sha256((r/n).read_bytes()).hexdigest())
