import { mapRollupToCheckState, ingestStack, detectDrift } from '/Users/osborn/Developer/CodeX/.worktrees/osstack/pr-candidate-snapshot-author/packages/github/dist/stack.js';
const rows = [];
for (const state of ['SUCCESS', 'FAILURE', 'ERROR', 'PENDING', 'EXPECTED']) {
  const rollup = [{ __typename: 'StatusContext', context: 'legacy-ci', state, targetUrl: 'https://example.invalid/build/1' }];
  const expected = state === 'SUCCESS' ? 'success' : ['FAILURE', 'ERROR'].includes(state) ? 'failure' : 'pending';
  const calls = [];
  const model = await ingestStack({ repo: 'fixture/repo', prNumbers: [1] }, { run: async (command, args) => {
    calls.push({ command, args, executed: false });
    return JSON.stringify({ number: 1, state: 'OPEN', baseRefName: 'main', headRefName: 'feature', mergeable: 'MERGEABLE', mergeStateStatus: 'CLEAN', statusCheckRollup: rollup, title: 'fixture', url: 'https://example.invalid/pr/1' });
  } });
  rows.push({ input: rollup, expected, actual: mapRollupToCheckState(rollup), ingested: model.nodes[0].ciState, drift: detectDrift(model), calls });
}
const controls = [
  { input: [{ conclusion: 'SUCCESS', status: 'COMPLETED' }], expected: 'success' },
  { input: [{ conclusion: 'FAILURE', status: 'COMPLETED' }, { __typename: 'StatusContext', state: 'SUCCESS', context: 'legacy-ci' }], expected: 'failure' },
  { input: [{ conclusion: 'NEUTRAL', status: 'COMPLETED' }, { conclusion: 'SKIPPED', status: 'COMPLETED' }], expected: 'success' },
].map(r => ({ ...r, actual: mapRollupToCheckState(r.input) }));
console.log(JSON.stringify({ kind: 'synthetic_forge_shape_real_current_implementation', live_forge_calls: 0, db_calls: 0, rows, controls }, null, 2));
