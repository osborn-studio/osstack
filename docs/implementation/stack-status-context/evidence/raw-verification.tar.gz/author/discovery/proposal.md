# Next small delivery: correct legacy GitHub status classification

Main `6c9a3e8f11f2664f15b4ce4a26c5014d68fdcd4b` ignores `StatusContext.state` in `mapRollupToCheckState`. The offline reproduction uses the real compiled mapper and `ingestStack` (injected forge runner); all three SUCCESS/FAILURE/ERROR statuses currently become pending. PENDING/EXPECTED and existing CheckRun controls behave as expected. Source bytes are bound to main in bindings.json; no stack CLI or DB was opened.

This affects existing stack ingestion and its initial card `ci_state`. A failed legacy integration can be presented as still pending, and a completed success can remain pending. It does not establish a live forge incident, nor does this analysis claim the new candidate snapshot has this defect.

Fix only `packages/github/src/stack.ts` and its existing test. Preserve public APIs and CheckRun neutral/skipped policy; honor the separate StatusContext state vocabulary and never upgrade absent/unknown states to success. Keep failure precedence in mixed rollups. Test both mapper and ingestion output with injected runner, then package-focused tests/build. Root owns independent audit, changeset and full regression.

The original source pstack `skills/poteto-mode/scripts/watch-pr/github.ts` at99b609a already separates CheckRun and StatusContext (lines275–305), supporting this concrete adaptation. No copied implementation, watcher, new method or runtime authority is needed. `detectDrift.clean` remains its existing limited drift report, not merge authorization.

Preflight had two read-only locator mistakes: short Git prefix `6c9` did not resolve; one OSStack Git lookup was accidentally issued in the upstream repository and failed. The successful source reads and actual reproduction use the full SHA and correct repository, with no product edits.
