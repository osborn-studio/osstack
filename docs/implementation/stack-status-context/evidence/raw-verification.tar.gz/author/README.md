# Stack StatusContext repair evidence

Candidate `60495d82b6f3190a47d840906795647395ed7151`, based on actual main `6c9a3e8f11f2664f15b4ce4a26c5014d68fdcd4b`. Only `packages/github/src/stack.ts` and `stack.test.ts` changed. The same 33 focused tests first produced 12 failures/21 passes, then all 33 passed after the minimal normalization fix. The GitHub package's 125 tests and tsc build passed. The original CheckRun neutral/skipped success policy is preserved; absent and unknown context states remain conservatively pending.

The source discovery records are copied verbatim from their original scratch location, with the original manifest and source hashes. The old compiled module path is historical provenance, not a requirement that its already-released worktree remain. This repair's RED/GREEN test command runs in the current author worktree and executes the actual mapper and ingestion code with injected forge responses. It does not open the stack CLI or DB, contact GitHub, run a model, or run the full repository suite.

The upstream flow at pstack99b609a distinguishes CheckRun from StatusContext. No upstream implementation body is copied into this production fix. Original upstream source retained in discovery is accompanied by its MIT license here. Root owns audit, central integration, changeset and publication. Independent criteria remain independently owned.
