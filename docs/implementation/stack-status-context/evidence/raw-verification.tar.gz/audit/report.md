# Verdict: PASS (static only, no blockers)

This is a source-only review. I executed nothing and infer no runtime result, including for the root full suite.

## Correctness of the fix

- **Root cause matches.** Before the fix, a `StatusContext` row had no `conclusion` and no `status`, so `conclusion == null` made every row pending. That fits your reproduction, with SUCCESS, FAILURE and ERROR all reported as pending.
- **State mapping follows GitHub's `StatusState` enum.**
  - SUCCESS → success.
  - FAILURE and ERROR → failure.
  - PENDING and EXPECTED → pending. EXPECTED means a required status that hasn't reported, so pending is right.
- **Failure precedence is preserved.** Legacy failures are rewritten to `conclusion: "FAILURE"`, which is already in `FAILING_CONCLUSIONS`. The `hasFailure` check still runs before `hasPending`, so failure dominates in every ordering.
- **CheckRun policy is untouched.** Rows that don't take the legacy branch are returned unchanged. NEUTRAL and SKIPPED therefore still count as success, and the pending/in-progress logic is as before.
- **Missing or unknown legacy state is conservative.** A typed `StatusContext` with a missing, null or unknown state becomes pending, even if it carries stray CheckRun-shaped fields. That is the safe direction, since it can't turn into a false success.
- **Typename-less heuristic is narrow.** It only fires when `state !== undefined`, so all existing `{conclusion, status}` fixtures and real CheckRun rows (which have no `state`) are unaffected.
- **Types look sound.** The `map` callback returns a union of object shapes, and `conclusion` and `status` exist on every member, so the downstream `.some` narrowing should typecheck.
- **Parse behavior.** The two new schema fields are optional and tolerant. The only behavior change is that a non-string `state` or `__typename` on a row now throws instead of being stripped. GitHub doesn't emit that.

## Tests

- The table tests cover all five enum states.
- Ordering and dominance cases are covered: legacy failure over a pending CheckRun, CheckRun failure over pending and successful contexts, and legacy success not hiding a pending CheckRun.
- The neutral/skipped policy is covered beside a legacy success.
- The end-to-end test runs through `ingestStack` and `detectDrift` with a mocked runner. I traced the expected values by hand:
  - A single PR with base `main` is root-exempt, so there is no orphan issue.
  - The issue kinds come out as `[]`, `ci_failing` or `ci_pending` as asserted.
  - The runner is called once with `gh pr view 9`.

## Blockers

None.

## Optional suggestions

1. **Tighten the unknown-state assertion.** `.not.toBe("success")` would also pass if the result were "failure" or "unknown". Asserting `toBe("pending")` pins the intended behavior.
2. **Add two cases.**
   - A typed context with `state: "FAILURE"` and stray `conclusion: "SUCCESS"` should give failure, which shows the state wins over CheckRun-shaped fields.
   - A typename-less row with `state: null` or an unknown state should give pending, which covers the heuristic branch for non-SUCCESS values.
3. **Formatting risk.** The new code is denser than the surrounding code:
   - The `if (check.__typename === ...)` line and the two `return` lines are over about 100 columns.
   - The tests use one-line tables and multiple statements per line.
   - `state =>` and `row =>` drop the parentheses the file uses elsewhere.

   If the full suite or CI includes a prettier or biome check, this could fail it, so run the repo formatter. I can't tell from the files whether that check is gated.
4. **Scope wording.** The change is two source files plus `.changeset/legacy-stack-status-context.md`, so it is three files rather than two. I couldn't verify from the supplied files that `@osstack/github` is the correct package name in the changeset.
5. **Pre-existing gaps, out of scope.** I would not fix these here.
   - Conclusions such as `ACTION_REQUIRED`, `STALE` and `STARTUP_FAILURE` are not in `FAILING_CONCLUSIONS`.
   - CheckRun statuses such as `WAITING` and `REQUESTED` are not in `IN_PROGRESS_STATUSES`.
   - An empty-string `conclusion` is not treated as null.

   Each of these can read as success. That is consistent with your instruction to preserve the legacy CheckRun policy, but it could be a follow-up.
6. **Case sensitivity.** State matching is case-sensitive. `gh` emits uppercase enum values, so this is fine today, and a lowercase state degrades to pending, which is safe.