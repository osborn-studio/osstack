# Independent StatusContext regression check

The narrow defect is reproduced on main6c9 and fixed by60495d82: **36 frozen vectors: old27 pass/9 fail; candidate36 pass/0 fail**. A separately declared undefined-rollup control also passes on both. Same inputs and harness were used; original failures remain preserved.

A three-PR scenario exercises actual public ingestStack and detectDrift with an offline runner. The old baseline misclassifies SUCCESS and ERROR contexts as pending; the candidate gives success/failure/pending and corresponding drift issues. The three fixed read commands, ref topology, edges and bottom-up order are unchanged. No GitHub call or DB persistence was exercised.

CheckRun neutral/skipped policy remains successful as required, and pending/failure priority, reversed mixed rows, unknown/missing context and malformed/empty inputs are covered. The author and root6f74/bda production stack source hashes agree; candidate changes onlystack.ts/test.ts.

Old Git source was transpiled in scratch with unchanged dependency modules; new candidate uses recorded author dist. This is bounded regression evidence, not a full rebuild or proof of every downstream database effect. No confirmed new issue. No model/full/forge/DB activity or product edits.
