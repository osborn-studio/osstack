# Stack StatusContext independent criteria

**SC01 Map five StatusContext states** — FAILURE and ERROR -> failure; SUCCESS -> success; PENDING and EXPECTED -> pending. Apply to realistic gh rollup state/context fields, with and without optional __typename.

**SC02 Order-independent mixed aggregation** — Any recognized failure dominates success/pending; pending dominates only successful known rows. Reverse order does not change result. StatusContext SUCCESS cannot hide CheckRun failure or queued, and vice versa.

**SC03 Existing CheckRun compatibility** — Keep known success/failure/cancelled/timedout/error semantics, pending queued/in_progress/null conclusion. Existing neutral and skipped completed rows remain allowed success; do not import stricter snapshot policy.

**SC04 Unknown and missing context** — Future or absent StatusContext.state never becomes success; pending or unknown is acceptable without inventing new gate policy. Unsupported non-string values may be rejected; must not clear.

**SC05 Absent and malformed rollup** — Non-array/empty/absent top-level rollup stays unknown. Malformed entry null/string remains a parse failure as baseline, not a silently healthy row.

**SC06 Real public ingress surface** — Inject existing CommandRunner into ingestStack with realistic gh JSON. Node ciState reflects state mapping and detectDrift produces ci_failing or ci_pending correctly; no DB persistence claim.

**SC07 Topology and command preservation** — Three PR ref chain/order/edges unchanged. Only existing gh pr view fixed JSON fields and optional repo query; returned strings are data. No added writes, retry, DB, policy, watch or merge behavior.

**SC08 Regression proof** — Known old baseline should fail state FAILURE/ERROR/SUCCESS expectations; same fixed input should meet candidate expectation. Old PENDING/EXPECTED and CheckRun controls retained. This proves narrow existing defect, not every downstream consequence.

**SC09 Source and evidence binding** — Bind exact old/candidate Git and compiled module hashes, original inputs, actual output/exit and command. Preserve harness mistakes separately. Independent code inspection does not assert production DB updates or actual GitHub execution.

**SC10 Scope separation** — Existing PR candidate snapshot has different skipped/neutral and qualification semantics and must remain unchanged. Upstream provides StatusContext shape/reference only; no automatic merge/watch permission is imported. No formal principal certification.

Freeze is before independent candidate inspection/execution; it does not assert unknown author editing timestamps. Upstream references supply shape and rationale, not permission to run their workflow. Unknown context stays non-success; neutral/skipped CheckRun policy remains local.
