# Fixed journey projection independent oracle

Frozen before author implementation. See criteria-prefreeze.json for15 falsifiable vectors and source-inputs.json for exact original Git and real/seamed evidence hashes. Only packet.json and manifest.json are allowed. Closed semantics include fixed two case IDs, actual versus reported nullable exits, verification/journey/cleanup enums, descendant not_attested, declared binding digests, logical original IDs/hash and strictly safe exact bounded output excerpts. Unknown input text is not forwarded.

Failures are data: a doctor failure/not_run case and a failed driver with unverified reported exit/unknown cleanup must remain visible. A missing receipt in a claimed passed/sealed case is an integrity failure, unlike a legitimate not_created case. Resealed malicious packet keys, extra files, path references and unsafe snippets must fail the standalone check. Complete machine records remain outside the model packet.

No product/default home/model run is authorized by this oracle. No compiler, live cleanup, authenticated history, formal principal or J gate is granted. The packet is a bounded derivative for reading, not a replacement for machine audit originals. Schema property spelling and finite size thresholds may be chosen by author before candidate freeze; semantic allowlist and rejection expectations stay fixed.
