# Independent first projection candidate review

Candidate1038dc9a0f79696d4077064181321de7501b7cb8: **REVISE**. Frozen criteria dea3d5b2…;33 real CLI invocations,31 expected results and2 unexpected acceptances. Worktree and all original input files remained unchanged.

Confirmed closed-schema consistency gaps:

1. A not_run row with cleanup.status=not_started and fixture_removed=true passes --check after manifest resealing. The packet contradicts its own unstarted state.
2. A passed healthy row can expose the exact allowlisted line “1 source(s) failed to check.” while still claiming healthy/product0; resealing and recomputing omitted-byte arithmetic passes --check. Safe textual grammar is not enough to reject internally contradictory selected evidence.

These are internal semantic contradictions under P11, not an attempt to authenticate a fully re-signed fictitious history. A coherent maliciously re-authored packet remains outside this tool's authenticity claim.

Observed positive behavior: exact real66ad pair projects/checks with products0/1, drivers0/0; doctor failure preserves later not_run; historical failed-driver seam preserves unverified reported0 and unknown cleanup. Portable packet checks work without reading originals. Injected nested environment, extra/hidden files, local path/URL snippets, unknown types/statuses, duplicate case, non-null not_run product, excessive lines, missing stream, file symlinks, hash mismatch, missing receipt/raw, traversal, overlapping/existing output and oversize/deep unknown data were rejected. Canary absolute path/environment/instruction text in raw stdout was omitted while original raw hash remained bound.

Each invocation has argv/cwd/explicit environment/timestamps/exit/stdout/stderr/hash records. All input variants and exact packet reseals are retained. Failure fixtures are previously recorded invoke seams, not new failed product execution. No full tests, models, default home/DB or product edits occurred; no formal independent-principal/J gate is issued.
