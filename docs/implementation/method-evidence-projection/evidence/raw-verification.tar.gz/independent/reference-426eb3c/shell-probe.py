from pathlib import Path
import re,subprocess,json,hashlib,datetime,shlex
O=Path(__file__).resolve().parent;S=O/'shell';S.mkdir();B=S/'bin';B.mkdir();node=B/'node';node.write_text('#!/usr/bin/python3\nimport os,sys,json\nprint(json.dumps({"argv":sys.argv[1:],"scratch_root":os.environ.get("OSSTACK_SCRATCH_ROOT"),"cwd":os.getcwd()}))\nprint("owned observer stderr",file=sys.stderr)\nsys.exit(int(os.environ.get("OBSERVER_EXIT","0")))\n');node.chmod(0o755)
source=(O/'reference-source.md').read_text();snippet=re.search(r'```sh\n(.*?)\n```',source,re.S).group(1);(S/'exact-snippet.sh').write_text(snippet+'\n');out=[]
for name,value,exitvalue in [('unexported-absolute',str(S/'new root with spaces'),0),('unset',None,0),('empty','',0),('relative','relative-owned',0),('driver-failure',str(S/'failed root'),7)]:
 cwd=S/name;cwd.mkdir();prefix='' if value is None else 'OSSTACK_SCRATCH_ROOT='+shlex.quote(value)+'\n';body=prefix+snippet+'\n';p=cwd/'probe.sh';p.write_text(body)
 env={'PATH':str(B)+':/usr/bin:/bin','HOME':str(O/'home'),'OBSERVER_EXIT':str(exitvalue)};argv=['/bin/bash','--noprofile','--norc',str(p)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=10);(cwd/'shell.stdout').write_bytes(r.stdout);(cwd/'shell.stderr').write_bytes(r.stderr);row={'name':name,'argv':argv,'cwd':str(cwd),'environment':env,'started_at':start,'exit_code':r.returncode,'snippet_sha256':hashlib.sha256((snippet+'\n').encode()).hexdigest(),'kind':'real shell, observer node substitute; no product execution'}
 if name in ['unexported-absolute','driver-failure']:
  logs=list((Path(value)/'runtime').glob('*.stdout'));assert len(logs)==1;observed=json.loads(logs[0].read_text());output=Path(observed['argv'][2]);assert observed['argv'][:2]==['scripts/method-verification-journey.mjs','--output'];assert observed['scratch_root']==value;assert output.parent==Path(value)/'runtime';assert not output.exists();assert Path(str(output)+'.stderr').read_text()=='owned observer stderr\n';assert r.returncode==exitvalue;row.update(observer=observed,output_not_precreated=True,stdout_stderr_siblings_retained=True)
 else:
  assert r.returncode!=0;assert not(cwd/'relative-owned').exists();row.update(rejected_before_node=True)
 (cwd/'command.json').write_text(json.dumps(row,indent=2)+'\n');out.append(row)
(S/'results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps([{'name':r['name'],'exit_code':r['exit_code']} for r in out],indent=2))
