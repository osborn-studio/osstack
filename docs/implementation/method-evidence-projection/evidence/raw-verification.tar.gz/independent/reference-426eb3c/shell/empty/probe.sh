OSSTACK_SCRATCH_ROOT=''
export OSSTACK_SCRATCH_ROOT="${OSSTACK_SCRATCH_ROOT:?Set an absolute owned scratch path first}"
case "$OSSTACK_SCRATCH_ROOT" in
  /*) ;;
  *) printf '%s\n' 'OSSTACK_SCRATCH_ROOT must be absolute' >&2; exit 2 ;;
esac
mkdir -p "$OSSTACK_SCRATCH_ROOT/runtime" || exit 1
journey_output="${OSSTACK_SCRATCH_ROOT:?}/runtime/skills-check-journey-$(date -u +%Y%m%dT%H%M%SZ)-$$"
node scripts/method-verification-journey.mjs --output "$journey_output" > "$journey_output.stdout" 2> "$journey_output.stderr"
