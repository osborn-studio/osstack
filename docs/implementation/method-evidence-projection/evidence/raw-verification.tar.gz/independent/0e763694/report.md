# Independent replay at 0e763694

Candidate: `0e763694c7bed7d3c3aa61c7fdb9d03bcc906402`. Criteria: `dea3d5b26124a97cf0dfba60cbe852a4fd167293231472b24790498354c3361e`.

Replayed the original 33 command-level observations against the revised candidate: 33 met their recorded expectations, zero unexpected outcomes. The two original unexpected accepts (`notrun-removed`, `passed-failure-summary`) now reject with exit 1. Original 1038dc9a records remain unchanged. Commands, original input inventory, source snapshots, mutations and stdout/stderr are retained alongside results.json.

This closes those two specific contradictions, not all possible retained-record inconsistencies. New Sonnet findings and later tests belong to a separate post-audit scope. Successful projection/check proves bounded retained-byte/schema checks; it does not authenticate a historical claim or rerun a product, model, compiler, cleanup or formal oracle. The historical negative inputs are previously retained seam observations, not new product failures. All original input inventories and worktree status were unchanged. No full suite, model, management instance or default home was used.

Archive caution: scratch contains intentional test symlinks to owned sentinels. The manifest records these as links without following them; a publication packager must preserve their test meaning safely rather than follow arbitrary links.
