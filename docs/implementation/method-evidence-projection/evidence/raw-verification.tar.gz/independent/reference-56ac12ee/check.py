from pathlib import Path
import subprocess,json,hashlib,datetime,re,urllib.parse
O=Path(__file__).resolve().parent;W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-journey-reference');C='56ac12ee0cc1a5675008812964efd3d4e3945d79';NODE='/opt/homebrew/opt/node@22/bin/node';sha=lambda b:hashlib.sha256(b).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==C;before=subprocess.check_output(['git','status','--porcelain'],cwd=W);env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(O/'home'),'OSSTACK_HOME':str(O/'unused-home'),'OSSTACK_SCRATCH_ROOT':str(O/'scratch')};(O/'home').mkdir();(O/'scratch').mkdir();results=[]
def run(name,argv):
 r={'argv':argv,'cwd':str(W),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};x=subprocess.run(argv,cwd=W,env=env,capture_output=True,timeout=30);(O/(name+'.stdout')).write_bytes(x.stdout);(O/(name+'.stderr')).write_bytes(x.stderr);r.update(exit_code=x.returncode,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(x.stdout),stderr_sha256=sha(x.stderr));(O/(name+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');assert x.returncode==0;return x
source='osstack-methods-skill/references/skills-check-journey.md';original=subprocess.check_output(['git','show',C+':'+source],cwd=W);assert(W/source).read_bytes()==original;(O/'reference-source.md').write_bytes(original)
for host,ns in [('codex','.agents'),('claude','.claude')]:
 dest=O/host;x=run('export-'+host,[NODE,str(W/'scripts/export-osstack-methods.mjs'),'--host',host,'--output',str(dest)]);receipt=json.loads(x.stdout);assert receipt['exported']and not receipt['installed']and not receipt['host_discovery_verified'];m=json.loads((dest/'manifest.json').read_text());assert len(m['files'])==52;graph={};edges=0
 for f in m['files']:
  p=dest/f['path'];b=p.read_bytes();assert len(b)==f['bytes']and sha(b)==f['sha256'];targets=[]
  for t in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)',b.decode()):
   u=urllib.parse.urlsplit(t)
   if u.scheme or u.netloc or not u.path:continue
   q=(p.parent/urllib.parse.unquote(u.path)).resolve();assert q.is_relative_to(dest.resolve())and q.is_file();targets.append(q);edges+=1
  graph[p.resolve()]=targets
 reach=[]
 for entry in ['osstack-mode','osstack-help','setup-osstack','osstack-agent']:
  start=(dest/ns/'skills'/entry/'SKILL.md').resolve();own=(start.parent/'references/skills-check-journey.md');assert own.read_bytes()==original;queue=[start];seen=set()
  while queue:
   q=queue.pop()
   if q in seen:continue
   seen.add(q);queue+=graph.get(q,[])
  hits=[q for q in seen if q.name=='skills-check-journey.md'];assert hits;reach.append({'entry':entry,'own_copy_exact':True,'reachable_through_bundle':True})
 results.append({'host':host,'files':52,'edges':edges,'reachability':reach})
run('focused-tests',[NODE,'--test','--test-name-pattern=D2a|verification creation, maintenance|documented journey invocation','scripts/export-osstack-methods.test.mjs'])
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==before
out={'candidate':C,'reference_source_sha256':sha(original),'commands_from_reference':['node scripts/method-verification-journey.mjs --output "$journey_output"'],'export_checks':results,'worktree_status_unchanged':True,'no_model_calls':True,'no_real_driver_run_in_this_review':True};(O/'results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
