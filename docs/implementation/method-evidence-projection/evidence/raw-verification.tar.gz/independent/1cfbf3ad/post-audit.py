from pathlib import Path
import json,hashlib,subprocess,shutil,datetime,re
O=Path(__file__).resolve().parent; P=O/'post-audit';P.mkdir();S=P/'scratch';S.mkdir();W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-evidence-projection');C='1cfbf3ade5d9b6de1c2c42cd92788c1c552e235e';NODE='/opt/homebrew/opt/node@22/bin/node';SCRIPT=W/'scripts/project-method-journey-evidence.mjs';sha=lambda b:hashlib.sha256(b).hexdigest();get=lambda p:json.loads(p.read_text());put=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(O/'home'),'OSSTACK_HOME':str(O/'unused-home'),'OSSTACK_SCRATCH_ROOT':str(S)};results=[];sources=get(O.parent/'source-inputs.json')['input_roots'];real=Path(sources[0]['path']);before=subprocess.check_output(['git','status','--porcelain'],cwd=W);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==C

def invoke(name,args,expected=1,reason=None):
 row={'name':name,'classification':'post-audit additional, not original prefreeze','argv':[NODE,str(SCRIPT)]+args,'cwd':str(W),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};x=subprocess.run(row['argv'],cwd=W,env=env,capture_output=True,timeout=8);(P/(name+'.stdout')).write_bytes(x.stdout);(P/(name+'.stderr')).write_bytes(x.stderr);observed=json.loads(x.stderr if x.returncode else x.stdout);ok=x.returncode==expected and (reason is None or observed.get('error')==reason);row.update(exit_code=x.returncode,expected_exit=expected,expected_reason=reason,observed_summary=observed,met_expectation=ok,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(x.stdout),stderr_sha256=sha(x.stderr));put(P/(name+'.command.json'),row);results.append(row);print(name,x.returncode,observed.get('error',''),ok,flush=True);return x

def packet(name,mut,base='real-pair',reason=None):
 d=S/name;shutil.copytree(O/'scratch'/base,d);j=get(d/'packet.json');mut(j);put(d/'packet.json',j);b=(d/'packet.json').read_bytes();put(d/'manifest.json',{'schema_version':1,'files':[{'path':'packet.json','bytes':len(b),'sha256':sha(b)}]});invoke(name,['--check',str(d)],reason=reason)

packet('A01-failed-cleanup-passed',lambda p:p['features'][0]['cleanup'].update(status='passed',fixture_removed=True),'driver-failed-reported-unknown','unverified_cleanup_claim')
for key,value in [('reported_product_exit',0),('reported_cleanup',{'status':'passed','fixture_removed':True,'descendant_termination':'not_attested'}),('receipt_cleanup_consistent',True),('bindings',{'source_digest':'a'*64,'build_digest':None})]:
 packet('A02-notcreated-'+key,lambda p,k=key,v=value:p['features'][1].update({k:v}),'doctor-failed-not-run','not_created_claim')
packet('A03-passed-reported-exit',lambda p:p['features'][0].update(reported_product_exit=0),reason='packet_passed_claim')

def edit(p,mut):
 d=get(p);mut(d);put(p,d)
def reseal(d):
 for case in (d/'cases').iterdir():
  if not case.is_dir():continue
  m=get(case/'manifest.json');m['files']=[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f in sorted(case.iterdir()) if f.is_file() and f.name!='manifest.json'];put(case/'manifest.json',m)
 m=get(d/'journey-manifest.json')
 for entry in m['case_manifests']:entry['sha256']=sha((d/'cases'/entry['case_id']/'manifest.json').read_bytes())
 j=get(d/'journey.json');j['retained']['case_manifests']=m['case_manifests']
 for f in j['features']:
  if f.get('manifest_sha256'):f['manifest_sha256']=next(e['sha256'] for e in m['case_manifests'] if e['case_id']==f['case_id'])
 put(d/'journey.json',j);m['files']=[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f in sorted(d.iterdir())if f.is_file()and f.name!='journey-manifest.json'];put(d/'journey-manifest.json',m)
def source(name,mut,expected=1,reason=None):
 d=S/('input-'+name);shutil.copytree(real,d);mut(d,d/'cases/healthy');reseal(d);out=S/('out-'+name);invoke(name,['--input',str(d),'--output',str(out)],expected,reason);return d,out

def failed_driver_pass(d,c):
 j=get(d/'journey.json');j['status']='failed';j['failure']={'message':'scratch_residue'}
 for f in j['features']:f['journey_status']='failed'
 f=j['features'][0];f.update(verification='failed',product_exit=None,product_status='unknown',reported_product_exit=0,cleanup={'status':'unknown','descendant_termination':'not_attested'});put(d/'journey.json',j)
 edit(d/'journey-manifest.json',lambda m:m['case_manifests'][0].update(verified=False))
d,out=source('A04-driver-passed-verifier-failed',failed_driver_pass,0);p=get(out/'packet.json');assert p['journey_status']=='failed'and p['features'][0]['verification']=='failed'and p['features'][0]['product_exit']is None and p['features'][0]['reported_product_exit']==0 and p['features'][0]['cleanup']['status']=='unknown'and p['features'][0]['reported_cleanup']['status']=='passed';invoke('A04-portable-check',['--check',str(out)],0)
source('A05-run-status',lambda d,c:edit(c/'run.json',lambda x:x.update(status='failed')),reason='run_state')
source('A06-run-bindings-unchanged',lambda d,c:edit(c/'run.json',lambda x:x.update(bindings_unchanged=False)),reason='run_bindings')
source('A07-run-final-bindings',lambda d,c:edit(c/'run.json',lambda x:x['final_bindings'].update(source_digest='a'*64)),reason='run_bindings')
source('A08-receipt-failure',lambda d,c:edit(c/'receipt.json',lambda x:x.update(failure={'message':'retained failure'})),reason='receipt_result')
source('A09-receipt-behavior',lambda d,c:edit(c/'receipt.json',lambda x:x.update(behavior='failed')),reason='receipt_result')
for name in ['manifest.json','receipt.json','run.json']:
 source('A10-id-'+name.replace('.','-'),lambda d,c,n=name:edit(c/n,lambda x:x.update(run_id='11111111-1111-4111-8111-111111111111')),reason='run_identity')
source('A11-input',lambda d,c:edit(c/'healthy.input.json',lambda x:x['sources'][0].update(id='missing-ref')),reason='input_identity')
source('A12-command-detail',lambda d,c:edit(c/'healthy.json',lambda x:x.update(exit_code=1)),reason='command_detail_conflict')

def cross_case(d,c,failed=False):
 c=d/'cases/missing-ref';b=get(c/'bindings.json');b['source']['files'][0]['sha256']='a'*64;b['source']['digest']=sha(json.dumps(b['source']['files'],ensure_ascii=False,separators=(',',':')).encode());put(c/'bindings.json',b);digest=b['source']['digest'];edit(c/'receipt.json',lambda x:x['binding_digests'].update(source_digest=digest));edit(c/'run.json',lambda x:(x['bindings'].update(source_digest=digest),x['final_bindings'].update(source_digest=digest)));j=get(d/'journey.json');j['features'][1]['bindings']['source_digest']=digest
 if failed:
  j['status']='failed';j['failure']={'message':'cross_case_bindings_changed'}
  for f in j['features']:f['journey_status']='failed'
 put(d/'journey.json',j)
source('A13-cross-case-passed',cross_case,reason='cross_case_bindings')
d,out=source('A13-cross-case-failed-retains-individual-pass',lambda d,c:cross_case(d,c,True),0);p=get(out/'packet.json');assert p['journey_status']=='failed'and all(f['verification']=='passed' for f in p['features'])and p['features'][0]['bindings']!=p['features'][1]['bindings'];invoke('A13-failed-portable-check',['--check',str(out)],0)
source('A14-missing-run',lambda d,c:(c/'run.json').unlink(),reason='required_evidence')
# Extra inventory entries: manifest still valid for original bytes; reject before output acquisition.
d=S/'input-A15-inventory';shutil.copytree(real,d)
for i in range(140):(d/('extra-%03d'%i)).write_text('x')
invoke('A15-inventory',['--input',str(d),'--output',str(S/'out-A15-inventory')],reason='directory_entry_limit');assert not(S/'out-A15-inventory').exists()
# Safe fixed error codes vs path-bearing filesystem errors; no canary text may escape.
invoke('A16-filesystem-error-redacted',['--check',str(S/'PRIVATE-CANARY-NONEXISTENT')],reason='projection_or_packet_validation_failed');assert b'PRIVATE-CANARY'not in(P/'A16-filesystem-error-redacted.stderr').read_bytes()
# Confirm read-only intent is not a false measured immutability field.
assert get(P/'A04-driver-passed-verifier-failed.command.json')['observed_summary']['input_opened_read_only']is True
assert 'original_evidence_modified'not in get(P/'A04-driver-passed-verifier-failed.command.json')['observed_summary']
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==before
unchanged=all(sha((Path(s['path'])/f['path']).read_bytes())==f['sha256']for s in sources for f in s['files']);assert unchanged
put(P/'results.json',{'candidate':C,'classification':'post-audit only','registered_expectations_sha256':sha((O.parent/'post-audit-expectations.json').read_bytes()),'results':results,'unexpected':[x['name']for x in results if not x['met_expectation']],'original_inputs_unchanged':unchanged,'worktree_status_unchanged':True,'no_product_driver_or_model_execution':True});print('unexpected:',[x['name']for x in results if not x['met_expectation']])
