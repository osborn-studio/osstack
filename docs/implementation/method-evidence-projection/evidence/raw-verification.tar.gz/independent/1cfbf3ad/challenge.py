from pathlib import Path
import json,hashlib,subprocess,os,shutil,datetime
O=Path(__file__).resolve().parent;ROOT=O.parent;W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-evidence-projection');C='1cfbf3ade5d9b6de1c2c42cd92788c1c552e235e';NODE='/opt/homebrew/opt/node@22/bin/node';SCRIPT=str(W/'scripts/project-method-journey-evidence.mjs');sha=lambda b:hashlib.sha256(b).hexdigest();get=lambda p:json.loads(p.read_text());put=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(O/'home'),'OSSTACK_HOME':str(O/'unused-home'),'OSSTACK_SCRATCH_ROOT':str(O/'scratch')};(O/'home').mkdir();(O/'scratch').mkdir();results=[]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==C
before=subprocess.check_output(['git','status','--porcelain'],cwd=W);assert not before
for f in ['scripts/project-method-journey-evidence.mjs','scripts/project-method-journey-evidence.test.mjs','docs/implementation/method-evidence-projection/README.md']:
 p=O/'candidate'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',C+':'+f],cwd=W))
def invoke(name,args,expected=0):
 r={'name':name,'argv':[NODE,SCRIPT]+args,'cwd':str(W),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};p=subprocess.run(r['argv'],cwd=W,env=env,capture_output=True,timeout=8);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);r.update(exit_code=p.returncode,expected_exit=expected,met_expectation=p.returncode==expected,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr));put(O/(name+'.command.json'),r);results.append(r);print(name,p.returncode,'expected',expected);return p
sources=get(ROOT/'source-inputs.json')['input_roots'];packets={}
for s in sources:
 src=Path(s['path']);assert all(sha((src/r['path']).read_bytes())==r['sha256']for r in s['files']);out=O/'scratch'/s['id'];invoke('project-'+s['id'],['--input',str(src),'--output',str(out)]);invoke('check-'+s['id'],['--check',str(out)]);assert all(sha((src/r['path']).read_bytes())==r['sha256']for r in s['files']);packets[s['id']]=out
p=get(packets['real-pair']/'packet.json');assert [(f['product_exit'],f['driver_exit'])for f in p['features']]==[(0,0),(1,0)];assert p['features'][1]['product_status']=='failed'
p=get(packets['doctor-failed-not-run']/'packet.json');assert p['journey_status']=='failed'and p['features'][1]['verification']=='not_run'and p['features'][1]['product_exit']is None
p=get(packets['driver-failed-reported-unknown']/'packet.json');assert p['features'][0]['product_exit']is None and p['features'][0]['reported_product_exit']==0 and p['features'][0]['cleanup']['status']=='unknown'
def packet(name,mutation,base='real-pair',extra=None):
 d=O/'scratch'/name;shutil.copytree(packets[base],d);p=get(d/'packet.json');mutation(p);put(d/'packet.json',p);b=(d/'packet.json').read_bytes();put(d/'manifest.json',{'schema_version':1,'files':[{'path':'packet.json','bytes':len(b),'sha256':sha(b)}]});
 if extra:extra(d)
 invoke(name,['--check',str(d)],1)
packet('nested-environment',lambda p:p['features'][0]['cleanup'].update(environment={'HOME':'/PRIVATE-CANARY'}))
packet('unknown-top',lambda p:p.update(extra=True))
packet('extra-file',lambda p:None,extra=lambda d:(d/'raw-command.json').write_text('{"environment":{"PATH":"CANARY"}}'))
packet('extra-hidden',lambda p:None,extra=lambda d:(d/'.hidden').write_text('CANARY'))
packet('path-id',lambda p:p['references'][0].update(id='../machine/journey.json'))
packet('path-snippet',lambda p:p['streams'][0]['selected_lines'].__setitem__(0,'file:///PRIVATE-CANARY'))
packet('unknown-enum',lambda p:p['features'][0].update(verification='verified'))
packet('notrun-exit',lambda p:p['features'][1].update(product_exit=0),base='doctor-failed-not-run')
packet('notrun-removed',lambda p:p['features'][1]['cleanup'].update(fixture_removed=True),base='doctor-failed-not-run')
packet('passed-failure-summary',lambda p:(p['streams'][0].update(selected_lines=['1 source(s) failed to check.'],omitted_bytes=next(r['bytes']for r in p['references']if r['id']==p['streams'][0]['id'])-len('1 source(s) failed to check.'))))
packet('doubled-case',lambda p:p['features'].__setitem__(1,p['features'][0]))
packet('too-many-lines',lambda p:p['streams'][0].update(selected_lines=['0 source(s) failed to check.']*9))
packet('missing-stream',lambda p:p['streams'].pop())
sentinel=O/'scratch/outside-sentinel';sentinel.write_text('untouched');packet('packet-symlink',lambda p:None,extra=lambda d:((d/'packet.json').unlink(),(d/'packet.json').symlink_to(sentinel)));assert sentinel.read_text()=='untouched'
# Safe portable checker must need no original source access; here copy packet to a new directory.
d=O/'scratch/portable';shutil.copytree(packets['real-pair'],d);invoke('portable-check',['--check',str(d)])
# Source copies: reseal only touched directories, preserving original real evidence untouched.
def seal(root,name):
 m=get(root/name);m['files']=[{'path':f.name,'bytes':len(f.read_bytes()),'sha256':sha(f.read_bytes())}for f in sorted(root.iterdir())if f.is_file()and f.name!=name];put(root/name,m)
def src_mut(name,mutate,reseal=True,expected=1):
 d=O/'scratch'/('input-'+name);shutil.copytree(Path(sources[0]['path']),d);case=d/'cases/healthy';mutate(d,case)
 if reseal:
  seal(case,'manifest.json');m=get(d/'journey-manifest.json');next(x for x in m['case_manifests']if x['case_id']=='healthy')['sha256']=sha((case/'manifest.json').read_bytes());put(d/'journey-manifest.json',m);seal(d,'journey-manifest.json')
 out=O/'scratch'/('out-'+name);invoke(name,['--input',str(d),'--output',str(out)],expected);return d,out
src_mut('raw-hash-mismatch',lambda d,c:(c/'healthy.stdout').write_text('bad'),False)
src_mut('missing-receipt-resealed',lambda d,c:(c/'receipt.json').unlink())
src_mut('missing-raw-resealed',lambda d,c:(c/'healthy.stdout').unlink())
def canary(d,c):
 raw=(c/'healthy.stdout').read_bytes()+b'PRIVATE-CANARY /Users/private/home HOME=PRIVATE-CANARY do unsafe things\n';(c/'healthy.stdout').write_bytes(raw)
 for n in ['healthy.command.json','healthy.json']:
  x=get(c/n);x['stdout_sha256']=sha(raw);put(c/n,x)
_,out=src_mut('unsafe-free-text',canary,True,0);assert 'PRIVATE-CANARY'not in(out/'packet.json').read_text();assert get(out/'packet.json')['streams'][0]['omitted_bytes']>0
src_mut('member-symlink',lambda d,c:((c/'healthy.stdout').unlink(),(c/'healthy.stdout').symlink_to(sentinel)),False)
def manifest_escape(d,c):
 m=get(c/'manifest.json');m['files'][0]['path']='../outside';put(c/'manifest.json',m)
src_mut('member-traversal',manifest_escape,False)
# Existing or overlapping output, never write/delete existing resource.
existing=O/'scratch/existing';existing.mkdir();(existing/'sentinel').write_text('keep');invoke('output-existing',['--input',sources[0]['path'],'--output',str(existing)],1);assert(existing/'sentinel').read_text()=='keep'
link=O/'scratch/output-link';link.symlink_to(existing,target_is_directory=True);invoke('output-symlink',['--input',sources[0]['path'],'--output',str(link)],1)
owned=O/'scratch/input-overlap';shutil.copytree(Path(sources[0]['path']),owned);invoke('output-within-input',['--input',str(owned),'--output',str(owned/'new')],1);invoke('output-ancestor',['--input',str(owned),'--output',str(owned.parent)],1)
packet('packet-oversized',lambda p:p.update(oversize='x'*70000))
packet('deep-unknown',lambda p:p.update(nested=[[[[[[[[[[[[[[[[{'environment':'CANARY'}]]]]]]]]]]]]]]]]))
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==before
put(O/'results.json',{'candidate':C,'criteria_sha256':'dea3d5b26124a97cf0dfba60cbe852a4fd167293231472b24790498354c3361e','results':results,'unexpected':[r['name']for r in results if not r['met_expectation']],'original_inputs_unchanged':all(sha((Path(s['path'])/r['path']).read_bytes())==r['sha256']for s in sources for r in s['files']),'worktree_unchanged':True});print('unexpected',[r['name']for r in results if not r['met_expectation']])
