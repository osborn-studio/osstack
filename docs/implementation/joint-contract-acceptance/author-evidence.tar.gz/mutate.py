from pathlib import Path
import os,json,subprocess,shutil,hashlib,re,datetime
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance');out=Path(__file__).parent;src=w/'packages/protocol';env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_HOME']=str(out/'home');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack'
mutations=[('control',None,None,None),('skip-expected-kind','joint-contracts.ts',lambda s:s.replace('if (value.kind !== kind)', 'if (false)'), 'JOINT_KIND_MISMATCH'),('skip-binding-identity','method-binding.ts',lambda s:re.sub(r"if \(binding.task_id.*?\) throw Error\('BINDING_PROPOSAL_MISMATCH'\);", "if (false) throw Error('BINDING_PROPOSAL_MISMATCH');",s,flags=re.S),'BINDING_PROPOSAL_MISMATCH'),('skip-role-binding','method-binding.ts',lambda s:re.sub(r"if \(!expected \|\|.*?\) throw Error\('BINDING_RECIPE_ROLE_MISMATCH'\);", "if (false) throw Error('BINDING_RECIPE_ROLE_MISMATCH');",s),'BINDING_RECIPE_ROLE_MISMATCH'),('drop-duplicate-key-check','joint-json.ts',lambda s:s.replace('Object.hasOwn(object, name) || ',''),'INVALID_JOINT_JSON'),('drop-domain-separator','joint-json.ts',lambda s:s.replace("domain + '\\n' + canonicalJointJson(value)","domain + canonicalJointJson(value)"),'digest')]

mutations += [
 ('fatal-utf8-disabled','joint-json.ts',lambda s:s.replace('fatal: true','fatal: false'),'raw bytes'),
 ('remove-number-safety','joint-json.ts',lambda s:s.replace('if (!Number.isSafeInteger(number) || Object.is(number, -0)) invalid();',''),'number rejection'),
 ('remove-unicode-validation','joint-json.ts',lambda s:s.replace('unicode(value); return value;', 'return value;'),'surrogate rejection'),
 ('remove-ascii-key-check','joint-json.ts',lambda s:s.replace('if ([...value].some(char => char.charCodeAt(0) > 127)) invalid();',''),'key rejection'),
 ('depth-off-by-one','joint-json.ts',lambda s:s.replace('const MAX_DEPTH = 64;', 'const MAX_DEPTH = 63;'),'positive boundary'),
 ('size-off-by-one','joint-json.ts',lambda s:s.replace('const MAX_BYTES = 1_048_576;', 'const MAX_BYTES = 1_048_577;'),'negative boundary'),
 ('source-locale-sort','joint-evidence.ts',lambda s:s.replace("Buffer.compare(Buffer.from(a.path, 'utf8'), Buffer.from(b.path, 'utf8'))", 'a.path.localeCompare(b.path)'),'locale sort'),
 ('source-utf16-sort','joint-evidence.ts',lambda s:s.replace("Buffer.compare(Buffer.from(a.path, 'utf8'), Buffer.from(b.path, 'utf8'))", 'a.path < b.path ? -1 : a.path > b.path ? 1 : 0'),'UTF16 sort'),
 ('lineage-locale-sort','joint-lifecycle.ts',lambda s:s.replace('[...v.expected_lineage_tables].sort()', '[...v.expected_lineage_tables].sort((a,b) => a.localeCompare(b))'),'ASCII sort'),
 ('remove-strict-shapes','joint-shapes.ts',lambda s:s.replace('.strict()', ''),'strict schema'),
 ('loose-schema-version','joint-shapes.ts',lambda s:s.replace('schema_version: z.literal(1)', 'schema_version: z.number()'),'version rejection'),
 ('remove-recipe-role-digest','method-binding.ts',lambda s:__import__('re').sub(r"  if \(Digest.safeParse.*?ROLE_REQUIREMENTS_DIGEST_MISMATCH'\);\n",'',s),'role digest'),
 ('remove-baseline-condition','method-binding.ts',lambda s:s.replace("  if (phase === 'candidate' && !v.baseline_artifact_ref) issue(ctx, 'MISSING_BASELINE');",''),'conditional field'),
 ('remove-trial-condition','method-binding.ts',lambda s:s.replace("  if ((v.mode === 'trial') !== (v.trial_permit_id !== undefined)) issue(ctx, 'TRIAL_PERMIT_MODE_MISMATCH');",''),'conditional field'),
 ('require-optional-budget','joint-shapes.ts',lambda s:s.replace('max_tokens: z.number().int().min(1).max(9007199254740991).optional()', 'max_tokens: z.number().int().min(1).max(9007199254740991)'),'optional field')
]

results=[]
for label,filename,transform,reason in mutations:
 target=out/'mutants'/label;target.mkdir(parents=True,exist_ok=True)
 for directory in ['src','fixtures','scripts','schemas']:shutil.copytree(src/directory,target/directory,dirs_exist_ok=True)
 shutil.copy2(src/'package.json',target/'package.json')
 if not (target/'node_modules').exists():(target/'node_modules').symlink_to(w/'node_modules',target_is_directory=True)
 shutil.copy2(w/'scripts/vitest-setup-scratch.ts',target/'scripts/vitest-setup-scratch.ts')
 (target/'packages/core/src').mkdir(parents=True,exist_ok=True)
 shutil.copy2(w/'packages/core/src/scratch.ts',target/'packages/core/src/scratch.ts')
 (target/'vitest.config.ts').write_text("import {defineConfig} from 'vitest/config'; export default defineConfig({test:{setupFiles:["+json.dumps('./scripts/vitest-setup-scratch.ts')+"]}});")
 if filename:
  path=target/'src'/filename;before=path.read_text();after=transform(before);assert before!=after,label;path.write_text(after)
 argv=[str(w/'node_modules/.bin/vitest'),'run','src/joint-reference.test.ts','src/joint-admission.test.ts','-t','JA59|JA70','--reporter=json','--outputFile='+str(out/(label+'.vitest.json'))]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:r=subprocess.run(argv,cwd=target,env=env,stdout=stdout,stderr=stderr,timeout=60)
 data=json.loads((out/(label+'.vitest.json')).read_text());failures=[a['fullName'] for suite in data['testResults'] for a in suite['assertionResults'] if a['status']=='failed']
 row={'candidate_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'test_source_sha256':{name:hashlib.sha256((target/'src'/name).read_bytes()).hexdigest() for name in ['joint-reference.test.ts','joint-admission.test.ts']},'mutated_source_sha256':hashlib.sha256((target/'src'/filename).read_bytes()).hexdigest() if filename else None,'label':label,'command':argv,'cwd':str(target),'started_at':start,'exit_code':r.returncode,'failed_tests':failures,'counts':{k:data.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests']},'expected':'pass' if filename is None else 'kill_by_test_failure','valid':r.returncode==0 if filename is None else r.returncode!=0 and bool(failures)};results.append(row)
 (out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n');print(label,row['counts'],row['valid'],flush=True)
assert all(r['valid'] for r in results)
