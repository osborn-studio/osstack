from pathlib import Path
import json,hashlib,copy,datetime
s=Path(__file__).parent;w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance');p=w/'packages/protocol/fixtures/joint/acceptance-oracle.json';d=json.loads((s/'acceptance-oracle.json').read_text());canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'));sha=lambda v:hashlib.sha256(v.encode()).hexdigest()
for r in d['component_matrix']:
 r['canonical_sha256']=sha(canon(r['sample']))
 r['identity_applicability']='binding/proposal/recipe association covered' if r['kind'] in ['method_binding','method_proposal','method_recipe'] else 'cross-record association not covered by this slice; structural validation only'
 r['role_applicability']='binding/proposal/recipe role association covered' if r['kind'] in ['method_binding','method_recipe'] else 'cross-record role association not covered by this slice'
 rules={}
 for f in r['optional']:
  error=None
  if r['kind']=='artifact' and f!='resource_ledger_ref':error='MISSING_BASELINE' if f=='baseline_artifact_ref' else 'MISSING_CANDIDATE_BINDING'
  if r['kind']=='method_binding':error='TRIAL_PERMIT_MODE_MISMATCH'
  if r['kind']=='recovery_receipt':error='EFFECT_IDENTITY_MISSING'
  rules[f]={'accepted':error is None,'error':error}
 r['optional_absence']=rules
# post-audit fixed raw inputs: boundaries and ordering adversaries authored before candidate edits/tests.
valid=[('ascii-order','{"a":2,"B":1,"a1":3,"a_b":4}','{"B":1,"a":2,"a1":3,"a_b":4}'),('depth64','['*64+'0'+']'*64,'['*64+'0'+']'*64),('object-depth64','{"a":'*64+'0'+'}'*64,'{"a":'*64+'0'+'}'*64)]
invalid=[('underflow','-9007199254740992'),('nested-duplicate','{"x":{"a":1,"a":2}}'),('escaped-non-ascii-key','{"\\u00e9":1}'),('formfeed-whitespace','\fnull'),('verticaltab-whitespace','\vnull'),('nbsp-whitespace','\u00a0null'),('object-depth65','{"a":'*65+'0'+'}'*65)]
for name,raw,expected in valid:d['wire_cases'].append(dict(id=name,bytes_hex=raw.encode().hex(),accepted=True,canonical=expected,hashes={domain:sha(domain+'\n'+expected) for domain in d['domains']}))
for name,raw in invalid:d['wire_cases'].append(dict(id=name,bytes_hex=raw.encode().hex(),accepted=False,error='INVALID_JOINT_JSON'))
for name,raw in [('utf8-eof',bytes.fromhex('22e4b8')),('utf8-out-of-range',bytes.fromhex('f4908080')),('utf8-overlong-three',bytes.fromhex('e08080')),('utf8-lone-continuation',bytes.fromhex('80')),('utf8-ff',bytes.fromhex('ff')),('utf16-bom',bytes.fromhex('fffe')),('utf8-outside-string',b'['+bytes.fromhex('ff')+b']'),('utf8-inside-key',b'{"'+bytes.fromhex('ff')+b'":1}')]:d['wire_cases'].append(dict(id=name,bytes_hex=raw.hex(),accepted=False,error='INVALID_JOINT_JSON'))
for r in d['helper_cases']:
 v=r['input'];h=r['helper']
 if h=='sourceSnapshotDigest':v['files']=[dict(path=path,mode='100644',blob='a'*40) for path in ['a','B','a_b','a1','😀','～']]
 if h=='schemaSpecDigest':v['expected_lineage_tables']=['a_b','a1']
 if h=='supportProfileDigest':v['measurement_refs']=['z','a']
 if h=='methodInputDigest':v['requested_materials']=['z','a']
 if h=='environmentDigest':v['setup_fixture_digests']=['b'*64,'a'*64]
 if h=='intentDigest':v['goals']=['z','a']
 body=copy.deepcopy(v)
 if h=='bindingDigest':del body['binding_digest'];body['role_materials'].sort(key=lambda x:x['role'])
 if h=='schemaSpecDigest':del body['kind'];del body['schema_version'];body['expected_lineage_tables'].sort()
 if h=='sourceSnapshotDigest':body['files'].sort(key=lambda x:x['path'].encode())
 if h=='checkRegistryDigest':body['entries'].sort(key=lambda x:x['ref'])
 r['expected']=('trial-' if h=='trialRootEffectId' else '')+sha(r['domain']+'\n'+canon(body))
d['version']=2;d['revision_reason']='Post-audit regression revision, not retroactive independent oracle qualification';d['boundary_cases']={'max_wire_bytes':1048576,'max_depth':64,'expected_error':'INVALID_JOINT_JSON'}
d['provenance']={'component_samples':'baseline contracts.json and published schema, manually completed in initial prepare.py; existing role/subject constants inherited unchanged from baseline, not newly sampled TypeScript outputs','new_expectations':'Python standard-library canonical UTF-8 SHA-256 computed from fixed frozen inputs before revised candidate tests; same author, not independent principal'}
raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode();(s/'acceptance-oracle-v2.json').write_bytes(raw);p.write_bytes(raw)
rec={'revision':2,'prior_fixture_sha256':hashlib.sha256((s/'acceptance-oracle.json').read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(raw).hexdigest(),'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_before_revision':'e5e5b2980175258ca2f9d1742488f8a3dd35b0d6','author':'same model session; unauthenticated','formal_gate':False,'reason':'confirmed Sonnet round1 gaps; expectations frozen before revised candidate assertions','counts':{'wire_cases':len(d['wire_cases']),'helpers':len(d['helper_cases']),'kinds':len(d['component_matrix'])}}
(s/'prefreeze-v2.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec))
