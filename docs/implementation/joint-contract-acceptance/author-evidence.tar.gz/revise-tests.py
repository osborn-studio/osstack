from pathlib import Path
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance');p=w/'packages/protocol/scripts/joint-acceptance-oracle.py';s=p.read_text().replace('Independent standard-library wire/hash regression oracle, not a host authority.', 'Separate standard-library wire/hash implementation; same author, no host authority.')
s=s.replace("    return {'wire': wire, 'helpers': helpers,\n            'components': [{'kind': row['kind'], 'canonical': canonical(row['sample']),\n                            'sha256': hashlib.sha256(canonical(row['sample']).encode('utf-8')).hexdigest()}\n                           for row in fixture['component_matrix']],\n            'authority': 'component_regression_only'}", "    components = []\n    for row in fixture['component_matrix']:\n        text = canonical(row['sample'])\n        result = hashlib.sha256(text.encode('utf-8')).hexdigest()\n        require(result == row['canonical_sha256'], row['kind'] + ': frozen component mismatch')\n        components.append({'kind': row['kind'], 'canonical': text, 'sha256': result})\n    return {'wire': wire, 'helpers': helpers, 'components': components,\n            'authority': 'component_regression_only'}")
p.write_text(s)
p=w/'packages/protocol/src/joint-reference.test.ts';s=p.read_text();s=s.replace("import { readFileSync } from 'node:fs';", "import { readFileSync } from 'node:fs';\nimport { createHash } from 'node:crypto';\nimport { decodeJointContractBytesAs } from './joint-contracts.js';")
s=s.replace('authenticated independent principal', 'authenticated independent principal').replace('covers every registered domain and every protocol digest constructor in the matrix','covers every registered domain and the 18 declared protocol digest helpers')
s=s.replace('domains: string[]; wire_cases: WireCase[]; helper_cases: HelperCase[];', 'domains: string[]; wire_cases: WireCase[]; helper_cases: HelperCase[]; not_applicable: Array<{domain: string; reason: string}>; boundary_cases: {max_wire_bytes: number; max_depth: number; expected_error: string};')
s=s.replace("    expect([...acceptance.domains].sort())", "    expect(acceptance.wire_cases).toHaveLength(63);\n    expect(acceptance.helper_cases).toHaveLength(18);\n    expect(acceptance.domains).toHaveLength(20);\n    expect(new Set(acceptance.wire_cases.map(row => row.id)).size).toBe(63);\n    expect(createHash('sha256').update(readFileSync(new URL('../fixtures/joint/acceptance-oracle.json', import.meta.url))).digest('hex')).toBe('541c754d30988154c0d2053b70f4e43600c7cb1f48fa3bbb8e684cf1fa0c151d');\n    expect([...new Set([...acceptance.helper_cases.map(row => row.domain), ...acceptance.not_applicable.map(row => row.domain)])].sort()).toEqual([...acceptance.domains].sort());\n    expect(acceptance.not_applicable.every(row => row.reason.includes('J02'))).toBe(true);\n    expect([...acceptance.domains].sort())")
s=s.replace("      expect(() => parseJointJsonBytes(raw)).toThrow(row.error);", "      expect(() => parseJointJsonBytes(raw)).toThrow(row.error);\n      expect(() => decodeJointContractBytesAs('method_proposal', raw)).toThrow(row.error);")
s=s.replace("    expect(() => jointDigest('osstack.joint.unregistered.v1', {})).toThrow('UNKNOWN_JOINT_DIGEST_DOMAIN');", "    for (const domain of ['osstack.joint.unregistered.v1', 'osstack.joint.support-profile.v1', 'OSSTACK.joint.intent.v1', 'osstack.joint.intent.v1\\n']) expect(() => jointDigest(domain, {})).toThrow('UNKNOWN_JOINT_DIGEST_DOMAIN');")
insert='''
  it('enforces exact raw-byte size boundaries at the parser and decoder', () => {
    const raw = Buffer.from(' '.repeat(acceptance.boundary_cases.max_wire_bytes - 2) + '{}');
    expect(parseJointJsonBytes(raw)).toEqual({});
    expect(() => parseJointJsonBytes(Buffer.concat([raw, Buffer.from(' ')]))).toThrow(acceptance.boundary_cases.expected_error);
    expect(() => decodeJointContractBytesAs('method_proposal', Buffer.concat([raw, Buffer.from(' ')]))).toThrow(acceptance.boundary_cases.expected_error);
  });
  it('retains declared-order arrays in additional schema-aware helpers', () => {
    for (const [helper, field] of [['supportProfileDigest', 'measurement_refs'], ['methodInputDigest', 'requested_materials'], ['environmentDigest', 'setup_fixture_digests'], ['intentDigest', 'goals'], ['artifactRequirementsDigest', 'requirements']]) {
      const row = acceptance.helper_cases.find(item => item.helper === helper)!;
      const reversed = structuredClone(row.input) as Record<string, unknown>;
      expect((reversed[field!] as unknown[]).length).toBeGreaterThan(1);
      (reversed[field!] as unknown[]).reverse();
      expect(digestHelpers[helper!]!(reversed)).not.toBe(row.expected);
    }
  });
  it('rejects corrupted new oracle expectations even with Python optimization', () => {
    const script = fileURLToPath(new URL('../scripts/joint-acceptance-oracle.py', import.meta.url));
    for (const expression of ["data['component_matrix'][0]['sample']['bytes']=2", "data['helper_cases'][0]['expected']='corrupted'", "data['wire_cases'][0]['hashes'][data['domains'][0]]='corrupted'"]) {
      const probe = `import json,pathlib,runpy,sys
original=pathlib.Path.read_bytes
def corrupted(path):
 raw=original(path)
 if path.name=='acceptance-oracle.json':
  data=json.loads(raw);${expression};return json.dumps(data).encode()
 return raw
pathlib.Path.read_bytes=corrupted
sys.argv=[sys.argv[1]]
runpy.run_path(sys.argv[0],run_name='__main__')`;
      expect(() => execFileSync('python3', ['-I', '-O', '-c', probe, script], {encoding: 'utf8', timeout: 10_000, stdio: 'pipe'})).toThrow('FAIL:');
    }
  });
'''
s=s.replace("  it('normalizes only explicitly",insert+"  it('normalizes only explicitly");p.write_text(s)
p=w/'packages/protocol/src/joint-admission.test.ts';s=p.read_text().replace("import { describe, expect, it } from 'vitest';", "import { describe, expect, it } from 'vitest';\nimport { ZodError } from 'zod';")
s=s.replace("optional: string[] }", "optional: string[]; canonical_sha256: string; identity_applicability: string; role_applicability: string; optional_absence: Record<string, {accepted: boolean; error: string | null}> }")
s=s.replace('JA70 full kind/field matrix at the real strict decoder','JA70 all-kind top-level required-field matrix at the real strict decoder')
s=s.replace("expect(componentMatrix.filter(row => row.kind.startsWith('material:'))).toHaveLength(10);", "expect(componentMatrix.filter(row => row.kind.startsWith('material:'))).toHaveLength(10);\n    expect(componentMatrix).toHaveLength(32);\n    for (const row of componentMatrix) {\n      expect(Object.keys(row.sample).every(key => [...row.required, ...row.optional].includes(key))).toBe(true);\n      expect(Object.keys(row.optional_absence).sort()).toEqual([...row.optional].sort());\n      expect(row.identity_applicability).toBe(['method_binding', 'method_proposal', 'method_recipe'].includes(row.kind) ? 'binding/proposal/recipe association covered' : 'cross-record association not covered by this slice; structural validation only');\n      expect(row.role_applicability).toBe(['method_binding', 'method_recipe'].includes(row.kind) ? 'binding/proposal/recipe role association covered' : 'cross-record role association not covered by this slice');\n    }")
s=s.replace("expect(createHash('sha256').update(canonical, 'utf8').digest('hex')).toBe(reference.sha256);", "expect(createHash('sha256').update(canonical, 'utf8').digest('hex')).toBe(row.canonical_sha256);\n      expect(reference.sha256).toBe(row.canonical_sha256);")
s=s.replace("expect(() => decode(missing)).toThrow();", "expect(() => decode(missing)).toThrow(ZodError);")
s=s.replace("    it('rejects unknown fields,", "    for (const field of row.optional) it(`checks absent optional/conditional ${field}`, () => {\n      const absent = structuredClone(row.sample); delete absent[field];\n      const rule = row.optional_absence[field]!;\n      if (rule.accepted) expect(decode(absent)).toEqual(absent);\n      else expect(() => decode(absent)).toThrow(rule.error!);\n    });\n    it('rejects unknown fields,")
s=s.replace("expect(() => decode({...row.sample, unregistered_authority: 'run'})).toThrow();", "expect(() => decode({...row.sample, unregistered_authority: 'run'})).toThrow(ZodError);")
s=s.replace("expect(() => decode({...row.sample, kind: 'unregistered_kind'})).toThrow();", "expect(() => decode({...row.sample, kind: 'unregistered_kind'})).toThrow(ZodError);")
s=s.replace("expect(() => decode({...row.sample, schema_version: -1})).toThrow();", "for (const version of [-1, 0, 999, '1']) expect(() => decode({...row.sample, schema_version: version})).toThrow(ZodError);")
s += '''

describe('JA70 conditional positives and role completeness', () => {
  it('accepts qualified bindings without permits and rejects contradictory modes', () => {
    const binding = sample('valid-method_binding'); binding.mode = 'qualified'; delete binding.trial_permit_id;
    expect(decodeJointContractAs('method_binding', JSON.stringify(binding))).toEqual(binding);
    expect(() => decodeJointContractAs('method_binding', JSON.stringify({...binding, trial_permit_id: 'unexpected'}))).toThrow('TRIAL_PERMIT_MODE_MISMATCH');
  });
  it('allows an intent artifact without candidate-only optional fields', () => {
    const artifact = sample('valid-artifact');
    Object.assign(artifact, {artifact_kind: 'intent_frame', artifact_phase: 'intent'});
    for (const key of ['candidate', 'scenario_digest', 'environment_digest', 'check_registry_digest', 'baseline_artifact_ref', 'resource_ledger_ref']) delete artifact[key];
    expect(decodeJointContractAs('artifact', JSON.stringify(artifact))).toEqual(artifact);
  });
  it('allows a legacy action receipt without an effect identity', () => {
    const receipt = sample('legacy-recovery-null-identities');
    expect(receipt.effect_id).toBeUndefined();
    expect(decodeJointContractAs('recovery_receipt', JSON.stringify(receipt))).toEqual(receipt);
  });
  it('rejects missing, added or duplicate binding roles and mismatched recipe role digests', () => {
    const binding = sample('valid-method_binding');
    const roles = binding.role_materials as Array<Record<string, unknown>>;
    for (const changed of [roles.slice(1), [...roles, roles[0]], [roles[0], roles[0], roles[2]]]) expect(() => decodeJointContractAs('method_binding', JSON.stringify({...binding, role_materials: changed}))).toThrow(ZodError);
    const recipe = sample('valid-method_recipe');
    (recipe.role_materials as Array<Record<string, unknown>>)[0]!.role_required_artifacts_digest = 'f'.repeat(64);
    expect(() => decodeJointContractAs('method_recipe', JSON.stringify(recipe))).toThrow('ROLE_REQUIREMENTS_DIGEST_MISMATCH');
  });
});
'''
p.write_text(s)
