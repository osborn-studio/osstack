# JP-01c component regression — delivery draft

Base: `3192b424174e5eb977d640cc0418e67c6b1461d1` (#284 merged); candidate `e5e5b2980175258ca2f9d1742488f8a3dd35b0d6`. Branch `codex/joint-contract-acceptance`. Four test assets only; product, reference-vectors, central gates and ledger unchanged.

## Scope and evidence

- JA59 regression: 20 registered domains × 17 legal raw JSON inputs, 28 malformed raw inputs (including duplicate keys, noncanonical numbers, Unicode surrogates and invalid UTF-8); 18 helper projections. Existing reference vectors are not rewritten. Source-content/source-inspection have generic domain hashing coverage; their J02 producer/adoption qualification is explicitly out of scope.
- JA70 regression: all 32 current union kinds, including 10 material bodies; 323 top-level required-field deletions; unknown fields, invalid kind/version, duplicate raw keys, wrong expected kind. Linked Binding/Proposal/Recipe identity substitutions (8) and all three roles × two role digest fields (6) use recomputed self-digests so structural self-integrity cannot mask missing association checks.
- Python is a separate standard-library implementation of strict wire parsing/canonicalization/digest projection. It does NOT duplicate Zod semantic validation. Python and TypeScript canonical bytes/hash are compared for all 32 valid component samples.
- Typed identity strings in fixtures are synthetic test inputs; schema acceptance is not authentication or host authority. Nested union state combinations and every external association consumer are not exhaustive.

## Validation

`validation.json` binds exact candidate, argv, start times, exit codes and stdout/stderr digests. 512 targeted tests pass; protocol typecheck passes; Python `-I -O` passes; diff check passes. No full monorepo test was run by this agent.

`mutation-results.json` records an unchanged positive control (500 new tests pass, 12 existing tests intentionally skipped by JA59/JA70 filter) and five isolated source mutations: skip expected-kind (32 failures), skip binding identity (8), skip role association (6), drop duplicate detection (34), drop domain separator (56). Actual failed test names and mutant source digests are retained. No mutation touches repository product files.

`mutation-attempt1` preserves initial harness failures: Vite could not resolve an external setup path, so 0 tests executed. Moving a copy of setup and its scratch helper into each isolated clone fixed the harness. `mutation-attempt2` preserves the first successful run before final import-only cleanup; final mutations are rebound to committed SHA. Initial fixture preparation also encountered a `$ref` resolution error before freeze; it was corrected before any candidate assertion or frozen expectation record.

## Gate disposition

`prefreeze.json` records UTC, fixture hash and identity limitations before candidate assertions. Expected wire outputs were authored from normative canonical rules, not sampled from TypeScript outputs. Inputs/schema required-field lists were selected from published base artifacts. The same model session authored test code and expectations; no independently authenticated author/custodian/reviewer principal exists. Therefore this artifact is component regression evidence only, not a qualified independent oracle.

`baseline-gates.json` captures exact base source hashes and O06/J01.contracts/JA59/JA70 records. O06 remains globally open; this task only rechecks the specified baseline and existing protocol APIs. J01.contracts remains `specified_not_run`; JA59/JA70 are not formally signed off. Formal qualification still requires the authoritative independent-principal/freeze custody/reviewer arrangement, complete gate binding identity tuple, reviewed applicable observation/error matrix and original traces on that exact candidate. JA01/JA02 real-host obligations remain separate and unchanged.

## Proposed PR paragraph

Expand protocol component regression coverage with a frozen strict-wire corpus, a separate Python canonical/digest implementation and a 32-kind decoder matrix. Verify malformed raw JSON rejection, digest domain separation, required fields and Binding/Proposal/Recipe associations; five isolated source mutations demonstrate the new assertions detect disabled safeguards. This changes test assets only and does not grant J01.contracts or host qualification.

Validation: 512 targeted tests, protocol typecheck, optimized Python oracle, five mutation controls; actual Sonnet 5.5 review result pending. Parent owns full-suite validation and combined ledger PR.
