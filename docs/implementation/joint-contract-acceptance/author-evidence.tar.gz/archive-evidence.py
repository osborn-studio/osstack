from pathlib import Path
import json,tarfile,hashlib,shutil,io
s=Path(__file__).parent;w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance');o=w/'docs/implementation/joint-contract-acceptance';o.mkdir(parents=True,exist_ok=True)
files=sorted(p for p in s.rglob('*') if p.is_file() and not p.is_symlink() and not any(part in ['mutants','home','node_modules'] for part in p.relative_to(s).parts))
manifest={'candidate_sha':'74ec436d28f3f134451d45e35536c5747a7f1cba','formal_gate_pass':False,'files':[{'path':str(p.relative_to(s)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files]}
raw=(json.dumps(manifest,indent=2)+'\n').encode();(o/'evidence-manifest.json').write_bytes(raw)
with tarfile.open(o/'author-evidence.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(s)),recursive=False)
 info=tarfile.TarInfo('ARCHIVE-MANIFEST.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(o/'author-evidence.tar.gz','r:gz') as tar:
 for row in manifest['files']:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256']
ind=s.parent/'contract-independent-evidence.tar.gz';assert hashlib.sha256(ind.read_bytes()).hexdigest()=='b6e4bbabe338dfa7a9b09032ae7c6a03eb9e891dc855ede2bbbfd6dcc73e1422';shutil.copy2(ind,o/ind.name)
with tarfile.open(ind,'r:gz') as tar:
 report=next(m for m in tar.getmembers() if m.name.endswith('independent-review.md'));(o/'independent-review.md').write_bytes(tar.extractfile(report).read())
for name in ['delivery.json','handoff.md','audit-disposition.md','round2-disposition.md','prefreeze.json','prefreeze-v2.json','prefreeze-v3.json','validation.json','mutation-results.json']:
 shutil.copy2(s/name,o/name)
for rd in ['audit-round1','audit-round2']:shutil.copy2(s/rd/'report.md',o/(rd+'.md'))
checks={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in [o/'author-evidence.tar.gz',o/'contract-independent-evidence.tar.gz',o/'evidence-manifest.json']};(o/'archive-checksums.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({'files':len(files),'archives':checks},indent=2))
