from pathlib import Path
import shutil
s=Path(__file__).parent;a=s/'mutation-v1-final';a.mkdir(exist_ok=True)
for f in s.glob('*.vitest.json'):shutil.copy2(f,a/f.name)
for f in ['mutate.py','mutation-results.json']:shutil.copy2(s/f,a/f)
for row in __import__('json').loads((s/'mutation-results.json').read_text()):
 for ext in ['stdout','stderr']:shutil.copy2(s/(row['label']+'.'+ext),a/(row['label']+'.'+ext))
p=s/'mutate.py';t=p.read_text();marker='results=[]';extra="""
mutations += [
 ('fatal-utf8-disabled','joint-json.ts',lambda s:s.replace('fatal: true','fatal: false'),'raw bytes'),
 ('remove-number-safety','joint-json.ts',lambda s:s.replace('if (!Number.isSafeInteger(number) || Object.is(number, -0)) invalid();',''),'number rejection'),
 ('remove-unicode-validation','joint-json.ts',lambda s:s.replace('unicode(value); return value;', 'return value;'),'surrogate rejection'),
 ('remove-ascii-key-check','joint-json.ts',lambda s:s.replace('if ([...value].some(char => char.charCodeAt(0) > 127)) invalid();',''),'key rejection'),
 ('depth-off-by-one','joint-json.ts',lambda s:s.replace('const MAX_DEPTH = 64;', 'const MAX_DEPTH = 63;'),'positive boundary'),
 ('size-off-by-one','joint-json.ts',lambda s:s.replace('const MAX_BYTES = 1_048_576;', 'const MAX_BYTES = 1_048_577;'),'negative boundary'),
 ('source-locale-sort','joint-evidence.ts',lambda s:s.replace(\"Buffer.compare(Buffer.from(a.path, 'utf8'), Buffer.from(b.path, 'utf8'))\", 'a.path.localeCompare(b.path)'),'locale sort'),
 ('source-utf16-sort','joint-evidence.ts',lambda s:s.replace(\"Buffer.compare(Buffer.from(a.path, 'utf8'), Buffer.from(b.path, 'utf8'))\", 'a.path < b.path ? -1 : a.path > b.path ? 1 : 0'),'UTF16 sort'),
 ('lineage-locale-sort','joint-lifecycle.ts',lambda s:s.replace('[...v.expected_lineage_tables].sort()', '[...v.expected_lineage_tables].sort((a,b) => a.localeCompare(b))'),'ASCII sort'),
 ('remove-strict-shapes','joint-shapes.ts',lambda s:s.replace('.strict()', ''),'strict schema'),
 ('loose-schema-version','joint-shapes.ts',lambda s:s.replace('schema_version: z.literal(1)', 'schema_version: z.number()'),'version rejection'),
 ('remove-recipe-role-digest','method-binding.ts',lambda s:__import__('re').sub(r\"  if \\(Digest.safeParse.*?ROLE_REQUIREMENTS_DIGEST_MISMATCH'\\);\\n\",'',s),'role digest'),
 ('remove-baseline-condition','method-binding.ts',lambda s:s.replace(\"  if (phase === 'candidate' && !v.baseline_artifact_ref) issue(ctx, 'MISSING_BASELINE');\",''),'conditional field'),
 ('remove-trial-condition','method-binding.ts',lambda s:s.replace(\"  if ((v.mode === 'trial') !== (v.trial_permit_id !== undefined)) issue(ctx, 'TRIAL_PERMIT_MODE_MISMATCH');\",''),'conditional field'),
 ('require-optional-budget','joint-shapes.ts',lambda s:s.replace('max_tokens: z.number().int().min(1).max(9007199254740991).optional()', 'max_tokens: z.number().int().min(1).max(9007199254740991)'),'optional field')
]
"""
t=t.replace(marker,extra+'\n'+marker);p.write_text(t)
