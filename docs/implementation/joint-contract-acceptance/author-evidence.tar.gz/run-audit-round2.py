from pathlib import Path
import subprocess,json,hashlib,datetime,os
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance');s=Path(__file__).parent;a=s/'audit-round2';a.mkdir(exist_ok=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
files=['packages/protocol/src/joint-reference.test.ts','packages/protocol/src/joint-admission.test.ts','packages/protocol/scripts/joint-acceptance-oracle.py','packages/protocol/fixtures/joint/acceptance-oracle.json','packages/protocol/src/joint-json.ts','packages/protocol/src/method-binding.ts','packages/protocol/src/joint-contracts.ts','packages/protocol/fixtures/joint/digest-catalog.json','packages/protocol/src/joint-shapes.ts','packages/protocol/src/joint-recovery.ts','packages/protocol/src/joint-evidence.ts','packages/protocol/src/joint-lifecycle.ts']
prompt='''Act as an adversarial reviewer for JP-01c test-only component regression. Review actual candidate SHA %s against baseline 3192b424174e5eb977d640cc0418e67c6b1461d1. Only first four attached files changed. Product sources and authoritative acceptance cases below are context, not changed. Find concrete bugs in tests/oracle, false positives/negatives, missed applicable matrix dimensions and misleading authority claims. This is deliberately component regression only, not a formal JA59/JA70 or J01 gate pass: same-session oracle author is NOT authenticated independent principal, expected fixtures are frozen before candidate assertions from normative catalog/schema; no runtime/host integration qualification claimed. Python checks strict JSON and canonical/digests, does not replicate Zod semantic validator. Top-level required fields for every schema kind are tested; this is not exhaustive all nested union state variants. Assess whether this bounded test slice is correct and valuable; list remaining formal gate requirements separately, not as reasons to invent a gate pass. Product bugs found are report-only. Give PASS or REVISE for this bounded candidate with precise defects/reproduction. Audit full 20 domain coverage, raw malformed-byte behavior, helper projections, 32-kind applicability/identity/role binding and mutation controls. Raw records retained; no tools available.\n'''%sha
for f in files:prompt+='\nFILE '+f+'\n'+(w/f).read_text()
cases=json.loads((w/'docs/design/2026-10-27-joint-engineering/acceptance-cases.json').read_text())
def pick(obj):
 if isinstance(obj,dict):
  if obj.get('id') in ['JA59','JA70']:return [obj]
  return sum([pick(v) for v in obj.values()],[])
 if isinstance(obj,list):return sum([pick(v) for v in obj],[])
 return []
prompt+='\nNORMATIVE CASES\n'+json.dumps(pick(cases),ensure_ascii=False,indent=2)
prompt+='\nPREFREEZE\n'+(s/'prefreeze.json').read_text()+'\nMUTATION RESULTS\n'+(s/'mutation-results.json').read_text()
prompt += '\nPRIOR RAW REVIEW\n'+(s/'audit-round1/report.md').read_text()+'\nDISPOSITION\n'+(s/'audit-disposition.md').read_text()+'\nREVISION FREEZE RECORDS\n'+(s/'prefreeze-v2.json').read_text()+(s/'prefreeze-v3.json').read_text()+'\nReview closure of confirmed issues and newly introduced regressions. Do not silently expand formal gate scope into this bounded regression slice. Additional future coverage suggestions may be separate; real current defects remain blockers.'
(a/'prompt.txt').write_text(prompt);(a/'empty-mcp.json').write_text('{"mcpServers":{}}');(a/'settings.json').write_text('{}')
argv=['/opt/homebrew/bin/claude','-p','--model','claude-sonnet-5-5','--effort','medium','--output-format','json','--disable-slash-commands','--tools','','--strict-mcp-config','--mcp-config',str(a/'empty-mcp.json'),'--safe-mode','--no-session-persistence','--permission-mode','dontAsk','--setting-sources','','--settings',str(a/'settings.json')]
record={'sha':sha,'argv':argv,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_hashes':{f:hashlib.sha256((w/f).read_bytes()).hexdigest() for f in files},'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest()};(a/'command.json').write_text(json.dumps(record,indent=2))
with (a/'prompt.txt').open() as stdin,(a/'response.json').open('w') as stdout,(a/'stderr').open('w') as stderr:r=subprocess.run(argv,cwd=a,stdin=stdin,stdout=stdout,stderr=stderr,timeout=1200)
record.update(exit_code=r.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());(a/'command.json').write_text(json.dumps(record,indent=2))
try:
 data=json.loads((a/'response.json').read_text());(a/'report.md').write_text(data.get('result',''));print(json.dumps({'exit':r.returncode,'is_error':data.get('is_error'),'modelUsage':data.get('modelUsage'),'result':data.get('result')},ensure_ascii=False))
except Exception as e:print(str(e));raise
