from pathlib import Path
import subprocess,os,json,hashlib,datetime
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance');s=Path(__file__).parent;env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_HOME']=str(s/'home');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack'
commands=[('targeted',['pnpm','--filter','@osstack/protocol','exec','vitest','run','src/joint-reference.test.ts','src/joint-admission.test.ts']),('protocol-all',['pnpm','--filter','@osstack/protocol','test']),('typecheck',['pnpm','--filter','@osstack/protocol','typecheck']),('oracle-optimized',['python3','-I','-O','packages/protocol/scripts/joint-acceptance-oracle.py']),('diff-check',['git','diff','--check'])];records=[]
for label,argv in commands:
 rec={'label':label,'argv':argv,'cwd':str(w),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (s/(label+'.stdout')).open('w') as out,(s/(label+'.stderr')).open('w') as err:r=subprocess.run(argv,cwd=w,env=env,stdout=out,stderr=err,timeout=120)
 rec.update(exit_code=r.returncode,stdout_sha256=hashlib.sha256((s/(label+'.stdout')).read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256((s/(label+'.stderr')).read_bytes()).hexdigest());records.append(rec)
result={'candidate_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'records':records};(s/'validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert all(r['exit_code']==0 for r in records)
