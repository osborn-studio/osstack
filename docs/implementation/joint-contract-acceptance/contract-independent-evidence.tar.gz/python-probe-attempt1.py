from pathlib import Path
import importlib.util,json,hashlib
r=Path(__file__).resolve().parent;p=r/'candidate/packages/protocol/scripts/joint-acceptance-oracle.py';s=importlib.util.spec_from_file_location('candidate_oracle',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
d=json.loads((r/'review-criteria.json').read_text());rows=[]
for c in d['valid']+d['invalid']:
 try:
  v=m.parse_wire(c['raw'].encode());out=m.canonical(v);result={'id':c['id'],'accepted':True,'canonical':out,'sha256':hashlib.sha256(out.encode()).hexdigest()}
 except ValueError as e:result={'id':c['id'],'accepted':False,'error':str(e)}
 expected='expected_canonical' in c;assert result['accepted']==expected,(c,result)
 if expected:assert result['canonical']==c['expected_canonical'] and result['sha256']==c['expected_sha256'],(c,result)
 rows.append(result)
for raw in d['invalid_utf8_hex']:
 try:m.parse_wire(bytes.fromhex(raw))
 except ValueError as e:assert str(e)=='INVALID_JOINT_JSON';rows.append({'hex':raw,'accepted':False})
 else:raise ValueError('accepted invalid UTF8: '+raw)
# Independent upper-byte bound positive then exact +1 negative; raw ASCII spaces have one byte each.
assert m.parse_wire(b' '*(1048576-2)+b'{}')=={}
try:m.parse_wire(b' '*(1048576-1)+b'{}')
except ValueError:rows.append({'id':'raw-size-1MiB-boundary','accepted':False,'positive_control':True})
else:raise ValueError('accepted oversized wire')
(r/'python-observations.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'checks':len(rows),'result':'passed','candidate_script_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
