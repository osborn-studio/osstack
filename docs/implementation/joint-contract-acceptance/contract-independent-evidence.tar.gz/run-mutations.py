from pathlib import Path
import shutil,subprocess,os,json
r=Path(__file__).resolve().parent;w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance');sha='74ec436d28f3f134451d45e35536c5747a7f1cba';cfg=(r/'vitest.config.mts').read_text()
(r/'selected.config.mts').write_text(cfg.replace("include:['independent.test.ts']","include:['candidate/packages/protocol/src/joint-admission.test.ts']"))
e=os.environ.copy();e.pop('OSSTACK_SOCKET',None);e.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(r/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
def run(label,config,test,filter):
 cmd=['/usr/bin/python3',str(r/'run-recorded.py'),'--label',label,'--cwd',str(r),'--code-sha',sha,'--','node',str(w/'node_modules/vitest/vitest.mjs'),'run','--config',config,test,'-t',filter]
 p=subprocess.run(cmd,env=e,cwd=r,capture_output=True,text=True);print(label,p.returncode);print((r/(label+'.stdout')).read_text()[-350:]);return p.returncode
assert run('selected-author-controls','selected.config.mts','candidate/packages/protocol/src/joint-admission.test.ts','wrong expected-kind|identity joins remain')==0
for name,file,old,new,filter in [('kind','joint-contracts.ts',"  if (value.kind !== kind) throw Error('JOINT_KIND_MISMATCH');","  // independent mutant removes expected kind guard",'wrong expected-kind'),('identity','method-binding.ts','binding.task_id !== proposal.task_id || ','','rejects binding task_id substitution')]:
 root=r/('mutant-'+name);shutil.copytree(r/'candidate',root)
 p=root/'packages/protocol/src'/file;s=p.read_text();assert s.count(old)==(2 if name=='kind' else 1);p.write_text(s.replace(old,new))
 config='mutant-'+name+'.config.mts';(r/config).write_text(cfg.replace("include:['independent.test.ts']", "include:['mutant-"+name+"/packages/protocol/src/joint-admission.test.ts']"))
 assert run('author-'+name+'-mutant',config,'mutant-'+name+'/packages/protocol/src/joint-admission.test.ts',filter)!=0
 # Same source mutation faced with independent inputs, not only author cases.
 (r/('independent-'+name+'.test.ts')).write_text((r/'independent.test.ts').read_text().replace('./candidate/','./mutant-'+name+'/'))
 (r/('independent-'+name+'.config.mts')).write_text(cfg.replace("include:['independent.test.ts']", "include:['independent-"+name+".test.ts']"))
 assert run('independent-'+name+'-mutant','independent-'+name+'.config.mts','independent-'+name+'.test.ts','wrong expected kind' if name=='kind' else 'different task identity')!=0
