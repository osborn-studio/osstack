from pathlib import Path
import subprocess,json,shutil,hashlib
r=Path(__file__).resolve().parent;repo=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack');sha='74ec436d28f3f134451d45e35536c5747a7f1cba';w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-contract-acceptance')
files=subprocess.check_output(['/usr/bin/git','ls-tree','-r','--name-only',sha,'packages/protocol/src','packages/protocol/fixtures/joint','packages/protocol/scripts/joint-acceptance-oracle.py','packages/protocol/schemas/joint/joint-contract.schema.json'],cwd=repo,text=True).splitlines()
for p in files:
 out=r/'candidate'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(subprocess.check_output(['/usr/bin/git','show',sha+':'+p],cwd=repo))
(r/'node_modules').symlink_to(w/'node_modules',target_is_directory=True)
(r/'vitest.config.mts').write_text("import {defineConfig} from 'vitest/config';export default defineConfig({test:{include:['independent.test.ts'],maxWorkers:1},server:{fs:{allow:["+json.dumps(str(r))+","+json.dumps(str(w))+","+json.dumps(str(w.resolve()))+"]}}});\n")
shutil.copyfile(r/'review-criteria.json',r/'oracle-freeze.json');shutil.copyfile('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-nextwave-20261028/independent/run-recorded.py',r/'run-recorded.py')
(r/'candidate-files.json').write_text(json.dumps({'candidate_sha':sha,'files':[{'path':p,'sha256':hashlib.sha256((r/'candidate'/p).read_bytes()).hexdigest()}for p in files]},indent=2)+'\n')
