from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;d=json.loads((r/'candidate/packages/protocol/fixtures/joint/acceptance-oracle.json').read_text());s=json.loads((r/'candidate/packages/protocol/schemas/joint/joint-contract.schema.json').read_text());leaves=[]
def visit(x):
 if isinstance(x,dict):
  p=x.get('properties',{});kind=p.get('kind',{}).get('const')
  if kind:leaves.append((kind,x))
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(s['definitions']['JointContract']);res=[]
for row in d['component_matrix']:
 candidates=[x for k,x in leaves if k==row['kind']]; match=[x for x in candidates if set(x.get('required',[]))==set(row['required']) and set(x.get('properties',{}))-set(x.get('required',[]))==set(row['optional'])]
 if not match:raise ValueError('required/optional do not match any published branch: '+row['kind'])
 canonical=json.dumps(row['sample'],ensure_ascii=False,sort_keys=True,separators=(',',':'));digest=hashlib.sha256(canonical.encode()).hexdigest()
 if digest!=row['canonical_sha256']:raise ValueError('canonical hash mismatch '+row['kind'])
 res.append({'kind':row['kind'],'matches_published_branch':True,'fixed_sample_hash_recomputed':digest,'identity_applicability':row['identity_applicability'],'role_applicability':row['role_applicability']})
if len(res)!=32 or len(set(x['kind']for x in res))!=32:raise ValueError('bad matrix cardinality')
(r/'matrix-observations.json').write_text(json.dumps({'rows':res,'scope':'branch-level structural required/optional and byte hashes; no external association or runtime qualification'},indent=2)+'\n');print('32 published shape branches and fixed canonical hashes verified')
