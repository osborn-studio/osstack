from pathlib import Path
import subprocess,json,hashlib,datetime
D=Path(__file__).resolve().parent;S=D/'snapshot';S.mkdir();repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';ref='0ed5bbb799df22048ef058e59861c86640c7b788';sha=lambda b:hashlib.sha256(b).hexdigest();commands=[]
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(D/'isolated-home'),'OSSTACK_HOME':str(D/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':str(D/'scratch'),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'}
(D/'isolated-home').mkdir();(D/'scratch').mkdir()
def run(argv,cwd):
 n=len(commands);p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=30);(D/f'{n:02}.stdout').write_bytes(p.stdout);(D/f'{n:02}.stderr').write_bytes(p.stderr);commands.append({'argv':argv,'cwd':str(cwd),'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)});assert p.returncode==0,(argv,p.stderr.decode());return p.stdout
paths=run(['/usr/bin/git','ls-tree','-r','--name-only',ref,'--','osstack-methods-skill','scripts/export-osstack-methods.mjs','scripts/lib/osstack-method-export.mjs'],repo).decode().splitlines();bound=[]
for path in paths:
 b=run(['/usr/bin/git','show',ref+':'+path],repo);p=S/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);bound.append({'path':path,'bytes':len(b),'sha256':sha(b)})
for h in ['codex','claude']:
 out=run(['/opt/homebrew/opt/node@22/bin/node',str(S/'scripts/export-osstack-methods.mjs'),'--host',h,'--output',str(D/('export-'+h))],S);(D/(h+'-receipt.json')).write_bytes(out)
(D/'execution.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':ref,'commands':commands,'source_files':bound,'environment':env,'scope':'Real exporter only; no host/model/benchmark/product command'},indent=2)+'\n');print(json.dumps({'sources':len(paths),'commands':len(commands)}))
