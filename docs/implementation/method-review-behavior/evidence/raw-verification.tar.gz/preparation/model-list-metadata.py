from pathlib import Path
import sys,json,subprocess,threading,queue,time,os,signal,shutil,hashlib
R=Path(__file__).parent;sys.path.insert(0,str(R/'harness'))
from common import env,save,now
C=R/'codex-model-metadata';C.mkdir();(C/'private-home').mkdir()
args=['/opt/homebrew/bin/codex','--disable','hooks','--disable','shell_snapshot','--disable','skill_mcp_dependency_install','app-server','--stdio']
requests=[{'id':1,'method':'initialize','params':{'clientInfo':{'name':'osstack_review_metadata','version':'1'},'capabilities':{'experimentalApi':True}}},{'method':'initialized','params':{}},{'id':2,'method':'model/list','params':{'limit':100,'includeHidden':False}}]
record={'started':now(),'argv':args,'environment':'same minimal env factory as planned Codex; no values logged','user_turns':0,'model_calls':0,'status':'incomplete','retry':False};p=None;raw=[]
try:
 p=subprocess.Popen(args,cwd=R/'runs/codex-review/workspace',env=env(C,'codex'),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 q=queue.Queue()
 def reader():
  for line in p.stdout:q.put(line)
  q.put(None)
 threading.Thread(target=reader,daemon=True).start()
 p.stdin.write(json.dumps(requests[0])+'\n');p.stdin.flush();deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  line=q.get(timeout=max(0,deadline-time.monotonic()))
  if line is None:break
  x=json.loads(line)
  # Retain only responses to this metadata protocol, never account/identity notifications.
  if x.get('id')==1:
   if 'error'in x:record['initialize_error']=x['error'];break
   raw.append(json.dumps({'id':1,'result':'initialize succeeded; host identity fields omitted'})+'\n')
   for request in requests[1:]:p.stdin.write(json.dumps(request)+'\n')
   p.stdin.flush()
  elif x.get('id')==2:
   raw.append(line)
   if 'error'in x:record['model_list_error']=x['error'];break
   result=x['result'];data=result.get('data',[])
   minimal=[{k:m[k]for k in ['id','model','isDefault','hidden','availabilityNux']if k in m}for m in data]
   defaults=[m for m in minimal if m.get('isDefault')is True and not m.get('hidden',False)]
   record.update(models=minimal,next_cursor=result.get('nextCursor'),unique_default=defaults[0]if len(defaults)==1 and not result.get('nextCursor')else None,status='metadata_observed')
   break
except Exception as ex:record['error']=str(ex)
finally:
 if p:
  p.stdin.close()
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  record['exit_code']=p.returncode
  # stderr is not retained: may contain user/account diagnostic values outside task.
  record['stderr_retained']=False
 shutil.rmtree(C/'private-home');record.update(finished=now(),owned_temp_removed=True)
 save(C/'requests.json',requests);(C/'responses.jsonl').write_text(''.join(raw));save(C/'result.json',record)
 print(json.dumps(record,indent=2))
