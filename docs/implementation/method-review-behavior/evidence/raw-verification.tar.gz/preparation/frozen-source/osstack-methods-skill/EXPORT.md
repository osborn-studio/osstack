# Export OSStack method entries

From this checkout, create a new project bundle beneath an existing parent:

```sh
pnpm export:methods --host codex --output /absolute/existing-parent/osstack-codex
pnpm export:methods --host claude --output /absolute/existing-parent/osstack-claude
```

Use `--dry-run` first to inspect the plan without creating files. The destination must not exist, including as a symlink. An export does not register global skills, edit existing project settings or change model/provider configuration. The exporter refuses destinations beneath the known protected host homes; select an ordinary new project destination. A failed export may leave its owned incomplete directory for inspection; use a new destination after fixing the reported cause.

Keep all four entry directories together: the entries link to each other. Each bundle has four entries: `osstack-mode`, `osstack-help`, `setup-osstack`, and `osstack-agent`. Codex gets `.agents/skills/`; Claude gets `.claude/skills/`. Shared references are copied into each entry and hashes are recorded in the manifest. Read that manifest and the resulting files before using the bundle. Copying an export into an existing project is a separate installation decision requiring collision checks; this tool does not perform it.

Open the generated project in the intended host and check the actual skill catalog. Host version, trust settings, disabled skills and conflicting names can affect discovery. Until that check is observed, report only successful export; do not claim a slash command is registered. Explicitly asking the host to read an exported `SKILL.md` is also supported, but proves a different consumption path.

## Host discovery checks

The observations below are bound to the earlier four-method materials at `ca95aba1`; they do not validate later feature/refactoring/code-review additions. Their new export checks and any later host experiments have separate candidate bindings.

A successful export and a model saying it used a skill are separate observations. For Codex, a native `skills/list` catalog probe can establish which project entries are available; if execution uses a separate process, retain that distinction and inspect its actual material-read results. In the CLI 0.160.1 experiment, all four entries appeared in the separate catalog, then the execution read the exported help and maintenance material via shell `cat`. No native skill-invocation event is attested for that execution. The overall result remains `inconclusive_observability`: the original workspace snapshot omitted Git metadata, resolved model identity was not exposed, and catalog process timing/PID and the vendor executable fingerprint were not captured. See the [experiment limits](../docs/implementation/method-native-discovery/README.md). This does not qualify Codex App or consumption of every entry.

Claude Code CLI 2.1.291 requires special care when testing project discovery: in the isolated, no-model initialization experiment, `--restricted` yielded no OSStack entries, while the otherwise identical empty-tool probe without that flag listed all four. The CLI help describes restricted mode as ignoring project settings; local loader inspection suggests why that would affect discovery. The paired catalog observation establishes the configuration difference in this environment, without proving every internal causal step. The separate safe mode disables skills according to CLI help, not a model experiment. A missing entry under these modes does not show that the exported package is invalid. Do not automatically drop restrictions in an existing user session; use a separately scoped experiment with its own read permissions, private state and retained observations.

The SDK initialize `commands` list is a user-invocable command snapshot, not a guarantee that every skill is available to a later execution. For actual Claude use, retain the run's system initialization fields and successful native `Skill` expansion and reference reads. In a separate fresh experiment using a native working-directory read fence and explicit permission rules, the same-process catalog exposed all four entries and `Skill(osstack-help)` loaded its body and the two relevant reference reads completed. This scoped result does not establish all-entry execution or general adversarial isolation. Evidence and limitations for these specific versions are recorded in the [native discovery experiment](../docs/implementation/method-native-discovery/README.md).

`osstack-mode` selects feature implementation, behavior-preserving refactoring, evidence-led bug fixing, code review, investigation, verification creation or maintenance. `osstack-help` explains these paths, `setup-osstack` prepares scoped role/model/budget choices, and `osstack-agent` guides an already delegated task. These materials create no OSStack CLI subcommands, native agent type, control-plane authority or runtime qualification. Original source attribution stays in each bundle.

The exporter is for the reviewed canonical materials. Reference sources must be non-hidden lowercase `.md` files; a stray `.DS_Store` is rejected. It supports a strict subset of Markdown links and definitions, so complex labels, titles, container definitions and some code-layout forms may be refused. Fragment anchors are not qualified. This is not a general HTML sanitizer or protection against concurrent mutation of source/output trees.
