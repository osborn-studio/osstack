from pathlib import Path
import os,json,hashlib,subprocess,datetime,selectors,time,signal,shutil
ROOT=Path(__file__).resolve().parent.parent
H=ROOT/'harness';USER=Path('/Users/osborn')
PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def env(case,host,auth=False):
 # No credential reads/copies/hashes or Keychain calls. Only the CLI itself uses its existing auth.
 private=case/'private-home';tmp=private/'tmp';tmp.mkdir(exist_ok=True)
 result={'PATH':PATH,'HOME':str(USER),'TMPDIR':str(tmp),'LANG':'en_US.UTF-8','OSSTACK_HOME':str(private/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}
 if host=='codex': result['CODEX_HOME']=str(USER/'.codex')
 else: result['CLAUDE_CONFIG_DIR']=str(USER/'.claude')
 return result

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def inventory(root):
 import stat
 root=Path(root); result={}
 def visit(path):
  st=path.lstat();rel=str(path.relative_to(root));row={'length':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
  if stat.S_ISDIR(st.st_mode):row['type']='directory'
  elif stat.S_ISREG(st.st_mode):row.update(type='file',sha256=sha(path))
  elif stat.S_ISLNK(st.st_mode):row.update(type='symlink',target=os.readlink(path))
  else:raise RuntimeError('unhandled filesystem type: '+rel)
  result[rel]=row
  if row['type']=='directory':
   for child in sorted(path.iterdir()):visit(child)
 visit(root);return result

def stop(p):
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
