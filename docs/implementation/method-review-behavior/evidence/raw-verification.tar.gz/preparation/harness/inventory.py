from pathlib import Path
import sys,json
from common import inventory
if __name__=='__main__':
 if len(sys.argv)!=2: raise SystemExit('inventory.py WORKSPACE')
 print(json.dumps(inventory(Path(sys.argv[1])),indent=2))
