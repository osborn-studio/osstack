# Prepared review-only calls — not dispatched

Root must first obtain a new C criteria/dispatch freeze and append that exact file hash to each approved guard. The templates here are approved:false and live outside harness; the runners require root-created approved guards at the named harness paths. No user turn has been sent.

One call per host, 180 seconds, no retry. Same fixed Git snapshots and method73d446b4, neutral A/B labels, no oracle outputs or revealing commit messages. The complete prompt suggests250–350 words but keeps the visible500 hard maximum. Both cases are reviewed in one call; no fixture execution is authorized.

Claude final-context catalog was observed at0turn with exact59 entries and non-target Skill denies. Codex model metadata was observed at0turn; gpt-6.1-sol is the unique default and only a requested-model recommendation. Existing host authentication remains CLI-internal, not copied; environment and OS-read isolation are not asserted. Original prior experiment failures are untouched.

Before/after inventories cover owned workspaces. External host internal writes and all descendants are not certified. Preserve all raw messages, reading paths, permission refusals, usage/model metadata and final bytes. Multiple agent messages require independent completeness judgment; do not silently select/truncate content to pass a limit. Root alone dispatches exact commands from run-protocol.json after freeze.
