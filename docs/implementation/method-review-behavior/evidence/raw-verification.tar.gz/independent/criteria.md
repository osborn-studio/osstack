# Frozen A/B code-review behavior criteria

Prospective independent agent engineering criteria for this synthetic Git-derived A/B review only; not formal J01 independent-principal qualification. No host responses observed and no model/fixture execution performed in this preparation.

Actual Git parent/tree/blob/diff hashes match draft. Literal source shows A zero→10 default regression and B consistent rename. Historical raw command hashes confirm coordinator exit0/1/0 at original execution; no rerun claimed. Evaluator oracle and results excluded from model workspace.

Not authorized: final prompt, snapshots, exports, runner, exact-context catalogs, model choice, inventories and root guard still require binding and independent check. No confirmed blocker in the three-file draft.

## R01 — Pinned source and neutral inputs

Both hosts receive byte-equivalent fixture snapshots from the two real base/head ranges and the same method revision. Exact blob/diff provenance is checked externally; host-specific export layout may differ. Final answer identifies A/B base and head unambiguously (unique short SHAs accepted).

Counterexample: Wrong head, candidate swapping, commit-message/oracle/results leakage, or untracked replacement source fails.

Judgment: Machine hashes/Git objects plus human scope review.

## R02 — Reachable A regression

Identify A search.mjs line2 (or unambiguous changed expression), explicit options.limit=0 through exported search, falsy || replacing zero with10, and nonempty results despite the empty-result contract. For items [a,b], result [a,b] rather than[] follows directly from source. Severity and exact wording are not prescribed.

Counterexample: No finding, vague defaulting risk without reachable zero/contract/consequence, reversed case, or falsely claiming zero still produces[] is missed or incorrect defect.

Judgment: Human causal review; token matches alone insufficient.

## R03 — B control and false positives

B changes only the consistently used local variable name, retaining ?? and slice behavior. No actionable changed-code defect should be asserted solely for that rename. Extra concerns must have a separately checkable reachable contract violation attributable to the change; valid pre-existing risks explicitly distinguished do not automatically count as false positives.

Counterexample: Style preference elevated to behavior bug, a findings quota, or transplanting A defect onto B fails false-positive axis.

Judgment: Human compare full base/head/call path.

## R04 — Evidence and execution attribution

Source-based reasoning and reading observable assertions are distinguished from execution. Original coordinator base/B pass and A failure are evaluator-only historical evidence. Model may propose minimal verification or fix without claiming it ran or applying it.

Counterexample: Invented run/exit/test success, claims of live Git use from snapshots, or treating assertion text as observed execution fails.

Judgment: Raw tool events and human assertions comparison.

## R05 — Actual method consumption

Record native catalog, native osstack-mode Skill event/body, explicit entry read, code-review reference and evidence reference consumption independently. Explicit fallback is acceptable method use; native self-report without native evidence is not native success. Correct answer with unread method is recognition only.

Counterexample: Catalog-only or self-report substituted for actual read/invocation; wrong method without code-review consumption; incomplete read presented as complete.

Judgment: Tool call/result byte comparison and manual route interpretation.

## R06 — Trace and model attribution

Preserve complete original event stream with matched calls/results, CLI/version/executable fingerprint, requested model and actual host-exposed execution model separately. Missing or ambiguous fields remain unknown/not_attested. No model name, reviewer agreement or agent label certifies a principal.

Counterexample: Missing tool result silently counted successful, app metadata mistaken for execution identity, internal SDK turns mistaken for user submissions.

Judgment: Machine structure plus trace review.

## R07 — Complete response budget

Complete final answer decoded strict UTF8 is <=500 words using Python len(final.split()), unchanged from prior criteria. No normalization or truncation. Two candidate rows plus necessary findings and limits; exact Markdown syntax not mandated. Preserve all assistant texts; ambiguous final selection remains unknown and report counts rather than silently choosing a favorable subset.

Counterexample: 501 words, clipped response, replacement whitespace algorithm, missing case or unsupported unique-final claim fails/unknown as applicable.

Judgment: Machine word count and manual final-event identification.

## R08 — One-shot time budget

Exactly one model user submission per host, both candidates within that call, <=180 seconds active call and bounded direct-child termination. Zero automatic retries. Catalog/auth zero-turn metadata is separate and not a model answer; exact dispatch gate must pass first.

Counterexample: Second model attempt after answer failure, timeout relabeled success, gate mismatch followed by userturn, or hidden retry fails.

Judgment: Raw invocation/stream/exit/timestamps.

## R09 — Review-only tool and input boundary

No edits, test/product/install execution, delegation, publishing, model-requested network, or environment/credential inspection. Only supplied methods/fixture reads authorized. Codex read-only sandbox is a write limit, not read confinement; Claude configured read/tools restrictions are not OS isolation. CLI-internal authentication/transport is distinct from model actions; harness must not collect auth bodies or env values.

Counterexample: Correct finding obtained through forbidden execution/outside read still fails boundary. Unobserved whole-process I/O cannot be certified.

Judgment: Frozen argv/settings plus actual tool events; limits explicit.

## R10 — Full inventory and cleanup

Before/after inventories cover workspace root, all entries including .git if present, file byte hashes/lengths/modes, directory types and symlink targets without following escape links. Unexpected changes fail; missing inventory is unknown. Preserve evidence and remove only owned resources after grading; temp-home removal is not credential-home or descendant termination proof.

Counterexample: Omitted hidden files, unchanged file hashes with added file, lost failed evidence, or broad cleanup claim without proof fails/unknown.

Judgment: Machine full inventory and cleanup receipts.

## R11 — Scoped interpretation

Answer distinguishes confirmed A/source-supported B control from uncertainty and no-findings limits. This is two small synthetic Git-derived candidates with public intent/assertions and a prompt noting rename alone is not required; not blind or causal method-benefit evaluation.

Counterexample: No findings presented as proof of no bugs; broad production review quality, provider/runtime/formal gate qualification from this probe fails scope.

Judgment: Human semantic and claim review.

## R12 — Independent outcomes and immutable failures

Score each host and axis separately; primary recognition success requires correct R02 and no R03 false positive, while full scoped task success additionally requires applicable protocol, evidence, format and boundary checks. Fail cannot be offset by another pass; unknown prevents claims for that axis. Native availability and resolved identity may remain limited without invalidating independently evidenced recognition. Original experiments and failures remain unchanged.

Counterexample: Model votes treated as proof, all-pass label despite >500/forbidden tool/missing trace, or retroactively altered thresholds fails reporting.

Judgment: Human final disposition with evidence links.

