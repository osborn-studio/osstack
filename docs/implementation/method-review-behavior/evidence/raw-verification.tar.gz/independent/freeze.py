from pathlib import Path
import json,hashlib,subprocess,datetime
R=Path(__file__).resolve().parent; P=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-review-behavior-preflight-20261028'); repo=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack'); F=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-native-packet-20261028/independent/code-review/behavior-fixture'); sha=lambda b:hashlib.sha256(b).hexdigest(); protocol=json.loads((P/'protocol.json').read_text());assert sha((P/'protocol.json').read_bytes())=='3018bb0f8969beea1b031ccaa69b005794537ff12030e64461509a03ed675380'
S=R/'sources';S.mkdir();L=R/'commands';L.mkdir();cmds=[]
env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_SYSTEM':'/dev/null','GIT_CONFIG_GLOBAL':'/dev/null','GIT_TERMINAL_PROMPT':'0','GIT_OPTIONAL_LOCKS':'0','GIT_ALLOW_PROTOCOL':'file'}
def git(cwd,*args):
 argv=['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','diff.external=',*args];p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=20);i=len(cmds);(L/f'{i:02}.stdout').write_bytes(p.stdout);(L/f'{i:02}.stderr').write_bytes(p.stderr);cmds.append({'argv':argv,'cwd':str(cwd),'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)});assert p.returncode==0;return p.stdout
bindings=[]
for a in protocol['source_anchors']:
 if 'source_sha'in a:
  b=git(repo,'show',a['source_sha']+':'+a['path']);assert sha(b)==a['sha256'];assert git(repo,'rev-parse',a['source_sha']+':'+a['path']).decode().strip()==a['git_blob'];n='method-'+Path(a['path']).name;(S/n).write_bytes(b);bindings.append({'snapshot':n,**a})
 else:assert sha(Path(a['path']).read_bytes())==a['sha256'];bindings.append(a)
for n in ['protocol.json','plan.md','handoff.json']:(S/('draft-'+n)).write_bytes((P/n).read_bytes())
for c in protocol['cases']:
 assert git(F/'repository','rev-parse',c['head_sha']+'^{tree}').decode().strip()==c['head_tree']
 assert git(F/'repository','rev-parse',c['head_sha']+'^').decode().strip()==c['base_sha']
 diff=git(F/'repository','diff','--no-ext-diff','--no-textconv',c['base_sha'],c['head_sha'],'--','search.mjs');assert sha(diff)==c['diff_sha256'];(S/(c['case_id']+'.diff')).write_bytes(diff)
 for n,h in c['file_sha256'].items():
  b=git(F/'repository','show',c['head_sha']+':'+n);assert sha(b)==h;(S/(c['case_id']+'-'+n)).write_bytes(b)
for n in ['search.mjs','behavior.mjs','intent.md']:(S/('base-'+n)).write_bytes(git(F/'repository','show',protocol['cases'][0]['base_sha']+':'+n))
old=json.loads((F/'results.json').read_text());historic=[]
for i,c in enumerate(old['commands']):
 for stream in ['stdout','stderr']:assert sha((F/f'{i:02}.{stream}').read_bytes())==c[stream+'_sha256']
 if c['argv'][-1]=='behavior.mjs':historic.append({'command_index':i,'exit_code':c['exit_code'],'stdout_sha256':c['stdout_sha256'],'stderr_sha256':c['stderr_sha256']})
assert [x['exit_code']for x in historic]==[0,1,0]
(S/'prior-results.json').write_bytes((F/'results.json').read_bytes())
for i in [4,8,13]:
 for stream in ['stdout','stderr']:(S/f'prior-{i:02}.{stream}').write_bytes((F/f'{i:02}.{stream}').read_bytes())
(R/'source-check.json').write_text(json.dumps({'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_bindings':bindings,'commands':cmds,'historical_coordinator_executions':historic,'new_fixture_or_model_executions':0,'git_read_only':True},indent=2)+'\n')
print((S/'base-search.mjs').read_text());print((S/'A-search.mjs').read_text());print((S/'B-search.mjs').read_text());print((S/'base-intent.md').read_text());print((S/'base-behavior.mjs').read_text())
