import assert from 'node:assert/strict';
import { search } from './search.mjs';
assert.deepEqual(search(['a','b'], {limit: 0}), []);
assert.deepEqual(search(['a','b'], {limit: 1}), ['a']);
assert.deepEqual(search(['a','b']), ['a','b']);
console.log('three observable behavior assertions passed');
