export function search(items, options = {}) {
  const maximumResults = options.limit ?? 10;
  return items.slice(0, maximumResults);
}
