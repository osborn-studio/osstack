export function search(items, options = {}) {
  const limit = options.limit || 10;
  return items.slice(0, limit);
}
