from pathlib import Path
import json,hashlib,stat,os,subprocess,datetime
D=Path(__file__).resolve().parent;I=D.parent;P=I.parent/'preparation';get=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def check(p,h):
 b=p.read_bytes();assert sha(b)==h,str(p);rows.append({'path':str(p),'bytes':len(b),'sha256':h});return b
def inv(r):
 out={}
 def rec(p):
  s=p.lstat();v={'length':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISDIR(s.st_mode):v['type']='directory'
  elif stat.S_ISREG(s.st_mode):v.update(type='file',sha256=sha(p.read_bytes()))
  elif stat.S_ISLNK(s.st_mode):v.update(type='symlink',target=os.readlink(p))
  else:raise AssertionError('unsupported')
  out[str(p.relative_to(r))]=v
  if v['type']=='directory':
   for c in sorted(p.iterdir()):rec(c)
 rec(r);return out
check(P/'run-protocol.json','875dde2a1f50c0d400771cbfdefb2c5d8096e94e73da0eb8352e0a38bce6acbc')
check(I/'criteria.json','8bbd2817e7c6181a8f2c9dd0ee81bcf8cbec53d79532e80dc73718833713fb5e')
for f in get(P/'prepared-manifest.json')['files']:assert len(check(P/f['path'],f['sha256']))==f['bytes']
repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';sm=get(P/'source-manifest.json');assert sm['source_sha']=='73d446b46e444ff5b8ef9a39c5fab962793967fd'
for f in sm['files']:
 b=check(P/'frozen-source'/f['path'],f['sha256']);r=subprocess.run(['/usr/bin/git','show',sm['source_sha']+':'+f['path']],cwd=repo,capture_output=True,timeout=10,env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0 and r.stdout==b
hosts={};indexes=[]
for h,prefix in [('codex','.agents'),('claude','.claude')]:
 c=P/'runs'/(h+'-review');w=c/'workspace';gpath=P/('dispatch-'+h+'-review.template.json');g=get(gpath);assert g['approved']is False
 assert not(P/'harness'/('dispatch-'+h+'-review.json')).exists();assert not(c/'evidence/run-before.json').exists();assert not(c/'private-home').exists()
 for f in g['frozen_files']:check(Path(f['path']),f['sha256'])
 assert g['workspace_inventory']==inv(w)==get(c/'state/workspace-inventory.json');assert not any(v['type']=='symlink'for v in inv(w).values())
 assert g['runner_sha256']==sha((P/'harness'/('run_'+h+'.py')).read_bytes());assert g['prompt_sha256']=='c425abfef14d059fac6171abf750d264976c8dec7ae4089fb35f7974d6dad288'
 assert any(f['path']==str(I/'criteria.json')for f in g['frozen_files']);assert any(f['path']==str(P/'harness/common.py')for f in g['frozen_files'])
 idx=get(w/'inputs/index.json');indexes.append(json.loads(json.dumps(idx).replace(prefix,'.HOST')))
 expected_inputs={'inputs/index.json'}
 for f in idx['source_files']:
  p=w/f['path'];check(p,f['sha256']);expected_inputs.add(f['path']);parts=Path(f['path']).parts;case=parts[1];name=parts[2];oracle=I/'sources'/((case+'.diff')if name=='change.diff'else(case+'-'+name));assert p.read_bytes()==oracle.read_bytes()
 actual_inputs={str(p.relative_to(w))for p in(w/'inputs').rglob('*')if p.is_file()};assert actual_inputs==expected_inputs
 for entry in ['osstack-mode','osstack-agent','osstack-help','setup-osstack']:
  d=w/prefix/'skills'/entry
  for f in(d/'references').iterdir():assert f.read_bytes()==(P/'frozen-source/osstack-methods-skill/references'/f.name).read_bytes()
  src=(P/'frozen-source/osstack-methods-skill/entries'/entry/'SKILL.md').read_text();assert (d/'SKILL.md').read_text()==src.replace('../../references/','references/')
 hosts[h]={'inventory_entries':len(inv(w)),'files':sum(v['type']=='file'for v in inv(w).values()),'guard_files':len(g['frozen_files']),'template_sha256':sha(gpath.read_bytes()),'fresh_before_run':True}
assert indexes[0]==indexes[1]
a=P/'runs/codex-review/workspace/.agents/skills';b=P/'runs/claude-review/workspace/.claude/skills'
assert {str(p.relative_to(a)):p.read_bytes()for p in a.rglob('*')if p.is_file()}=={str(p.relative_to(b)):p.read_bytes()for p in b.rglob('*')if p.is_file()}
c=P/'runs/claude-review';sett=get(c/'state/settings.json');perm=sett['permissions'];assert sett['disableAllHooks']and perm['blockReadsOutsideWorkingDirectories']and perm['additionalDirectories']==[]
assert get(c/'state/empty-mcp.json')=={'mcpServers':{}}
cat=get(c/'evidence/catalog-preflight-result.json');names=get(P/'harness/claude-builtin-catalog.json');targets=['osstack-help','osstack-mode','setup-osstack','osstack-agent'];assert len(names)==55 and cat['catalog_names']==sorted(names+targets)and cat['exit_code']==0 and cat['user_turns']==0
assert all('Skill('+n+')'in perm['deny']for n in names)and all('Skill('+n+')'in perm['allow']for n in targets)
assert get(c/'evidence/catalog-preflight-before.json')==get(c/'evidence/catalog-preflight-after.json')==inv(c/'workspace')
events=[json.loads(l)for l in(c/'evidence/catalog-preflight.jsonl').read_text().splitlines()];assert all(e['type']in ['control_response','system']for e in events)
control=[e for e in events if e['type']=='control_response'][0];assert sorted(x['name']for x in control['response']['response']['commands'])==cat['catalog_names']
model=get(P/'codex-model-metadata/result.json');assert model['user_turns']==0 and model['exit_code']==0 and model['unique_default']['id']=='gpt-6.1-sol'
assert get(P/'dispatch-codex-review.template.json')['codex_model']=='gpt-6.1-sol'
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'eligible_for_root_one_shot_dispatch_with_stated_limits','hosts':hosts,'verified_preparation_files':len(get(P/'prepared-manifest.json')['files']),'method_source_files':len(sm['files']),'same_inputs_except_host_paths':True,'source_snapshots_exact_independent_oracle_bytes':True,'source_oracle_logs_or_bundle_in_workspace':False,'claude_zero_turn_catalog':{'names':59,'targets':4,'explicit_denied_non_targets':55,'exit_code':0},'requested_models':{'codex':'gpt-6.1-sol','claude':'claude-sonnet-5-5'},'new_model_fixture_product_calls_by_reviewer':0,'bindings':rows}
(D/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='bindings'}))
