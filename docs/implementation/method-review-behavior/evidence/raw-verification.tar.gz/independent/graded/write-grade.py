from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).resolve().parent;I=D.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();obs=json.loads((D/'observations.json').read_text())
shared={
'R02':('passed_scoped','Both identify reachable explicit limit0, A line2 || default10 and nonempty result contrary to documented empty result; source reasoning correct.'),
'R03':('passed_scoped','Neither asserts actionable defect solely from B consistent local rename. No false positive on B.'),
'R04':('passed_scoped','Both distinguish static reasoning from execution, explicitly state assertions unexecuted and no live Git verification. No test/product command observed.'),
'R06':('observed_with_identity_limits','35 raw events each retained; all tool operations paired. Claude init2/result34 report sonnet5.5; Codex requested6.1-sol execution-resolved identity not exposed/not_attested. No principal certification.'),
'R07':('passed','Codex final263 words; progress22 + final263 =285 even under combined assistant-text counting. Claude final365 words. Both<=500; advisory250–350 is not hard threshold. Codex manual contextual final selection stated; no native final channel claimed.'),
'R08':('passed_scoped','Exactly one submitted user turn each; naturalexit0, no retry; Codex40.094s/Claude24.773s under180. Claude metadata rate_limit_event is not a retry.'),
'R09':('passed_observed_compliance','Codex only15 cat/cat-n commands; Claude Skill+Glob+10Read. All within supplied workspace; no model credential/env/external/network/fixture/product/edit/delegation observed. Not OS or whole-process isolation.'),
'R10':('passed_inventory_cleanup_pending','83 root-inclusive inventory entries each before=after=current=frozen; temp homes absent. Workspaces retained for independent review and owner archive/cleanup. No descendant/global no-write claim.')}
specific={
'codex':{
'R01':('passed_scoped','Exact full base/head SHAs in answer. All supplied source/assertion/intent/diff files read,15 total complete file reads independently byte-matched.'),
'R05':('failed_native_attribution','All mode/review/evidence consumption was explicit cat. Final says used available skill and no fallback needed; raw trace provides no native Skill event. Explicit method use established; native claim unsupported and fallback not disclosed as requested. This does not prove host lacks native capability.'),
'R11':('passed_scoped','Correct limited A/B review with no-test/no-liveGit/external-caller boundaries; no broad quality or causal efficacy claim.'),
'R12':('limited_not_unconditional_pass','Core recognition/no-B-false-positive passed. Full task cannot receive unconditionalPASS because native/fallback attribution was unsupported; actual execution model remains not_attested.')},
'claude':{
'R01':('partial_complete_input_instruction_not_met','Pins unique base/head prefixes correctly.10completeRead returns checked, plus exact nativeSkillbody. Four supplied duplicate files A/B intent.md and behavior.mjs were not opened; final transparently discloses reliance on index hashes. Evaluator confirms duplicates actually match, but that does not retroactively satisfy model full-input-read instruction.'),
'R05':('passed_native_observed','Skill call4/result5/body6 exact expansion independently checked; code-review/evidence references read fully. This is observed native invocation plus explicit reference reads.'),
'R11':('partial_inaccurate_extra_generalization','Final limits says negative/null/non-numeric/fractional limits behave the same on base/A/B, and parenthetically says A differs for null then no difference. Null actually defaults10 in both; the non-numeric blanket assertion is unsupported/false for NaN or booleanfalse: || selects10 while ?? preserves the value and slice converts it to0. This is static source inference, not a newly executed case or claimed defect in an unspecified input contract. Core A/B finding remains correct; the broad equivalence claim must not be endorsed.'),
'R12':('limited_not_unconditional_pass','Core recognition/no-B-false-positive passed and hard word limit passed. Four unread supplied files and inaccurate added equivalence claim prevent unconditional full-taskPASS. No retry or retrospective criterion change.')}}
results={}
for h in ['codex','claude']:
 merged={**shared,**specific[h]};results[h]={'overall':'limited','primary_defect_control_result':'passed_scoped_A_found_B_no_false_positive','axes':[{'id':i,'status':merged[i][0],'basis':merged[i][1]}for i in [f'R{n:02}'for n in range(1,13)]],'observation':obs['hosts'][h]}
x={'graded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'criteria_sha256':sha(I/'criteria.json'),'supplement_sha256':sha(I/'final-preparation/supplement.json'),'observations_sha256':sha(D/'observations.json'),'results':results,'scope':'Small synthetic Git-derived A/B source-review observation. No model fixture execution, generalized quality benchmark, causal benefit, provider/runtime gate or independent principal certification. Earlier experiments unchanged.','reviewer_calls':{'model':0,'fixture_or_product':0}}
(D/'graded-results.json').write_text(json.dumps(x,indent=2)+'\n')
md='# Independent A/B review grading\n\nBoth hosts correctly identify A\'s explicit-zero regression and do not misreport B\'s rename. **Both overall results are limited, not unconditional PASS.**\n\nCodex final263 words (285 including its earlier22-word progress message), Claude365 words, both within the frozen500-word limit. Each completed one call with no retry;40.094s and24.773s respectively.\n\n'
for h in ['codex','claude']:
 md+='## '+h+'\n\n'
 for a in results[h]['axes']:md+='**'+a['id']+' — '+a['status']+'**: '+a['basis']+'\n\n'
md+='## Raw evidence and interpretation\n\nEvent indexes are zero-based in preparation/runs/<host>-review/evidence/run.jsonl. Codex final event33 follows all completed file reads and precedes turn.completed34; event2 is progress. Claude final33 matches result34 exactly. Claude Skill4/result5/body6 and all10Read return bytes were matched; Codex15cat/cat-n return bytes were matched. Hashes, paths and raw bindings are in observations.json. Claude four unread duplicates remain unread despite evaluator byte equivalence.\n\nNo extra execution was used to check the non-numeric assertion: the counterexample follows from the already supplied operators and slice semantics. This is a factual limitation in added prose, not an invented new product contract or required finding. No evidence supports broad method efficacy, and agreement is not proof. Workspaces are now ready for owner-controlled archival cleanup; new cleanup receipts must remain separate from this grade.\n'
(D/'graded-results.md').write_text(md)
rows=[]
for p in sorted(I.rglob('*')):
 if p.is_file():rows.append({'path':str(p.relative_to(I)),'bytes':p.stat().st_size,'sha256':sha(p)})
(I/'final-manifest.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':rows,'scope':'All independent files including original frozen criteria/source/commands and subsequent supplements/grades; this manifest excludes itself only.'},indent=2)+'\n')
print(json.dumps({'grade_sha256':sha(D/'graded-results.json'),'md_sha256':sha(D/'graded-results.md'),'observations_sha256':sha(D/'observations.json'),'manifest_sha256':sha(I/'final-manifest.json'),'members':len(rows)}))
