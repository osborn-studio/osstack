from pathlib import Path
import json,hashlib,stat,os,shlex,datetime
D=Path(__file__).resolve().parent;I=D.parent;P=I.parent/'preparation';sha=lambda b:hashlib.sha256(b).hexdigest();get=lambda p:json.loads(p.read_text())
def inv(root):
 out={}
 def walk(p):
  s=p.lstat();d={'length':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISDIR(s.st_mode):d['type']='directory'
  elif stat.S_ISREG(s.st_mode):d.update(type='file',sha256=sha(p.read_bytes()))
  elif stat.S_ISLNK(s.st_mode):d.update(type='symlink',target=os.readlink(p))
  else:raise AssertionError('unsupported')
  out[str(p.relative_to(root))]=d
  if d['type']=='directory':
   for c in sorted(p.iterdir()):walk(c)
 walk(root);return out
hosts={};bindings=[]
for h in ['codex','claude']:
 c=P/'runs'/(h+'-review');w=c/'workspace';E=c/'evidence';events=[json.loads(l)for l in(E/'run.jsonl').read_bytes().decode('utf-8',errors='strict').splitlines()];res=get(E/'run-result.json');gpath=P/'harness'/('dispatch-'+h+'-review.json');g=get(gpath);assert g['approved']is True
 for f in g['frozen_files']:assert sha(Path(f['path']).read_bytes())==f['sha256'],f['path']
 assert inv(w)==get(E/'run-before.json')==get(E/'run-after.json')==g['workspace_inventory'];assert not(c/'private-home').exists();assert res['exit_code']==0 and res['automatic_retry']is False
 reads=[];messages=[]
 if h=='codex':
  started={e['item']['id']:e['item']for e in events if e.get('type')=='item.started'}
  for i,e in enumerate(events):
   if e.get('type')!='item.completed':continue
   item=e['item']
   if item['type']=='agent_message':messages.append({'event':i,'words':len(item['text'].split()),'sha256':sha(item['text'].encode())});continue
   assert item['type']=='command_execution';assert started[item['id']]['command']==item['command'];a=shlex.split(item['command']);assert a[:2]==['/bin/zsh','-lc']and len(a)==3;b=shlex.split(a[2]);assert b[0]=='cat'and len(b)in[2,3];numbered=len(b)==3
   if numbered:assert b[1]=='-n'
   p=w/b[-1];assert p.resolve().is_relative_to(w.resolve());raw=p.read_bytes();expected=(''.join(f'{n:6}\t'+l for n,l in enumerate(raw.decode().splitlines(keepends=True),1))).encode()if numbered else raw
   assert item['aggregated_output'].encode()==expected and item['exit_code']==0
   reads.append({'event':i,'path':str(p.relative_to(w)),'bytes':len(raw),'sha256':sha(raw),'complete_return_equal':True})
  final=events[33]['item']['text'];assert(E/'final-response.txt').read_bytes()==final.encode();assert events[-1]['type']=='turn.completed';assert res['model_user_turns']==1 and not res['timed_out'];native='not_observed_explicit_cat';model='not_attested';assert len(reads)==15
 else:
  uses=[];results={}
  for i,e in enumerate(events):
   for b in e.get('message',{}).get('content',[]):
    if b.get('type')=='tool_use':uses.append((i,b))
    if b.get('type')=='tool_result':results[b['tool_use_id']]=(i,b)
  assert len(uses)==12
  for i,b in uses:
   ri,r=results[b['id']];assert not r.get('is_error',False)
   if b['name']=='Read':
    p=Path(b['input']['file_path']);assert p.resolve().is_relative_to(w.resolve());raw=p.read_bytes();expected='\n'.join(str(n)+'\t'+l for n,l in enumerate(raw.decode().split('\n'),1));assert r['content']==expected
    reads.append({'event':i,'result_event':ri,'path':str(p.relative_to(w)),'bytes':len(raw),'sha256':sha(raw),'complete_return_equal':True})
   elif b['name']=='Skill':assert b['input']['skill']=='osstack-mode'and r['content']=='Launching skill: osstack-mode'
   else:assert b['name']=='Glob';assert set(r['content'].splitlines())=={str(p.relative_to(w))for p in(w/'inputs').rglob('*')if p.is_file()}
  skill=(w/'.claude/skills/osstack-mode/SKILL.md').read_text();body=skill.split('---',2)[2].lstrip('\n');expanded=events[6]['message']['content'][0]['text'];assert expanded=='Base directory for this skill: '+str(w/'.claude/skills/osstack-mode')+'\n\n'+body+'\n\nARGUMENTS: code-review method: review candidates A and B'
  final=events[33]['message']['content'][0]['text'];assert events[34]['result']==final and events[34]['subtype']=='success';assert events[2]['model']=='claude-sonnet-5-5'and list(events[34]['modelUsage'])==['claude-sonnet-5-5'];assert res['user_turns']==1;assert len(reads)==10
  native='observed_Skill_event4_result5_exact_body6';model='host_reported_claude-sonnet-5-5';messages=[{'event':33,'words':len(final.split()),'sha256':sha(final.encode())}]
 assert len(final.split())==({'codex':263,'claude':365}[h])
 required={f['path']for f in get(w/'inputs/index.json')['source_files']}|{'inputs/index.json'};readpaths={f['path']for f in reads};unread=sorted(required-readpaths)
 duration=(datetime.datetime.fromisoformat(res['finished'])-datetime.datetime.fromisoformat(res['at'])).total_seconds();assert duration<180
 hosts[h]={'raw_events':len(events),'final_event':33,'final_words':len(final.split()),'assistant_messages':messages,'all_assistant_text_words':sum(m['words']for m in messages),'final_selection':'Claude assistant33 equals result34; Codex progress2 before reads and sole complete A/B answer33 after reads before turn.completed34; no Codex native final-channel marker asserted','actual_model':model,'native':native,'complete_reads':reads,'unread_fixture_files':unread,'full_inventory_entries':len(inv(w)),'private_temporary_home_absent':True,'workspace_retained_for_owner_cleanup':True,'duration_seconds':duration,'final_sha256':sha(final.encode()),'guard_sha256':sha(gpath.read_bytes())}
 for p in sorted(E.iterdir()):
  if p.is_file():bindings.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
(D/'observations.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hosts':hosts,'raw_bindings':bindings,'reviewer_model_or_fixture_calls':0},indent=2)+'\n');print(json.dumps({h:{k:v for k,v in x.items()if k!='complete_reads'}for h,x in hosts.items()}))
