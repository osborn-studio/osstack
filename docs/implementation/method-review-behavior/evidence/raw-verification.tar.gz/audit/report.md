**Verdict: REVISE.** One confirmed contradiction with the supplied records, plus a few provenance claims the supplied records don't support. The substantive findings and scope disclaimers hold up. This is a toolless read of the supplied text only. I executed nothing and verified no hashes.

## Confirmed blockers

1. **Supplement overstated as binding root guards.** The report says the final preparation supplement "bound … root guards." `independent-supplement.json` says the opposite:
   - It states "this supplement is not approval and creates no guard."
   - Its `remaining_root_actions` list freezing models, appending the supplement SHA to the guard, and approving calls as still to be done.
   - It binds only `guard_template_sha256`.
   - Fix: say it bound guard *templates* and that root guards were approved separately.

2. **Claims with no support in the supplied records.** Either cite a bound source or remove them:
   - "published in PR296 at `4833bd97`". Only the `73d446b4…` method source appears in the records.
   - CLI versions "Codex CLI 0.160.1" and "Claude CLI 2.1.291". They appear in none of the supplied files.
   - The earlier 515-word experiment "used older material and a different task". The records say only that the failure is unchanged and not regraded.
   - "J11" in "No J01/J11/runtime qualification". Only J01 appears in the records.

## Checked and supported

- **Codex reads:** 15 complete reads with exact bytes, 263 final words, 285 across all assistant messages. No native Skill event, so the "no fallback needed" claim is correctly marked unsupported.
- **Claude reads:** native Skill call, result and body observed, 10 exact reads, 365 words. The four A/B `intent.md` and `behavior.mjs` files were not opened, and the report states this.
- **Static analysis** (from the source, not run):
  - **NaN:** A gives `NaN||10` = 10, so all items. Base and B give `slice(0, NaN)` = `[]`. This is a real counterexample.
  - **`false`:** the same split, 10 against `[]`. Also a real counterexample.
  - **`null`:** both `||` and `??` give 10, so the parenthetical in Claude's final contradicts itself.
  - **Negative and fractional limits:** the same on all three versions.
  - The "overbroad" characterization is accurate.
- **Run and cleanup:** one turn each, exit 0, 40.1s and 24.8s, no retries. Inventories (83 entries) unchanged and temp homes absent. Workspaces are retained and the report does not claim they were cleaned up.
- **Scope:** no causal-benefit, provider, principal or runtime-gate overclaim. Host-reported model identity is separated from attestation.

## Suggestions (non-blocking)

- State that Claude's 365 words exceeded the advisory 250–350 target while staying under the 500 hard ceiling. "Within budget" currently reads as covering only time.
- Say explicitly that workspaces are retained pending owner archive and cleanup. "Follows archive verification" could be read as done.
- Add `""` (and BigInt `0n`) as further static counterexamples to the non-numeric claim, if you want it complete.
- Fix the missing spaces before numbers ("CLI0.160.1", "Final263", "and10").
- Note that the shared index differs only in host paths. The "identical bytes" claim is otherwise accurate for the source, diff, intent and assertion files.