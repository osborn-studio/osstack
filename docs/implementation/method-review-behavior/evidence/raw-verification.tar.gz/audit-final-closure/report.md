**Verdict: PASS.** I found no remaining confirmed issues in R1 or the spacing. This was a toolless read of the supplied text. I computed no hashes, and the guard SHAs `921f7792…` and `fa55ec17…` are taken from root's independent check, as you said.

## R1: closed

- **Supplement binding:** both `codex-actual-approved-guard.json` and `claude-actual-approved-guard.json` end `frozen_files` with `.../independent/final-preparation/supplement.json`, SHA-256 `5aa4807bec991ed82c68a4837f53487e13e791a59bfd965156e7eb700ea33a3a`. This matches the value in `supplement_entry` in `root-verified-extracted-binding.json`.
- **Approval:** both guards have `approved: true` and a `root_dispatch` block. Each carries the same `protocol_sha256` as the `run-protocol.json` entry in its `frozen_files`, `875dde2a…`.
- **Separate guards:** the guards differ as expected. The runner SHAs are `68da449b…` and `6bf94331…`, matching the respective `run_codex.py` and `run_claude.py` entries. The workspace paths (`.agents` vs `.claude`) and `inputs/index.json` hashes also differ, which is consistent with the report's "index differs only in host export paths". The prompt SHA `c425abfe…` is shared and matches `review-prompt.txt`.
- **Report sentence:** "root subsequently approved separate exact guards, each binding that supplement" is now backed.

## Spacing: closed

The previously flagged items now read correctly: "advisory 350 target", "hard 500 ceiling", "exit 0" and "from 73d to 4833". I found no other run-together number or word in the report body. "PR296" is a name token and fine as written.

## Not assessed

- **Ordering:** the guards show root dispatch times of 14:59:22 and 14:59:23, but the supplied data has no call timestamps. "Before the actual calls" therefore rests on records outside this packet. R1 doesn't depend on it.
- **Hashes:** I did not check the final-grade hash `04ea1c39…` or the guard SHAs against files.

## Optional (non-blocking)

- Add `""` and `0n` as further static non-numeric counterexamples to the overbroad Claude claim.
- The `budget` string in both `root_dispatch` records has run-together text ("one userturn perhost,180seconds"). It is a preserved root record, so I would leave it unedited.