# PR305 main retarget independent Git proof

No confirmed retarget defect. Main 5248195 has the exact PR304/old-base tree; new head 6f79d125 has the exact prior PR305 tree. Its parents are prior head 52f16faf and actual main 5248195. A fresh merge-tree computation returned the same tree without conflicts. The complete binary diff against main is byte-identical to the previous diff against 185d283a.

51 changed paths: five source/material/CI files and 46 documentation/evidence files. All five non-document file bytes match prior PR305. No package/runtime/shared-contract/schema/lock changes. Existing full projection and passed-stderr fixes remain in scope.

CI 40911455127 is in progress at this snapshot; no claim of fresh CI success. Necessary bounded checks and exact source hashes are in git-report.json. No test, model, PR or ledger action was performed. Historical archive contents were not revalidated here.
