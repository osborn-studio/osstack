from pathlib import Path
import importlib.util,json
spec=importlib.util.spec_from_file_location('validation',Path(__file__).with_name('run-validation.py'));v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
R=v.R;record=v.record

def snapshot(root):
 return [{'path':str(p.relative_to(root)),'sha256':v.sha(p.read_bytes()),'bytes':p.stat().st_size}for p in sorted(root.rglob('*'))if p.is_file()]
summary={}
for scope in ['default','full']:
 out=R/('actual-'+scope);args=['node','scripts/method-verification-journey.mjs','--output',str(out)]
 if scope=='full':args+=['--scope','full']
 record('actual-'+scope,args)
 result=json.loads((R/('actual-'+scope+'.stdout')).read_text());assert result==json.loads((out/'journey.json').read_text())
 ids=['healthy','missing-ref'] if scope=='default' else ['healthy','missing-ref','drift','mixed','empty']
 exits=[0,1] if scope=='default' else [0,1,2,1,0]
 assert result['status']=='passed' and [x['case_id']for x in result['features']]==ids and[x['product_exit']for x in result['features']]==exits
 assert all(x['driver_exit']==0 and x['verification']=='passed' and x['cleanup']['fixture_removed']for x in result['features'])
 before=snapshot(out);(R/(scope+'-before-projection.json')).write_text(json.dumps(before,indent=2)+'\n')
 packet=R/('packet-'+scope)
 args=['node','scripts/project-method-journey-evidence.mjs','--input',str(out),'--output',str(packet)]
 if scope=='full':args+=['--scope','full']
 record('project-'+scope,args)
 record('check-'+scope,['node','scripts/project-method-journey-evidence.mjs','--check',str(packet)])
 assert json.loads((R/('check-'+scope+'.stdout')).read_text())['status']=='valid'
 p=json.loads((packet/'packet.json').read_text());assert p['schema_version']==(1 if scope=='default' else 2)
 after=snapshot(out);assert before==after
 (R/(scope+'-after-projection.json')).write_text(json.dumps(after,indent=2)+'\n')
 packet_before=snapshot(packet);probes=[]
 for mode in ['passed-conflict','failed-control']:
  probe=R/(scope+'-'+mode)
  record('make-'+scope+'-'+mode,['node',str(R/'make-stderr-probe.mjs'),str(packet),str(probe),mode])
  pb=snapshot(probe)
  record('check-'+scope+'-'+mode,['node','scripts/project-method-journey-evidence.mjs','--check',str(probe)],1 if mode=='passed-conflict' else 0)
  if mode=='passed-conflict':assert json.loads((R/('check-'+scope+'-'+mode+'.stderr')).read_text())=={'status':'rejected','error':'passed_stderr_conflict'}
  else:
   assert json.loads((R/('check-'+scope+'-'+mode+'.stdout')).read_text())['status']=='valid'
   q=json.loads((probe/'packet.json').read_text());assert q['features'][0]['verification']=='failed' and q['features'][0]['cleanup']['status']=='unknown'
  assert pb==snapshot(probe)
  probes.append({'mode':mode,'expected_exit':1 if mode=='passed-conflict' else 0,'unchanged_by_check':True,'files':pb})
 assert packet_before==snapshot(packet) and before==snapshot(out)
 summary[scope]={'journey_status':result['status'],'packet_schema_version':p['schema_version'],'product_exits':exits,'driver_exits':[x['driver_exit']for x in result['features']],'source_members':len(before),'source_unchanged':True,'packet_unchanged_by_probes':True,'probes':probes,'case_manifests':result['retained']['case_manifests'],'limits':result['limitations']}
(R/'actual-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('actual verification complete',flush=True)
