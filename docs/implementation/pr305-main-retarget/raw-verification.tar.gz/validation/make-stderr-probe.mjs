import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
const [source, output, mode] = process.argv.slice(2);
if (!source || !output || !['passed-conflict', 'failed-control'].includes(mode)) throw Error('invalid probe arguments');
const packet = JSON.parse(await readFile(join(source, 'packet.json'), 'utf8'));
const id = 'healthy';
const stderr = Buffer.from('x');
const digest = b => createHash('sha256').update(b).digest('hex');
Object.assign(packet.references.find(x => x.id === `${id}.product.stderr`), { bytes: stderr.length, sha256: digest(stderr) });
packet.streams.find(x => x.id === `${id}.product.stderr`).omitted_bytes = stderr.length;
if (mode === 'failed-control') {
  packet.journey_status = 'failed'; packet.failure_recorded = true;
  const row = packet.features.find(x => x.case_id === id);
  row.reported_cleanup = structuredClone(row.cleanup);
  Object.assign(row, { verification: 'failed', product_exit: null, reported_product_exit: 0, product_status: 'unknown', cleanup: { status: 'unknown', fixture_removed: null, descendant_termination: 'not_attested' } });
}
await mkdir(output, { mode: 0o700 });
const bytes = Buffer.from(JSON.stringify(packet, null, 2) + '\n');
await writeFile(join(output, 'packet.json'), bytes, { flag: 'wx' });
await writeFile(join(output, 'manifest.json'), JSON.stringify({ schema_version: 1, files: [{ path: 'packet.json', bytes: bytes.length, sha256: digest(bytes) }] }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ mode, schema_version: packet.schema_version, packet_sha256: digest(bytes), mutation: 'scratch copy only; original packet untouched' }));
