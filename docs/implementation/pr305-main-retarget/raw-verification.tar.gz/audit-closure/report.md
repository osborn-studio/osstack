**Verdict: REVISE.** There is one real defect, a broken sentence introduced by this change. The rest of the closure holds, and my earlier PASS on the code and CI stands. This is a static read of the three doc hunks only. I ran nothing, and I did not verify the test counts or hashes quoted in them.

## Defect

`osstack-methods-skill/references/maintain-verification.md`, the last sentence of the final paragraph:

> "This consistency check it does not replace the source review, actual drives and cleanup observations…"

This is a leftover splice: "it" should not be there. The sentence is ungrammatical in a reference that agents and maintainers read as normative. The fix is one word:

> "This consistency check does not replace the source review, actual drives and cleanup observations required for maintenance, or turn failed/unknown/not-run rows into passed ones."

## Confirmed

- **Packet vs original evidence:** "validates only the packet and its own manifest; it does not reopen or revalidate the original evidence" is accurate. It matches `original_evidence_revalidated: false` and the journey recipe's wording. The earlier overstated "retained evidence structure and byte consistency" is gone.
- **v1 output unchanged, checker stricter:** The README addendum says valid v1 producer output is unchanged. It also says the later stderr-consistency repair tightens both the v1 and v2 checkers, rejecting previously accepted passed packets with non-empty stderr. It scopes the older "unchanged v1 branch" statement to the cleanup-identity repair alone. That resolves the original suggestion 1 and matches what the code review found.
- **Historical results not relabeled:** The table rows for `da059ca3`, `1d366d4d` and the CI303/304 observations are untouched. The new section is appended under its own heading and says the observations above "remain historical". The stale `493caa4e…`/parent304 text is supplemented, not rewritten, which is the right treatment.
- **The 227 row:** "76 projection + 43 journey + 94 export + 14 reader" sums to 227, so the original "227 vs 228" concern was a misreading. The adjacent repaired row (79 + 43 + 94 + 14 = 230) is consistent with it. The 77 pass / 2 fail RED run is a different execution and is correctly not folded into either row.
- **EOF blank line:** Removing the trailing blank line in `skills-check-journey.md` is a pure whitespace fix and clears the `git diff --check` finding.

## Optional

The "Fresh local checks passed: 239 focused tests, 241 document checks…" sentence has no run ID, log or archive binding. Elsewhere the README says raw evidence binds each execution to its candidate. A short clause saying these fresh checks are not part of the 1,868-member archive or its receipt, if that is true, would keep readers from assuming they are. I don't count it as a defect.