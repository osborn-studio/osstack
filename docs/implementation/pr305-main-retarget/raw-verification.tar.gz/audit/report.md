**Verdict: PASS.** I found no blocker in the code or CI change shown. This is a static read only. I ran nothing, and the test counts and CI results quoted in the READMEs are the PR's own claims, which I did not check.

## What I checked

- **Explicit v2 with unchanged v1 producer:** `parseOptions` accepts `--scope full` only as the sixth argument of the projection form, and `--check ... --scope full` falls through to usage. `projectJourney` rejects any scope other than `undefined` or `'full'`.
  - A five-row input without the option, or a two-row input with it, fails `fixed_case_set`. That happens inside `buildProjection`, before `mkdir`, so no output is created.
  - The v1 producer path keeps `safeLine`, `SCOPE`, `IDS` and the old `fixed_expectation` check.
- **`--check` auto-versioning:** `validatePacket` picks the rules from `schema_version` (1 or 2). Any other version is rejected as `packet_version_scope`. A v1 or v2 packet relabeled as the other fails on case count and scope equality. The manifest envelope stays version 1 for both formats, which matches the docs.
- **Failed, `not_run` and unknown rows:** the non-passed branch is unchanged. It forces `product_exit: null`, `product_status: 'unknown'` and `fixed_removed: null`, and keeps the reported values separate. `FULL_IDS` now flows through the `cases` entry limit, the manifest index limit, the stream and reference limits, and `not_run_claim`.
- **Raw input unchanged:** reads go through `bounded` (`O_RDONLY | O_NOFOLLOW`), and the input/output overlap and scratch-root checks are untouched. The new `fixture_path` handling only builds strings (`join`, `pathToFileURL`) and compares them, so it never opens a path or traverses one.
- **No unrelated fixture fields:** the packet carries only fixed IDs, hashes and allowlisted lines. The `safeFullLine` allowlist adds only the drift row and the 0/1/3 source counts. Error codes stay `[a-z_]+`, and malformed-shape TypeErrors fall through to the generic CLI code.
- **Passed row with non-empty stderr:** this is rejected in the packet validator (`passed_stderr_conflict`, for both v1 and v2) and in the full producer path (`git_raw` requires empty Git stderr, and `evaluateCase` handles product stderr).
- **Cleanup identity:** the check on `cleanup.json`, `receipt.cleanup` and `feature.cleanup` runs before `cleanup()` strips `fixture_path`. `fullExpectation` further ties that path to `origin`, the git `cwd` and the expected source URLs.

## Non-blocking suggestions

1. **v1 checker is tightened, not unchanged.** `passed_stderr_conflict` in `validatePacket` applies to v1 as well. A previously accepted malformed v1 packet now fails `--check`. Valid v1 producer bytes are unchanged. Say "v1 output unchanged; v1 check stricter" in `docs/implementation/method-full-projection/README.md` rather than "the default v1 branch is unchanged".
2. **Test gap for the Git checks.** I see no regression test for `git_raw` (non-empty `git-0N` stderr), `git_index` (missing or duplicate label), or `git_observation` (cwd mismatch). The README promises the non-empty-stderr refusal, so add one reseal-and-reject case next to the `full passed source rejects resealed ...` loop.
3. **Overstated sentence in `maintain-verification.md`.** "Packet checking validates retained evidence structure and byte consistency" reads as if `--check` reopens the evidence. It validates only the packet and its own manifest (`original_evidence_revalidated: false`). The journey recipe words this correctly; copy that wording.
4. **Duplicated expectations and brittle comparisons in `fullExpectation`.** The projector rebuilds `POLICIES` and the source objects itself, although the test already imports `caseDefinition`. Source and stdout equality use `JSON.stringify`, so they depend on key order, and `pathToFileURL(origin).href` assumes the driver builds URLs the same way (a path with spaces or `%` would differ from naive `file://${path}`). The full tests would catch drift in a changed `caseDefinition`. Deriving from it, or comparing order-insensitively, is cleaner. The `git-03`/`git-05` label numbering is also a hidden coupling to the driver's command sequence.
5. **Empty-stderr digest not enforced.** A passed row checks `bytes === 0` for stderr but not that `sha256` is the empty-input digest. The README already admits this, and it matters little since hashes do not authenticate anything.
6. **Hygiene nits.** The diff adds a trailing blank line at EOF in `skills-check-journey.md` (`git diff --check` flags this), and two consecutive blank lines before the first new test.
7. **Stale retarget text.** The README says "actual main at this observation remains `493caa4e…`" and "parent304 must be retargeted". BASE is now `5248195…`. A one-line retarget addendum would stop readers taking that as current state.
8. **Test arithmetic.** "Initial standalone combination … 227 passed" does not equal 77 + 43 + 94 + 14 = 228, which the README's own counts imply. A different export-test count at `cc6b67c3` would explain it, but the README should say so.

## Not verifiable from what you gave me

- The diff omits `docs/design/*`, the evidence JSON and tarballs, `package.json`, and `scripts/lib/skills-check-verification.mjs`. Confirm that `caseDefinition(id, origin, oldSha, currentSha)` is already exported at BASE and that `method:project-evidence` exists in `package.json`.
- The CI step needs its input directory name (`method-journey-full-ci-evidence`) and the shared `OSSTACK_SCRATCH_ROOT` to match the earlier step's. If that job is a matrix, the artifact name `method-full-packet-evidence-${run_id}-${run_attempt}` could collide.
- Check `git merge-base --is-ancestor 5248195… 6f79d12…`. The four-hash line you pasted is ambiguous about ancestry.

No authentication, oracle or runtime-qualification claim appears in the code or the docs I read. The docs state the opposite limits consistently.