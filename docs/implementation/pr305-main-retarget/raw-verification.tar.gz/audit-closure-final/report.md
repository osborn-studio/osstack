**Verdict: PASS**

This is a static read of the two hunks in the supplied diff. I ran nothing and did not check the HEAD or the files on disk.

- **Splice removed:** `maintain-verification.md` now reads "This consistency check does not replace the source review, actual drives and cleanup observations required for maintenance, or turn failed/unknown/not-run rows into passed ones." The stray "it" is gone, and the rest of the paragraph is unchanged.
- **Evidence boundary added:** the README now says "These fresh local observations bind to `6f79d125` and are retained separately from the original 1,868-member archive." That covers the optional suggestion. It sits before the "Fresh published-head CI remains a separate condition" sentence, so the CI caveat is unchanged.
- **Scope:** the diff touches only these two hunks. The historical rows, the v1/v2 stricter-checker paragraph and the packet-vs-original-evidence wording are untouched.

**Caveat:** the "retained separately" clause is a factual claim I can't check from a diff. The author should confirm the fresh-check logs are in fact stored outside the archive and receipt. It also uses the short hash `6f79d125`, while the same paragraph gives the full hash, which is cosmetic only.