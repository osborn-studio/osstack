from pathlib import Path
import json,hashlib,datetime,subprocess,os,stat
I=Path(__file__).resolve().parent;O=I/'validation-final';O.mkdir();R='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';A='0f2e383b8d8f630947599ac6e7856d0acd6c409e';B='14853ad61ebb396141a10f69a614cb59f27fa19b';N='/opt/homebrew/opt/node@22/bin/node';rows=[];fail=[]
def hash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def git(s,p):return subprocess.check_output(['git','show',s+':'+p],cwd=R)
save(O/'freeze-timing-supplement.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'criteria_sha256':hash(I/'criteria.json'),'correction':'Criteria were frozen before independent verifier inspected candidate or ran candidate checks, not proven before author implementation. Parent observed concurrent untracked source; author later confirmed implementation preceded freeze notification. Earlier messages claiming author had not implemented are withdrawn. Original criteria/records unchanged.','author_candidate':A,'formal_principal':False})
source=O/'read-method-material.mjs';source.write_bytes(git(A,'scripts/read-method-material.mjs'));env={'PATH':'/opt/homebrew/opt/node@22/bin:/usr/bin:/bin','HOME':str(O/'unused-home'),'OSSTACK_HOME':str(O/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':str(O/'runtime'),'LANG':'C','LC_ALL':'C'}
def call(label,args,expected=0,script=source):
 argv=[N,str(script),*args];r=subprocess.run(argv,cwd=O,env=env,capture_output=True,timeout=5);p=O/'raw'/label;p.parent.mkdir(exist_ok=True);Path(str(p)+'.stdout').write_bytes(r.stdout);Path(str(p)+'.stderr').write_bytes(r.stderr);row={'label':label,'argv':argv,'cwd':str(O),'env':env,'exit':r.returncode,'expected_exit':expected,'stdout_sha256':hash(Path(str(p)+'.stdout')),'stderr_sha256':hash(Path(str(p)+'.stderr'))};save(Path(str(p)+'.command.json'),row);rows.append(row)
 if r.returncode!=expected:fail.append({'label':label,'reason':'exit','actual':r.returncode,'expected':expected});return None
 if expected!=0:
  try:d=json.loads(r.stderr);assert isinstance(d.get('error'),str) and r.stdout==b'' and 'text'not in d
  except Exception as e:fail.append({'label':label,'reason':'error_shape','detail':str(e)})
  return None
 return json.loads(r.stdout)
def paginate(path,label,lines=60):
 raw=path.read_bytes();parts=[];start=1;sha=None;pages=[]
 while True:
  args=['--file',str(path),'--start',str(start),'--lines',str(lines)]+(['--sha256',sha]if sha else [])
  d=call(label+'-p'+str(len(pages)+1),args)
  if d is None:return
  pages.append(d);expectedlines=raw.count(b'\n')+(1 if raw and not raw.endswith(b'\n')else 0)
  assert d['sha256']==hash(path) and d['file_bytes']==len(raw) and d['total_lines']==expectedlines
  assert d['start']==start and d['end']==min(start+lines-1,expectedlines)
  assert d['eof']==(d['end']==expectedlines)
  parts.append(d['text'].encode())
  if d['eof']:assert d['next_start']is None;break
  assert d['next_start']==d['end']+1;start=d['next_start'];sha=d['sha256']
 assert b''.join(parts)==raw,label
 return {'path':str(path),'source_sha256':hash(path),'pages':len(pages),'bytes':len(raw),'lines':expectedlines,'exact_reassembly':True}
fixture_results=[]
for name in ['lines-64-tail-0.md','lines-64-tail-1.md','lines-65-tail-0.md','lines-65-tail-1.md','mixed-crlf.md','bom-utf8.md','empty.md','blank-lines.md','exact-page.md','real-evidence.md']:
 fixture_results.append(paginate(I/'fixtures'/name,'fixture-'+name))
f=I/'fixtures/real-evidence.md';h=hash(f)
neg=[('tail-nohash',['--file',str(f),'--start','61']),('wronghash-first',['--file',str(f),'--sha256','0'*64]),('wronghash-tail',['--file',str(f),'--start','61','--sha256','0'*64]),('beyond-eof',['--file',str(f),'--start','65','--sha256',h]),('duplicate',['--file',str(f),'--file',str(f)]),('unknown',['--file',str(f),'--noop','1']),('startzero',['--file',str(f),'--start','0']),('negative',['--file',str(f),'--start','-1']),('noninteger',['--file',str(f),'--lines','1.5']),('unsafeinteger',['--file',str(f),'--start','9007199254740992']),('lines201',['--file',str(f),'--lines','201']),('missingfile',['--file',str(O/'does-not-exist')]),('invalidUTF8',['--file',str(I/'fixtures/invalid-utf8.md')]),('filecap',['--file',str(I/'fixtures/oversized-file.md')]),('pagecap',['--file',str(I/'fixtures/over-page-unicode.md')]),('directory',['--file',str(O)]),('empty-beyond',['--file',str(I/'fixtures/empty.md'),'--start','2','--sha256',hash(I/'fixtures/empty.md')])]
symlink=O/'final-link.md';symlink.symlink_to(f);fifo=O/'fifo';os.mkfifo(fifo);neg.extend([('finalsymlink',['--file',str(symlink)]),('fifo',['--file',str(fifo)])])
for label,args in neg:call('negative-'+label,args,1)
# One mutable owned copy demonstrates identical-length drift with actual first-page hash.
drift=O/'drift.md';drift.write_bytes((I/'fixtures/drift-a.md').read_bytes());first=call('drift-first',['--file',str(drift),'--lines','1']);drift.write_bytes((I/'fixtures/drift-b.md').read_bytes());call('drift-tail',['--file',str(drift),'--start','2','--sha256',first['sha256']],1)
# Exact file byte cap: bounded page, not whole-file stdout.
cap=O/'exact-file-cap.md';cap.write_bytes(b'x\n'*524288);d=call('exact-file-cap',['--file',str(cap),'--lines','2']);assert d['file_bytes']==1048576 and d['text']=='x\nx\n'and not d['eof']
# Produce both real exports using B material snapshot + unchanged exporter, reader from A.
snap=O/'snapshot';paths=subprocess.check_output(['git','ls-tree','-r','--name-only',B,'--','osstack-methods-skill'],cwd=R,text=True).splitlines()+['scripts/export-osstack-methods.mjs','scripts/lib/osstack-method-export.mjs']
for p in paths:q=snap/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(git(B,p))
export_results=[]
for host in ['codex','claude']:
 out=O/('export-'+host);d=call('export-'+host,['--host',host,'--output',str(out)],script=snap/'scripts/export-osstack-methods.mjs');assert d['status']=='exported'
 manifest=json.loads((out/'manifest.json').read_text());files=manifest['files'];parts=[]
 for n,e in enumerate(files):
  p=out/e['path'];assert hash(p)==e['sha256'];parts.append(paginate(p,host+'-'+str(n)))
 export_results.append({'host':host,'payload_count':len(files),'manifest_sha256':hash(out/'manifest.json'),'page_reassembly':parts})
# Verify all original frozen fixture bytes remained unchanged; do not read FIFO as a regular file.
for v in json.loads((I/'criteria.json').read_text())['vectors']:assert hash(I/v['path'])==v['sha256']
report={'reader_candidate':A,'reader_sha256':hash(source),'material_candidate':B,'criteria_sha256':hash(I/'criteria.json'),'timing_supplement_sha256':hash(O/'freeze-timing-supplement.json'),'fixtures':fixture_results,'negative_count':len(neg)+1,'command_count':len(rows),'failure_count':len(fail),'failures':fail,'actual_exports':export_results,'model_calls':0,'semantic_review':{'MR09':'B absolute checkout helper command/path and original SHA continuation match API; handles preview/page-too-large/version drift, narrow entry denial and task stop rule.','MR10':'Explicitly states EOF/raw delivery/understanding/native/runtime distinct; old closed experiment cannot be retried/retroactively upgraded.'},'scope':'actual independent CLI/export bytes only, not model consumption; no general sandbox/concurrency-fencing claim'}
save(O/'report.json',report);print(json.dumps({'commands':len(rows),'failures':fail,'exports':[(e['host'],e['payload_count'])for e in export_results],'report_sha256':hash(O/'report.json')}))
