from pathlib import Path
import json,hashlib,datetime,subprocess
P=Path(__file__).resolve().parent;R=P.parent;S=json.loads((R/'scope.json').read_text());D=P/'fixtures';D.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
fixtures={}
for n in [64,65]:
 for tail in [False,True]:fixtures[f'lines-{n}-tail-{int(tail)}.md']=('\n'.join(f'row{i:02}: 原始 ✓'for i in range(1,n+1))+ ('\n'if tail else '')).encode()
fixtures.update({'mixed-crlf.md':b'first\r\n\r\n'+ '三\n'.encode()+b'last\r\n','bom-utf8.md':b'\xef\xbb\xbf'+ '首行\r\n第二行\n'.encode(),'empty.md':b'','blank-lines.md':b'\n\r\n\n','invalid-utf8.md':b'valid\n\xffbad\n','oversized-file.md':b'x'*(1048576+1),'over-page-unicode.md':('字'*5462).encode(),'exact-page.md':b'x'*16384,'drift-a.md':b'first\nsecond\n','drift-b.md':b'FIRST\nsecond\n'})
source_path='osstack-methods-skill/references/evidence.md';real=subprocess.check_output(['git','show',S['base']+':'+source_path],cwd='/Volumes/AIMATE_WORK/Developer/CodeX/osstack');fixtures['real-evidence.md']=real
manifest=[]
for name,data in fixtures.items():
 (D/name).write_bytes(data);lines=0 if not data else len(data.split(b'\n'))-(1 if data.endswith(b'\n')else 0)
 manifest.append({'path':'fixtures/'+name,'bytes':len(data),'sha256':sha(data),'LF_content_lines':lines})
criteria=[
('MR01','Read-only standalone interface; strict unique known flags and bounded positive integer parameters. No install/network/DB/model/global access; failure is nonzero structuredJSON without file text.'),
('MR02','Real64-line evidence and synthetic64/65 with/without trailingLF: default60 returns eof=false and next_start61, tail reaches actualend; concatenated UTF8 encoded texts exactly equal sourcebytes. Missing last page never called complete.'),
('MR03','Mixed LF/CRLF/blank lines and UTF8BOM are valid bytes. Preserve exact selected line delimiters/content; total_lines follows LF split excluding only terminal empty element. No implicit BOM/CR/newline normalization.'),
('MR04','Subsequent start>1 without exact whole-file SHA rejected; correct hash succeeds. Wrong first-page hash and same-length changed-file/oldhash rejected with no content.'),
('MR05','File cap1MiB, pageUTF8cap16384 and linesmax200 enforced by bytes. Exactcap accepted if other constraints hold; oversized line must fail explicitly, not silently truncate or claim EOF.'),
('MR06','Emptyfile start1 textempty/total0/eoftrue; beyondEOF invalid except that case. Page metadata and next_start consistent with exact covered lines; no requirement that eof proves prior pages were read.'),
('MR07','InvalidUTF8, oversizedfile, finalsymlink, FIFO/directory rejected without blocking/content. Final-component restriction only; no parent-path sandbox or hostile concurrency fencing claim.'),
('MR08','Two actual host exports: reader pages on every exported Markdownpayload concatenate to exact originals, fullhash consistent, all terminalpages coherent. Existing exporter behavior/schema unchanged.'),
('MR09','Usage guidance must use available command/path and exact current hash for continuation; tiny advisory page budgets may require smallerpages on error. Permission denial stops/no disguised retries or automatic permission expansion.'),
('MR10','Reader output coverage, host-native Skill event, model-visible delivery and model understanding are distinct. No retroactive upgrade of previous LIMITED, receipt/gate/provider qualification, or claim this helper prevents arbitrary outside IO.')]
frozen={'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'prefrozen_independent_engineering_criteria_not_formal_principal','scope_sha256':sha((R/'scope.json').read_bytes()),'base':S['base'],'criteria':[{'id':i,'expectation':e}for i,e in criteria],'original_source':{'path':source_path,'sha256':sha(real),'bytes':len(real),'LF_content_lines':len(real.split(b'\n'))-1},'vectors':manifest,'candidate_not_read':True,'model_calls':0,'future_negative_actions':['In isolated copies change only firstword of drift-a to same-length drift-b after firstpage, then request tail with originalhash.','Create finalsymlink and namedpipe under independent scratch; bound reader child externally to avoid hanging verifier.','CLI duplicate/unknownflags, start0/negative/noninteger/unsafeinteger, lines201, missingfile, start beyondEOF.'],'schema_limits':'Empty end and EOF next_start exact representation not specified by root; test consistency and documentation rather than invent values. Dynamic errors checked by structuredJSON/nonzero/no file text, not message wording.'}
with(P/'criteria.json').open('x')as f:json.dump(frozen,f,ensure_ascii=False,indent=2);f.write('\n')
with(P/'criteria.md').open('x')as f:f.write('# Material reader 独立验收冻结\n\n'+frozen['frozen_at']+'。不调用模型、不签正式 oracle 资格。\n\n'+'\n'.join('- **'+i+'** '+e for i,e in criteria)+'\n\n已从固定 Git 读取真实64行 evidence 原件；以上预生成夹具及摘要均在候选实现读取前保存。将运行真实CLI和两host导出分页重组，不以文本关键词测试代替行为。EOF只是本页达到文件末尾，绝不是模型已理解或先前页已交付。旧LIMITED保持不变。\n')
print('criteria',sha((P/'criteria.json').read_bytes()));print('md',sha((P/'criteria.md').read_bytes()));print('real lines',frozen['original_source']['LF_content_lines'])
