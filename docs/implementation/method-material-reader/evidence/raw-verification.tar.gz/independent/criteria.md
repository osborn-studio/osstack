# Material reader 独立验收冻结

2026-10-29T06:50:33.925769+00:00。不调用模型、不签正式 oracle 资格。

- **MR01** Read-only standalone interface; strict unique known flags and bounded positive integer parameters. No install/network/DB/model/global access; failure is nonzero structuredJSON without file text.
- **MR02** Real64-line evidence and synthetic64/65 with/without trailingLF: default60 returns eof=false and next_start61, tail reaches actualend; concatenated UTF8 encoded texts exactly equal sourcebytes. Missing last page never called complete.
- **MR03** Mixed LF/CRLF/blank lines and UTF8BOM are valid bytes. Preserve exact selected line delimiters/content; total_lines follows LF split excluding only terminal empty element. No implicit BOM/CR/newline normalization.
- **MR04** Subsequent start>1 without exact whole-file SHA rejected; correct hash succeeds. Wrong first-page hash and same-length changed-file/oldhash rejected with no content.
- **MR05** File cap1MiB, pageUTF8cap16384 and linesmax200 enforced by bytes. Exactcap accepted if other constraints hold; oversized line must fail explicitly, not silently truncate or claim EOF.
- **MR06** Emptyfile start1 textempty/total0/eoftrue; beyondEOF invalid except that case. Page metadata and next_start consistent with exact covered lines; no requirement that eof proves prior pages were read.
- **MR07** InvalidUTF8, oversizedfile, finalsymlink, FIFO/directory rejected without blocking/content. Final-component restriction only; no parent-path sandbox or hostile concurrency fencing claim.
- **MR08** Two actual host exports: reader pages on every exported Markdownpayload concatenate to exact originals, fullhash consistent, all terminalpages coherent. Existing exporter behavior/schema unchanged.
- **MR09** Usage guidance must use available command/path and exact current hash for continuation; tiny advisory page budgets may require smallerpages on error. Permission denial stops/no disguised retries or automatic permission expansion.
- **MR10** Reader output coverage, host-native Skill event, model-visible delivery and model understanding are distinct. No retroactive upgrade of previous LIMITED, receipt/gate/provider qualification, or claim this helper prevents arbitrary outside IO.

已从固定 Git 读取真实64行 evidence 原件；以上预生成夹具及摘要均在候选实现读取前保存。将运行真实CLI和两host导出分页重组，不以文本关键词测试代替行为。EOF只是本页达到文件末尾，绝不是模型已理解或先前页已交付。旧LIMITED保持不变。
