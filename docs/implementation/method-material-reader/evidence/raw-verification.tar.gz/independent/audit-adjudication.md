# Independent audit adjudication

Audit source: `audit/report.md`, SHA256 14b443fbca2f81537ac2fb668f53637df6a4b69135ff87b684a15337b0862855. This is a limited read-only adjudication. No source modification, model call or full-suite run.

## Confirmed blockers and correction to my earlier review

**B1 confirmed.** The original `It does not bypass host permissions` sentence is misleading. This executable accepts an arbitrary path and reads under the subprocess user’s OS permissions; the host’s own Read-tool ACL is not automatically inherited. The existing final-symlink/type/size checks do not provide a path allowlist. Root’s chosen documentation correction is sufficient for the stated non-sandbox scope: declare OS permissions/no allowlist/no inherited file-tool policy, and prohibit using the helper to bypass a denied or unauthorized task path. A new general read sandbox is unnecessary here.

My earlier MR09/static boundary review did not catch that sentence and was too broad in reporting the permission wording consistent. That conclusion is corrected here; the preserved 233 actual command results remain valid byte/interface observations, not ACL enforcement evidence. No protected-path or credential probe was performed.

**B2 publication record remains to close, not a demonstrated code defect.** The README placeholder must be replaced with the actual full-suite/audit result before the claimed publication gate. Independent scoped checks never substitute for full tests. The audit’s inability to see the bug-fix delta is a context limitation: `7abb0baddff719bc659a078087b79fafcee1797f` actually changes step4 to behavioral test RED before source edits, same controlled test/inputs for GREEN, and honest treatment of revised inputs. It does not add pagination to that method and need not do so. Root’s currently observed README accurately distinguishes this change from host-usage pagination; preserve that wording rather than remove the valid change claim.

## Optional suggestions, with actual coverage

1. **Hash/concurrency wording:** worthwhile cheap clarification. The current root README already says “If a supplied digest no longer matches ...”, which removes the overstatement. Returned hash describes the observed buffer; neither the hash nor stat snapshots fence concurrent writers.
2. **Nanosecond stats:** optional incremental detection improvement, not a blocking guarantee. Even nanoseconds cannot establish arbitrary concurrent-writer exclusion. Do not broaden this slice into a race-proof reader.
3. **procfs/sysfs error classification:** optional platform-specific diagnostics. No such behavior was executed here. Safe rejection under an imperfect code is not evidence of accepted unauthorized content.
4. **Serialized output/truncation:** real usability limitation, not a contradiction of the explicit *page text* 16KiB bound. JSON control-character escaping can expand more than the audit’s quote-only ~2x example. Placing metadata before text is a cheap possible improvement; neither order nor a length field proves actual delivery. Do not claim the current helper prevents host truncation. Existing docs correctly retain this limit.
5. **Suggested tests:** exact1,048,576-byte acceptance **was independently executed**, in `validation-final/raw/exact-file-cap.command.json` (2-line bounded page), and again with max200 lines in `max-lines200.command.json`. First-page wrong-hash rejection **was executed** in `negative-wronghash-first.command.json`; this does **not** establish the untested positive first-page supplied-hash case. Uppercase hashes, symlinked parent behavior, `file_changed`/growth-during-read were not part of my233 commands; do not mark them covered. Importing/injecting filesystem failures is optional infrastructure, not required to support the already observed outcomes.
6. **No-Intl decoder builds:** optional portability concern. No such build was tested; supported local Node22 succeeded, including BOM/invalidUTF8 boundaries.
7. **Windows:** unverified platform limitation. The reviewed CI has Ubuntu and macOS jobs, not a Windows job. Do not add a false Windows guarantee or blanket-skip safety checks under this scope.
8. **Additional error guidance:** useful but optional. `sha256_required` should lead to starting/pinning the first page, `start_beyond_eof` to checking the reported range/version, and `file_changed` to preserving the failed read and starting a new authorized snapshot. Unsupported long single lines are an explicit scope boundary; no fallback platform is needed.
9. **CI wiring:** `14853ad6` has a dedicated `pnpm test:method-read` workflow step and package script. Root `pnpm test` is `pnpm -r test`, so it does not itself imply this standalone root Node test ran. Keep separate root-reader and full-package results in the publication record.

## Scope of prior evidence

The successful independent run was 231 reader commands plus two real exports, all in `validation-final/`; 88 payloads per host were reconstructed byte-for-byte. Earlier syntax and log-filename-collision failures remain preserved as verifier failures. Freeze timing is only before independent candidate inspection/testing, not before author implementation. The old Claude trial stays LIMITED, and no new host-understanding, permission-enforcement or formal-principal result is issued.
