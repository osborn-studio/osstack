# Method material reader author evidence

Base: 493caa4e46e616b1d7e9e1c87ed0a5775eae3ad1. Node 22.22.1. Only reader and test changed.

`red.*` is an initial harness error: this baseline scratch helper exports async createScratchDir only. It is not behavioral RED. `behavior-red.*` is the corrected test suite before reader implementation: all 14 failed because the CLI did not yet exist. `green.*` binds the same behavioral tests and new reader: 14 passed, zero skipped.

`actual-exports.commands.json` and per-command raw streams retain fresh Codex/Claude exports plus seven-line hash-pinned reconstruction of each exported evidence.md. Selected text bytes match the original exactly; this proves delivery, not model reading or understanding. No models, full suite, installation, database or runtime qualification invoked.

The CLI bounds file and page text bytes, rejects terminal symlinks/nonregular files and pins later pages. Parent path traversal is not a sandbox; stat checks are not a concurrent-writer fence. Requested page bytes and JSON escaping are different sizes. Source bytes remain read-only.
