# Final claims check

Read-only check at 2026-10-29T06:59:28.433880+00:00. No tests or model calls were run for this review. This is a wording/source/evidence comparison, not an independent host-effect experiment.

Reviewed root working-tree README at `docs/implementation/method-material-reader/README.md`, SHA256 `6b43031863048ffdbcca96377e1c5d4d5cec7a2bc2ab7e189c47e83cf9dd2f6a`. It was untracked when read; it is not the contents of commit `14853ad61ebb396141a10f69a614cb59f27fa19b`. Root references at that commit are byte-identical to author B `7abb0baddff719bc659a078087b79fafcee1797f`. Reader implementation is A `0f2e383b8d8f630947599ac6e7856d0acd6c409e`.

No confirmed material overclaim found in the reviewed README.

- The prior 60-of-64 limitation agrees with the actual Claude read trace and retained independent LIMITED result. This slice does not rerun or upgrade that result.
- The source-checkout-only statement agrees with real exports: each host exported 88 members; neither bundle includes the checkout reader. Four entries retained exact updated reference bytes. This proves packaging, not native discovery.
- Author paging evidence is four actual coordinator CLI invocations on two exported evidence files. Each returned lines 1–60 with EOF false, then 61–64 with the original hash and EOF true. Concatenation equals the original 6,441 bytes and SHA256 `9cab2fbbc75cc1dba4d6a6a7ea7f1ecadc4f0ddf1f120c90f85be6c4b6a5237d`. This supports page delivery and continuation only; no model consumed these results in this validation.
- The README explicitly excludes model-visible delivery, reading, understanding, native discovery and formal qualification. The references additionally say that an already complete host-tool result needs no helper, and that EOF on one page does not prove prior pages reached the model. These limits match the evidence.
- The implementation uses only filesystem/crypto/path builtins, no write API, network, credential access or daemon. Its parent-path and concurrent-writer limitations are explicit. No OS isolation claim is made.
- The reference change preserves the cheap-local-test condition, then requires intended behavioral RED before a source fix and the same test/controlled inputs for GREEN. It does not require eight calls for all repairs. Test nonzero and permission denial remain distinct, and closed experiments are not automatically retried.

Optional precision only: the README's “Changed content fails before any page text is emitted” follows the pinned continuation example and is correct in that context. “If the supplied digest no longer matches, the request fails before emitting page text” would avoid reading it as a guarantee that an unpinned first request detects every historical or concurrent change. The following paragraph already denies a concurrent-writer fence, so this is not a blocking defect.

Evidence pointers: `export-tests.stdout` (94 passed); `codex-export.command.json`; `claude-export.command.json`; `reader-validation/result.json` and its four command/stdout/stderr sets; `source-map.json`. Their original manifest remains SHA256 `718a02c5bfaf11430c9945f857d0d4dc158e7eaf84e58500c25639cc80d74d0b`; this later review is intentionally outside that frozen manifest. Root's full suite and actual Sonnet audit were still in progress and are not claimed here.
