# Verdict: REVISE

I read the code and docs only; no tools were available, so nothing here was executed. I traced the page arithmetic and the argument parser by hand and found no code defect. The blockers are a false boundary claim and an unfinished record.

## Blockers

**B1. "It does not bypass host permissions" is false in the way that matters** (`host-usage.md`, last sentence of the helper paragraph).

The helper takes any `--file` with no path scope and runs as a subprocess with the user's OS permissions. Host rules on the host's own file tool, such as a Read deny on `.env`, do not apply to it. Whether a given host's Bash permission layer filters file paths is host-specific, and I could not check that.

Reproduction, assuming the host denies its Read tool on a path but allows this script as a command:
```sh
node /abs/checkout/scripts/read-method-material.mjs --file /abs/project/.env
```
The command returns the contents as JSON for any UTF-8 file of at most 1 MiB. In practice, permission to run this script is read access to every such file the user can read.

Fix, either of these:
- Reword to something like: "Runs with the invoking user's OS permissions. Host file-tool allow/deny rules are not applied to it, and it has no path allowlist."
- Add a path scope, such as requiring `.md` or a skills/references directory. Given the stated non-sandbox posture, rewording alone is acceptable.

**B2. The validation record is not finished.**

- The README ends with "Candidate verification and actual Sonnet audit are recorded below after completion", and nothing follows it.
- The independent report says it ran no full suite, and full tests are still running, so PASS here cannot stand in for that gate.
- The README says the bug-fix instructions were updated, but the supplied `bug-fix.md` contains nothing about paging or complete reading. I did not see the diff, so I can't confirm what changed. State the actual change, or drop the claim.

Fill in or remove the placeholder, and record the full-suite result before merge.

## Checked and sound

- **Line math:** I traced these cases by hand:
  - `''`, `'\n'`, `'\n\n'` and `'a\n\n'`
  - no trailing LF, and a trailing lone `\r`
  - BOM and CRLF split across a page boundary (CR stays attached to its line)

  In all of them the concatenated page texts equal the original.
- **UTF-8:** `fatal` plus `ignoreBOM: true` keeps the BOM, and valid UTF-8 re-encodes byte-exactly.
- **Strict inputs:**
  - JS `$` does not match before a trailing `\n`, so `"1\n"` is rejected.
  - Unsafe integers, duplicate flags, odd argument counts, empty values and `--help` with extra arguments are all refused.
  - `sha256_required` fires before any file is touched.
- **Open race:** `lstat` followed by `O_NOFOLLOW|O_NONBLOCK` and then `fstat` handles a symlink, FIFO, directory or device swapped in after the `lstat`. Returned text and `sha256` always come from the same buffer, which is the real guarantee. The mtime/ctime comparison is best-effort, and the docs already say this is not a writer fence.

## Suggestions

1. **TOCTOU wording.** The README line "Changed content fails before any page text is emitted" is only true against a supplied hash. A first page has nothing to compare, and the stat check is best-effort. Say "hash describes the returned bytes; later pages fail on mismatch."
2. **Stat precision.** Use `fstatSync(fd, { bigint: true })` with `mtimeNs` and `ctimeNs`. Linux coarse timestamps can still hide same-tick writes, so keep the disclaimer.
3. **`file_changed` is misleading for procfs and sysfs.** Those report `size` 0 but yield content, so they hit `file_changed` rather than a not-regular-file code. It is safe but mislabeled. Also, growth past the limit during the read reports `file_too_large` rather than `file_changed`.
4. **Output size versus host truncation (unverified against any specific host).**
   - `TEXT_LIMIT` caps raw text, but JSON escaping can roughly double a quote-heavy page, to about 32 KB for 16 KiB of `"`.
   - `eof` and `next_start` come after `text` in the JSON. A host that tail-truncates would drop exactly the fields that stop tail-hiding.
   - Emit the metadata first and `text` last, or cap serialized bytes.
   - Optionally add a `text_bytes` field so truncation is detectable.
5. **Untested paths.**
   - `file_changed` and growth during the read.
   - Exactly 1,048,576 bytes accepted.
   - Uppercase `--sha256` accepted.
   - A symlinked parent directory works (documented behavior).
   - `--start 1 --sha256` verifying on the first page.

   The script isn't importable because it runs `main` at load. Guarding `main` behind an `import.meta.url` check would let tests inject `fs` failures.
6. **Decoder error mapping.** The `catch` maps every decoder failure to `invalid_utf8`, including `ERR_NO_ICU` on Node builds without Intl. `buffer.isUtf8` (Node 18.14 and later) avoids this.
7. **Windows.** `O_NOFOLLOW` and `O_NONBLOCK` are undefined there, so the flags silently become 0. The symlink test may also fail with EPERM. Gate the tests on platform if Windows is in the CI matrix.
8. **Docs.** `host-usage.md` should say what to do on `file_changed`, `start_beyond_eof` and `sha256_required`. It handles only the hash mismatch and `page_too_large`. There is also no fallback for a single line over 16 KiB beyond "report it unsupported". That is honest, but it makes a minified 1 MiB file unreadable through the helper.
9. **CI wiring.** The `ci.yml` step is fine. I could not see whether any aggregate `test` script exists that also needs `test:method-read`.