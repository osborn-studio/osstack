from pathlib import Path
import subprocess,json,hashlib,time,os
P=Path(__file__).resolve().parent;REPO=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack');NODE='/opt/homebrew/opt/node@22/bin/node'
SHAS={'old':'4611fd6de998868e09fef042dc142bb52efaa6dd','fixed':'a1cb1779d62107d2c4f101b98311f3ec39116ae1'}
NAMES=['osstack-mode','osstack-help','setup-osstack','osstack-agent'];rows=[];bindings=[]
# Historical production files and method source tree, not a reimplemented checker.
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',SHAS['old'],'--','osstack-methods-skill'],cwd=REPO,text=True).splitlines()
source={path:subprocess.check_output(['git','show',SHAS['old']+':'+path],cwd=REPO) for path in paths}
# Incident text is the exact regression added in the real fix commit.
cases={'incident':b'```md\nexample\n```\r\n[x](../../references/missing.md)\n','canonical':None,'valid-fenced-example':b'```md\n[x](../../references/missing.md)\n```\n','plain-invalid':b'[x](../../references/missing.md)\n'}
for version,sha in SHAS.items():
 for case,content in cases.items():
  root=P/'probes'/version/case;root.mkdir(parents=True)
  for path,b in source.items():
   f=root/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
  for path in ['scripts/export-osstack-methods.mjs','scripts/lib/osstack-method-export.mjs']:
   b=subprocess.check_output(['git','show',sha+':'+path],cwd=REPO);f=root/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
   bindings.append({'version':version,'source_sha':sha,'path':path,'sha256':hashlib.sha256(b).hexdigest()})
  if content is not None:(root/'osstack-methods-skill/entries/osstack-mode/SKILL.md').write_bytes(content)
  before={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file()}
  output=root/'output';env={'PATH':'/opt/homebrew/opt/node@22/bin:/usr/bin:/bin','HOME':str(root/'unused-home'),'OSSTACK_HOME':str(root/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack','LANG':'C','LC_ALL':'C'}
  argv=[NODE,'scripts/export-osstack-methods.mjs','--host','claude','--output',str(output)]
  start=time.monotonic();r=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=10);elapsed=time.monotonic()-start
  log=P/(version+'-'+case);log.with_suffix('.stdout').write_bytes(r.stdout);log.with_suffix('.stderr').write_bytes(r.stderr)
  assert all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in before.items())
  rec={'version':version,'case':case,'source_sha':sha,'argv':argv,'cwd':str(root),'env':env,'exit_code':r.returncode,'elapsed_seconds':elapsed,'output_created':output.exists(),'input_and_source_unchanged':True,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'stdout_path':log.name+'.stdout','stderr_path':log.name+'.stderr'}
  if output.exists():
   manifest=json.loads((output/'manifest.json').read_text());rec['export_members']=len(manifest['files']);rec['manifest_sha256']=hashlib.sha256((output/'manifest.json').read_bytes()).hexdigest()
   if case=='incident':
    out=(output/'.claude/skills/osstack-mode/SKILL.md').read_bytes();rec['incident_bytes_retained']=out==content;rec['missing_target_absent']=not(output/'.claude/skills/osstack-mode/references/missing.md').exists()
  rows.append(rec)
(P/'probe-results.json').write_text(json.dumps({'runs':rows,'bindings':bindings},indent=2)+'\n')
for r in rows:print(r['version'],r['case'],r['exit_code'],round(r['elapsed_seconds'],3),r['output_created'])
