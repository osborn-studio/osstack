# Verdict: PASS (closure of the conditional CI finding only)

This is a static closure. I executed nothing and make no claim about full or CI execution.

## Basis

The prior review made the CI item conditional on `scratchRoot()` having no safe default. The supplied `scripts/lib/scratch.mjs` shows it does have one:

```js
const override = env.OSSTACK_SCRATCH_ROOT?.trim();
return override ? resolve(override) : join(tmpdir(), 'osstack');
```

- An unset or blank `OSSTACK_SCRATCH_ROOT` resolves to `<os.tmpdir()>/osstack`, so the "Skills map maintenance contracts" step does not fail from the missing variable.
- `createScratchDir('tests', …)` builds its parent with `mkdir(..., { recursive: true })` under that same root, so the test fixtures don't depend on a pre-existing directory.
- The CLI test spawns with `env: process.env`, so the child resolves the same fallback.
- The CI diff matches your disposition: `pnpm install --frozen-lockfile` and `pnpm -r build` precede both new steps, and the workflow has no `defaults.run.working-directory` override. The relative script path in the CLI test therefore resolves from the repository root.
- `map.json` has the five rows with the expected exits and statuses (0/healthy, 1/failed, 2/drift, 1/failed, 0/empty).

## Disposition of the earlier item

- **Status change:** the "confirmed blocker" is withdrawn. It is now an optional consistency suggestion.
- **Optional hardening:** add the same `env: OSSTACK_SCRATCH_ROOT: ${{ runner.temp }}/osstack` block to the unit step. It would make the unit step's scratch location match its neighbors and make artifacts and debugging uniform. It is not required for correctness.

## Unchanged from my original report

- The original findings 1 and 2 stay closed, and the seam-provenance suggestion stays adopted.
- The optional suggestions stay as written: the evidence-shape note for 8ed11e37, the ambiguous raw `ENOENT`, `map.unchanged: false` on an after-read failure, the reference wording, and the artifact pin check.
- The "not verifiable" list still applies, with `lib/scratch.mjs` behavior now resolved by the supplied source. Still unverified are `maintain-skills-check-map.mjs` itself, `pnpm` argument pass-through, and the RED→GREEN history.
- One point is outside this closure, so I'm not reopening it. The unit tests place `output` under `…/tests/…`, not under a `runtime/` parent. My earlier hand trace treated them as passing, but I still haven't seen `runMaintenance`'s output-path validation. If it enforces a `runtime/` parent, the earlier trace was wrong. The tests in the suite that expect success would then contradict it, so I take it as not enforced.

PASS applies only to this closure. It is not an execution or CI-success claim.