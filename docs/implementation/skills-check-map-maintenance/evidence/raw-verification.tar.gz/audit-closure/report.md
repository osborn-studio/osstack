# Verdict: REVISE (one CI item), with source and test closure at PASS

I read the revised source and diffs statically and ran nothing. I traced the new and existing tests against the code by hand. That trace is not an execution result, and I make no claim about the ongoing full run or the CI step.

## Original findings

| Finding | Status | Basis |
|---|---|---|
| 1. Later failure overwrote the first failure, and `result.journey` was null after an identity or read failure | **Closed** | `fail()` keeps the first reason in `failure` and appends later ones to `subsequent_failures`. `result.journey` is now assigned before any file read, with nullable hashes and `receipt_matches_returned`. Status and exit always return to blocked/2 on any `fail`. |
| 2. Test header and title overstated what the suite does | **Closed** | The header now says real five-case runs are separate release evidence. The title now reads "real `runJourney` with a stubbed driver". |
| Optional: seam provenance | **Adopted** | `execution_path` has three values. The README says it is a declaration, not authentication. |

The other optional items (manifest cross-check, `map_json` and `map_utf8` codes, post-`mkdir` write failure, BOM and duplicate keys, the remaining test gaps) were not taken up. None blocks closure.

## Hand trace of the five new cases

- **Journey failure with map removed:** `failure` is `journey_failed`, and `subsequent_failures` is `['map_after:ENOENT']`.
- **Map change plus `map-after.json` collision:** `subsequent_failures` is `['map_changed','map_after:EEXIST']`.
- **Missing manifest:** `failure` is `ENOENT`, and `subsequent_failures` is `['map_changed']`. `journey.features` and `receipt_sha256` survive, `manifest_sha256` is null, and `rows` stays empty because the row check is never reached.
- **Receipt identity mismatch:** `failure` is `journey_result_identity`, with `receipt_matches_returned === false`.
- **Seam declaration:** `execution_path` is `injected_journey` and `runJourney_with_injected_driver`.

The 19 earlier tests still hold. `map_changed`, `journey_incomplete` and the doctor-failure expectations are unchanged, because those failures were already first. The suite now has 24 tests.

## Confirmed blocker

**The unit-contract CI step omits `OSSTACK_SCRATCH_ROOT`** (`ci.yml`, step "Skills map maintenance contracts")
- The tests call `createScratchDir('tests', …)`, and `runMaintenance` calls `scratchRoot()`. Both depend on the scratch root.
- The README lists `OSSTACK_SCRATCH_ROOT` as a prerequisite. The next existing step, "Model evidence projection contracts", sets it explicitly. Only the real-run step in this diff sets it.
- I haven't seen `lib/scratch.mjs`, so I can't confirm whether a missing variable fails or falls back to a default. If it fails, this step is red on its first CI run.
- The fix is one `env:` block, copied from the step below it. It is harmless if a default exists.
- If `scratchRoot()` has a safe default, this drops to optional and the overall verdict becomes PASS.

## Optional suggestions

- **Evidence shape.** The 671f change adds `subsequent_failures`, `execution_path` and `receipt_matches_returned`. It also makes `receipt_sha256` and `manifest_sha256` nullable, with `schema_version` still 1. The five-case evidence bound to 8ed11e37 therefore has an older `maintenance.json` shape. Don't cite it as the candidate's output format. A note in the handoff is enough.
- **Raw `ENOENT` is ambiguous.** The primary `failure` doesn't say whether the receipt or the manifest was missing. Use a code such as `journey_manifest_read` or `journey_receipt_read`. `receipt_sha256` and `manifest_sha256` already disambiguate it for a reader.
- **`map.unchanged: false` when the after-read failed.** It is indistinguishable from "changed", and `after_sha256: null` is the only hint. `null` would be more truthful.
- **Reference wording.** `maintain-verification.md` says the output is "a new directory under `OSSTACK_SCRATCH_ROOT`" and omits the `runtime/` parent requirement. It does defer to the README.
- **Artifact action pin.** Confirm the `upload-artifact` SHA is identical to the one in the existing step above it.

## Integration diff, checked and sound

- **`package.json`:** the two aliases map directly to the test file and the CLI. Nothing else changed.
- **Artifact path:** `${{ runner.temp }}/osstack/runtime/skills-map-ci-evidence` matches `$OSSTACK_SCRATCH_ROOT/runtime/skills-map-ci-evidence`. The map path is absolute and points to a checked-out regular file.
- **Artifact upload:** `if: always() && outcome != 'skipped'` uploads evidence on exit 1 or 2. It skips upload only when the unit step fails first, which is coherent. The artifact name is unique per run and attempt.
- **Reference text:** it matches the exit semantics, the "never corrects the map" rule, and the keep-the-first-comparison rule, and it makes no run claim.

## Not verifiable from the supplied material

- **`map.json` contents.** The real-run step exits 1 if any of its five cells is wrong.
- **Prior CI steps.** I saw only one hunk, so I can't confirm that `pnpm install` and `pnpm build` precede it (the README requires them), or that no `defaults.run.working-directory` breaks the CLI test's relative script path.
- **`pnpm` argument pass-through.** The `--map` and `--output` flags reaching the script is expected, but I haven't run it.
- **`lib/scratch.mjs` behavior,** and the RED→GREEN history itself.