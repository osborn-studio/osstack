# Smallest usable wiring for the fixed skills-check maintenance command

Read-only source review of candidate `8ed11e37` and main `5248195bd2611cc21a98a0ef3e39d229cdf9b681`. No command/test/model/CI run and no product edits.

The candidate is already a real bounded capability: it accepts a separately maintained map, invokes a fresh full five-case journey, compares expected exit **and status**, preserves evidence/map snapshots, and returns consistent0 / mismatch1 / blocked2. It never edits the map. It is not yet discoverable from the existing maintenance reference or package scripts, and `pnpm -r test` does not include this standalone Node test file. These are the immediate integration gaps, not a missing new method.

## Recommended three-file wiring

1. `package.json:77–82` (main524): add two aliases alongside existing method scripts:
   - `test:method-maintenance`: `node --test scripts/maintain-skills-check-map.test.mjs`
   - `method:maintain-skills-map`: `node scripts/maintain-skills-check-map.mjs`
   Keep existing journey/export/reader/projector commands unchanged.
2. `osstack-methods-skill/references/maintain-verification.md:20`: append a short concrete command recipe after the fixed five-case target. Use the target checkout with dependencies/build ready; `--map` and `--output` are absolute, the owned scratch parent exists, and output is new. Example from that checkout: `node scripts/maintain-skills-check-map.mjs --map /owned/maps/skills-check.json --output /owned/scratch/runtime/map-check-001`. Point users in prose/code to the repository sample `docs/implementation/skills-check-map-maintenance/map.json`; do not add a relative link escaping exported skill roots. Explain that the map can be copied to an owned location before an authorized correction, that a discrepancy does not tell whether documentation or product is wrong, and that corrections require a fresh output plus retained failed evidence. Do not pass `--scope`, `--input`, `--check` or an arbitrary command: this CLI accepts only map/output (script:19–28). `consistent` is agreement for five fixed cases, **not** the method's complete `clean` outcome at reference:12–18, which still needs source review and issue classification. Existing four entries already route to this method; no new entry/router/method count is needed.
3. `.github/workflows/ci.yml`: add a standalone test step next to main524:157 (journey contracts), plus one actual maintained-map command after the full journey evidence block at main524:185–192 and before projector checks at194. Use the checked-in valid map, a separate owned output, and `always()` artifact retention for the attempted maintenance step. Example:

```yaml
- name: Fixed skills map maintenance contracts
  run: pnpm test:method-maintenance
- name: Maintain fixed skills map (real local journey)
  id: skills-map-maintenance
  env:
    OSSTACK_SCRATCH_ROOT: ${{ runner.temp }}/osstack
  run: |
    mkdir -p "$OSSTACK_SCRATCH_ROOT/runtime"
    pnpm method:maintain-skills-map --map "$GITHUB_WORKSPACE/docs/implementation/skills-check-map-maintenance/map.json" --output "$OSSTACK_SCRATCH_ROOT/runtime/skills-map-maintenance-ci-evidence"
- name: Preserve skills map maintenance evidence
  if: always() && steps.skills-map-maintenance.outcome != 'skipped'
  uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02
  with:
    name: skills-map-maintenance-evidence-${{ github.run_id }}-${{ github.run_attempt }}
    path: ${{ runner.temp }}/osstack/runtime/skills-map-maintenance-ci-evidence
    if-no-files-found: warn
    retention-days: 7
```

The actual command creates its own full journey (`runMaintenance:81`); it **cannot consume/reuse** the earlier CI full-journey directory. This adds one real local five-case drive. Do not invent a reuse flag or claim the old step tested the new comparator. Unit seams test map/closeout logic; their generated `passedJourney` is explicitly synthetic. The separate real stale-map mismatch → authorized one-cell map correction → fresh successful comparison should remain in the author's actual evidence; the CI smoke above is only the correct-map acceptance surface, not proof of that whole correction loop.

## Scope and acceptance

- Require the standalone suite, existing exported-link/contract checks, and an actual correct-map invocation with five matching rows, unchanged map SHA, sealed child journey, and retained cleanup limits. Preserve nonzero comparisons and blocked observations; don't auto-correct or suppress mismatch in CI.
- A malformed map is rejected before driving; a valid but stale map is a real mismatch after driving. Those are different outcomes. Retain that distinction in user-facing text and tests.
- Source/build hashes and cleanup retain the journey's limits. `maintenance.json` is local raw evidence, not the safe model packet; do not feed the entire directory to a host as if projected/sanitized.
- This slice depends on the merged full journey from main524/PR304, not the still-separate full projector PR305. Preserve main524's default two-case projector refusal statement when integrating here. Reconcile the optional full-v2 sentence only when integrating the actual305 branch; don't predeclare it merged.
- One future limitation worth stating, not expanding now: the fixed map has no general repository-feature discovery or source-review automation. Five-case consistency is useful but cannot finish all pstack maintenance capabilities.

No new failure conclusion about PR305 is made here. Its supplied pending/canceling CI state was not queried or rerun.
