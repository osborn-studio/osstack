# Verdict: REVISE (small, non-blocking fixes)

This is a static read of the four slice files, with `method-verification-journey.mjs` and `handoff.md` as context. I ran nothing. I found no defect in the core comparison or exit-code logic. The two confirmed defects fall on axes you named: failure propagation and truthful evidence claims. Both are cheap to fix.

## Confirmed defects

**1. A later failure overwrites the first failure in `maintenance.json`** (`runMaintenance`, closeout `try`)
- The first `catch` sets `result.failure` to a code such as `journey_incomplete` or `journey_result_identity`.
- The closeout block then does `result.failure = 'map_changed'` or `` `map_after:…` ``, which discards that code.
- When the identity or read check fails, `result.journey` is still `null`. That is because the object literal throws before assignment, so `maintenance.json` keeps no record of the primary failure. It survives only on disk under `journey/`.
- Exit code and status stay correct (blocked, 2). The loss is diagnostic fidelity, which contradicts the "preserve first failures" intent in MM08 and MM10.
- Fix: use `result.failure ??= …`, or collect a `failures` array. Assign `result.journey` incrementally so partial journey data survives a later read failure.
- If writing `map-after.json` throws, the catch also replaces `map_changed` with `map_after:<code>`. The same fix covers that.

**2. Test evidence claims overstate what the committed tests do** (`maintain-skills-check-map.test.mjs`)
- The header says "Actual CLI behavior is tested separately with the real journey." No committed test runs the real five-case journey.
  - The only CLI test is the invalid-input one.
  - The doctor-failure test stubs `invoke`.
  - Real-run evidence exists only as the handoff's out-of-band claim, which I cannot verify from the supplied material.
- The test title "real existing journey doctor failure…" is also loose. It runs the real `runJourney` code with an injected fake driver result.
- Fix: reword both. For example, "real `runJourney` with a stubbed driver", and "real five-case runs are recorded in release evidence, not in this suite".

## Optional suggestions (not defects)

- **Seam provenance.** `maintenance.json` does not record that `seams.journey` or `seams.invoke` was used. A seam-driven `consistent` result is indistinguishable from a real one except through the injected limitation text. A single field such as `driver: "runJourney" | "injected"` would support MM10's distinction. The CLI cannot reach the seams, so this concerns programmatic callers only.
- **Manifest cross-check.** `manifest_sha256` is recorded but never checked against the manifest's own `journey.json` entry compared with `receipt_sha256`. The identity check on `journey.json` already holds, so this only tightens the binding. The trusted-local premise makes it optional.
- **Stable codes for parse errors.** JSON syntax and UTF-8 failures surface as raw `error.message`, not a `map_*` code. The CLI's stderr can also echo a short snippet of the map from the `SyntaxError` text. Wrapping them as `map_json` and `map_utf8` would make codes consistent with the README's refusal vocabulary.
- **Post-`mkdir` write failures.** If `writeFile('map-before.json')` throws after `mkdir`, the output directory is left without `maintenance.json`. The CLI reports only a bare error. The README's "keeps its available evidence" is literally true but could say that no result file exists in this case.
- **Parser looseness.** `TextDecoder` silently strips a leading BOM, and `JSON.parse` accepts duplicate keys with last-wins. Both sit slightly outside the "closed" framing. Only worth documenting.
- **Test gaps** (all covered in code, none by a test):
  - `output_outside_scratch`
  - `absolute_paths_required`
  - `map_inside_output` (largely redundant with `EEXIST`, since an output containing the map must already exist)
  - exit bounds such as 256, -1 and 1.5
  - truncated JSON
  - an unreadable map at closeout
  - The CLI test depends on the cwd being the repo root because it uses a relative script path.

## Checked and found sound

- **Input handling:**
  - Map validation is closed and fail-closed, and runs before `mkdir` or any drive.
  - Row order is irrelevant because rows are keyed by `case_id`.
  - Five rows plus unique known IDs imply the complete set.
  - `O_NOFOLLOW`, `O_NONBLOCK`, the `isFile` check and the 64 KiB bound behave as the README states. Symlinks are refused only at the final path component.
- **Output ownership:** non-recursive `mkdir` refuses existing directories and symlinks, and `wx` flags prevent overwrite. The tool never writes to `mapPath`.
- **Exit precedence:**
  - Exit 0 requires all of: a `passed` journey, all five rows sealed with cleanup passed and `fixture_removed`, every row matching, an unchanged map, and a successfully written `maintenance.json`.
  - Journey failure, incompleteness or a changed map yields exit 2 even when rows would match.
  - The catch-all `try` blocks cannot turn an error into success.
  - If `maintenance.json` cannot be written, the call rejects and the CLI exits 2.
- **Case order:** `IDS` matches `fullCases` order.
- **Handoff counts:** the test count (19) and the number of fixtures (10) are internally consistent with the file and the two five-case runs.
- **README:** limits and non-claims are appropriately hedged. It makes no run claim and defers to release evidence. The source/build-binding and descendant-termination disclaimers match the journey's own.

## Not verifiable from the supplied material

- The `scratchRoot`, `sha256` and `evaluateCase` library files were not provided. That includes whether `source_check_status` yields exactly `healthy`, `failed`, `drift` or `empty`. The map's `STATUSES` set and the test seam assume it, and the handoff reports matching observations.
- The claims that the real runs happened, that "exactly four files" changed, and that the four generated knowledge artifacts are outside the slice. I saw no diff or logs.
- The pstack attribution, author, license and pinned URL in the README.