import subprocess,pathlib,json,hashlib,os
r=pathlib.Path(__file__).parent; w=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr305-retarget-ledger')
env={**os.environ,'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}
m=json.loads((w/'docs/implementation/skills-check-map-maintenance/map.json').read_text());m['features'][1]['expected_product_exit']=0
f=r/'active-map.json';f.write_text(json.dumps(m,indent=2)+'\n')
records=[]
for phase,expected in [('red',1),('green',0)]:
 if phase=='green':
  m['features'][1]['expected_product_exit']=1;f.write_text(json.dumps(m,indent=2)+'\n')
 before=f.read_bytes();(r/(phase+'-map.json')).write_bytes(before)
 cmd=['pnpm','smoke:skills-map','--map',str(f),'--output',str(r/('actual-'+phase))]
 with (r/(phase+'.stdout')).open('w') as o,(r/(phase+'.stderr')).open('w') as e:
  p=subprocess.run(cmd,cwd=w,env=env,stdout=o,stderr=e)
 assert p.returncode==expected,(phase,p.returncode)
 result=json.loads((r/('actual-'+phase)/'maintenance.json').read_text())
 assert result['exit_code']==expected and f.read_bytes()==before
 assert [x['actual']['product_exit'] for x in result['rows']]==[0,1,2,1,0]
 assert result['execution_path']=='runJourney'
 records.append({'phase':phase,'command':cmd,'exit':p.returncode,'status':result['status'],'map_sha256':hashlib.sha256(before).hexdigest(),'map_unchanged':True,'product_exits':[x['actual']['product_exit'] for x in result['rows']]})
(r/'actual-binding.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'runs':records,'only_correction':'missing-ref expected_product_exit 0 to 1','classification':'explicit injected map drift; not spontaneous product bug'},indent=2))
print(json.dumps(records))
