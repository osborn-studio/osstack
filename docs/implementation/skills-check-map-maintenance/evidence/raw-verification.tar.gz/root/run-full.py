import subprocess,pathlib,json,hashlib,os,datetime
r=pathlib.Path(__file__).parent
w=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr305-retarget-ledger')
def snap():
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=w).decode().split('\0')
 return {p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in paths if p and (w/p).is_file()}
before=snap();(r/'full-before.json').write_text(json.dumps(before,indent=2))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
dirty=subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'full.log').open('w') as o:
 code=subprocess.run(['pnpm','test'],cwd=w,stdout=o,stderr=subprocess.STDOUT,env={**os.environ,'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}).returncode
after=snap();(r/'full-after.json').write_text(json.dumps(after,indent=2))
(r/'full-binding.json').write_text(json.dumps({'head':head,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dirty_before':dirty,'exit_code':code,'tracked_bytes_unchanged':before==after,'tracked_count':len(before),'changed_paths':[k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)]},indent=2))
print('full exit',code,'tracked equal',before==after,'head',head)
