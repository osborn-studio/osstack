# Fixed skills-check map maintenance acceptance

- **MM01 Closed data input:** Accept one schema_version1/target skills-check-full map with exactly five unique known IDs and closed typed fields. Missing/duplicate/unknown IDs, unknown keys, malformed JSON/UTF8, over64KiB, nonregular/symlink input and unknown CLI flags exit2 before any drive/output. Reordered valid rows may be keyed by ID; do not silently drop rows.

- **MM02 Real positive path:** With authored canonical map execute the existing runJourney exactly once scope full, preserve its real five rows healthy/missing-ref/drift/mixed/empty product0/1/2/1/0, statuses healthy/failed/drift/failed/empty and driver0. Exit0 requires all verified and owned cleanup confirmed, not exit-only matching.

- **MM03 Real discrepancy and repair:** A syntactically legal stale missing-ref expected_product_exit0 produces exit1 after the same real five-case journey. Keep original map, RED output and all raw evidence. In separately authorized copy change only expectation0→1; use fresh output and same command for GREEN0. Never alter product/negative input to match stale expectations.

- **MM04 Status discrepancy:** A legal but incorrect expected status with correct exit remains mismatch1; report per-ID expected and observed values. Do not diagnose documentation drift solely from mismatch or auto-bless/rewrite map.

- **MM05 Blocked execution precedence:** Doctor/driver/evidence failure or whole journey failed means exit2 even if available individual rows agree. Preserve failed/not_run rows and unknown cleanup; unavailable observation is not a verified mismatch or healthy result. Test controlled early failure and globalfailure-with-passedrows separately from real positive run.

- **MM06 Original input and evidence binding:** Map bytes/hash before and after must match for closeout; mutation during run prevents agreement and is retained as changed-input/blocked. Bind original journey bytes/hash and existing per-case source/build digests without relabeling their scope as independently compiled/authenticated. Crosscase binding failure remains blocked; no new full repository scan requirement.

- **MM07 Owned output and no execution injection:** New exclusive output under existing scratch rules, no input/output overlap or overwrite. Map is never executable recipe/shell. Only fixed runJourney is invoked; no projection dependency, default OSSTACK_HOME/provider/network arbitrary source, scheduler or model.

- **MM08 Failure retention and cleanup ownership:** Do not erase completed/partial journey, map snapshot or diagnostics on failure. Cleanup assertions inherit existing ownedfixture behavior; no all-descendants termination claim. Preserve sources/output against cleanup paths; expose unknown explicitly.

- **MM09 Report exact limits:** Result separates map agreement, verified fixed fixture observations, and source-review obligation. Neither success nor corrected map signs PS09/J gate, native/model effect, authenticated oracle or general project coverage. No fabricated fresh Git/CI evidence.

- **MM10 Reproducible independent verification:** Candidate source SHA/hash, actual argv/cwd/exit/raw logs and input beforeafter hashes bind each observation. Preserve first failures; distinguish real five-case runs from seam fault probes and static review. No repeated old host experiments.

This is a bounded engineering procedure, not a formal oracle or host-model qualification. Existing bindings retain their original limitations.
