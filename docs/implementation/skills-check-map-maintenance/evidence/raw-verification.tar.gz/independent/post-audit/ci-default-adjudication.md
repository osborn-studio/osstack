# Conditional CI concern: independent disposition

Not a confirmed blocker. Actual scratchRoot has the safe `<os.tmpdir()>/osstack` fallback. Unit setup creates a unique tests directory under that same root before runMaintenance resolves it, so omitting OSSTACK_SCRATCH_ROOT does not by itself fail the tests. An explicit CI env is a consistency improvement only.

Frozen install/build precede both steps; no working-directory override exists. The checked-in map has the correct five semantic rows, aliases target the intended scripts, and artifact path/pin match the existing workflow. The reviewer explicitly conditioned REVISE on absence of a safe fallback; this condition is disproved by supplied source. Raw audit remains unchanged.

No execution or future CI-success claim: source/configuration adjudication only.
