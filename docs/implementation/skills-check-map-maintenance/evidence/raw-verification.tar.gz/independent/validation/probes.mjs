import {readFile,writeFile,mkdir,symlink,access} from 'node:fs/promises';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {runMaintenance} from '/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-map-maintenance/scripts/maintain-skills-check-map.mjs';
const root=process.env.OSSTACK_SCRATCH_ROOT, repo='/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-map-maintenance';
const original=JSON.parse(await readFile(join(repo,'docs/implementation/skills-check-map-maintenance/map.json')));
const journey=JSON.parse(await readFile('/Volumes/AIMATE_WORK/tmp/osstack/runtime/skills-map-maintenance-20261030/author/map-green/journey/journey.json'));
const exists=async p=>{try{await access(p);return true;}catch{return false;}};
const rows=[];
for(const [name,change,bytes] of [
 ['missing',m=>m.features.pop()],['duplicate',m=>m.features[4]=m.features[0]],['unknown',m=>m.features[2].case_id='arbitrary'],['root-command',m=>m.command='touch sentinel'],['row-command',m=>m.features[2].command='touch sentinel'],['exit-string',m=>m.features[0].expected_product_exit='0'],['exit-range',m=>m.features[0].expected_product_exit=256],['status-unknown',m=>m.features[0].expected_product_status='unknown'],['extra-row',m=>m.features.push(m.features[0])],['invalid-utf8',null,Buffer.from([0xff])],['large',null,Buffer.alloc(65537,32)],['bad-json',null,Buffer.from('{')]
]){const dir=join(root,'probe-'+name);await mkdir(dir);const m=structuredClone(original);change?.(m);const map=join(dir,'map.json'),out=join(dir,'out');await writeFile(map,bytes??JSON.stringify(m));const args=['scripts/maintain-skills-check-map.mjs','--map',map,'--output',out];const p=spawnSync(process.execPath,args,{cwd:repo,env:process.env,encoding:'utf8',timeout:15000});await writeFile(join(dir,'stdout'),p.stdout);await writeFile(join(dir,'stderr'),p.stderr);rows.push({name,kind:'actual_cli_invalid_preflight',argv:args,exit:p.status,output_exists:await exists(out),passed:p.status===2&&!await exists(out)});}
for(const name of ['failed-all-passed','unknown-cleanup','map-byte-change','row-status-mismatch','driver-throws','receipt-disagreement']){
 const dir=join(root,'probe-'+name);await mkdir(dir);let calls=0;const map=join(dir,'map.json'),out=join(dir,'out');const m=structuredClone(original);if(name==='row-status-mismatch')m.features[4].expected_product_status='healthy';await writeFile(map,JSON.stringify(m));
 const result=await runMaintenance({map,output:out},{journey:async({output,scope})=>{calls++;if(scope!=='full')throw Error('bad_scope');if(name==='driver-throws')throw Error('injected prerequisite failure');const j=structuredClone(journey);if(name==='failed-all-passed'){j.status='failed';j.failure='cross_case_bindings_changed';}if(name==='unknown-cleanup')j.features[2].cleanup.status='unknown';await mkdir(output);await writeFile(join(output,'journey.json'),JSON.stringify(j));await writeFile(join(output,'journey-manifest.json'),'{}');if(name==='map-byte-change')await writeFile(map,JSON.stringify(m)+' ');if(name==='receipt-disagreement')j.status='failed';return j;}});
 const expected=name==='row-status-mismatch'?1:2;rows.push({name,kind:'controlled_seam_using_real_receipt_copy_not_product_run',calls,exit:result.exit_code,failure:result.failure,status:result.status,passed:result.exit_code===expected&&calls===1});
}
await writeFile(join(root,'probe-results.json'),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify({total:rows.length,passed:rows.filter(x=>x.passed).length,failures:rows.filter(x=>!x.passed)}));
