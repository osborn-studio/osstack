from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).parent;a=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/skills-map-maintenance-20261030/author');w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-map-maintenance');sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text());results=[]
def manifest(path):
 m=load(path);n=0
 for f in m['files']:
  p=path.parent/f['path'];b=p.read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],str(p);n+=1
 return {'path':str(path),'sha256':sha(path.read_bytes()),'verified_files':n}
results.append(manifest(a/'author-manifest.json'));allruns=[]
for name,base,expect in [('author-red',a/'map-red',1),('author-green',a/'map-green',0),('independent-reordered',r/'actual-reordered',0)]:
 m=load(base/'maintenance.json');j=load(base/'journey/journey.json');assert m['exit_code']==expect;assert sha((base/'map-before.json').read_bytes())==m['map']['before_sha256']==m['map']['after_sha256'];assert m['map']['unchanged'];assert sha((base/'journey/journey.json').read_bytes())==m['journey']['receipt_sha256'];assert sha((base/'journey/journey-manifest.json').read_bytes())==m['journey']['manifest_sha256'];results.append(manifest(base/'journey/journey-manifest.json'))
 for f in j['features']:
  mp=base/'journey/cases'/f['case_id']/'manifest.json';results.append(manifest(mp));assert sha(mp.read_bytes())==f['manifest_sha256'];assert not Path(f['cleanup']['fixture_path']).exists();assert f['cleanup']['fixture_removed'] is True
 assert [f['product_exit'] for f in j['features']]==[0,1,2,1,0];assert [f['product_status'] for f in j['features']]==['healthy','failed','drift','failed','empty'];assert all(f['driver_exit']==0 and f['verification']=='passed' for f in j['features']);allruns.append({'name':name,'status':m['status'],'exit':m['exit_code'],'mismatches':[x['case_id'] for x in m['rows'] if not x['matches']],'fixtures_observed_absent':5,'bindings':j['features'][0]['bindings']})
red=load(a/'map-red/map-before.json');green=load(a/'map-green/map-before.json');delta=[]
for i,(x,y) in enumerate(zip(red['features'],green['features'])):
 for k in x:
  if x[k]!=y[k]:delta.append([i,x['case_id'],k,x[k],y[k]])
assert delta==[[1,'missing-ref','expected_product_exit',0,1]];assert allruns[0]['bindings']==allruns[1]['bindings']==allruns[2]['bindings']
live=load(a/'map-green/journey/cases/healthy/bindings.json');livecount=0
for kind in ['source','build']:
 for f in live[kind]['files']:
  b=(w/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path'];livecount+=1
source=[]
for p in ['scripts/maintain-skills-check-map.mjs','scripts/maintain-skills-check-map.test.mjs']:
 b=(w/p).read_bytes();git=subprocess.check_output(['git','show','8ed11e37175cd9b100d5fc176e79c2c7d3d99c02:'+p],cwd=w);assert b==git;source.append({'path':p,'sha256':sha(b)})
(r/'evidence-verification.json').write_text(json.dumps({'status':'verified','manifests':results,'runs':allruns,'map_repair_delta':delta,'current_source_build_members_checked':livecount,'source':source,'limitations':['Bindings establish current byte correspondence, not authenticated compilation.','Author RED/GREEN were read-only reverified; independent reordered run executed separately.','Fixture absence is observed now, not all descendant termination.']},indent=2)+'\n');print(json.dumps({'manifests':len(results),'live_members':livecount,'runs':allruns,'delta':delta}))
