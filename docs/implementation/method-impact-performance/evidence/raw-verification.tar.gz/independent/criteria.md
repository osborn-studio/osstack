# Pre-frozen method acceptance

Prospective independent engineering review of change-impact and performance-measurement method material. No new author candidate read before freezing. No model, product, fixture or full test execution. Not a generalized benchmark or formal principal/gate.

No mandated exact prose or new runtime schema. Preserve useful upstream methodology within existing authorization. Requirement to measure means withhold unsupported claims when measurement unavailable, not automatically execute privileged workloads.

## IP01 — Pin the exact change and behavior

Record requested change, actual base/head or separate dirty patch hashes and relevant intended behavior; follow changed and unchanged consumers, pinned dependency versions and local patches. If scope changes, identify which evidence needs rechecking.

Counterexample: An unchanged JSON consumer relies on a removed key; searching only renamed symbols or assuming latest library behavior misses it.

Source: blast-radius steps1/3; main code-review scope.

## IP02 — Challenge the decisive safety assumption

State one or two facts the safety claim depends on, make the bad-case path and preconditions concrete, and seek disconfirming evidence. Include serialized/wire/DB/other-language/flag and scheduling/teardown boundaries where relevant, not an obligatory exhaustive checklist.

Counterexample: Claim cache deletion is safe because entries are dead while eviction callbacks still release a live resource; caller listing alone is insufficient.

Source: blast-radius steps2/3.

## IP03 — Evidence strength and real-code reachability

Distinguish assertion, source anchor, demonstrated unreachable path, real shipped-code probe and running-app observation. Prefer the cheapest in-scope probe of the exact decisive path with an observable failure predicate; record command/input/version/raw outcome. Static findings remain useful but cannot be called executed proof.

Counterexample: Mock helper copies the assumption rather than invoking actual dependency; a passing unit check is called app reproduction; grep finds no references so safety is declared proven.

Source: blast-radius How sure/step5; main evidence.

## IP04 — Risk disposition without invented certainty

Report confirmed risks with reachable trigger, consequence, evidence anchor, realistic likelihood/impact rationale and cheapest next check. Separate cleared risks and remaining unproven assumptions; do not invent callers, numerical probabilities or fictional observations.

Counterexample: A plausible async teardown path is labeled observed failure despite no reachable schedule; cleared guard evidence is omitted so risk list appears larger.

Source: blast-radius steps4/output.

## IP05 — Authorization and host limits remain intact

Analysis does not authorize product fixes, production data, installs/network, extra model calls or PR actions. Use already authorized isolated checks without repeated permission requests; if execution exceeds scope, keep a source-supported result and explicit unproven boundary. Additional reviewers only with actual support/authorization; agreement is not proof.

Counterexample: Upstream instruction to run real code/arena is treated as unconditional authority to run untrusted code with credentials or manufacture reviewers.

Source: main code-review/evidence; deliberate bounded adaptation of upstream arena.

## IP06 — Define claim, baseline and comparable workload

Before measurement record expected claim/unit, timer boundaries, work counts, source/build/runtime/data versions, production flags/tuning, concurrency and warm/cold state. Compare equivalent useful work; adoption decisions cannot choose a winner from a known untuned side by merely narrowing the wording.

Counterexample: Debug/per-row-commit baseline compared with release/batched candidate; dataset differs; timing excludes completion; headline winner is selected anyway.

Source: benchmark before/questions2/7.

## IP07 — Correct work and errors are mandatory

Validate outputs and work completed inside timed region, not just presence or exit0; count failed/rejected responses, retries/timeouts and actual completed useful work. Deferred generators/promises must be consumed/awaited and results observed. Failure or uncheckable output/work invalidates a speedup verdict.

Counterexample: 0.1ms candidate rejects all100 requests or returns wrong rows; unawaited operation is timed; absent error counts silently assumed zero.

Source: benchmark questions4/7; explain-the-number.

## IP08 — Explain measured limiter and plausible bounds

Use measured profiling/system counters on an unreported diagnostic run to establish limiter and map to source, including saturated load generator. Challenge cache/no-op/skipped work and arithmetic resource bounds. Distinguish elapsed-time reduction from throughput gain. No source guess promoted to measured bottleneck.

Counterexample: Changed piece consumes10ms of100ms baseline yet claims total latency40ms solely from removing it; 100→90ms is10%latency reduction/~11.1%throughput gain, not60%.

Source: benchmark questions1/3; explain-the-number.

## IP09 — Samples, noise and bounded exception

For measured comparisons use at least5 runs per side alternating/interleaved under comparable conditions; report run count, median and range and treat differences within observed variation as no measurable difference/inconclusive rather than certain win. Explain workload/noise or use appropriate additional statistics for close calls. A user-requested rough one-run ballpark is labeled one run and still checks correct output and work; choosing between options is not ballpark.

Counterexample: A=[99,101,100,102,98] B=[100,98,101,99,102] has identical median100/range98–102; cherry-picked98vs102 is not speedup. Onerun option adoption bypasses sample requirement.

Source: benchmark exception/question5/before.

## IP10 — User-visible relevance and end-to-end bounds

Pair micro measurements with realistic end-to-end path/data/concurrency and report component share; otherwise explicitly limit the result to micro measurement and withhold end-to-end benefit claim. Bound benefit by original contribution, not multiplier alone.

Counterexample: 1ms of100ms helper becomes0.1ms: maximum saved0.9ms =0.9%total latency, not10x user request speedup.

Source: benchmark question6; explain-the-number.

## IP11 — Verdict and auditable evidence

Verdict faster/slower/no measurable difference/inconclusive is tied to stated predicate; preserve baseline/candidate samples, raw command/output/counts/errors, spread, limiter evidence and missing checks. Do not silently repair inputs or erase failing runs. Missing limiter for claimed difference, untuned side or unverifiable error/work requires inconclusive; concise summary links evidence.

Counterexample: Faster label survives wrong output; profiled run mixed with normal samples; numbers copied from source comments are presented as measured.

Source: benchmark report; main evidence.

## IP12 — Accessible material, honest coverage and source attribution

Both new methods are reachable from intended mode/help/delegate routes and actual Codex/Claude four-entry exports with working relative shared-reference links. Preserve existing routes and source attribution; explain adapted upstream dependencies instead of requiring nonexistent arena/unslop tools. Exact export/navigation checks establish packaging only, not model compliance, native discovery, causal gain or runtime/gate qualification.

Counterexample: Newref exists but unlinked or missing from onehost export; count stale; wording treats two docs as runtime integration or verified host effect.

Source: main routing/exports/evidence; upstream provenance.

