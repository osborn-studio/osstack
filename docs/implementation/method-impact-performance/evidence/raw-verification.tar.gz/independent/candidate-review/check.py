from pathlib import Path
import json,subprocess,hashlib,re,statistics,fractions,datetime
D=Path(__file__).resolve().parent;R=D.parent;repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';sha=lambda b:hashlib.sha256(b).hexdigest();commands=[]
def git(*args):
 argv=['/usr/bin/git',*args];p=subprocess.run(argv,cwd=repo,capture_output=True,timeout=15,env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'});n=len(commands);(D/f'{n:02}.stdout').write_bytes(p.stdout);(D/f'{n:02}.stderr').write_bytes(p.stderr);commands.append({'argv':argv,'cwd':repo,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)});assert p.returncode==0;return p.stdout
A='f6c56937f7b3ca75a0b349d9f757a8caa901da3e';B='5f7797034437e5005dbfe8696c4a3762d3a7e724';base='92088fe55a2f985ca743fa1fabee0c081a6f672d';bindings=[]
for commit,path,name in [(A,'osstack-methods-skill/references/change-impact.md','change-impact.md'),(A,'docs/implementation/method-change-impact/README.md','impact-implementation.md'),(B,'osstack-methods-skill/references/performance-measurement.md','performance-measurement.md'),(B,'docs/implementation/method-performance-measurement/README.md','performance-implementation.md'),(base,'scripts/bench-cli-startup.mjs','baseline-startup-script.mjs')]:
 b=git('show',commit+':'+path);(D/name).write_bytes(b);bindings.append({'commit':commit,'path':path,'sha256':sha(b)})
for commit in [A,B]:git('diff','--name-only',base,commit);git('diff','--check',base,commit)
s=(D/'performance-measurement.md').read_text();arrays=[[int(n.strip())for n in raw.split(',')]for raw in re.findall(r'`([0-9, ]+) ms`',s)];assert len(arrays)==6
med=[statistics.median(a)for a in arrays];ranges=[(min(a),max(a))for a in arrays];assert med==[100,90,1000,990,100,100];assert ranges==[(98,102),(88,92),(998,1002),(988,992),(97,103),(98,102)]
F=fractions.Fraction;calc={'declared_arrays':arrays,'medians':med,'ranges':ranges,'latency_reduction':str(F(med[0]-med[1],med[0])),'micro_speedup':str(F(med[0],med[1])),'e2e_reduction':str(F(med[2]-med[3],med[2])),'boundary_totals':[40+60,70+30],'component_removal_fraction':str(F(10,1000)),'component_removal_speedup':str(F(1000,990)),'fast_failure_elapsed_ratio':str(F(100,5)),'fast_failure_completed_work':[20,0],'fast_failure_successful_speedup':'not defined by elapsed ratio: zero correct candidate completions','noise_median_difference':med[4]-med[5]}
assert calc['latency_reduction']=='1/10'and calc['micro_speedup']=='10/9'and calc['e2e_reduction']=='1/100'and calc['boundary_totals']==[100,100]and calc['component_removal_speedup']=='100/99'and calc['noise_median_difference']==0
# Independent pre-frozen counterexamples (not copied author test implementation).
independent={'prefrozen_noise':{'A':[99,101,100,102,98],'B':[100,98,101,99,102]},'prefrozen_component':{'base':100,'component':1,'new_component':F(1,10)},'prefrozen_impossible':{'base':100,'component':10,'claimed_total':40}}
z=independent['prefrozen_noise'];assert statistics.median(z['A'])==statistics.median(z['B'])==100
x=independent['prefrozen_component'];reduction=(F(x['component'])-x['new_component'])/x['base'];assert reduction==F(9,1000)
y=independent['prefrozen_impossible'];assert y['base']-y['claimed_total']>y['component']
calc['independent_prefrozen_results']={'noise':'same median100 and range98–102; cherry-picked difference rejected','1ms_to_0.1ms_of_100ms_max_latency_reduction':str(reduction),'10ms_of_100ms_claim40ms':'violates unchanged-rest bound'}
(D/'arithmetic-results.json').write_text(json.dumps({'scope':'Pure synthetic arithmetic, not benchmark, runtime or model evidence','results':calc},indent=2)+'\n')
(D/'source-check.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_bindings':bindings,'commands':commands,'product_or_model_executions':0},indent=2)+'\n');print(json.dumps(calc))
