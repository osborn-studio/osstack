# Independent A/B material review

No confirmed substantive gap in the two frozen author candidates. This is source/manual scenario review and synthetic arithmetic only; no real benchmark, model call or broad test suite ran. Final ninth-method routing/export coverage remains pending the integrated candidate.

**IP01 (A)**: Change scope section records base/candidate, dirty patches and hidden behavior; dependency section locks version/patch and loaded build. The JSON-consumer counterexample is directly covered by follow-contracts guidance.

**IP02 (A)**: Falsifiable one/two assumptions plus counterexample search; evictions, callbacks/teardown and concurrency included. No caller-count substitute for safety.

**IP03 (A)**: Explicit distinction among hypothesis/source/path/probe/app; real shipped function and caller with contract-derived oracle and nearby controls. Mock and function-to-app overclaims rejected. No test was run by this independent material review.

**IP04 (A)**: Confirmed/cleared/unresolved separation, actual consumer/trigger/consequence and likelihood evidence. Unknown inaccessible consumers remain unknown; no invented probabilities.

**IP05 (A+B)**: A untrusted code/isolation/no credential/default-home limits explicit; execution blocked retains source-supported conclusion; existing fixes/delegation authority honored. B calls candidate scripts code needing an authorized boundary, refuses unrelated process stopping and limits fixes/deployment. Both inherit common evidence, no unconditional model panel.

**IP06 (B)**: Claim/build/workload/timer and tuned equivalent work recorded; adoption from untuned as-shipped comparison explicitly inconclusive. Comparison-setting variables identified.

**IP07 (B)**: Per-sample correctness/errors/timeouts/retries/completed work and consumed async/lazy results required. Synthetic fast-rejection ratio20 is correctly rejected as successful-work speedup; nothing silently repaired.

**IP08 (B)**: Measured profiler/counters separate from headline samples, load-generator limit included; arithmetic bounds and causal uncertainty explicit.100→90 is10% latency and10/9 speedup, correctly stated.

**IP09 (B)**: At least5 per side interleaved, full data/median/range, warmup/drift and uncertainty. Ballpark exception preserves correctness/work and cannot choose option. Both frozen identical-noise vector and document arrays prohibit cherry-picked win.

**IP10 (B)**: Full user path/representative workload and micro share required. Shifted setup+compute totals100ms each;10ms/1000ms cap1%; frozen1→0.1ms component of100ms cap0.9%. No claimed measured end-to-end improvement.

**IP11 (B)**: Bounded verdict with raw samples/limiter/correctness/error/build scope and causal limits; invalid runs preserved; missing checks force inconclusive. README description of existing startup script checked directly against main:5 spawns per surface, exit/stdout checks, median/min/max budget, not comparative speedup.

**IP12 (A+B)**: A8-method routes/count/source/EXPORT changes statically consistent; B explicitly not wired in its isolated2-file slice. Final9-method actual dual-host export/navigation remains pending root combined candidate; no packaging or host-behavior claim made here.

