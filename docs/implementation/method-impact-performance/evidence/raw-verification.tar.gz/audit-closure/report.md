**Verdict: PASS**, limited to the diff you supplied. I ran no tools and verified no hashes. I did not check candidate 687811a69c564b5812200c65f02e8aba35f002a3 itself, and I take the pending independent final re-export as not claimed.

## Checked

1. **Throughput direction and equal-work math**
   - `(candidate - baseline) / baseline` is the right relative gain for a higher-is-better metric, and `candidate / baseline` is the right rate ratio.
   - With equal completed work W, `baseline_time / candidate_time = (W/baseline_rate) / (W/candidate_rate) = candidate_rate / baseline_rate`, so the stated equivalence holds. The caveat about changed work counts or excluded failures correctly names where it breaks.
   - The synthetic example is correct:
     - 100 → 120 ops/s is a 20% gain and a 1.2× rate ratio.
     - 1200 ops take 12 s versus 10 s, a 1.2× time speedup.
     - The latency reduction is (12−10)/12 = 16.67%, not 20%.
   - The example is labeled "explicitly synthetic", which matches the section's "invented teaching data" framing. The latency formulas are unchanged, and the new sentence sits after them without contradicting them.

2. **Additive-bound premise**
   - The added sentence states the assumption the bound depends on: other costs and the critical path stay fixed. It says that queueing, contention or overlap changes can break it, and that these must be measured separately.
   - This addresses the earlier gap, where a real gain such as shorter lock hold time could exceed the component's own service time.
   - It doesn't weaken the bound. The unchanged next sentence still sends a bound-crossing result to investigation, and the 1000 ms / 10 ms example still holds under its "everything else unchanged" condition.
   - The list of causes in that next sentence doesn't repeat queueing or contention, but the sentence just before it covers them. I don't consider this a defect.

3. **Existing authority**
   - The performance sentence says privileged profiling, dependency-install lifecycle scripts and shared or remote load stay under existing authorization. It says an unavailable diagnostic leaves "an explicit gap rather than permission to expand access."
   - That restricts rather than grants, and it adds no command, service or gate.
   - The change-impact addition contains no new authority and no new runtime or code mechanism.

4. **Scope-change recheck**
   - The addition is consistent with the adjacent "Do not silently analyze a different base or discard someone else's work".
   - It retains the old map and results, pins the new boundary, and rechecks the affected assumptions, consumers and probes before the old conclusion is applied. That is a procedural instruction only.

## Scope notes

- **Not adopted, not a defect:** the direct-label navigation test is optional. Your stated basis is that the exported graph already checks four-entry reachability via the mode-allowed path and that direct navigation was inspected independently. I accept that as recorded. It is inspection plus graph reachability, not a host behavioral test of the exact link wording.
- **Not adopted:** ABBA counterbalancing, which was optional polish in the earlier audit.
- **Still pending:** the independent final re-export. This PASS does not stand in for it. It also isn't an approval or merge decision.