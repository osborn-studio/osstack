from pathlib import Path
import json,statistics,unittest
from fractions import Fraction
X=json.loads((Path(__file__).parent/'synthetic-examples.json').read_text())
class ArithmeticChecks(unittest.TestCase):
 def test_explicit_synthetic_scope(self):
  self.assertIs(X['synthetic'],True);self.assertIs(X['not_a_benchmark'],True)
 def test_paired_distribution(self):
  a,b=X['paired']['A'],X['paired']['B']
  self.assertEqual((len(a),len(b)),(5,5));self.assertEqual((statistics.median(a),statistics.median(b)),(100,90))
  self.assertEqual((min(a),max(a),min(b),max(b)),(98,102,88,92))
  self.assertEqual(X['paired']['order'],[n+str(i)for i in range(1,6)for n in ['A','B']])
 def test_latency_and_speedup_have_distinct_denominators(self):
  self.assertEqual(Fraction(100-90,100),Fraction(1,10));self.assertEqual(Fraction(100,90),Fraction(10,9))
  self.assertNotEqual(Fraction(100-90,100),Fraction(100,90)-1)
 def test_full_path_small_share(self):
  a,b=map(statistics.median,[X['paired']['e2e_A'],X['paired']['e2e_B']]);self.assertEqual((a,b),(1000,990));self.assertEqual(Fraction(a-b,a),Fraction(1,100))
 def test_shifted_boundary_disproves_whole_path_claim(self):
  z=X['shifted'];self.assertEqual(Fraction(z['A_compute']-z['B_compute'],z['A_compute']),Fraction(1,2));self.assertEqual(z['A_prepare']+z['A_compute'],z['B_prepare']+z['B_compute'])
 def test_component_bound_rejects_twenty_percent(self):
  z=X['component_bound'];self.assertEqual(Fraction(z['component'],z['total']),Fraction(1,100));self.assertGreater(z['unsupported_claim_reduction'],z['component']/z['total']);self.assertEqual(Fraction(z['total'],z['total']-z['component']),Fraction(100,99))
 def test_fast_failure_has_no_successful_work_speedup(self):
  a,b=X['failure']['A'],X['failure']['B'];self.assertEqual(a['elapsed']/b['elapsed'],20);self.assertEqual(b['completed_correct'],0);self.assertEqual(b['rejected'],b['attempted']);self.assertNotEqual(a['completed_correct'],b['completed_correct'])
 def test_noise_does_not_change_median(self):
  a,b=X['noise']['A'],X['noise']['B'];self.assertEqual(statistics.median(a),statistics.median(b));self.assertTrue(max(min(a),min(b))<=min(max(a),max(b)))
if __name__=='__main__':unittest.main(verbosity=2)
