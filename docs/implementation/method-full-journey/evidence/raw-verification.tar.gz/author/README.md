# Optional full journey author evidence

Candidate `32a9a9e18fc0b415c18cf14ce42c9f4f6d98f0c8`, base main493caa4e. Only journey implementation/tests committed. Node22.22.1. C criteria freeze was received before writing tests/implementation.

- Existing25 passed and new16 failed in `red`/`red-isolated`. The isolated revision prevents the direct-API unknown-scope negative from invoking real driver work. The first RED run used the original rejected-scope path during build; it is not a successful real-case qualification. Both original logs remain.
- First `green` had40pass/1fail: empty source cardinality rejection had the origin reason instead of fixed_source. Fixed check order; `green-fixed`41pass. Two additional failure/recorded-current-SHA tests bring `final-focused` to43pass/0fail/0skip.
- `install` succeeded. `build` failed because pnpm does not accept --force there; `build-standard` ran standard pnpm build successfully on this fresh worktree. Four tracked knowledge/dist outputs and their patch/hash are retained until independent checks finish. No dist restore occurred during validation.
- `actual-full` ran real driver doctor/drive for healthy, missing-ref, drift, mixed, empty: five passed predicates, product exits0/1/2/1/0, driver0 each, all five fixture paths removed. `actual-default` preserves the two-case run. Existing projection/check succeeds for default; full projection refuses fixed_case_set without creating output.
- Actual commands ran before commit at observed Git HEAD493caa4e with working implementation bytes. candidate.json binds those exact implementation hashes to32a9; do not relabel raw HEAD as32a9. The final tests include two later added regressions; actual product implementation bytes did not change.

Raw command stdout/stderr/exit/hash records and per-case manifests remain in their original directories. These are finite coordinator checks, not model consumption, authenticated oracle, live source reread attestation, OS sandboxing or all-descendant termination. Full means only these five fixed skills-check fixtures. No model, global home, daemon, full package suite or new runtime gate was used.
