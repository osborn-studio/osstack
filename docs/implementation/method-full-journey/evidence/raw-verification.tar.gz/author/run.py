import subprocess,sys,os,json,hashlib,datetime
from pathlib import Path
root=Path(__file__).parent
label=sys.argv[1];argv=sys.argv[2:]
env={**os.environ,'PATH':'/opt/homebrew/opt/node@22/bin:'+os.environ['PATH'],'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(label+'.stdout')).open('xb') as out,(root/(label+'.stderr')).open('xb') as err:
 r=subprocess.run(argv,stdout=out,stderr=err,env=env)
files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('scripts/method-verification-journey.mjs'),Path('scripts/method-verification-journey.test.mjs')]}
(root/(label+'.command.json')).write_text(json.dumps({'argv':argv,'cwd':str(Path.cwd()),'exit_code':r.returncode,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_hashes':files,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2))
print(label,r.returncode)
sys.exit(r.returncode)
