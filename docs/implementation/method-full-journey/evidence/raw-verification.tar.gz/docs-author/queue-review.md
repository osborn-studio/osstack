# Queue review

Read-only snapshot at 2026-10-29T07:16:12.019965+00:00, root HEAD `a5f4d954af07d06b5b98f4ccac806c0aab00c4d6`. Queue SHA256 `1b58c3f4618148697783a4e56de1f94cc1eefaa01911a90a71e20c0aa658edd4`; rollup SHA256 `09007662578cb4022ecce29f0b4abee645d2c60b10ed21e75471fd9f237ea0b5`. No forge query, execution test, model call or file change outside this report.

## Counts and actual progress

The queue's population counts match the rollup: **20 partial groups, four deferred groups (PS10/PS11/PS15/PS22), zero whole capabilities complete**. Four entries and fourteen method materials are delivered artifacts, not capability completion. There are 32 formal milestones and zero formal milestone completions. Do not turn 20 partial into 20 complete, and do not describe zero whole milestones as zero working deliverables.

Confirmed presentation mismatch: the queue's PS20 row still summarizes only exported materials and limited reading/native help. The rollup's `export_repair_execution` and `next_complete_capability_queue[1]` record actual bounded Codex packet repair and Claude exporter repair. Update that short row to mention both demonstrated local RED/fix/GREEN loops, keeping Claude's required-reading LIMITED, the original blocked attempt, different tasks/permissions and no equivalence claim. Otherwise a user reading this feature list misses the main recent execution result.

The active full-five-case item is correctly **in progress**. At this snapshot `scripts/method-verification-journey.mjs` still has two case IDs and the output-only parser; documentation for optional full scope was integrated before A's code. PS08's two-row journey and PS09's missing reusable full-five maintenance path therefore remain accurate for delivered code. After final implementation, verification and publication, revise those specific component descriptions; broad source coverage and whole PS08/PS09 completion still do not follow.

The rollup's older `next_complete_capability_queue[2]` still names finishing skill-authoring publication, although its own latest result records PR302 merged. Treat that as completed historical queue work rather than a remaining task. The new feature queue correctly omits it. Likewise the rollup top-level `observed_at` precedes newer append-only slices: show slice-specific status/time rather than present the whole JSON as one live forge snapshot. PR303's live CI status was not independently queried in this review.

## Priority and one next code gap

Finish full-five behavior/evidence/failure-path validation first. Neither issue287 identity qualification nor Firstmate deep recovery is a prerequisite for this bounded script. A fresh host task remains a separate validation activity, not proof that all partial groups completed.

**One bounded next code task: a five-case evidence projection that preserves the existing two-case packet contract.** The current `scripts/project-method-journey-evidence.mjs:116` requires exactly two features; line121 limits case directories to two; passed feature validation at line170 assumes healthy/missing-ref exits and statuses. `projectJourney` validates before acquiring output (line224). These are deliberate fail-closed limits, not current bugs. They leave the new full-five audit bundle unusable by existing packet-only host tasks. Do not bypass them by deleting three rows.

If this user-facing gap is prioritized, scope implementation to that projector and its tests, with an explicit version/scope distinction and compatible default packets. Acceptance: default packet bytes/validation retain current behavior; a full packet retains all five rows, exact semantics and evidence bindings, including mixed failure plus drift and empty source count; malformed/missing/reordered claims and unverified/not_run states cannot become passed; no raw environment/stderr disclosure; rejection creates no output. Independent fixtures should exercise full and default inputs. This does not require new methods, a watcher, model calls or formal J gate. It need not block the current full-five PR, which correctly promises refusal by the existing projector.
