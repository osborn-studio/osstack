**PASS.** This is static review only. I found no code blocker.

## What I checked

- **Default compatibility (FJ01, FJ04).** Omitted scope returns `{output}`, uses `defaultCases`, and emits the same `scope` string, `feature-map.md` tail and `journey.json` shape as before.
  - `parseOptions` fails closed on repeated flags, a missing value, a non-absolute output, an unknown scope value or a stray token.
  - `runJourney` checks `scope` before any `mkdir`, and `null` or `'unknown'` is rejected. `EEXIST` still protects existing output.
- **Full scope (FJ02, FJ03).** `fullCases` is in the fixed order, and `policies` encodes the exits 0/1/2/1/0 and the failed/drifted counts 0/0, 1/0, 0/1, 1/1, 0/0.
  - `fixedSources` is rebuilt from `git-03.stdout` (old SHA), `current_sha` and the fixture origin, then compared with `equal` against `expectations.json`.
  - Key order matches `caseDefinition`, so the comparison is sound.
  - `input_identity` ties that to the input bytes, and `git-05` is bound to `current_sha`.
  - The exact non-blank-line equality on `rawOut` closes the gap that `evaluateCase`'s `includes` leaves open: extra or contradictory source rows.
  - I traced each new test mutation to its intended check (`fixed_source`, `fixture_origin`, `fixed_expectation`, `behavior`, `raw_semantics`, `git_sha_identity`). They hit the right labels, and `cleanup_ownership` is still reached in the foreign-path test.
- **Failure preservation (FJ05, FJ06).** The row is set to `failed` before any phase runs, and raw doctor and drive logs are written before any check can throw. The remaining rows stay `not_run` with `not_started` cleanup. Drive cleanup is `unknown` until verified, and reported values are labeled `reported:… (unverified)`. `retainedState` marks manifests `verified:false` for failed rows and never links `not_created` evidence.
- **Cleanup (FJ08).** The checks cover actual fixture absence, `scratch/smoke` empty, `scratch` containing only `smoke`, and `descendant_termination: 'not_attested'`. Scratch and home are per-journey and explicit, so five cases do not share fixture resources.
- **Projector refusal (FJ09).** A full journey has 5 features, so `buildProjection` throws `fixed_case_set` before `mkdir(output)` and before any write.
  - The input is only opened read-only.
  - The 128-entry manifest and directory-entry limits are not exceeded by 5 cases, about 33 flat files in all.
  - The docs claim "refuses before creating its output directory", and the code supports it.
- **Docs and CI.** The docs are consistent with the code: default vs. full is explicit, product failure/drift is kept distinct from verification success, empty is "no check", and nothing claims model, native or qualification coverage. The CI step uploads on `always()` with a unique artifact name and uses the same scratch convention.

## Non-blocking suggestions

1. **Strict raw equality depends on real CLI output shape.** I can't see `skills-command.ts`.
   - The check assumes source rows come out in manifest order (mixed: healthy, missing-ref, drift).
   - It also assumes there are no extra hint lines on drift or failure, and that `Checking 0 source(s)…` is printed for empty.
   - A mismatch fails closed, never a false pass, and the new CI step is the first real exercise of it.
   - Run one real default and one real full journey before merge. A default-journey regression from this stricter check is the only FJ01 risk I can't rule out statically.
2. **Verifier assumption.** The verifier requires `git-00` through `git-05` plus the case label for every case, including `empty`. That is only valid if the driver builds the two-commit fixture unconditionally. Same real-run confirmation applies.
3. **Test gaps relative to FJ02 and FJ09.** Add:
   - a seam-driven `scope: 'full'` success run asserting five ordered doctor and drive pairs, and cross-case binding equality across all five;
   - a test that a sealed five-case journey is refused by the unchanged projector with no output directory created and input bytes unchanged;
   - a test that a default journey still projects.

   The shown diff has none of these; they may live in the projector's own test file.
4. **Minor ordering nit.** `join(cleanup.fixture_path, 'origin')` runs before the string and ownership check, so a malformed cleanup record yields a `TypeError` instead of `cleanup_ownership`. It still rejects, and this existed before the change.
5. **Stale wording elsewhere.** Grep the rest of the skill (SKILL.md, `evidence.md`, `sources.md`, any README) for "two-row", "accepts only `--output`" and "outside this two-row map".
6. **CI.** Confirm the `smoke:method-journey` package script forwards trailing args (`--output … --scope full`) and that the step runs after `pnpm build`.