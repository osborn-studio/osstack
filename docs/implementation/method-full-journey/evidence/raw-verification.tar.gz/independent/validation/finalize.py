import json,pathlib,hashlib,subprocess,datetime
S=pathlib.Path(__file__).resolve().parent;I=S.parent;R=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-journey-delivery').resolve()
def sha(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();initial=J(S/'source-binding.json')
assert head==initial['head']=='6e4c61689ee4b58ee52929519e9bdb95d6c3e0ea'
for f in initial['files']:assert sha((R/f['path']).read_bytes())==f['sha256']
A='32a9a9e18fc0b415c18cf14ce42c9f4f6d98f0c8';B='08c48fcb5300f5263bc5a2f15ebd6a8bca87e8fc'
lineage=[]
for ref,paths in [(A,['scripts/method-verification-journey.mjs','scripts/method-verification-journey.test.mjs']),(B,['osstack-methods-skill/references/skills-check-journey.md','osstack-methods-skill/references/maintain-verification.md'])]:
 for p in paths:
  b=subprocess.check_output(['git','show',ref+':'+p],cwd=R);assert b==(R/p).read_bytes();lineage.append({'author_sha':ref,'path':p,'sha256':sha(b),'same_as_composition':True})
base='493caa4e46e616b1d7e9e1c87ed0a5775eae3ad1'
for p in ['scripts/project-method-journey-evidence.mjs','scripts/smoke-skills-check.mjs','scripts/lib/skills-check-verification.mjs']:
 assert subprocess.check_output(['git','show',base+':'+p],cwd=R)==(R/p).read_bytes()
adv=J(S/'adversarial-results.json');sem=J(S/'semantic-result.json');assert all(x['passed'] for x in adv['results'])
axes=[
 ('FJ01','Default actual CLI two rows, stable original scope/qualification flags and existing projector success.','actual-default.command.json; project-default.command.json; semantic-result.json'),
 ('FJ02','Full actual CLI ordered five rows, products 0/1/2/1/0 and driver 0 each.','actual-full.command.json; actual-full/journey.json; semantic-result.json'),
 ('FJ03','Actual source cardinality/ref/blessed/current SHA and counts checked; resealed wrongold/current/duplicate/drop/ref/empty-source rejected.','semantic-result.json; adversarial-results.json; mutation-inputs/'),
 ('FJ04','CLI invalid/duplicate scope exit2 and no output; direct API rejects unknown before invoke, existing sentinel unchanged; default API parse shape preserved.','semantic-result.json; adversarial-results.json'),
 ('FJ05','Four injected drift-stage failure variants preserve preceding passed and later not_run; drive/verifier failure cleanup unknown. Cross-binding case keeps individually passed observation but whole journey fails.','fault-doctor/; fault-drive/; fault-verifier/; fault-cross-binding/; adversarial-results.json'),
 ('FJ06','Missing/unsealed raw and resealed receipt/detail/raw contradictions rejected; failed verifier retained manifest verified:false.','mutation-inputs/; fault-verifier/journey.json'),
 ('FJ07','All seven normal case binding pairs equal; independently hashed 1061 source +2336 build live files at check time; old/current identity verified. Cross-case consistent local reseal rejected by whole journey.','semantic-result.json; fault-cross-binding/journey.json'),
 ('FJ08','All seven normal fixtures absent, scratch contains only empty smoke; explicit fixture home and file origin records checked; evidence survives. No all-descendant claim.','semantic-result.json; actual-default/; actual-full/'),
 ('FJ09','Unchanged projector accepts actual default; actual full rejected fixed_case_set before output. Additional refusal records whole input pre/post hashes equal.','project-default.command.json; project-full.command.json; semantic-result.json'),
 ('FJ10','Two frozen B references match final composition; static review confirms exact optional scope, source/driver distinction, empty meaning, failure/unknown and projector limits. No new model/native claim.','report.md; source-binding.json')]
report={'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed_with_declared_scope_limits','confirmed_defects':[],'candidate':head,'author_source_lineage':lineage,'criteria_sha256':sha((I/'criteria.json').read_bytes()),'axes':[{'id':a,'status':'passed','finding':b,'evidence':c} for a,b,c in axes],'actual_normal_cases':sem['case_rows'],'adversarial_observations':len(adv['results']),'limitations':['No model, native host, formal joint gate, production runtime or full-suite certification.','Fault seams and resealed copies are verifier-generated and explicitly distinct from natural product failures; no original normal evidence was modified.','Source/build bytes matched live files at observation, not authenticated compiler provenance.','CLI fixture isolation/configuration is not an OS sandbox and descendant termination remains not_attested.','No old host call or prior LIMITED result was repeated or rewritten.','No new double-host exports run by this verifier: this change adds no method/route; docs match B exact bytes and their wrapper commands were exercised.'],'audit_nonblocker_mapping':{'real_default_full_cli':'actual-default/actual-full exit0 and 7 normal case semantic checks','default_full_projection':'default success, full fixed_case_set refusal/no output','ordered_full_cases':'actual-full/journey.json exact ordered five','cross_case_binding_fault':'fault-cross-binding actual preceding calls and consistent drift-record binding mutation; overall failed'}}
(S/'report.json').write_text(json.dumps(report,indent=2)+'\n')
text='''# Independent five-case journey verification

No confirmed defect found within frozen FJ01–10. Tested composition `6e4c61689ee4b58ee52929519e9bdb95d6c3e0ea`; A script/test bytes equal `32a9a9e1`, B reference bytes equal `08c48fcb`. Original criteria and source snapshots remain unchanged.

Actual default journey completed healthy/missing-ref, and the unchanged projector accepted it. Actual full journey completed healthy/missing-ref/drift/mixed/empty in order with product exits **0/1/2/1/0**, each driver exit 0. Seven normal case records were inspected against actual source arrays, Git old/current observations, raw output, unchanged input, manifests and removed fixture paths. All seven shared source/build digests; 1,061 source and 2,336 build files matched their live bytes at independent observation. This does not establish compiler provenance.

The unchanged projector rejected the full run with `fixed_case_set`, creating no output. A second bounded refusal captured complete input hashes before/after and confirmed no change; the first attempt is preserved. Default scope text, two-row shape and qualification flags remain compatible.

30 bounded adversarial/interface observations passed: positive relocated evidence controls; resealed wrong blessed SHA, duplicate/missing/misconfigured mixed sources, introduced empty source, extra raw source, receipt/detail/cleanup/Git contradictions; unsealed or missing raw bytes; CLI/API scope and existing-output checks. Four additional-case fault seams used the actual prior driver calls, then injected doctor, drive, verifier or cross-case binding failure. Prior observations survived, later rows stayed `not_run`, unknown cleanup stayed unknown, and retained verifier-failure evidence was marked unverified. In the binding-mismatch case the individually verified drift row remains passed while the whole journey fails, preserving the actual observation.

These executions address the audit's requests for real default/full runs and projection compatibility/refusal, ordered five-case checking and a cross-case binding fault. See `report.json`, `semantic-result.json`, `adversarial-results.json` and raw command/log files. Mutation inputs are sparse changes over the preserved actual-full case, plus documented relocation of receipt evidence identity; original normal runs were not edited.

B documentation was reviewed statically and exact-byte compared to the final tree. It accurately distinguishes optional full scope, product failures/drift from successful verification, empty configuration, and the existing two-case projector limit. No new host export was necessary for this verifier's executable-command scope; author export results are not relabeled independent execution.

No full suite, host/model call, production/runtime gate or independent-principal certification was performed. Fixture/configuration isolation is not an OS sandbox; all-descendant termination remains unproven. Prior LIMITED experiments are untouched.
'''
(S/'report.md').write_text(text)
# Retrospective index of the independently executed orchestration; command-level real runs have their own contemporaneous metadata.
(S/'execution-index.json').write_text(json.dumps({'recorded_after_execution':True,'commands':[{'argv':['/usr/bin/python3',str(S/'run-actual.py')],'exit_code':0,'evidence':'four per-command .command.json records and raw streams'},{'argv':['/opt/homebrew/opt/node@22/bin/node',str(S/'adversarial.mjs')],'exit_code':0,'stdout':'adversarial.stdout','stderr':'adversarial.stderr','environment_overrides':{'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':str(S),'OSSTACK_HOME':str(S/'isolated-home/osstack')}},{'argv':['/usr/bin/python3',str(S/'check-results.py')],'exit_code':0,'stdout':'check-results.stdout','stderr':'check-results.stderr'}]},indent=2)+'\n')
files=[]
for p in sorted(I.rglob('*')):
 if p.is_file() and p.name!='final-manifest.json':
  b=p.read_bytes();files.append({'path':str(p.relative_to(I)),'bytes':len(b),'sha256':sha(b),'mode':oct(p.stat().st_mode&0o777)})
(I/'final-manifest.json').write_text(json.dumps({'files':files,'count':len(files),'payload_bytes':sum(x['bytes'] for x in files)},indent=2)+'\n')
for p in [S/'report.json',S/'report.md',I/'final-manifest.json']:print(p,sha(p.read_bytes()))
print('members',len(files))
