import os,json,pathlib,hashlib,subprocess,time
S=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-journey-delivery').resolve();N='/opt/homebrew/opt/node@22/bin/node'
def sha(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_bytes())
def inv(d):return {str(p.relative_to(d)):sha(p.read_bytes()) for p in d.rglob('*') if p.is_file()}
def seal(d,name):
 m=J(d/name)
 for f in m['files']:
  b=(d/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],str(d/f['path'])
 return len(m['files'])
ids=['healthy','missing-ref','drift','mixed','empty'];exits=[0,1,2,1,0];counts=[(0,0),(1,0),(0,1),(1,1),(0,0)];case_rows=[];seen_binding=[];checkedfiles=0
for run in ['actual-default','actual-full']:
 d=S/run;j=J(d/'journey.json');assert j['status']=='passed';selected=ids[:2] if run.endswith('default') else ids
 assert [f['case_id'] for f in j['features']]==selected
 assert j['model_calls']==0 and j['formal_gate_pass'] is False and j['provider_qualified'] is False
 checkedfiles+=seal(d,'journey-manifest.json')
 for cid in selected:
  c=d/'cases'/cid;checkedfiles+=seal(c,'manifest.json');e=J(c/'expectations.json')['definitions'][0];inp=J(c/(cid+'.input.json'));cmd=J(c/(cid+'.command.json'));detail=J(c/(cid+'.json'));receipt=J(c/'receipt.json');cleanup=J(c/'cleanup.json')
  old=(c/'git-03.stdout').read_text().strip();current=(c/'git-05.stdout').read_text().strip();assert old!=current and e['current_sha']==current
  names={'healthy':['healthy'],'missing-ref':['missing-ref'],'drift':['drift'],'mixed':['healthy','missing-ref','drift'],'empty':[]}[cid]
  assert [x['id'] for x in inp['sources']]==names and e['sources']==inp['sources']
  for src in inp['sources']:
   assert src['origin']==(pathlib.Path(cleanup['fixture_path'])/'origin').as_uri()
   assert src['blessed_sha']==(old if src['id']=='drift' else current)
   assert src['ref']==('refs/heads/not-present' if src['id']=='missing-ref' else 'refs/heads/main')
   assert src['auto_minor'] is False
  n=ids.index(cid);assert (e['failed'],e['drifted'])==counts[n] and cmd['exit_code']==exits[n]
  assert receipt['driver_exit']==0 and receipt['cases'][0]['actual_exit']==exits[n] and receipt['status']=='passed'
  assert detail['manifest_before_sha256']==detail['manifest_after_sha256']==sha((c/(cid+'.input.json')).read_bytes())
  assert cleanup['status']=='passed' and cleanup['fixture_removed'] and not pathlib.Path(cleanup['fixture_path']).exists() and cleanup['descendant_termination']=='not_attested'
  assert cmd['environment']['OSSTACK_HOME']==str(pathlib.Path(cleanup['fixture_path'])/('home-'+cid))
  b=J(c/'bindings.json');seen_binding.append((b['source']['digest'],b['build']['digest']))
  case_rows.append({'run':run,'case':cid,'product_exit':cmd['exit_code'],'driver_exit':receipt['driver_exit'],'sources':len(inp['sources']),'failed':e['failed'],'drifted':e['drifted'],'old_sha':old,'current_sha':current,'fixture_absent':True,'source_stdout_sha256':sha((c/(cid+'.stdout')).read_bytes())})
 assert list((d/'scratch').iterdir())==[d/'scratch/smoke'] and not list((d/'scratch/smoke').iterdir())
assert len(set(seen_binding))==1
live=[]
for kind in ['source','build']:
 b=J(S/'actual-full/cases/healthy/bindings.json')[kind]
 assert sha(json.dumps(b['files'],ensure_ascii=False,separators=(',',':')).encode())==b['digest']
 for f in b['files']:
  p=R/f['path'];raw=p.read_bytes();assert len(raw)==f['bytes'] and sha(raw)==f['sha256'],str(p)
 live.append({'kind':kind,'files_checked':len(b['files']),'digest':b['digest']})
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(S/'isolated-home'),'OSSTACK_HOME':str(S/'isolated-home/osstack'),'OSSTACK_SCRATCH_ROOT':str(S),'LANG':'C','LC_ALL':'C'}
commands=[]
for label,args in [('invalid-scope',['--output',str(S/'invalid-cli-output'),'--scope','all']),('duplicate-scope',['--output',str(S/'invalid-cli-output'),'--scope','full','--scope','full'])]:
 argv=[N,str(R/'scripts/method-verification-journey.mjs'),*args];t=time.time();p=subprocess.run(argv,cwd=R,env=env,capture_output=True,timeout=15);(S/(label+'.stdout')).write_bytes(p.stdout);(S/(label+'.stderr')).write_bytes(p.stderr);assert p.returncode==2 and not (S/'invalid-cli-output').exists();commands.append({'label':label,'argv':argv,'exit_code':p.returncode,'elapsed_seconds':time.time()-t,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)})
before=inv(S/'actual-full');argv=[N,str(R/'scripts/project-method-journey-evidence.mjs'),'--input',str(S/'actual-full'),'--output',str(S/'full-packet-hash-check')];p=subprocess.run(argv,cwd=R,env=env,capture_output=True,timeout=15);after=inv(S/'actual-full');assert p.returncode==1 and b'fixed_case_set' in p.stderr and before==after and not (S/'full-packet-hash-check').exists();(S/'projection-hash-check.stdout').write_bytes(p.stdout);(S/'projection-hash-check.stderr').write_bytes(p.stderr);commands.append({'label':'projection-hash-check','argv':argv,'exit_code':p.returncode,'before':before,'after_equal':True,'output_absent':True,'purpose':'additional refusal invocation records complete pre/post input hashes; original execution retained'})
(S/'semantic-result.json').write_text(json.dumps({'case_rows':case_rows,'sealed_members_checked':checkedfiles,'live_bindings':live,'cross_case_and_run_binding_equal':True,'commands':commands,'environment':env,'repository':str(R)},indent=2)+'\n')
print(json.dumps({'cases':len(case_rows),'sealed_members':checkedfiles,'live_binding_files':live,'adversarial_results':len(J(S/'adversarial-results.json')['results'])},indent=2))
