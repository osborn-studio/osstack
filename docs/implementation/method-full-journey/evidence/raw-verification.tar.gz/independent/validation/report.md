# Independent five-case journey verification

No confirmed defect found within frozen FJ01–10. Tested composition `6e4c61689ee4b58ee52929519e9bdb95d6c3e0ea`; A script/test bytes equal `32a9a9e1`, B reference bytes equal `08c48fcb`. Original criteria and source snapshots remain unchanged.

Actual default journey completed healthy/missing-ref, and the unchanged projector accepted it. Actual full journey completed healthy/missing-ref/drift/mixed/empty in order with product exits **0/1/2/1/0**, each driver exit 0. Seven normal case records were inspected against actual source arrays, Git old/current observations, raw output, unchanged input, manifests and removed fixture paths. All seven shared source/build digests; 1,061 source and 2,336 build files matched their live bytes at independent observation. This does not establish compiler provenance.

The unchanged projector rejected the full run with `fixed_case_set`, creating no output. A second bounded refusal captured complete input hashes before/after and confirmed no change; the first attempt is preserved. Default scope text, two-row shape and qualification flags remain compatible.

30 bounded adversarial/interface observations passed: positive relocated evidence controls; resealed wrong blessed SHA, duplicate/missing/misconfigured mixed sources, introduced empty source, extra raw source, receipt/detail/cleanup/Git contradictions; unsealed or missing raw bytes; CLI/API scope and existing-output checks. Four additional-case fault seams used the actual prior driver calls, then injected doctor, drive, verifier or cross-case binding failure. Prior observations survived, later rows stayed `not_run`, unknown cleanup stayed unknown, and retained verifier-failure evidence was marked unverified. In the binding-mismatch case the individually verified drift row remains passed while the whole journey fails, preserving the actual observation.

These executions address the audit's requests for real default/full runs and projection compatibility/refusal, ordered five-case checking and a cross-case binding fault. See `report.json`, `semantic-result.json`, `adversarial-results.json` and raw command/log files. Mutation inputs are sparse changes over the preserved actual-full case, plus documented relocation of receipt evidence identity; original normal runs were not edited.

B documentation was reviewed statically and exact-byte compared to the final tree. It accurately distinguishes optional full scope, product failures/drift from successful verification, empty configuration, and the existing two-case projector limit. No new host export was necessary for this verifier's executable-command scope; author export results are not relabeled independent execution.

No full suite, host/model call, production/runtime gate or independent-principal certification was performed. Fixture/configuration isolation is not an OS sandbox; all-descendant termination remains unproven. Prior LIMITED experiments are untouched.
