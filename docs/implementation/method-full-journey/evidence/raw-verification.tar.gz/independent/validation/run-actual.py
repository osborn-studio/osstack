import os,json,subprocess,hashlib,time,pathlib
R=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-journey-delivery').resolve()
S=pathlib.Path(__file__).resolve().parent
N='/opt/homebrew/opt/node@22/bin/node'
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(S/'isolated-home'),'OSSTACK_HOME':str(S/'isolated-home/osstack'),'OSSTACK_SCRATCH_ROOT':str(S),'LANG':'C','LC_ALL':'C'}
(S/'isolated-home').mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def run(label,args):
 t=time.time(); p=subprocess.run([N,*args],cwd=R,env=env,capture_output=True,timeout=300)
 (S/(label+'.stdout')).write_bytes(p.stdout);(S/(label+'.stderr')).write_bytes(p.stderr)
 rec={'argv':[N,*args],'cwd':str(R),'environment':env,'exit_code':p.returncode,'started_unix':t,'elapsed_seconds':time.time()-t,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)}
 (S/(label+'.command.json')).write_text(json.dumps(rec,indent=2)+'\n');print(label,p.returncode,flush=True);return p
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
paths=['scripts/method-verification-journey.mjs','scripts/method-verification-journey.test.mjs','scripts/project-method-journey-evidence.mjs','osstack-methods-skill/references/skills-check-journey.md','osstack-methods-skill/references/maintain-verification.md']
(S/'source-binding.json').write_text(json.dumps({'head':head,'files':[{'path':p,'sha256':sha((R/p).read_bytes())} for p in paths]},indent=2)+'\n')
assert run('actual-default',[str(R/'scripts/method-verification-journey.mjs'),'--output',str(S/'actual-default')]).returncode==0
assert run('actual-full',[str(R/'scripts/method-verification-journey.mjs'),'--output',str(S/'actual-full'),'--scope','full']).returncode==0
assert run('project-default',[str(R/'scripts/project-method-journey-evidence.mjs'),'--input',str(S/'actual-default'),'--output',str(S/'default-packet')]).returncode==0
assert run('project-full',[str(R/'scripts/project-method-journey-evidence.mjs'),'--input',str(S/'actual-full'),'--output',str(S/'full-packet')]).returncode==1
assert not (S/'full-packet').exists()
print('ACTUAL COMPLETE',flush=True)
