import {readFile,writeFile,readdir,mkdir,cp,rm,lstat,realpath} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname,join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const S=dirname(fileURLToPath(import.meta.url));
const R=await realpath('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-journey-delivery');
const {verifyCaseEvidence,runJourney,invokeDriver,parseOptions}=await import(pathToFileURL(join(R,'scripts/method-verification-journey.mjs')));
const hash=b=>createHash('sha256').update(b).digest('hex');
const json=async p=>JSON.parse(await readFile(p));
const save=async(p,x)=>writeFile(p,JSON.stringify(x,null,2)+'\n');
const results=[];
await mkdir(join(S,'mutation-inputs'),{recursive:true});
async function seal(d){const m=await json(join(d,'manifest.json'));m.files=[];for(const n of (await readdir(d)).sort())if(n!=='manifest.json'){const b=await readFile(join(d,n));m.files.push({path:n,bytes:b.length,sha256:hash(b)});}await save(join(d,'manifest.json'),m);}
async function edit(d,n,f){const x=await json(join(d,n));f(x);await save(join(d,n),x);}
async function runMutation(label,id,mutate,expected){
 const d=join(S,'mutation-working');await rm(d,{recursive:true,force:true});await cp(join(S,'actual-full','cases',id),d,{recursive:true});
 await edit(d,'receipt.json',r=>r.evidence.directory=d);await seal(d);
 const initial=new Map(await Promise.all((await readdir(d)).map(async n=>[n,hash(await readFile(join(d,n)))])));
 if(mutate)await mutate(d);
 const changed=[]; const out=join(S,'mutation-inputs',label);await mkdir(out);
 for(const n of new Set([...initial.keys(),...await readdir(d)])){const b=await readFile(join(d,n)).catch(e=>e.code==='ENOENT'?null:Promise.reject(e));if(b===null||hash(b)!==initial.get(n)){changed.push({path:n,sha256:b&&hash(b),bytes:b?.length??null});if(b)await writeFile(join(out,n),b);}}
 let error=null,observed=null;try{observed=await verifyCaseEvidence({directory:d,scratch:join(S,'actual-full/scratch'),caseId:id,repository:R,stdout:await readFile(join(d,'receipt.json')),driverExit:0});}catch(e){error=e.message;}
 const row={label,id,base:'actual-full/cases/'+id,copy_adjustment:'receipt.evidence.directory relocated then manifest resealed before mutation',changed,expected,observed:error??'accepted',passed:expected==='accepted'?error===null:error!==null&&new RegExp(expected).test(error)};
 results.push(row);await save(join(out,'result.json'),row);console.log(label,row.observed,row.passed);assert(row.passed,label);
}
await runMutation('positive-drift-copy','drift',null,'accepted');
await runMutation('positive-mixed-copy','mixed',null,'accepted');
await runMutation('positive-empty-copy','empty',null,'accepted');
for(const [label,id,fn] of [
 ['drift-blessed-current','drift',e=>e.sources[0].blessed_sha=e.current_sha],
 ['drift-blessed-wrong-old','drift',e=>e.sources[0].blessed_sha='c'.repeat(40)],
 ['mixed-duplicate-source','mixed',e=>e.sources[1]={...e.sources[0]}],
 ['mixed-drop-source','mixed',e=>e.sources.pop()],
 ['mixed-swap-ref','mixed',e=>e.sources[2].ref='refs/heads/not-present'],
 ['empty-introduce-source','empty',e=>e.sources=[{id:'healthy',origin:'file:///foreign',ref:'refs/heads/main',blessed_sha:e.current_sha,auto_minor:false}]],
 ['mixed-auto-minor','mixed',e=>e.sources[0].auto_minor=true],
])await runMutation(label,id,async d=>{await edit(d,'expectations.json',x=>fn(x.definitions[0]));const e=(await json(join(d,'expectations.json'))).definitions[0];await save(join(d,id+'.input.json'),{version:1,sources:e.sources});const h=hash(await readFile(join(d,id+'.input.json')));await edit(d,id+'.json',x=>{x.manifest_before_sha256=h;x.manifest_after_sha256=h;});await seal(d);},'fixed_source');
await runMutation('missing-raw','drift',async d=>{await rm(join(d,'drift.stdout'));await seal(d);},'required_evidence');
await runMutation('unsealed-raw','mixed',async d=>writeFile(join(d,'mixed.stdout'),'all good\n'),'manifest_hash');
await runMutation('resealed-extra-raw-source','mixed',async d=>{const p=join(d,'mixed.stdout');await writeFile(p,(await readFile(p,'utf8'))+'  ✓ foreign  up-to-date\n');const h=hash(await readFile(p));await edit(d,'mixed.command.json',x=>x.stdout_sha256=h);await edit(d,'mixed.json',x=>x.stdout_sha256=h);await seal(d);},'raw_semantics');
await runMutation('receipt-product-conflict','drift',async d=>{await edit(d,'receipt.json',x=>x.cases[0].actual_exit=0);await seal(d);},'case_receipt');
await runMutation('detail-input-hash-conflict','empty',async d=>{await edit(d,'empty.json',x=>x.manifest_after_sha256='f'.repeat(64));await seal(d);},'behavior');
await runMutation('cleanup-unknown','empty',async d=>{await edit(d,'cleanup.json',x=>{x.status='unknown';x.fixture_removed=false;});const c=await json(join(d,'cleanup.json'));await edit(d,'receipt.json',x=>x.cleanup=c);await seal(d);},'cleanup_claim');
await runMutation('git-current-wrong','drift',async d=>{await writeFile(join(d,'git-05.stdout'),'d'.repeat(40)+'\n');await edit(d,'git-05.command.json',x=>x.stdout_sha256=hash(Buffer.from('d'.repeat(40)+'\n')));await seal(d);},'git_sha_identity');
await rm(join(S,'mutation-working'),{recursive:true});
for(const args of [[],['--output',join(S,'bad'),'--scope','default'],['--output',join(S,'bad'),'--scope','full','--scope','full'],['--scope',''],['--output',join(S,'bad'),'--scope'],['--output',join(S,'bad'),'--scope','FULL'],['--output',join(S,'bad'),'--case','all']]){let failed=false;try{parseOptions(args);}catch{failed=true;}assert(failed);results.push({label:'usage',args,passed:failed});}
assert.deepEqual(parseOptions(['--output',join(S,'x')]),{output:join(S,'x')});assert.deepEqual(parseOptions(['--scope','full','--output',join(S,'x')]),{scope:'full',output:join(S,'x')});
let invoked=false;await assert.rejects(runJourney({output:join(S,'invalid-api'),scope:'all'},{invoke:()=>{invoked=true;}}),/invalid_scope/);assert(!invoked);assert.equal(await lstat(join(S,'invalid-api')).catch(()=>null),null);results.push({label:'unknown-direct-api-no-output',passed:true});
await mkdir(join(S,'existing'));await writeFile(join(S,'existing/sentinel'),'unchanged');await assert.rejects(runJourney({output:join(S,'existing'),scope:'full'},{invoke:()=>{invoked=true;}}),/EEXIST/);assert(!invoked);assert.equal(await readFile(join(S,'existing/sentinel'),'utf8'),'unchanged');results.push({label:'existing-output-preserved',passed:true});
// Faults affect only this verifier-owned run's child result/evidence; real prior cases still execute.
for(const phase of ['doctor','drive','verifier','cross-binding']){
 const output=join(S,'fault-'+phase);let seamHit=false;
 const result=await runJourney({output,scope:'full'},{invoke:async(args,env,timeout,signal)=>{
  const id=args[args.indexOf('--case')+1],isDoctor=args.includes('--doctor');
  if(id==='drift'&&((phase==='doctor'&&isDoctor)||(phase==='drive'&&!isDoctor))){seamHit=true;return {exit_code:1,signal:null,killed:false,stdout:Buffer.from(phase==='doctor'?'{"ready":false,"executed":false}':'{"cleanup":{"status":"unknown"},"cases":[{"actual_exit":2}]}'),stderr:Buffer.from('independent injected failure')};}
  const rec=await invokeDriver(args,env,timeout,signal);
  if(id==='drift'&&!isDoctor&&(phase==='verifier'||phase==='cross-binding')){
   seamHit=true;const d=args[args.indexOf('--evidence-dir')+1];
   if(phase==='verifier'){await edit(d,'expectations.json',x=>x.definitions[0].sources[0].blessed_sha=x.definitions[0].current_sha);}
   else{await edit(d,'bindings.json',x=>{x.source.files.find(f=>f.path==='packages/cli/src/skills-command.ts').sha256='a'.repeat(64);x.source.digest=hash(Buffer.from(JSON.stringify(x.source.files)));});const b=await json(join(d,'bindings.json'));for(const n of ['run.json','receipt.json'])await edit(d,n,x=>{if(n==='run.json'){x.bindings.source_digest=b.source.digest;x.final_bindings.source_digest=b.source.digest;}else x.binding_digests.source_digest=b.source.digest;});}
   await seal(d);rec.stdout=await readFile(join(d,'receipt.json'));
  }
  return rec;
 }});
 assert(seamHit);assert.equal(result.status,'failed');assert.deepEqual(result.features.slice(0,2).map(x=>x.verification),['passed','passed']);assert.deepEqual(result.features.slice(3).map(x=>x.verification),['not_run','not_run']);
 assert.equal(result.features[2].verification,phase==='cross-binding'?'passed':'failed');
 if(phase==='drive'||phase==='verifier')assert.equal(result.features[2].cleanup.status,'unknown');
 if(phase==='verifier')assert.equal(result.retained.case_manifests.find(x=>x.case_id==='drift').verified,false);
 if(phase==='cross-binding')assert.equal(result.failure,'cross_case_bindings_changed');
 results.push({label:'fault-'+phase,passed:true,failure:result.failure,features:result.features.map(x=>({id:x.case_id,verification:x.verification,cleanup:x.cleanup.status}))});console.log('fault-'+phase,result.failure);
}
await save(join(S,'adversarial-results.json'),{scope:'retained-copy mutation and injected child-result seams; no product mutation or host calls',results});
