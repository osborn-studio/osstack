# Fixed skills-check journey

Journey status: failed. See journey.json for failure details.

| Feature | Product exit | Driver exit | Verification | Cleanup | Evidence |
|---|---|---|---|---|---|
| healthy | 0 | 0 | passed (journey:failed) | passed | cases/healthy/manifest.json |
| missing-ref | 1 | 0 | passed (journey:failed) | passed | cases/missing-ref/manifest.json |
| drift | 2 | 0 | passed (journey:failed) | passed | cases/drift/manifest.json |
| mixed | not_observed | not_observed | not_run (journey:failed) | not_started | not_created |
| empty | not_observed | not_observed | not_run (journey:failed) | not_started | not_created |

Expected missing-ref product exit1 is an unrecovered source failure. Driver exit0 means its fixed negative predicate passed. Native selection/model execution: not observed/not run. Descendant termination: not attested. Full scope covers only these five fixed cases. Expected drift exit2 reports changed source; mixed exit1 preserves failure precedence over drift. Existing two-case projection does not accept this scope.
