import { spawnSync } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
const root = resolve(process.argv[2]);
const repository = '/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-ci-fix';
await mkdir(root); await mkdir(join(root, 'bin')); await mkdir(join(root, 'home'));
const env = { PATH: '/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin', HOME: join(root, 'home'), OSSTACK_HOME: join(root, 'home'), OSSTACK_SCRATCH_ROOT: '/Volumes/AIMATE_WORK/tmp/osstack', GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_AUTHOR_NAME: 'Repro', GIT_AUTHOR_EMAIL: 'repro@example.invalid', GIT_COMMITTER_NAME: 'Repro', GIT_COMMITTER_EMAIL: 'repro@example.invalid' };
const commandLog = [];
const git = args => { const r = spawnSync('/usr/bin/git', args, { env, encoding: 'utf8', cwd: root }); commandLog.push({ executable: '/usr/bin/git', argv: args, exit: r.status, stdout: r.stdout, stderr: r.stderr }); if (r.status) throw Error(r.stderr); return r.stdout.trim(); };
const origin = join(root, 'origin');
git(['init', '--initial-branch=main', origin]);
git(['-C', origin, '-c', 'commit.gpgsign=false', 'commit', '--allow-empty', '-m', 'baseline']); const old = git(['-C', origin, 'rev-parse', 'HEAD']);
git(['-C', origin, '-c', 'commit.gpgsign=false', 'commit', '--allow-empty', '-m', 'current']); const current = git(['-C', origin, 'rev-parse', 'HEAD']);
const timeline = join(root, 'timeline.jsonl');
// Controlled transport shim: fetch a real Git result, then let a child holding
// inherited stdout deliver it after the direct Git shim exits. No network.
const late = `const fs=require('node:fs'); setTimeout(()=>{fs.appendFileSync(${JSON.stringify(timeline)}, JSON.stringify({event:'late_stdout',at:Date.now()})+'\\n');process.stdout.write(Buffer.from(process.argv[1],'base64'));},150);`;
const shim = `#!${process.execPath}\nconst {spawnSync,spawn}=require('node:child_process');const fs=require('node:fs');const result=spawnSync('/usr/bin/git',process.argv.slice(2));fs.appendFileSync(${JSON.stringify(timeline)},JSON.stringify({event:'real_git_complete',exit:result.status,stdout:result.stdout.toString(),at:Date.now()})+'\\n');const tail=spawn(process.execPath,['-e',${JSON.stringify(late)},result.stdout.toString('base64')],{stdio:['ignore',1,2]});tail.unref();process.stderr.write(result.stderr);fs.appendFileSync(${JSON.stringify(timeline)},JSON.stringify({event:'shim_exiting',at:Date.now()})+'\\n');process.exit(result.status);\n`;
await writeFile(join(root, 'bin/git'), shim, { mode: 0o700 });
const probe = `const {checkSource}=await import(${JSON.stringify(pathToFileURL(join(repository, 'packages/skill-registry/dist/watcher.js')).href)});const result=await checkSource({id:'drift',origin:${JSON.stringify(pathToFileURL(origin).href)},ref:'refs/heads/main',blessed_sha:${JSON.stringify(old)},auto_minor:false});console.log(JSON.stringify({result,expected_current_sha:${JSON.stringify(current)},resolved_at:Date.now()}));`;
const r = spawnSync(process.execPath, ['--input-type=module', '-e', probe], { env: { ...env, PATH: join(root, 'bin') + ':' + env.PATH }, cwd: root, encoding: 'utf8', timeout: 5000 });
await writeFile(join(root, 'commands.json'), JSON.stringify(commandLog, null, 2)+'\n'); await writeFile(join(root, 'stdout'),r.stdout);await writeFile(join(root,'stderr'),r.stderr);
const result = { exit:r.status,signal:r.signal,actual:r.stdout.trim(),timeline:(await readFile(timeline,'utf8')).trim().split('\n').map(x=>JSON.parse(x)),note:'Controlled inherited-pipe experiment using actual git ls-remote output. Demonstrates product event-order defect, not proven historical CI origin.' };
await writeFile(join(root,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
