import fs from 'node:fs';
import fsp from 'node:fs/promises';
import cp from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
const attempts=[];
for(const [object,names] of [[cp,['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']],[fsp,['mkdir','mkdtemp','writeFile','appendFile','rm','unlink','rename','copyFile','cp','symlink','link','chmod','chown','truncate','open']],[fs,['mkdir','mkdirSync','mkdtemp','mkdtempSync','writeFile','writeFileSync','appendFile','appendFileSync','rm','rmSync','unlink','unlinkSync','rename','renameSync','copyFile','copyFileSync','symlink','symlinkSync','open','openSync','createWriteStream']]]) {
 for(const name of names){object[name]=(...args)=>{attempts.push(name);throw Error('independent_forbidden_effect:'+name)}}
}
syncBuiltinESMExports();
process.on('exit',()=>process.stderr.write('INDEPENDENT_EFFECT_ATTEMPTS='+JSON.stringify(attempts)+'\n'));
