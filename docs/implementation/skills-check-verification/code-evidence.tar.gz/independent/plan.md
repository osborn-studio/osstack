# Independent black-box plan (awaiting frozen candidate)

No candidate source has been read. Expectations are derived from the delegated public interface at the recorded base. This is engineering evidence, not an authenticated oracle or runtime qualification.

1. Record frozen candidate SHA, dirty status and actual script/build hashes. Use existing built artifacts only after the owner declares them stable. Never alter the author checkout.
2. Probe doctor/dry-run under explicit isolated scratch environment with file/child observation. Use a dedicated preloader or controlled copy if needed to observe child-process calls; state limitations. Compare owned directory trees before/after. These probes must not run product actions.
3. Execute all five cases through the actual script with a fresh evidence destination. Inspect actual raw command/output records and manifest bytes, not only success labels. Compare reported case results to 0/1/2/1/0 and independent hashes. Retention may be intentional; resource cleanup and evidence retention are distinct.
4. Retry only the existing evidence destination as a negative input, with a preexisting sentinel. Check no bytes changed. Invalid case/value is another early-failure probe.
5. Use an entirely scratch controlled repository copy for missing-build and invalid/legacy-zero CLI mutants. Copy only files needed by the documented script, without changing frozen product files; preserve model/loader import resolution and record copy inventory. If copying cannot faithfully preserve runtime boundaries, report the probe unsupported rather than substitute an unrelated helper test.
6. Retain command argv, timestamps, actual exit code, raw streams, pre/post observations and candidate/source hashes. Failed probes remain in the report. No edits to product, central ledger or PR; no external network services or default OSSTACK_HOME.

The exact execution harness and evidence layout inspection will be prepared after candidate freeze; those mechanics are not falsely presented as pre-registered source-independent implementation details. No candidate execution is authorized before the parent signals freeze.
