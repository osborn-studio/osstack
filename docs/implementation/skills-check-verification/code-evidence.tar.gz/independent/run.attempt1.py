from pathlib import Path
import json,hashlib,subprocess,os,datetime,shutil
r=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/skills-check-verification-20261028/independent'); repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-verification');node='/opt/homebrew/opt/node@22/bin/node'
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def tree(p):return {str(x.relative_to(p)):sha(x.read_bytes()) for x in p.rglob('*') if x.is_file() and not x.is_symlink()} if p.exists() else {}
env=os.environ.copy();env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(r/'unused-home'),OSSTACK_SCRATCH_ROOT=str(r/'runtime'));env.pop('OSSTACK_SOCKET',None);env.pop('NODE_OPTIONS',None)
def run(label,args,cwd=repo):
 start=now(); p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=150);(r/(label+'.stdout')).write_bytes(p.stdout);(r/(label+'.stderr')).write_bytes(p.stderr)
 d={'argv':list(map(str,args)),'cwd':str(cwd),'start':start,'end':now(),'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)};(r/(label+'.command.json')).write_text(json.dumps(d,indent=2));return p
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='a0be527aedc7bfba4efe15b3c55ecdd2c10026ec'
source_names=['scripts/smoke-skills-check.mjs','scripts/lib/skills-check-verification.mjs','scripts/smoke-skills-check.test.mjs']
initial={p:sha((repo/p).read_bytes()) for p in source_names if (repo/p).exists()};(r/'candidate-binding.json').write_text(json.dumps({'sha':head,'source':initial},indent=2))
results=[]
# Intercept writes/subprocess APIs in preflight. Node builtin/module initialization itself is outside this observation.
for name,flags in [('doctor',['--doctor']),('dry-run',['--dry-run']),('bad-case',['--case','bad']),('missing-case',['--case'])]:
 destination=r/(name+'-evidence'); before=tree(r/'runtime')
 p=run(name,[node,'--import',str(r/'no-effects.mjs'),str(repo/'scripts/smoke-skills-check.mjs'),*flags,'--evidence-dir',str(destination)])
 good=(p.returncode==0 if name in ['doctor','dry-run'] else p.returncode!=0) and 'INDEPENDENT_EFFECT_ATTEMPTS=[]' in p.stderr.decode() and not destination.exists() and tree(r/'runtime')==before
 results.append({'id':{'doctor':'I01','dry-run':'I02','bad-case':'I06','missing-case':'I06'}[name],'probe':name,'passed':good,'exit':p.returncode})
# Existing destination sentinel, rejected before any effects.
existing=r/'existing-evidence';existing.mkdir();shutil.copy2(r/'sentinel.txt',existing/'sentinel.txt');before=tree(existing)
p=run('existing',[node,'--import',str(r/'no-effects.mjs'),str(repo/'scripts/smoke-skills-check.mjs'),'--evidence-dir',str(existing)])
results.append({'id':'I05','passed':p.returncode!=0 and tree(existing)==before and 'INDEPENDENT_EFFECT_ATTEMPTS=[]' in p.stderr.decode()})
p=run('all',[node,str(repo/'scripts/smoke-skills-check.mjs'),'--case','all','--evidence-dir',str(r/'all-evidence')]); receipt=json.loads(p.stdout); expected={'healthy':0,'missing-ref':1,'drift':2,'mixed':1,'empty':0}
results.append({'id':'I03','passed':p.returncode==0 and receipt['status']=='passed' and {c['case_id']:c['actual_exit'] for c in receipt['cases']}==expected})
e=r/'all-evidence'; checks=[]
manifest=json.loads((e/'manifest.json').read_text())
for f in manifest['files']:checks.append(sha((e/f['path']).read_bytes())==f['sha256'])
for cid,code in expected.items():
 c=json.loads((e/(cid+'.json')).read_text());cmd=json.loads((e/(cid+'.command.json')).read_text()); b=(e/(cid+'.input.json')).read_bytes()
 checks.extend([c['actual_exit']==code,cmd['exit_code']==code,sha(b)==c['manifest_before_sha256']==c['manifest_after_sha256'],cmd['argv']==[str(repo/'packages/cli/dist/bin.js'),'skills','check'],cmd['direct_child_exit_confirmed'],cmd['environment']['GIT_ALLOW_PROTOCOL']=='file',cmd['environment']['OSSTACK_HOME']!=str(Path.home()/'.osstack')])
 checks.extend([sha((e/cmd['stdout_path']).read_bytes())==cmd['stdout_sha256'],sha((e/cmd['stderr_path']).read_bytes())==cmd['stderr_sha256']])
cleanup=json.loads((e/'cleanup.json').read_text());checks.extend([cleanup['status']=='passed',cleanup['fixture_removed'],not Path(cleanup['fixture_path']).exists()])
bindings=json.loads((e/'bindings.json').read_text())
for category in ['source','build']:
 for f in bindings[category]['files']:checks.append(sha((repo/f['path']).read_bytes())==f['sha256'])
results.append({'id':'I04','passed':all(checks),'independent_checks':len(checks),'evidence_retained':e.exists(),'descendants':'not_attested'})
(r/'partial-result.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2),flush=True)
# Controlled full src/dist copy; package node_modules reused read-only for dependency resolution.
copy=r/'controlled-copy';copy.mkdir();(copy/'scripts/lib').mkdir(parents=True)
for p in ['package.json','pnpm-lock.yaml','scripts/smoke-skills-check.mjs','scripts/lib/skills-check-verification.mjs']:
 shutil.copy2(repo/p,copy/p)
(copy/'packages').mkdir()
for pkg in (repo/'packages').iterdir():
 if not pkg.is_dir():continue
 target=copy/'packages'/pkg.name;target.mkdir()
 for name in ['src','dist']:
  if (pkg/name).exists():shutil.copytree(pkg/name,target/name,symlinks=True)
 if (pkg/'package.json').exists():shutil.copy2(pkg/'package.json',target/'package.json')
 if (pkg/'node_modules').exists():(target/'node_modules').symlink_to(pkg/'node_modules',target_is_directory=True)
if (repo/'node_modules').exists():(copy/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
run('copy-git-init',['git','init'],copy);run('copy-git-commit',['git','-c','user.name=Independent Fixture','-c','user.email=fixture@example.invalid','-c','commit.gpgsign=false','commit','--allow-empty','-m','controlled copy'],copy)
cli=copy/'packages/cli/dist/bin.js'; original=cli.read_bytes();cli.unlink()
p=run('missing-build',[node,str(copy/'scripts/smoke-skills-check.mjs'),'--evidence-dir',str(r/'missing-build-evidence')],copy)
results.append({'id':'I07','passed':p.returncode!=0 and not (r/'missing-build-evidence').exists(),'raw_error':p.stderr.decode()[:1200]})
cli.write_bytes((r/'legacy-zero-cli.mjs').read_bytes())
p=run('mutant',[node,str(copy/'scripts/smoke-skills-check.mjs'),'--case','missing-ref','--evidence-dir',str(r/'mutant-evidence')],copy)
mutant=json.loads(p.stdout) if p.stdout.strip() else {}
results.append({'id':'I08','passed':p.returncode!=0 and mutant.get('status')=='failed' and 'exit_mismatch' in mutant.get('cases',[{}])[0].get('errors',[]),'receipt':mutant})
results.append({'id':'candidate_unchanged','passed':initial=={p:sha((repo/p).read_bytes()) for p in initial}})
(r/'result.json').write_text(json.dumps({'candidate':head,'checks':results,'passed':all(x['passed'] for x in results),'scope':'engineering blackbox; no qualification'},indent=2));print((r/'result.json').read_text(),flush=True)
