import { spawnSync } from 'node:child_process';
const p=spawnSync(process.execPath,["/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/skills-check-verification/packages/cli/dist/bin.js",...process.argv.slice(2)],{cwd:process.cwd(),env:process.env,stdio:'inherit'});
if(p.error||p.signal) process.exitCode=99; else process.exitCode=p.status===1?0:p.status;
