import fs from 'node:fs';
import fsp from 'node:fs/promises';
import cp from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
const attempts=[];
for(const [object,names] of [[cp,['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']],[fsp,['mkdir','mkdtemp','writeFile','appendFile','rm','unlink','rename','copyFile','cp','symlink','link','chmod','chown','truncate']],[fs,['mkdir','mkdirSync','mkdtemp','mkdtempSync','writeFile','writeFileSync','appendFile','appendFileSync','rm','rmSync','unlink','unlinkSync','rename','renameSync','copyFile','copyFileSync','symlink','symlinkSync','createWriteStream']]]) {
 for(const name of names){object[name]=(...args)=>{attempts.push(name);throw Error('independent_forbidden_effect:'+name)}}
}
for (const [object,name] of [[fsp,'open'],[fs,'open'],[fs,'openSync']]) {
 const original=object[name]; object[name]=(...args)=>{
  const flags=args[1]??'r';
  const readonly=typeof flags==='number' ? flags===0 : flags==='r';
  if(!readonly){attempts.push(name+':write');throw Error('independent_forbidden_effect:'+name)}
  return original.apply(object,args);
 };
}
syncBuiltinESMExports();
process.on('exit',()=>process.stderr.write('INDEPENDENT_EFFECT_ATTEMPTS='+JSON.stringify(attempts)+'\n'));
