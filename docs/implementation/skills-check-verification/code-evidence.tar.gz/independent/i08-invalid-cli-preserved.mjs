#!/usr/bin/env node
// Deliberately invalid scratch mutant; never install as product.
console.log('Checking 1 source(s) against their tracked refs...\n  x fixture unreachable: no_matching_ref\n0 source(s) drifted from blessed_sha.');
process.exitCode = 0;
