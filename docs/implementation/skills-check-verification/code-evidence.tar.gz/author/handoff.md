# Skills check verification driver — author handoff

Frozen three-file candidate on base64b203c32d245d5ad9a76914253ca18cbb54a073. Only the assigned new driver/helper/test files were authored. Fresh frozen install and build exited0; build may leave the usual four tracked knowledge/dist generated differences for owner exclusion/cleanup after testing. No full repository test, commit, PR, paid model or management write was performed.

## Interface

`node scripts/smoke-skills-check.mjs [--doctor | --dry-run] [--case all|healthy|missing-ref|drift|mixed|empty] [--evidence-dir NEW_DIRECTORY]`

Default run/all. Mode/selector/evidence duplicate options and unknown arguments fail with usage exit2. Preflight unavailable or run failures exit1. Run exit0 requires every selected expected case predicate and actual owned-fixture cleanup to pass. Case actual exits0/1/2/1/0 remain visible and distinct from driver status. Missing-ref input stays missing and its source_check_status stays failed when correctly observed; a false observation is unknown, not the expected source status.

Doctor/dry-run use only filesystem/PATH checks and import no product module; no subprocess or directory creation. Native dependency loading is not qualified by preflight. Run creates one owned local Git file:// repository with two real commits and isolated HOME, OSSTACK_HOME, XDG, template/hooks/global/system Git configuration. The explicitly constructed environment excludes inherited Git/Node/socket/provider injection. Only file protocol is allowed. No skills are installed/executed, sources are never blessed/repaired, and each check home is verified to contain only its unchanged manifest.

## Evidence

Small receipt.json/stdout contains selected_cases, case_id/verification_status/source_check_status/actual_exit/expected_exit/input_unchanged/errors, behavior and cleanup axes, evidence paths and two binding digests. Full source/build byte manifests are separate bindings.json; source scope explicitly includes the new driver/helper. Both source and build are rechecked after execution. This does not prove generated dist was compiled from source or authenticate installed dependencies.

Each case retains exact input JSON, raw stdout/stderr bytes, exact executable/argv/cwd/minimal environment, times, direct-child exit/signal/timeout/output-limit observations, before/after manifest hashes. Expectations are written before case execution; they are fixed same-author engineering expectations, not an independently qualified oracle. Final manifest hashes all retained evidence files. Evidence is allocated exclusively before the separate random fixture and cannot be overwritten.

Owned command timeout is capped10s, stream output1MiB each, direct-child kill grace2s;90s command-sequence deadline is checked between commands. File binding and cleanup operations are explicitly not a hard whole-process wall-clock budget. A timed out/output-limited/interrupted command means descendants are not attested; the fixture remains and overall cleanup fails. Only the spawned child is killed. Normal cleanup claims removed only after rm and a fresh lstat ENOENT observation. Cleanup failure retains successful behavior evidence and returns driver1.

## Checks and limitations

21 node tests passed,0 failed/skipped, including actual compiled CLI all5 cases, separate real missing-ref driver invocation, old-zero-exit rejection, wrong drift-head rejection, readonly preflight witnesses, bounded owned commands, exclusive evidence race, and real workflows with failing/no-op cleanup seams. Node --check succeeded for all3 new files; git diff --check passed. Biome is NOT an applicable pass: repository configuration excludes these .mjs paths and its no-files-processed exit1 is retained. Initial RED was missing new module, transparently recorded; the original skills exit bug's real local Git RED remains in prior independent evidence.

Tests remove their temporary integration evidence after checking retained files/hashes. Owner's next independent black-box/host experiment should retain its own real run bundle and bind it to the committed candidate. Same-author tests cannot certify formal principal/oracle/provider/runtime/closure gates, and this driver covers only the five local skills-check cases. No further code writes after this freeze without root request.
