import pathlib,subprocess,os,json,hashlib,datetime,sys
s=pathlib.Path(__file__).parent;r=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-verification');label=sys.argv[1]
entry=s/'linked-entry.mjs'
if not entry.is_symlink():entry.symlink_to(r/'scripts/smoke-skills-check.mjs')
expected=s/'expectations.json'
if not expected.exists():expected.write_text(json.dumps({'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entry':'real filesystem symlink to driver','expected':['exit0','nonempty JSON receipt with status passed','evidence manifest exists and hashes match','fixture_removed true and fixture path absent'],'case':'empty'},indent=2)+'\n')
e=s/(label+'-evidence');assert not e.exists()
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(s/'parent-home'),'OSSTACK_HOME':str(s/'parent-osstack-home'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack','OSSTACK_UPDATE_CHECK':'0'}
a=['/opt/homebrew/opt/node@22/bin/node',str(entry),'--case','empty','--evidence-dir',str(e)]
b=(r/'scripts/smoke-skills-check.mjs').read_bytes();start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(a,cwd=r,env=env,capture_output=True,timeout=120)
(s/(label+'.stdout')).write_bytes(p.stdout);(s/(label+'.stderr')).write_bytes(p.stderr)
checks={'exit_zero':p.returncode==0,'nonempty_stdout':bool(p.stdout.strip()),'manifest_exists':(e/'manifest.json').is_file()}
if p.stdout.strip():
 try:
  result=json.loads(p.stdout);checks.update(receipt_passed=result['status']=='passed',fixture_removed=result['cleanup']['fixture_removed'],fixture_absent=not pathlib.Path(result['cleanup']['fixture_path']).exists())
  m=json.loads((e/'manifest.json').read_text());checks['hashes_match']=all(hashlib.sha256((e/f['path']).read_bytes()).hexdigest()==f['sha256'] for f in m['files'])
 except Exception as ex:checks['parse_and_verify_error']=str(ex)
record={'argv':a,'cwd':str(r),'environment':env,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.run(['git','rev-parse','HEAD'],cwd=r,env=env,capture_output=True,check=True).stdout.decode().strip(),'driver_sha256':hashlib.sha256(b).hexdigest(),'expectations_sha256':hashlib.sha256(expected.read_bytes()).hexdigest(),'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'checks':checks,'expectation_passed':all(v is True for v in checks.values())}
(s/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
