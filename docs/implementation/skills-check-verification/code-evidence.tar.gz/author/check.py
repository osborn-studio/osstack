import os,sys,subprocess,pathlib,json,hashlib,datetime
s=pathlib.Path(__file__).parent; label=sys.argv[1];env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(s/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack');env.pop('OSSTACK_SOCKET',None)
paths=['scripts/smoke-skills-check.mjs','scripts/lib/skills-check-verification.mjs','scripts/smoke-skills-check.test.mjs'];records=[]
for name,a in [('tests',['node','--test','scripts/smoke-skills-check.test.mjs']),('biome',['pnpm','exec','biome','check',*paths]),('diff-check',['git','diff','--check'])]:
 before={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in paths};start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(a,env=env,capture_output=True,timeout=180)
 (s/(label+'-'+name+'.stdout')).write_bytes(p.stdout);(s/(label+'-'+name+'.stderr')).write_bytes(p.stderr)
 records.append({'argv':a,'cwd':os.getcwd(),'environment_overrides':{k:env[k] for k in ['PATH','OSSTACK_HOME','OSSTACK_SCRATCH_ROOT']},'unset':['OSSTACK_SOCKET'],'source_sha256':before,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(s/(label+'-commands.json')).write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode);print(p.stdout.decode()[-3000:]);print(p.stderr.decode()[-2000:])
