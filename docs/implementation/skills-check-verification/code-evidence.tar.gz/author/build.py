import os,subprocess,pathlib,json,datetime
s=pathlib.Path(__file__).parent;env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(s/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack');env.pop('OSSTACK_SOCKET',None)
records=[]
for name,a in [('install',['pnpm','install','--frozen-lockfile']),('build',['pnpm','build'])]:
 with(s/(name+'.stdout')).open('wb') as o,(s/(name+'.stderr')).open('wb')as e:
  p=subprocess.run(a,env=env,stdout=o,stderr=e)
 records.append({'argv':a,'cwd':os.getcwd(),'exit_code':p.returncode,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat()});(s/'build-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:break
