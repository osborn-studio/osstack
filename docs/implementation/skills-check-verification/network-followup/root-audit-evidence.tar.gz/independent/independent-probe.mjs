import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {createServer} from 'node:http';
import {mkdir,writeFile,readFile,access} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url));
const realExec=cp.execFileSync;
let tarCalls=[];
cp.execFileSync=(...args)=>{tarCalls.push(args.slice(0,2));return realExec(...args);};syncBuiltinESMExports();
const {prepareNodeHeaders}=await import('./candidate.mjs');
const name=`node-v${process.versions.node}`;
const source=join(root,'fixture',name,'include/node');await mkdir(source,{recursive:true});
const [major,minor,patch]=process.versions.node.split('.');
await writeFile(join(source,'node_version.h'),`#define NODE_MAJOR_VERSION ${major}\n#define NODE_MINOR_VERSION ${minor}\n#define NODE_PATCH_VERSION ${patch}\n#define NODE_MODULE_VERSION ${process.versions.modules}\n`);
await writeFile(join(source,'config.gypi'),'{}');
realExec('tar',['-czf',join(root,'fixture.tar.gz'),'-C',join(root,'fixture'),name]);
const archive=await readFile(join(root,'fixture.tar.gz'));const checksum=createHash('sha256').update(archive).digest('hex');
const archiveName=name+'-headers.tar.gz';const observations=[];
for (const scenario of ['sums-abort-then-valid','body-dribble-deadline','checksum-before-tar']) {
 const counts={sums:0,archive:0};const logs=[];tarCalls=[];
 const server=createServer((req,res)=>{
  const kind=req.url.endsWith('SHASUMS256.txt')?'sums':'archive';counts[kind]++;
  if(scenario==='sums-abort-then-valid'&&kind==='sums'&&counts[kind]===1){res.writeHead(200,{'content-length':1000});res.write(checksum.slice(0,3));setTimeout(()=>res.destroy(),8);return;}
  if(scenario==='body-dribble-deadline'&&kind==='archive'){res.writeHead(200);res.write('x');const timer=setInterval(()=>res.write('x'),10);res.on('close',()=>clearInterval(timer));return;}
  res.end(kind==='sums'?`${scenario==='checksum-before-tar'?'0'.repeat(64):checksum}  ${archiveName}\n`:archive);
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const started=performance.now();let result,error;
 try {result=await prepareNodeHeaders({output:join(root,scenario),baseUrl:`http://127.0.0.1:${server.address().port}`,timeoutMs:80,attempts:2,retryDelayMs:0,log:m=>logs.push(m)});}catch(e){error=e.message;}
 const elapsed=performance.now()-started;server.closeAllConnections();await new Promise(r=>server.close(r));
 if(scenario==='sums-abort-then-valid'){assert.equal(result.status,'verified');assert.deepEqual(counts,{sums:2,archive:1});assert.equal(tarCalls.length,2);}
 else {assert.equal(result,undefined);assert.equal(tarCalls.length,0);await assert.rejects(access(join(root,scenario,'receipt.json')));}
 if(scenario==='body-dribble-deadline'){assert.match(error,/deadline/);assert.equal(counts.archive,2);assert.ok(elapsed<1500);}
 if(scenario==='checksum-before-tar'){assert.match(error,/SHA256 mismatch/);assert.equal(counts.archive,1);}
 observations.push({scenario,status:'pass',counts,elapsed_ms:elapsed,result,error,tar_calls:tarCalls,logs});
}
await writeFile(join(root,'probe-result.json'),JSON.stringify({runtime:process.version,abi:process.versions.modules,observations},null,2)+'\n');
console.log(JSON.stringify({status:'pass',scenarios:observations.length}));
