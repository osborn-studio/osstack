# Independent Node headers prerequisite review

Status: PASS within the reviewed source/workflow scope; awaiting author commit binding. No confirmed blocking issue.

Baseline `6df338e8a7d232e6f44f8848e06c99b3f7a9d018`. Reviewed downloader SHA256 `ab505f1c2621924aaa0046ebb7bd44c7e23eb7f1338b5950d28dedec88644f3d`. Files copied into this evidence directory, not changed in the candidate.

## Executed independent probes

`/opt/homebrew/opt/node@22/bin/node independent-probe.mjs` exited 0 on Node22.22.1/ABI127. The script imports an exact scratch copy and instruments the genuine child-process binding to record tar invocations.

1. Truncated SHASUMS response after HTTP200: two sums attempts, then complete valid archive; verified receipt; two tar invocations (listing and extraction).
2. Archive continuously emits bytes every10ms: both80ms attempts still hit whole-body deadlines; elapsed168ms, zero tar calls, no success receipt.
3. Checksum mismatch: one archive attempt, zero tar calls, no success receipt. Bytes retained only in the newly-owned diagnostic directory.

Full inputs/logs/counters and source hashes are in probe-result.json, probe.command.json, independent-probe.mjs and snapshot.json. A later inspection command accidentally ran git diff in scratch, exit129; this did not run tests or modify the candidate. Correct workflow diff is preserved separately.

## Source and workflow review

- Timer spans fetch and full streamed response consumption; aborts/retries discard partial buffers. CLI uses3 attempts per resource,60s each,1s between retries,1MiB sums and32MiB archive limits. The CI step adds an8minute outer bound. Tar listing/extraction each have30s timeout.
- Expected archive SHA is checked before listing or extraction. Exact one SHASUMS entry required. This uses HTTPS official release SHA, not an independent signature verification claim.
- CLI offers no mirror/runtime override. Version derives process.versions.node after setup-node selects the matrix runtime; extracted node_version.h must match exact major/minor/patch and process.versions.modules. Required regular header and config files checked before receipt.
- Workflow retains both20.6.0 and22.23.1 and all existing graph/core/CLI checks. Only adds preparation/tests and passes the exact version-derived --nodedir to rebuild.
- [node-gyp11.5.0 configure.js](https://raw.githubusercontent.com/nodejs/node-gyp/v11.5.0/lib/configure.js), lines50–75, uses supplied nodedir directly; gyp.commands.install is in the alternate branch. This supports avoiding its headers network path. It is not a claim that npm install or all build tools are offline.

## Limits

No full suite, actual20.6/22.23 runtime execution, external TLS fault injection, native SQLite rebuild, PR change or model invocation performed by this reviewer. Official-host availability still depends on CI. Test-only dependency injection is not a new public production configuration surface. No general-purpose archive security/PKI system is proposed. Root retains final release/CI decision.
