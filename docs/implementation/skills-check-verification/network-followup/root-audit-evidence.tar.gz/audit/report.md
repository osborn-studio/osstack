**Verdict: PASS.** I found no concrete blockers. This is a source-only review. I ran nothing and I'm relying on your reported results for the tests and the Node 22.22.1 fetch.

## Requirements check

| Requirement | Result |
|---|---|
| Product gate, ABI and tests preserved | The source build and later steps are unchanged. The only change to the build is `--nodedir` pointing at the same `process.versions.node` that `setup-node` installed. The header version and `NODE_MODULE_VERSION` are checked against `process.versions`. |
| Bounded full-body acquisition | One timer is armed before `request()` and covers connect, TLS, headers and the whole body. `finish` clears it and destroys both `res` and `req`. `maxBytes` is enforced while streaming. `agent:false` means no pooled sockets keep the process alive. |
| Finite retry | There are 3 attempts with a 1s delay. 4xx (except 429), the byte limit and an unsupported protocol are permanent. The delay runs only after a failed attempt that has another attempt left. |
| SHA before extraction | `tar -t` and `tar -x` run only after the digest matches. The SHASUMS file must contain exactly one entry for the archive. Any failure throws, so later steps are skipped. There is no `node-gyp` download fallback because `--nodedir` is always supplied. |
| Bounded child failures | Both `execFileSync('tar')` calls have a 30s timeout and a 4MB `maxBuffer`. The CLI sets `exitCode` instead of calling `process.exit`. The real-child test fails if the parent timeout kills the child. |
| Original failure mode | A hang or a TLS body abort in an attempt becomes a 60s deadline or an `aborted` error, then a fresh retry. |
| Scope | The CI change is limited to the test step, the prepare step and `--nodedir`. The CLI exposes no mirror override. `baseUrl`, the timeouts and the limits are reachable only through the function's parameters. |

## Non-blocking findings

1. **Step budget is thin.** The worst case is 2×(3×60s + 2×1s) + 2×30s tar ≈ 424s, about 7m04s, against `timeout-minutes: 8`. That leaves roughly 56s. I'd raise it to 10, or cut the tar timeouts to 15s.
2. **Link entries are not checked.** The member check uses `tar -tzf`, which doesn't show link types, so a symlink or hardlink member would pass. The checksum on the official archive mitigates this. As hardening, use `-tvzf` and reject entries that start with `l` or `h`.
3. **Unverified bytes are written first.** `archiveName` is written to disk before the digest comparison, so a mismatch leaves an unverified file under the official name in the retained directory. Nothing consumes it. Writing after the check, or using an `.unverified` suffix, would be cleaner.
4. **Trust anchor.** `SHASUMS256.txt` comes over TLS from the same origin as the archive and its GPG signature is not checked. The SHA therefore protects against truncation and corruption, not a compromised origin. That is the same trust `node-gyp` has today. It is acceptable, but worth a one-line comment.
5. **Scratch helper.** `scripts/lib/scratch.mjs` duplicates `packages/core/src/scratch.ts`. The test titled "matches canonical root" only checks the helper against itself, so drift is not detected. Keep it only if the repo's scratch policy requires it, and ideally compare it against the TS source. Also confirm that `$RUNNER_TEMP/osstack/runtime` is intended to differ from `tmpdir()/osstack` on hosted runners.
6. **Small test and workflow gaps.**
   - The fixture's `execFileSync('tar', …)` has no timeout.
   - The `node --test` step has no `timeout-minutes`.
   - Confirm the lowest matrix Node supports `t.after` (≥20.1 or 18.17).
7. **Minor robustness.**
   - If `request()` threw synchronously, the armed timer would hold the event loop for up to 60s. This is practically unreachable.
   - Proxy environment variables are ignored, which is fine on GitHub-hosted runners.
   - A SHA mismatch is never retried. That is fail-closed and defensible.

## Remaining risk

Your fetch evidence covers Node 22.22.1 (ABI 127). The failing job is 20.6.0, so real CI is the first check that:
- the 20.6.0 header tarball has the expected `include/node/{node_version.h,config.gypi}` layout and defines;
- `node-gyp@11.5.0` accepts the extracted directory as `--nodedir`.

I expect both to hold. Treat that CI run as the gate, as you already planned.