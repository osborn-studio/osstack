import json,os,subprocess,datetime,hashlib,sys
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-verification')
expected='4f6c3c8fd21778798bdf22c12c0f4adfda28807a'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==expected
script=repo/'scripts/smoke-skills-check.mjs'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='306bf661a3f6057027b11242182c0a58d149660ba17677dc013f26f5477d592f'
# Explicit host labels and paths are root-controlled; no model commands are executed.
if len(sys.argv)!=3 or sys.argv[1] not in ['codex','claude']:raise SystemExit('host and validated selection path required')
host=sys.argv[1];selection=Path(sys.argv[2])
subprocess.run([sys.executable,str(root/'validate-selection.py'),str(selection)],check=True)
base=root/'runs'/host;base.mkdir(parents=True,exist_ok=False)
env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack',OSSTACK_HOME=str(base/'parent-home'));env.pop('OSSTACK_SOCKET',None)
rows=[]
for case in ['healthy','missing-ref']:
 evidence=base/(case+'-evidence')
 argv=['/opt/homebrew/opt/node@22/bin/node',str(script),'--case',case,'--evidence-dir',str(evidence)]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (base/(case+'.stdout')).open('w') as out,(base/(case+'.stderr')).open('w') as err:
  try: code=subprocess.run(argv,cwd=repo,env=env,stdout=out,stderr=err,timeout=120).returncode
  except subprocess.TimeoutExpired:code=124
 row={'case_id':case,'argv':argv,'cwd':str(repo),'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driver_exit':code,'evidence':str(evidence),'candidate':expected,'outer_timeout':code==124}
 if code==124:row['cleanup']='unknown; no cleanup assertion after outer timeout'
 if (evidence/'receipt.json').exists():row['receipt']=json.loads((evidence/'receipt.json').read_text())
 if (evidence/'manifest.json').exists():
  manifest=json.loads((evidence/'manifest.json').read_text());row['evidence_hashes_match']=all(hashlib.sha256((evidence/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['files'])
 if 'receipt' in row:
  fixture=row['receipt']['cleanup']['fixture_path'];row['fixture_absent']=bool(fixture) and not Path(fixture).exists()
 row['root_verified']=(code==0 and row.get('receipt',{}).get('status')=='passed' and row.get('evidence_hashes_match') is True and row.get('fixture_absent') is True and row.get('receipt',{}).get('selected_cases')==[case])
 rows.append(row);(base/'results.json').write_text(json.dumps(rows,indent=2))
 if not row['root_verified']:break
print(json.dumps(rows,indent=2))
