# Minimal host-assisted skills-check validation

Version 3. Original v1 and the original v2 validator, prompts, raw model responses and rejection are preserved under `v1/` and `v2/`. Status: semantic criteria frozen; **waiting for the driver to freeze**. No model call or product case has run for this experiment. Base is `64b203c32d245d5ad9a76914253ca18cbb54a073`, card `card_25794a87`.

## Why this is worth one small run

It can show that Codex and Claude can consume the same method, state observable expectations, and correctly interpret an actual root-controlled verification result. The prior read-only consult established document consumption only; this adds a real execution round trip. It cannot establish autonomous tool use, automatic method selection or improved defect detection. Both hosts see the correct expectations, so reproducing those expectations is deliberately not a reasoning benchmark. A larger agent framework, blind A/B study or extra case matrix would cost more without answering this bounded question.

## Frozen input and stages

Both actual CLI hosts receive byte-identical embedded `shared-input/` materials, including the pinned SKILL, evidence rules, create-verification reference and fixed plan. Preserve `shared-input-manifest.json`. Host labels and run directories are assigned by root outside the model-controlled payload. Do not give one host the other host's answer. Use fresh ephemeral Codex exec calls and fresh no-session-persistence Claude calls. The current root conversation is not a participant. This is still not a blinded comparison: both receive the correct expectations.

1. Root waits for a frozen driver commit, verifies build/source bindings, and appends `driver-binding.json` with actual CLI interface, driver SHA256, code SHA, build identity, method hashes and environment. The semantic criteria cannot change after seeing results. If interface adaptation changes semantics, freeze a new version before dispatch.
2. Each host consumes the same input and receives `phase-1-prompt.txt`. Record the exact stdin prompt bytes and hashes; embed all required files rather than relying on optional file reads. Each proposes the two allowed case IDs with expected product exits and predicates. No result is supplied yet.
3. Root saves the raw response and runs `validate-selection.py PLAN_JSON`. It rejects unknown/duplicate IDs, changed exit values, extra fields including command/argv/path, malformed JSON and excessive output. Text fields are explanatory only and never executed. A valid syntax result is not an authorization or proof that the explanation is correct; root checks it against HU02.
4. Root runs only the fixed driver mapping below, once per host/case. Four product executions total, serialized. Each receives a fresh local Git fixture and exclusive evidence directory. Both hosts use the same frozen build and recipe; generated IDs/paths/timestamps can differ and are recorded. Doctor may be run once per unchanged build/environment, but its result is only preflight.
5. Root reads receipts and raw logs, checks expected behavior, child exit, input hash preservation, owned fixture removal and retained evidence hashes. Model text cannot override these checks. It makes a small, provenance-bound receipt packet for each host.
6. The same host gets its own packet plus `phase-2-prompt.txt`. Record the raw response. Root assesses whether the response distinguishes product negative exit, behavioral result, harness, cleanup and incomplete coverage. Preserve any mistaken interpretation instead of rewriting it as success.

## Fixed runner mapping

Author's current draft interface (not yet frozen):

```text
node scripts/smoke-skills-check.mjs --doctor
node scripts/smoke-skills-check.mjs --case healthy --evidence-dir ROOT_CHOSEN_NEW_DIRECTORY
node scripts/smoke-skills-check.mjs --case missing-ref --evidence-dir ROOT_CHOSEN_NEW_DIRECTORY
```

Root resolves Node and script to its pinned absolute paths and uses argv without a shell. Root generates each evidence path under this experiment, e.g. `runs/codex/healthy-UUID` and `runs/claude/missing-ref-UUID`; model paths are not accepted. Reject `--case all`, unknown flags and every model-proposed command. The default all-case behavior must never be invoked accidentally.

The driver is expected to return **0** only when the selected predicate and cleanup pass, **1** on failed run closeout and **2** on usage error. This is different from the embedded product command: healthy expects product **0**, missing-ref expects product **1**. Preserve both values explicitly.

| Case | Observable product predicate | Required closeout |
| --- | --- | --- |
| healthy | exit 0; up-to-date; failed=0; drift=0 | inputs unchanged; child exit confirmed; fixture removed; evidence readable with matching hashes |
| missing-ref | exit 1; `no_matching_ref`; failed=1; drift=0 | same closeout; expected negative product result is a passed verification |

Draft receipt fields are `case_id`, `verification_status`, `source_check_status`, `actual_exit`, `expected_exit`, `input_unchanged`, and evidence/manifest/binding paths. Root maps the frozen real schema to a separate interpretation; it does not edit the driver's original receipt. If cleanup or ownership is missing, the corresponding axis is unknown and the run is not clean.

## Model/tool boundary

**Codex:** perform two actual `codex exec` CLI invocations, one planning and one receipt interpretation. Use `--ignore-user-config --ephemeral --sandbox read-only --skip-git-repo-check --json`, with prompt input through stdin and a root-selected scratch cwd. Do not count root/current-session reasoning as either invocation. Capture actual binary path, `codex --version`, raw JSONL/stdout/stderr, command argv, timestamps, exit status, final answer and any exposed model field. If the runtime does not expose the actual model ID, record `unavailable`; never substitute the desktop model, a guessed default or the CLI version. No fresh subagent is needed.

Request no tool calls because the complete small material/receipt packet is embedded. The read-only sandbox is defense in depth; it is not proof that zero subprocesses were invoked. Inspect actual JSONL events. A model tool call is recorded as a deviation from the zero-tool plan. Any attempted product/test execution is a boundary failure, not another authorized product case. Do not reuse model-generated commands. If the installed CLI rejects the specified flags, retain that actual failed invocation and report blocked rather than silently dropping isolation flags.

**Claude:** perform two actual calls requesting `claude-sonnet-5-5`, with `--tools ''`, slash commands disabled, safe mode, strict empty MCP config and no session persistence. Pass the same phase prompt/material bytes through stdin. Preserve actual CLI version, initialization metadata, result `modelUsage`, raw stream/JSON/stderr and exit. No Bash/Edit/Write/MCP tools are granted. Tool-less interpretation is sufficient for this bounded method-use task because the supplied method bytes are the same ones consumed by Codex.

Phase 1 stdin is identical across hosts. Phase 2 uses the identical instruction and method/plan prefix plus each host's own receipt packet and its prior raw selection. The different run IDs/paths are intentional and recorded; do not claim the entire phase2 prompt hashes must match. Archive both exact prompts and their common-prefix hash.

Only root drives the product. Report **host-assisted**, not native autonomous execution.

## Budget and retry boundary

- Four model calls maximum: two actual Codex exec and two actual Claude CLI calls. Each call is bounded to 180 seconds; Claude also has a 6-turn cap; planner response at most 5000 bytes, final explanation at most 500 words. Retain full raw output even if the small summary exceeds its budget, and classify over-budget output explicitly.
- Shared material is four small files; receipt packet target <=8 KiB with raw paths/hashes. Large source/build manifests and original logs remain external and recoverable; do not truncate away required failure or cleanup facts to meet the summary budget. If a required fact cannot fit, use an explicit bounded additional read and account for it.
- Four fixed product runs maximum. Driver draft budget 90 seconds total, each command 10 seconds plus 2 seconds for confirmed child exit. Root outer budget 120 seconds per run, so it exceeds the driver budget and cleanup tail. If the outer bound fires, root uses only its owned process handle and records unknown cleanup until verified.
- No automatic retry, no new whole-repository regression, no network Git sources, no provider workload, no repeated model judging loop. Existing install/build are prerequisites owned by root.
- Record actual token/cost values when returned. Do not promise a dollar cost from a token guess. Maximum dispatch count is fixed; a timeout or usage failure ends that cell without switching models silently.

The maximum serial wall-clock allowance is roughly 8 minutes for four outer-bounded product runs plus 12 minutes for four model calls, excluding the already-required build and minimal bookkeeping. Normal local file-fixture runs should be shorter, but that is a prediction to be measured.

## Evidence and reporting

Retain input hashes; frozen criteria and timestamp; candidate/build and clean/dirty state; raw host selections; validator outputs; exact command/cwd/environment/times/exits; original receipts/raw stdout/stderr; owned resource identifiers; cleanup and evidence survival checks; raw model response/modelUsage; and each small summary's raw pointer and hash. Runtime metadata unavailable from a host is a visible gap.

Use separate fields for execution, behavior, harness, cleanup and coverage. No invented principal, runtime activation, formal gate, host-quality ranking or causal-effect language. State `healthy + missing-ref only`; drift/mixed/empty/network/timeout remain uncovered by this experiment. A failed host interpretation is useful evidence about the method instructions, not a reason to hide a product pass or to rerun until the wording is green.

## v3 posthoc harness repair (no model retry)

Both v2 phase1 CLI calls exited0 without tools. Claude returned correct case IDs and expectations but seven limitations; the validator rejected them against an undisclosed five-item cap. Root authorized one narrow repair: limitations count1–10 instead of1–5; each-item400-character cap, full5000-byte cap, case IDs/exits, predicate lengths and allowed fields stay unchanged. The prompt now publicly states all format limits.

Original responses are revalidated without changing a byte. This can establish selection validity under repaired v3, not retroactive v2 PASS or a new model success. The v2 phase1 runner is retired and remains preserved; it is not rerun. Any phase2 report must distinguish original planning candidate a0be527a from the actual repaired driver candidate supplied later by root. No product execution is authorized by the validator alone.
