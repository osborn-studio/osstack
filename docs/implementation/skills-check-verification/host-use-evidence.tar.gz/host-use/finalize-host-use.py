from pathlib import Path
import json,hashlib,datetime,tarfile
ROOT=Path(__file__).resolve().parent
D=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):
 with p.open('x') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
calls=[]
for host in ['codex','claude']:
 for phase in [1,2]:
  p=ROOT/'model-runs'/host/f'phase{phase}';m=json.loads((p/'invocation.json').read_text());e=json.loads((p/'parsed-events.json').read_text());r=e['final_result']
  assert m['exit_code']==0 and m['tool_calls']==0 and not m['timed_out']
  calls.append({'host':host,'phase':phase,'invocation_ref':str((p/'invocation.json').relative_to(ROOT)),'invocation_sha256':D(p/'invocation.json'),'response_ref':str((p/'final-response.txt').relative_to(ROOT)),'response_sha256':D(p/'final-response.txt'),'raw_stream_ref':str((p/'response.jsonl').relative_to(ROOT)),'raw_stream_sha256':D(p/'response.jsonl'),'version':(p/'version.stdout').read_text().strip(),'actual_models':m['actual_models'],'model_process_exit':m['exit_code'],'tool_calls':m['tool_calls'],'started_at':m['started_at'],'ended_at':m['ended_at'],'historical_harness_status':m['status'],'usage':r.get('usage'),'modelUsage':r.get('modelUsage'),'phase2_word_count':len((p/'final-response.txt').read_text().split()) if phase==2 else None,'phase2_500_word_budget_met':len((p/'final-response.txt').read_text().split())<=500 if phase==2 else None})
assert len(calls)==4
revalidation=json.loads((ROOT/'v3-posthoc-revalidation.json').read_text())
for x in revalidation['results']:
 assert D(ROOT/'model-runs'/x['host']/'phase1/final-response.txt')==x['original_response_sha256']
criteria=[
 {'id':'HU01','status':'met_with_versioned_binding','evidence':['phase1.input.txt','phase2-prepared.json','shared-input-manifest.json'],'note':'Both hosts received identical method bytes and common plan within each phase. Phase1 original v2 prompt remains; phase2 v3 plan discloses format repair. No assertion they read files using tools: embedding is the exposure surface.'},
 {'id':'HU02','status':'met_after_disclosed_posthoc_harness_repair','evidence':['v2/','v3-posthoc-revalidation.json'],'note':'Both selected healthy/missing-ref, expected0/1, with predicates before root execution. Claude originally rejected by undisclosed limitations cap5; same7-limit response accepted by v3 cap10. Original v2 rejection retained. No new model call or response edit.'},
 {'id':'HU03','status':'met','evidence':['root-run-cases.py','runs/codex/results.json','runs/claude/results.json'],'note':'Root runner uses hardcoded two-case allowlist and fixed argv after schema validation. No model text executed. Four distinct root-owned runs/evidence directories.'},
 {'id':'HU04','status':'bounded_behavior_and_direct_cleanup_met_process_tree_unknown','evidence':['phase2-reader-checks.json','root-receipt-gate.json'],'note':'All four product predicates actual0/1, driver0, before/after input hash equal, direct child exit and fixture removal observed in records; each29 manifest file hashes/sizes rechecked. Broader no-dangling-process expectation not established because descendant_termination=not_attested. Do not label all cleanup/gates passed.'},
 {'id':'HU05','status':'semantic_interpretation_met_format_partial','evidence':['model-runs/codex/phase2/final-response.txt','model-runs/claude/phase2/final-response.txt'],'note':'Both name exact host run IDs and raw pointers, interpret expected missing-ref failure, separate axes and withhold unconditional closeout for descendants. Codex341 words meets500; Claude527 words exceeds500. Keep full raw; no retry/truncation/reclassification.'},
 {'id':'HU06','status':'recorded_with_explicit_unavailable_metadata','evidence':['model-runs/','driver-binding.json','phase2-execution-binding.json','runs/'],'note':'Actual CLI versions, stdin/raw streams, commands/time/exits/modelUsage recorded. Codex actual model absent in events is unavailable. Claude actual claude-sonnet-5-5. Historical a0be planning vs4f6 executed working bytes explicitly distinct. Build hashes are execution-time evidence, not reproducible source-to-build/dependency attestation; root later restored generated dist.'},
 {'id':'HU07','status':'met','evidence':['model-runs/codex/phase2/final-response.txt','model-runs/claude/phase2/final-response.txt'],'note':'Both remain host-assisted and two-case bounded; no provider qualification, native autonomy, installation/trigger, independent principal, formal gate, ranking or causal benefit established.'}]
assessment={'assessed_at':now,'evaluator':'terminal_preflight subagent, read-only evidence inspection; not authenticated independent principal','classification':'bounded_host_assisted_observation_with_disclosed_harness_repair_and_remaining_limits','all_host_acceptance_passed':False,'model_calls_total':4,'model_retries':0,'product_runs_by_root':4,'product_runs_by_evaluator':0,'phase2_packet_bytes':{'codex':5543,'claude':5547},'phase2_common_prefix_sha256':json.loads((ROOT/'phase2-prepared.json').read_text())['common_prefix_sha256'],'criteria':criteria,'calls':calls,'confirmed_limits':['Claude phase2 527 whitespace-delimited words exceeds500; output retained unmodified.','Full descendant process termination unproven; direct owned-child exit and fixture removal recorded separately.','v2 original Claude schema rejection persists; v3 was a posthoc harness repair, not pristine prospective pass.','Model responses planned a0be; root executed only revised4f6; response not replayed under new planning SHA.','Four deterministic local file:// fixtures do not establish provider/network/installation/gate qualification or causal improvement.','Rehash is later byte verification, not independent process observation; manifests have root/evaluator SHA anchors but no external timestamp or principal attestation.','No live build reread after root restored four tracked knowledge/dist files; execution-time bindings retained.']}
write(ROOT/'independent-assessment.json',assessment)
report='''# Host-assisted verification result

Both actual CLI hosts selected the fixed healthy/missing-ref cases and interpreted root-executed receipts. All four behavior predicates matched: product exits 0/1, driver exit 0, unchanged inputs, direct child exit confirmed, fixture absent, and 29 retained manifest members per case rehashed correctly. This is bounded behavior evidence, **not all host acceptance passed**.

- Codex CLI 0.160.1: two actual calls, exit 0, no tool calls. Actual model metadata unavailable. Phase2: 341 words (within 500).
- Claude CLI 2.1.291: two actual calls, modelUsage claude-sonnet-5-5, exit 0, no tool calls. Phase2: 527 words (**over 500**, raw preserved, no retry).
- Both responses correctly distinguish expected missing-ref product failure from failed verification and refuse an unconditional clean closeout because descendant termination is not attested. Direct child exit/fixture removal are confirmed within the driver scope; no complete process-tree proof is claimed.
- Phase1 planned a0be527a. All four product cases executed corrected4f6c3c8f (R1 entry-path, R2 fixture ownership, R3 error reason). The original planning responses remain unchanged. Source/build digests reflect execution-time bytes; root later restored generated dist. No current-build or source-to-dist reproducibility claim.
- Claude's original v2 rejection remains: it returned7 limitations against an undisclosed cap5. Root authorized v3 cap10 posthoc validation of the same bytes. No model retry, response rewrite or pristine v2 pass.

Raw model output and exact usage: model-runs/{codex,claude}/phase{1,2}/response.jsonl, final-response.txt, invocation.json. Full host-specific final statements remain unedited; this report is evaluator synthesis. Detailed HU01–HU07 assessment and calls: independent-assessment.json. Actual runs: runs/{codex,claude}/results.json and their evidence; the reader verified the original stdout receipt and all manifest hashes, rather than executing more product cases. Phase2 packets are 5543/5547 bytes. Their common prefix and complete stdin hashes are in phase2-prepared.json.

No native autonomous execution, automatic method routing/installation, live provider, authenticated independent principal, formal gate, host ranking or causal benefit is demonstrated. Do not promote the scoped behavior observations into those conclusions.
'''
with (ROOT/'handoff.md').open('x') as f:f.write(report)
# Archive only this bounded experiment; not sibling author/audit/full-regression trees.
excluded={'delivery-manifest.json','host-use-evidence.tar.gz','delivery-check.json'}
files=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts:
  files.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':D(p)})
manifest={'created_at':now,'scope':'Only host-use experiment including original v1/v2/phase1 history and four run evidence sets. No sibling full-suite, product tree, dependencies or binaries.','exclusions':['delivery-manifest.json itself','host-use-evidence.tar.gz','delivery-check.json','__pycache__'],'files':files}
write(ROOT/'delivery-manifest.json',manifest)
archive=ROOT/'host-use-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for f in files:tar.add(ROOT/f['path'],arcname='host-use/'+f['path'],recursive=False)
 tar.add(ROOT/'delivery-manifest.json',arcname='host-use/delivery-manifest.json',recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for f in files:
  raw=tar.extractfile('host-use/'+f['path']).read();assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
 assert tar.extractfile('host-use/delivery-manifest.json').read()==(ROOT/'delivery-manifest.json').read_bytes()
check={'recorded_at':now,'archive':archive.name,'archive_sha256':D(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':D(ROOT/'delivery-manifest.json'),'members_verified':len(files),'archive_manifest_verified':True,'report_sha256':D(ROOT/'handoff.md'),'assessment_sha256':D(ROOT/'independent-assessment.json')}
write(ROOT/'delivery-check.json',check);print(json.dumps(check,indent=2))
