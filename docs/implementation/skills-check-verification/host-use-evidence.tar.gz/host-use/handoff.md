# Host-assisted verification result

Both actual CLI hosts selected the fixed healthy/missing-ref cases and interpreted root-executed receipts. All four behavior predicates matched: product exits 0/1, driver exit 0, unchanged inputs, direct child exit confirmed, fixture absent, and 29 retained manifest members per case rehashed correctly. This is bounded behavior evidence, **not all host acceptance passed**.

- Codex CLI 0.160.1: two actual calls, exit 0, no tool calls. Actual model metadata unavailable. Phase2: 341 words (within 500).
- Claude CLI 2.1.291: two actual calls, modelUsage claude-sonnet-5-5, exit 0, no tool calls. Phase2: 527 words (**over 500**, raw preserved, no retry).
- Both responses correctly distinguish expected missing-ref product failure from failed verification and refuse an unconditional clean closeout because descendant termination is not attested. Direct child exit/fixture removal are confirmed within the driver scope; no complete process-tree proof is claimed.
- Phase1 planned a0be527a. All four product cases executed corrected4f6c3c8f (R1 entry-path, R2 fixture ownership, R3 error reason). The original planning responses remain unchanged. Source/build digests reflect execution-time bytes; root later restored generated dist. No current-build or source-to-dist reproducibility claim.
- Claude's original v2 rejection remains: it returned7 limitations against an undisclosed cap5. Root authorized v3 cap10 posthoc validation of the same bytes. No model retry, response rewrite or pristine v2 pass.

Raw model output and exact usage: model-runs/{codex,claude}/phase{1,2}/response.jsonl, final-response.txt, invocation.json. Full host-specific final statements remain unedited; this report is evaluator synthesis. Detailed HU01–HU07 assessment and calls: independent-assessment.json. Actual runs: runs/{codex,claude}/results.json and their evidence; the reader verified the original stdout receipt and all manifest hashes, rather than executing more product cases. Phase2 packets are 5543/5547 bytes. Their common prefix and complete stdin hashes are in phase2-prepared.json.

No native autonomous execution, automatic method routing/installation, live provider, authenticated independent principal, formal gate, host ranking or causal benefit is demonstrated. Do not promote the scoped behavior observations into those conclusions.
