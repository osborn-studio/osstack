#!/usr/bin/env python3
"""One exclusive final model invocation per host. No product-command execution."""
from pathlib import Path
import argparse,json,os,runpy,signal,subprocess,sys
ROOT=Path(__file__).resolve().parent
shared=runpy.run_path(str(ROOT/'phase1-runner.py'),run_name='phase1_helpers_only')
now,digest,command,parse_response=[shared[x] for x in ['now','digest','command','parse_response']]
PATH=shared['PATH'];BINARIES=shared['BINARIES']
def run(host):
 prepared=json.loads((ROOT/'phase2-prepared.json').read_text());entry=prepared['inputs'][host];inp=ROOT/entry['path']
 assert digest(inp.read_bytes())==entry['sha256']
 assert digest((ROOT/entry['packet']).read_bytes())==entry['packet_sha256'] and entry['packet_bytes']<=8192
 assert digest((ROOT/'model-runs'/host/'phase1/final-response.txt').read_bytes())==entry['phase1_original_sha256']
 run_dir=ROOT/'model-runs'/host/'phase2';run_dir.mkdir(parents=True,exist_ok=False)
 (run_dir/'stdin.txt').write_bytes(inp.read_bytes());(run_dir/'empty-mcp.json').write_text('{"mcpServers":{}}\n');(run_dir/'settings.json').write_text('{}\n')
 env=os.environ.copy();env['PATH']=PATH
 for k in list(env):
  if k.startswith('OSSTACK_'):del env[k]
 env.update(OSSTACK_HOME=str(run_dir/'unused-home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
 argv=command(host,run_dir);meta={'host':host,'phase':2,'started_at':now(),'argv':argv,'cwd':str(run_dir),'stdin_sha256':entry['sha256'],'common_prefix_sha256':prepared['common_prefix_sha256'],'packet_sha256':entry['packet_sha256'],'phase1_original_sha256':entry['phase1_original_sha256'],'PATH':PATH,'OSSTACK_HOME':env['OSSTACK_HOME'],'timeout_seconds':180,'retry':False,'model_requested':'claude-sonnet-5-5' if host=='claude' else 'CLI configured/default; no explicit model override','model_call_started':False}
 def save():(run_dir/'invocation.json').write_text(json.dumps(meta,indent=2)+'\n')
 save()
 try:
  with (run_dir/'version.stdout').open('wb') as out,(run_dir/'version.stderr').open('wb') as err:
   version=subprocess.run([BINARIES[host],'--version'],env=env,cwd=run_dir,stdout=out,stderr=err,timeout=10)
  meta['version_exit_code']=version.returncode
  if version.returncode:raise ValueError('CLI version probe failed; no model invocation')
  meta.update(binary_resolved_path=str(Path(BINARIES[host]).resolve()),binary_sha256=digest(Path(BINARIES[host]).read_bytes()),model_call_started=True);save()
  with inp.open('rb') as stdin,(run_dir/'response.jsonl').open('wb') as out,(run_dir/'stderr.txt').open('wb') as err:
   process=subprocess.Popen(argv,cwd=run_dir,env=env,stdin=stdin,stdout=out,stderr=err,start_new_session=True);meta['owned_pid']=process.pid;save()
   try:meta['exit_code']=process.wait(timeout=180);meta['timed_out']=False
   except subprocess.TimeoutExpired:
    meta['timed_out']=True;os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
    meta['exit_code']=process.returncode
  meta['process_exit_confirmed']=process.returncode is not None
  parsed=parse_response(host,(run_dir/'response.jsonl').read_text());(run_dir/'parsed-events.json').write_text(json.dumps(parsed,indent=2)+'\n')
  final=parsed['final_response'] or '';(run_dir/'final-response.txt').write_text(final)
  meta.update(actual_models=parsed['actual_models'],tool_calls=len(parsed['tool_items']),stream_parse_errors=parsed['malformed_lines'],response_words=len(final.split()),response_bytes=len(final.encode()))
  result=parsed['final_result'] or {};meta['usage']=result.get('usage');meta['modelUsage']=result.get('modelUsage')
  if meta['timed_out'] or meta['exit_code']!=0 or parsed['malformed_lines'] or parsed['tool_items'] or parsed['final_result'] is None:raise ValueError('invocation failed, boundary deviation, or incomplete stream')
  if host=='claude' and (result.get('is_error') or 'claude-sonnet-5-5' not in parsed['actual_models']):raise ValueError('Claude error or requested model not observed')
  if not final:raise ValueError('empty final response')
  meta['response_budget_met']=meta['response_words']<=500
  meta['status']='response_recorded_pending_independent_assessment'
 except Exception as error:meta.update(status='blocked_no_retry',error=str(error))
 finally:
  meta['ended_at']=now();meta['input_unchanged']=digest(inp.read_bytes())==entry['sha256'];meta['raw_hashes']={p.name:digest(p.read_bytes()) for p in run_dir.iterdir() if p.is_file() and p.name!='invocation.json'};save()
 return meta
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('host',choices=['codex','claude']);args=parser.parse_args()
 result=run(args.host);print(json.dumps(result,indent=2));sys.exit(1 if result['status']=='blocked_no_retry' else 0)
