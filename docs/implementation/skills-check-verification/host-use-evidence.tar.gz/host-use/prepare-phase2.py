from pathlib import Path
import hashlib,json,datetime
ROOT=Path(__file__).resolve().parent
D=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
sha='4f6c3c8fd21778798bdf22c12c0f4adfda28807a'
packdir=ROOT/'phase2-receipt-packets';packdir.mkdir(exist_ok=False)
checks=[]
for host in ['codex','claude']:
 rows=json.loads((ROOT/'runs'/host/'results.json').read_text());assert [r['case_id'] for r in rows]==['healthy','missing-ref']
 packet={'host':host,'candidate_sha':sha,'results_ref':f'runs/{host}/results.json','results_sha256':D(ROOT/'runs'/host/'results.json'),'reader_checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verification_scope':'Read-only rehash of root execution evidence; reader did not execute product commands or observe original process independently.','cases':[]}
 for row in rows:
  case=row['case_id'];p=Path(row['evidence']);assert p==ROOT/'runs'/host/(case+'-evidence')
  m=json.loads((p/'manifest.json').read_text());r=json.loads((p/'receipt.json').read_text());c=json.loads((p/(case+'.command.json')).read_text());case_result=json.loads((p/(case+'.json')).read_text());run=json.loads((p/'run.json').read_text());bindings=json.loads((p/'bindings.json').read_text())
  for x in m['files']:
   fp=p/x['path'];assert fp.resolve().is_relative_to(p.resolve());assert fp.stat().st_size==x['bytes'] and D(fp)==x['sha256']
  assert row['candidate']==run['git_head']==sha and row['driver_exit']==r['driver_exit']==0
  assert row['receipt']==r and r['selected_cases']==[case] and r['status']==r['behavior']=='passed'
  assert (p.parent/(case+'.stdout')).read_bytes()==(p/'receipt.json').read_bytes()
  assert not row['outer_timeout'] and not (p.parent/(case+'.stderr')).read_bytes()
  expected=0 if case=='healthy' else 1
  assert c['exit_code']==r['cases'][0]['actual_exit']==expected==r['cases'][0]['expected_exit']
  assert c['direct_child_exit_confirmed'] and c['signal'] is None and c['spawn_error'] is None and not any(c[k] for k in ['timed_out','output_limited','interrupted'])
  assert r['cleanup']['status']=='passed' and r['cleanup']['fixture_removed'] and not Path(r['cleanup']['fixture_path']).exists()
  assert run['bindings_unchanged'] and run['bindings']==run['final_bindings']==r['binding_digests']
  assert case_result['manifest_before_sha256']==case_result['manifest_after_sha256'] and r['cases'][0]['input_unchanged']
  out=(p/(case+'.stdout')).read_text();err=(p/(case+'.stderr')).read_text()
  assert D(p/(case+'.stdout'))==c['stdout_sha256'] and D(p/(case+'.stderr'))==c['stderr_sha256'] and not err
  assert ('up-to-date' in out if expected==0 else 'no_matching_ref' in out)
  assert f'{expected} source(s) failed to check.' in out and '0 source(s) drifted from blessed_sha.' in out
  refs={name:{'sha256':D(p/name)} for name in ['manifest.json','receipt.json',case+'.command.json',case+'.stdout',case+'.stderr',case+'.json','cleanup.json','run.json','bindings.json']}
  item={'case_id':case,'run_id':r['run_id'],'raw_directory':str(p.relative_to(ROOT)),'evidence_refs':refs,'receipt_case':r['cases'][0],'driver_exit':row['driver_exit'],'behavior':r['behavior'],'outer_timeout':row['outer_timeout'],'command':{k:c[k] for k in ['executable','argv','cwd','started_at','ended_at','exit_code','direct_child_exit_confirmed','timed_out','signal']},'raw_stdout':out,'raw_stderr':err,'cleanup':r['cleanup'],'reader_checks':{'manifest_members_rehashed':len(m['files']),'all_hashes_and_sizes_match':True,'driver_stdout_byte_equals_receipt':True,'fixture_absent_now':True,'input_before_after_hash_equal':True,'bindings_unchanged':True},'binding_digests':r['binding_digests'],'provider_qualified':False}
  packet['cases'].append(item);checks.append({'host':host,'case_id':case,'run_id':r['run_id'],'manifest_sha256':D(p/'manifest.json'),'checks':item['reader_checks']})
 packet['bindings_scope']=bindings['scope']
 # Compact encoding keeps each actual receipt packet within the prospectively specified 8 KiB.
 raw=(json.dumps(packet,ensure_ascii=False,separators=(',',':'))+'\n').encode();assert len(raw)<=8192,len(raw)
 with (packdir/(host+'.json')).open('xb') as f:f.write(raw)
write(ROOT/'phase2-reader-checks.json',{'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'execution_count_this_reader':0,'checks':checks})
transition={'planning_candidate':'a0be527aedc7bfba4efe15b3c55ecdd2c10026ec','planning_driver_sha256':'f72befbbd1027c63b5860def7572b3c76009a1b80981f3445fdaa5d077792a3f','execution_candidate':sha,'execution_driver_sha256':'306bf661a3f6057027b11242182c0a58d149660ba17677dc013f26f5477d592f','transition':'Phase1 original model responses planned a0be. Root ran no product case on a0be in this experiment. Root fixed R1 symlink entry guard silent exit0; R2 fixture allocation/ownership/cleanup bounds; R3 AbortError and error reason type. All four actual cases executed on 4f6. Phase1 responses were not revised or reissued for new SHA.','format_history':'Original phase1 prompt omitted the validator limit of5 limitations. Claude emitted7 semantically relevant limitations; model exit0 but v2 validator rejected. Original v2 rejection is preserved. Root authorized v3 posthoc cap5-to10 repair, all other constraints unchanged. Exact original responses revalidated without new model calls. HU semantics unchanged; this is not a pristine prospective v2 pass.','posthoc_revalidation_ref':'v3-posthoc-revalidation.json','posthoc_revalidation_sha256':D(ROOT/'v3-posthoc-revalidation.json'),'root_runner_ref':'root-run-cases.py','root_runner_sha256':D(ROOT/'root-run-cases.py'),'root_receipt_gate_ref':'root-receipt-gate.json','root_receipt_gate_sha256':D(ROOT/'root-receipt-gate.json'),'audit_note':'Actual Sonnet closure report says R1-R3 closed; diff-only review ran no tests. Current packet is root executed observations, not model execution.','budget_scope':'90s driver subprocess-sequence deadline,10s each command,2s direct-child exit grace; filesystem binding/cleanup not hard wall-clock bounded. Root outer subprocess timeout120s; none occurred.','qualification':'Only healthy and missing-ref perhost; no provider qualification, native autonomy, automatic installation/trigger, causal benefit, independent-principal or formal gate claims.'}
write(ROOT/'phase2-execution-binding.json',transition)
m=json.loads((ROOT/'shared-input-manifest.json').read_text());parts=[(ROOT/'phase-2-prompt.txt').read_text()]
for f in m['files']:
 assert D(ROOT/f['path'])==f['sha256'];parts.extend(['\n===== SHARED '+f['path']+' SHA256 '+f['sha256']+' =====\n',(ROOT/f['path']).read_text()])
parts.extend(['\n===== CANDIDATE AND HARNESS TRANSITION =====\n',json.dumps(transition,ensure_ascii=False,indent=2)])
prefix=''.join(parts)
with (ROOT/'phase2-common-prefix.txt').open('x') as f:f.write(prefix)
prepared={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'common_prefix_sha256':hashlib.sha256(prefix.encode()).hexdigest(),'inputs':{}}
for host in ['codex','claude']:
 original=ROOT/'model-runs'/host/'phase1/final-response.txt';packet=packdir/(host+'.json')
 prompt=prefix+'\n===== YOUR UNCHANGED ORIGINAL PHASE1 RESPONSE (HISTORICAL a0be PLANNING) =====\n'+original.read_text()+'\n===== YOUR ROOT-EXECUTED RECEIPT PACKET (4f6) =====\n'+packet.read_text()+'\nAnswer in English, at most 500 words. No tool calls. Interpret supplied evidence; do not claim you inspected files outside this prompt.\n'
 target=ROOT/(f'phase2-{host}.input.txt')
 with target.open('x') as f:f.write(prompt)
 prepared['inputs'][host]={'path':target.name,'sha256':D(target),'bytes':target.stat().st_size,'packet':str(packet.relative_to(ROOT)),'packet_sha256':D(packet),'packet_bytes':packet.stat().st_size,'phase1_original_sha256':D(original)}
write(ROOT/'phase2-prepared.json',prepared);print(json.dumps(prepared,indent=2))
