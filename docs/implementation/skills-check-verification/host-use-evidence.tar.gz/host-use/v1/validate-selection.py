#!/usr/bin/env python3
"""Pure selection validation only. Never runs a model, product command or shell."""
import json,sys
from pathlib import Path
EXPECTED={'healthy':0,'missing-ref':1}
def validate(value):
 if not isinstance(value,dict) or set(value)!={'schema_version','choices','limitations'}:raise ValueError('unexpected top-level fields')
 if type(value['schema_version']) is not int or value['schema_version']!=1:raise ValueError('unsupported schema')
 choices=value['choices']
 if not isinstance(choices,list) or len(choices)!=2:raise ValueError('exactly two choices required')
 seen=set()
 for row in choices:
  if not isinstance(row,dict) or set(row)!={'case_id','expected_exit','predicate'}:raise ValueError('unexpected choice fields')
  name=row['case_id']
  if not isinstance(name,str) or name not in EXPECTED or name in seen:raise ValueError('unknown or duplicate case')
  seen.add(name)
  if type(row['expected_exit']) is not int or row['expected_exit']!=EXPECTED[name]:raise ValueError('changed expected product exit')
  if not isinstance(row['predicate'],str) or not 1<=len(row['predicate'])<=1000:raise ValueError('predicate text invalid')
 limits=value['limitations']
 if not isinstance(limits,list) or not 1<=len(limits)<=5 or any(not isinstance(x,str) or not 1<=len(x)<=400 for x in limits):raise ValueError('limitations invalid')
 return {'selection_valid':True,'case_ids':[x['case_id'] for x in choices],'execution_authorized_by_this_validator':False,'note':'Root must independently enforce frozen predicates and candidate binding. Free text is never executable.'}
if __name__=='__main__':
 try:
  if len(sys.argv)!=2:raise ValueError('usage: validate-selection.py PLAN_JSON')
  raw=Path(sys.argv[1]).read_bytes()
  if len(raw)>5000:raise ValueError('selection exceeds byte limit')
  print(json.dumps(validate(json.loads(raw))))
 except (ValueError,TypeError,OSError) as error:print(json.dumps({'selection_valid':False,'error':str(error)}));sys.exit(1)
