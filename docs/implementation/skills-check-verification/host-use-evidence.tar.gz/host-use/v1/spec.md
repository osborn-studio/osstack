# Minimal host-assisted skills-check validation

Status: semantic criteria frozen; **waiting for the driver to freeze**. No model call or product case has run for this experiment. Base is `64b203c32d245d5ad9a76914253ca18cbb54a073`, card `card_25794a87`.

## Why this is worth one small run

It can show that Codex and Claude can consume the same method, state observable expectations, and correctly interpret an actual root-controlled verification result. The prior read-only consult established document consumption only; this adds a real execution round trip. It cannot establish autonomous tool use, automatic method selection or improved defect detection. Both hosts see the correct expectations, so reproducing those expectations is deliberately not a reasoning benchmark. A larger agent framework, blind A/B study or extra case matrix would cost more without answering this bounded question.

## Frozen input and stages

Both hosts receive byte-identical `shared-input/` files, including the pinned SKILL, evidence rules, create-verification reference and fixed plan. Preserve `shared-input-manifest.json`. Host labels and run directories are assigned by root outside the model-controlled payload. Do not give one host the other host's answer. Existing Codex context contamination is disclosed; this is not a blinded comparison.

1. Root waits for a frozen driver commit, verifies build/source bindings, and appends `driver-binding.json` with actual CLI interface, driver SHA256, code SHA, build identity, method hashes and environment. The semantic criteria cannot change after seeing results. If interface adaptation changes semantics, freeze version 2 before dispatch.
2. Each host consumes the same input and receives `phase-1-prompt.txt`. Record file reads or exact prompt embedding. Each proposes the two allowed case IDs with expected product exits and predicates. No result is supplied yet.
3. Root saves the raw response and runs `validate-selection.py PLAN_JSON`. It rejects unknown/duplicate IDs, changed exit values, extra fields including command/argv/path, malformed JSON and excessive output. Text fields are explanatory only and never executed. A valid syntax result is not an authorization or proof that the explanation is correct; root checks it against HU02.
4. Root runs only the fixed driver mapping below, once per host/case. Four product executions total, serialized. Each receives a fresh local Git fixture and exclusive evidence directory. Both hosts use the same frozen build and recipe; generated IDs/paths/timestamps can differ and are recorded. Doctor may be run once per unchanged build/environment, but its result is only preflight.
5. Root reads receipts and raw logs, checks expected behavior, child exit, input hash preservation, owned fixture removal and retained evidence hashes. Model text cannot override these checks. It makes a small, provenance-bound receipt packet for each host.
6. The same host gets its own packet plus `phase-2-prompt.txt`. Record the raw response. Root assesses whether the response distinguishes product negative exit, behavioral result, harness, cleanup and incomplete coverage. Preserve any mistaken interpretation instead of rewriting it as success.

## Fixed runner mapping

Author's current draft interface (not yet frozen):

```text
node scripts/smoke-skills-check.mjs --doctor
node scripts/smoke-skills-check.mjs --case healthy --evidence-dir ROOT_CHOSEN_NEW_DIRECTORY
node scripts/smoke-skills-check.mjs --case missing-ref --evidence-dir ROOT_CHOSEN_NEW_DIRECTORY
```

Root resolves Node and script to its pinned absolute paths and uses argv without a shell. Root generates each evidence path under this experiment, e.g. `runs/codex/healthy-UUID` and `runs/claude/missing-ref-UUID`; model paths are not accepted. Reject `--case all`, unknown flags and every model-proposed command. The default all-case behavior must never be invoked accidentally.

The driver is expected to return **0** only when the selected predicate and cleanup pass, **1** on failed run closeout and **2** on usage error. This is different from the embedded product command: healthy expects product **0**, missing-ref expects product **1**. Preserve both values explicitly.

| Case | Observable product predicate | Required closeout |
| --- | --- | --- |
| healthy | exit 0; up-to-date; failed=0; drift=0 | inputs unchanged; child exit confirmed; fixture removed; evidence readable with matching hashes |
| missing-ref | exit 1; `no_matching_ref`; failed=1; drift=0 | same closeout; expected negative product result is a passed verification |

Draft receipt fields are `case_id`, `verification_status`, `source_check_status`, `actual_exit`, `expected_exit`, `input_unchanged`, and evidence/manifest/binding paths. Root maps the frozen real schema to a separate interpretation; it does not edit the driver's original receipt. If cleanup or ownership is missing, the corresponding axis is unknown and the run is not clean.

## Model/tool boundary

**Codex:** use the actual authorized Codex host for two turns/phases, retaining its real prompt/output or thread-turn reference and read evidence. This spec does not spawn another agent. Record the actual exposed host/model metadata. If the desktop does not expose an exact model ID or build version, explicitly use `unavailable`; a locally installed `codex --version` is not evidence of the desktop model. Do not fabricate metadata or silently replace the host with a new CLI experiment. If exact Codex identity is a mandatory deliverable, that cell remains blocked until trustworthy runtime metadata is available.

**Claude:** use gstack-claude consult safety rules. Phase 1 may use only Read/Grep/Glob with explicit `--tools Read,Grep,Glob`, allowlist, denied Bash/Edit/Write, slash commands disabled, safe mode, empty strict MCP config, and no session persistence. Phase 2 may be tool-less (`--tools ''`) with the same method/plan and exact receipt packet embedded; this keeps the two phases comparable in materials and avoids filesystem tool overhead. Request `claude-sonnet-5-5`, preserve actual CLI `--version`, init tool list, actual result `modelUsage`, raw stream/JSON/stderr and exit. A configured model name alone is not the observed model. Do not grant Bash, Edit, Write or MCP and do not ask the model to invoke another skill.

Only root drives the product. Report **host-assisted**, not native autonomous execution.

## Budget and retry boundary

- Two Claude calls maximum: plan and receipt interpretation. Each bounded to 180 seconds and 6 turns; planner response at most 5000 bytes, final explanation at most 500 words. Retain full raw output even if the small summary exceeds its budget, and classify over-budget output explicitly.
- Shared material is four small files; receipt packet target <=8 KiB with raw paths/hashes. Large source/build manifests and original logs remain external and recoverable; do not truncate away required failure or cleanup facts to meet the summary budget. If a required fact cannot fit, use an explicit bounded additional read and account for it.
- Four fixed product runs maximum. Driver draft budget 90 seconds total, each command 10 seconds plus 2 seconds for confirmed child exit. Root outer budget 120 seconds per run, so it exceeds the driver budget and cleanup tail. If the outer bound fires, root uses only its owned process handle and records unknown cleanup until verified.
- No automatic retry, no new whole-repository regression, no network Git sources, no provider workload, no repeated model judging loop. Existing install/build are prerequisites owned by root.
- Record actual token/cost values when returned. Do not promise a dollar cost from a token guess. Maximum dispatch count is fixed; a timeout or usage failure ends that cell without switching models silently.

The maximum wall-clock allowance is roughly 8 minutes for four outer-bounded runs plus 6 minutes for two model calls, excluding Codex interaction and already-required build. Normal local file-fixture runs should be shorter, but that is a prediction to be measured.

## Evidence and reporting

Retain input hashes; frozen criteria and timestamp; candidate/build and clean/dirty state; raw host selections; validator outputs; exact command/cwd/environment/times/exits; original receipts/raw stdout/stderr; owned resource identifiers; cleanup and evidence survival checks; raw model response/modelUsage; and each small summary's raw pointer and hash. Runtime metadata unavailable from a host is a visible gap.

Use separate fields for execution, behavior, harness, cleanup and coverage. No invented principal, runtime activation, formal gate, host-quality ranking or causal-effect language. State `healthy + missing-ref only`; drift/mixed/empty/network/timeout remain uncovered by this experiment. A failed host interpretation is useful evidence about the method instructions, not a reason to hide a product pass or to rerun until the wording is green.
