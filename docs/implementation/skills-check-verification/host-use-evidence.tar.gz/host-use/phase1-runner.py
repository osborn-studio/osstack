#!/usr/bin/env python3
"""Explicit dispatch only. Preparation/import never invokes either CLI."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,runpy,signal,subprocess,sys
ROOT=Path(__file__).resolve().parent
PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
BINARIES={'codex':'/opt/homebrew/bin/codex','claude':'/opt/homebrew/bin/claude'}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b):return hashlib.sha256(b).hexdigest()
def unique_object(pairs):
 result={}
 for key,value in pairs:
  if key in result:raise ValueError('duplicate JSON key: '+key)
  result[key]=value
 return result
def strict_json(raw):return json.loads(raw,object_pairs_hook=unique_object,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('non-JSON constant: '+x)))
def verify_shared():
 m=json.loads((ROOT/'shared-input-manifest.json').read_text())
 for f in m['files']:
  p=ROOT/f['path']
  if digest(p.read_bytes())!=f['sha256']:raise ValueError('shared input hash mismatch: '+f['path'])
 if json.loads((ROOT/'frozen-criteria.json').read_text())['version']!=2:raise ValueError('expected frozen v2 criteria')
 return m
def common_prefix():
 m=verify_shared();parts=[(ROOT/'phase-1-prompt.txt').read_text()]
 for f in m['files']:
  parts.extend(['\n===== '+f['path']+' SHA256 '+f['sha256']+' =====\n',(ROOT/f['path']).read_text()])
 return ''.join(parts)
def command(host,run_dir):
 if host=='codex':return [BINARIES[host],'exec','--ignore-user-config','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--color','never','--json','-C',str(run_dir),'-']
 return [BINARIES[host],'-p','--model','claude-sonnet-5-5','--effort','high','--output-format','stream-json','--verbose','--disable-slash-commands','--tools','','--strict-mcp-config','--mcp-config',str(run_dir/'empty-mcp.json'),'--safe-mode','--no-session-persistence','--permission-mode','dontAsk','--setting-sources','','--settings',str(run_dir/'settings.json'),'--max-turns','6']
def parse_response(host,raw):
 events=[];malformed=[]
 for n,line in enumerate(raw.splitlines(),1):
  if not line.strip():continue
  try:events.append(strict_json(line))
  except (ValueError,TypeError) as error:malformed.append({'line':n,'error':str(error)})
 tool_items={};model=[];text=None;final=None
 for event in events:
  if isinstance(event.get('model'),str):model.append(event['model'])
  if isinstance(event.get('message'),dict) and isinstance(event['message'].get('model'),str):model.append(event['message']['model'])
  if host=='codex':
   item=event.get('item',{})
   if event.get('type')=='item.completed' and item.get('type')=='agent_message':text=item.get('text','')
   if item and item.get('type') not in ['agent_message','reasoning']:
    tool_items[item.get('id',str(len(tool_items)))]=item
   if event.get('type')=='turn.completed':final=event
  else:
   for block in event.get('message',{}).get('content',[]) if isinstance(event.get('message',{}).get('content'),list) else []:
    if block.get('type')=='tool_use':tool_items[block['id']]=block
   if event.get('type')=='result':final=event;text=event.get('result','')
 if host=='claude' and final:
  model.extend((final.get('modelUsage') or {}).keys())
 return {'events':events,'malformed_lines':malformed,'tool_items':list(tool_items.values()),'actual_models':sorted(set(model)) or ['unavailable'],'final_response':text,'final_result':final}
def prepare():
 prefix=common_prefix();target=ROOT/'phase1-common-prefix.txt'
 if target.exists() and target.read_text()!=prefix:raise ValueError('refuse to overwrite changed prepared input')
 if not target.exists():target.write_text(prefix)
 readme={'status':'prepared_not_dispatched','common_prefix_sha256':digest(prefix.encode()),'common_prefix_bytes':len(prefix.encode()),'driver_binding_required':'driver-binding.json','required_driver_fields':['state=frozen','candidate_sha (40hex)','driver_sha256 (64hex)','build_digest (64hex)'],'model_calls_made':0,'commands':{h:command(h,ROOT/'model-runs'/h/'phase1') for h in BINARIES},'notes':['Prepared commands are not executed by prepare.','Root must provide frozen binding and authorize actual run; no product commands exist in this runner.','One exclusive directory per host phase; existing attempt cannot be retried/overwritten.']}
 (ROOT/'phase1-prepared.json').write_text(json.dumps(readme,indent=2)+'\n');return readme
def run(host):
 # This guard is checked before version/model CLI subprocesses or attempt creation.
 manifest=verify_shared();binding_path=ROOT/'driver-binding.json'
 binding=strict_json(binding_path.read_text())
 if binding.get('state')!='frozen':raise ValueError('driver not frozen')
 for key,size in [('candidate_sha',40),('driver_sha256',64),('build_digest',64)]:
  if not isinstance(binding.get(key),str) or not re.fullmatch('[0-9a-f]{'+str(size)+'}',binding[key]):raise ValueError('invalid '+key)
 prefix=common_prefix();prompt=prefix+'\n===== ROOT FROZEN DRIVER BINDING =====\n'+json.dumps(binding,sort_keys=True,indent=2)+'\n'
 dispatch=ROOT/'phase1.input.txt'
 if dispatch.exists():
  if dispatch.read_text()!=prompt:raise ValueError('shared dispatch input changed')
 else:
  with dispatch.open('x') as out:out.write(prompt)
 run_dir=ROOT/'model-runs'/host/'phase1';run_dir.mkdir(parents=True,exist_ok=False)
 (run_dir/'stdin.txt').write_text(prompt);(run_dir/'empty-mcp.json').write_text('{"mcpServers":{}}\n');(run_dir/'settings.json').write_text('{}\n')
 env=os.environ.copy();env['PATH']=PATH
 for k in list(env):
  if k.startswith('OSSTACK_'):del env[k]
 env.update(OSSTACK_HOME=str(run_dir/'unused-home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
 argv=command(host,run_dir);metadata={'host':host,'phase':1,'started_at':now(),'argv':argv,'cwd':str(run_dir),'stdin_sha256':digest(prompt.encode()),'common_prefix_sha256':digest(prefix.encode()),'driver_binding_sha256':digest(binding_path.read_bytes()),'frozen_criteria_sha256':digest((ROOT/'frozen-criteria.json').read_bytes()),'shared_manifest_sha256':digest((ROOT/'shared-input-manifest.json').read_bytes()),'PATH':PATH,'OSSTACK_HOME':env['OSSTACK_HOME'],'timeout_seconds':180,'retry':False,'model_requested':'claude-sonnet-5-5' if host=='claude' else 'CLI configured/default; no explicit model override','model_call_started':False}
 def save():(run_dir/'invocation.json').write_text(json.dumps(metadata,indent=2)+'\n')
 save()
 try:
  with (run_dir/'version.stdout').open('wb') as out,(run_dir/'version.stderr').open('wb') as err:
   version=subprocess.run([BINARIES[host],'--version'],env=env,cwd=run_dir,stdout=out,stderr=err,timeout=10)
  metadata['version_exit_code']=version.returncode
  if version.returncode:raise ValueError('CLI version probe failed; no model invocation')
  metadata['binary_resolved_path']=str(Path(BINARIES[host]).resolve());metadata['binary_sha256']=digest(Path(BINARIES[host]).read_bytes())
  metadata['model_call_started']=True;save()
  with dispatch.open('rb') as inp,(run_dir/'response.jsonl').open('wb') as out,(run_dir/'stderr.txt').open('wb') as err:
   process=subprocess.Popen(argv,cwd=run_dir,env=env,stdin=inp,stdout=out,stderr=err,start_new_session=True);metadata['owned_pid']=process.pid;save()
   try:metadata['exit_code']=process.wait(timeout=180);metadata['timed_out']=False
   except subprocess.TimeoutExpired:
    metadata['timed_out']=True;os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
    metadata['exit_code']=process.returncode
  metadata['process_exit_confirmed']=process.returncode is not None
  parsed=parse_response(host,(run_dir/'response.jsonl').read_text());(run_dir/'parsed-events.json').write_text(json.dumps(parsed,indent=2)+'\n')
  metadata.update(actual_models=parsed['actual_models'],tool_calls=len(parsed['tool_items']),stream_parse_errors=parsed['malformed_lines'])
  final=parsed['final_response'];(run_dir/'final-response.txt').write_text(final or '')
  if metadata['timed_out'] or metadata['exit_code']!=0 or parsed['malformed_lines'] or parsed['tool_items'] or parsed['final_result'] is None:raise ValueError('invocation failed, boundary deviation, or incomplete event stream')
  if host=='claude' and (parsed['final_result'].get('is_error') or 'claude-sonnet-5-5' not in parsed['actual_models']):raise ValueError('Claude result error or requested model not observed')
  if final is None or len(final.encode())>5000:raise ValueError('missing or excessive final response')
  selection=strict_json(final);validate=runpy.run_path(str(ROOT/'validate-selection.py'),run_name='selection_validator')['validate'];validation=validate(selection)
  (run_dir/'selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n');(run_dir/'selection-validation.json').write_text(json.dumps(validation,indent=2)+'\n');metadata['status']='selection_valid_waiting_for_root_predicate_review'
 except Exception as error:
  metadata.update(status='blocked_no_retry',error=str(error))
 finally:
  metadata['ended_at']=now();metadata['inputs_unchanged']=all(digest((ROOT/f['path']).read_bytes())==f['sha256'] for f in manifest['files']);metadata['driver_binding_unchanged']=digest(binding_path.read_bytes())==metadata['driver_binding_sha256'];
  if not metadata['inputs_unchanged'] or not metadata['driver_binding_unchanged']:metadata.update(status='blocked_no_retry',error='frozen input changed during invocation')
  metadata['raw_hashes']={p.name:digest(p.read_bytes()) for p in run_dir.iterdir() if p.is_file() and p.name!='invocation.json'};save()
 return metadata
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('operation',choices=['prepare','run']);p.add_argument('--host',choices=list(BINARIES));args=p.parse_args()
 try:
  if args.operation=='run' and not args.host:raise ValueError('--host required for explicit dispatch')
  result=prepare() if args.operation=='prepare' else run(args.host)
  print(json.dumps(result,indent=2));sys.exit(1 if result.get('status')=='blocked_no_retry' else 0)
 except Exception as error:print(json.dumps({'status':'blocked_before_dispatch','error':str(error)}));sys.exit(1)
