**PASS** for F1-F4, static closure only. I checked the attached final JSON and the original move receipts. I did not re-open `raw-verification.tar.gz`, the status doc or `boards-after-rollup.json` this round, and I make no wider source-review claim.

## Closure

| Finding | Result | Basis |
|---|---|---|
| F1 | PASS | Stale and current facts are now separate objects. `historical_new_fact.board_status_reread: false` is explicitly historical. `current_merge_fact` has `board_status_reread: true`, `observed_status: done`, and cites `reconciliation/pr301-board-merged.json`. The `PR301_two_status_changes` note now says the original snapshot "remains historical". |
| F2 | PASS | The union of `contributes_to.PS` across the two cards is PS05, PS13, PS16, PS17, PS18, PS19, PS24, which equals `pstack_groups`. Each of those seven capabilities lists 301 in `merged_prs`, and no other capability does. `card_be3dc4a2` backs PS13, PS17, PS18, PS19 and PS24. `card_2cccba22` backs PS05 and PS16. |
| F3 | PASS | `delivered_or_reusable` and `delivery_dimensions.delivered` are identical for all 32 J items in my read. J26 now carries the "capability-index、交付账本及文档schema校验已存在…仅候选" wording, and the unbacked "实际feature-map" and "离线validator" claims are gone. J15 carries the PR301 sentence in both fields. |
| F4 | PASS | `suggested_board_status` is now `historical_engineering_recommendation`, with a per-item `historical_recommendation_limit`. That limit says it is an e26 snapshot that includes reused foundations, not a current board state or evidence of new implementation. `engineering_slice_started` and `observed_board_status` are separate fields. |

**Receipt check for F1:**
- Comments 538 and 539 plus the two `status: done` records exist. Their `completed_at` values are 1793248600.311 and 1793248600.312, which is 04:36:40Z. That falls between the 04:25:11 blocked snapshot and the 04:39:34 re-read. It is also earlier than the first logged rollup mutation (≥ 1793248774.51), which resolves the missing-from-log concern.
- The comment bodies say the merged main is `1bf1f6ca…` and that the formal J gate does not pass with the merge, matching `scope_relation` and `formal_joint_gate_pass_asserted: false`.
- The "re-read in `boards-after-rollup.json`" part rests on the 04:39:34 observation I verified earlier. I did not re-open the dump.

**F4 consistency check:** started true maps to running and started false maps to todo, for 20 running and 12 todo. All seven `planned_or_deferred_not_accepted` items have started false. The five `partial_…` items with started false (J10, J13, J14, J20, J24) are covered by the "includes reused foundations" limit text.

## Optional additions (not blocking F1-F4)

1. **Actor wording.** `PR301_two_status_changes` says the cards were "moved done by root". The receipt has only the comment author `joint-entry`, and the status records have no actor field. Either say "by joint-entry" or note that `joint-entry` is root's board identity.
2. **Evidence path mismatch.** Both 301 cards cite `docs/implementation/method-parallel-reporting/README.md`. `prs301.primary_artifacts` and `evidence_readme` cite `docs/implementation/method-parallel-reporting-delivery/README.md`. Confirm these are two real files or fix the typo. I couldn't check this without the tree.
3. **Top-level `observed_status`.** The cards still carry `observed_status: "blocked"` with `observed_at` 04:25:11 beside `current_board_observation: done`. It is self-dated, but renaming it to `snapshot_observed_status` would remove any ambiguity for consumers.
4. **Deferred but running.** J16, J17 and J23 have `deferred_from_current_priority: true` alongside `observed_board_status: running` and `engineering_slice_started: true`. This may be intended, but a one-line definition of the deferred flag would pre-empt questions.
5. **J-level link for PR301.** J15 is `primary_j` for #301, but no PS `joint_work_items` list includes J15. The cards' `contributes_to.J` is `[]`, and `design_context_only_J` names J07/J30/J17/J18/J21, not J19. This fits the "no J acceptance" stance, but the J15 primary link rests on `primary_delivery_prs` alone.
6. **Carried over from the earlier pass.** #301 still lacks `merge_diff_inventory` and `J_classification`, and the doc's next-batch item 3 omits candidate SHA `9cbb463a`.