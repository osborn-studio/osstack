**结论：REVISE**

主线事实（main 1bf1f6ca、#301 已合并、4 入口 / 13 方法、第 14 方法为未合并候选、`formal_milestones_completed: 0`）以及 PR→J 映射都正确。涉及 `kanban.link/patch` 的 RPC 描述未虚构，推迟项的原义务也保留着。以下两处是已确认的阻断项。

## 已确认阻断项

**B1. `delivery-rollup.json` 的 `board_execution_status` 与同文件看板快照矛盾**
- 里程碑条目里有 20 个是 `running`：J01–J04、J06–J09、J11、J12、J15–J17、J19、J23、J25、J26、J29–J31。
- 同文件 `board_mechanics.snapshot.milestones` 显示实际只有 2 个 running（J01、J11）、1 个 ready（J02）、29 个 todo。
- 例子：J03（`card_7d169d5f`）和 J12（`card_e342e365`）在看板上是 `todo`，J02 是 `ready`，条目却写 `running`。J03 的评论数为 0。
- `status_semantics` 把 running 重新解释为“已有工程切片”，这是把看板状态字段改写成工程判断，等于把“running”当作进展信号。
- 修复：这个字段只填看板快照里的真实状态。“已开始工程切片”另设字段，例如 `engineering_slice_started`，不要复用看板状态字段名。

**B2. #301 的 PS 映射在 rollup 内自相矛盾，且有过期措辞**
- #301 条目的 `pstack_groups` 是 PS05、PS16、PS18、PS19。
- 但 PS18 的 `merged_prs` 只有 [300]，PS19 的只有 [..., 299]，都不含 301。两处的交付文字也未提 #301。只有 PS05 和 PS16 反向包含 301。
- `delivery-status.md` 的 PS24 写“301简报候选”，而 #301 已合并。PS24 的 `merged_prs` 是 [299]，#301 的 `pstack_groups` 也不含 PS24。
- 修复：二选一统一方向。要么给 PS18、PS19（以及 PS24，若确属 #301）补上 301 和对应的实际边界，要么从 #301 的 `pstack_groups` 删掉它们。同时把“候选”改成“已合并的 #301 简报/紧凑报告材料”，并写明未提供什么。

## 可选改进（非阻断）

1. #301 条目缺少其他 PR 条目都有的字段：`primaryJ`、`supportingJ`、`mergedSHA`、`merge_diff_inventory`、`evidence_readme`、`design_associations`、`scope_relation`。只读 camelCase 字段的消费者会读到空值。建议补齐，或明确 snake_case 是新规范。
2. “下一批”三项还不够可直接执行：
   - 没有给出具体的目标仓库和历史缺陷，也没有冻结协议的版本或路径、预算和责任人。
   - 第 3 项没有写候选 SHA（`9cbb463a`）。
   - 第 2 项的验收（“同一路径 RED→修复→GREEN”）是对的，但“预冻结”应指向具体的冻结产物。
3. 第 2 项映射到 PS06/PS07/PS20，而 bug-fix 方法本身落在 PS01（poteto-mode 的 bug-fix playbook）。建议确认是否应补上 PS01 和 PS08。
4. J23 标“后排”，但 J10、J14、J16 的 `exact_stage_gates` 都依赖 J23.scoped 或 J23.method_context，而且第 2 项的真实宿主测量本质上就是 J23 的一部分。建议在 J23 行注明“宿主测量作为第 2 项的一部分提前”，避免“后排”被理解为不做。
5. J26 的“离线 validator”没有指出具体文件，而计划路径 `scripts/capabilities/validate.mjs` 在固定 main 上不存在。建议写明实际 validator 路径，或改成更准确的措辞。
6. `project-operations.md` 的“真实支持状态”只列了五个状态，快照里还有 `triage` 和 `archived`。另外，该文件正文大部分是历史批次叙述，建议在开头标注“历史章节，不代表当前状态；当前状态以 delivery-status.md 和 delivery-rollup.json 为准”。

## 已核对无误

- **PR 映射：** 对照 #272–#301，delivery-status 的 PR 表与 rollup 的 `primary_j`/`supporting_j` 一致，里程碑的 `primary_delivery_prs`/`supporting_prs` 也一致。
- **看板计数：** 32 个里程碑加 39 张活动卡等于 71 张，分母分开，没有把 35 除以 71 或 32。
- **已交付 vs 复用：** J04、J13、J14、J24 等条目明确区分了复用的既有基础和本项目新交付，`primary_delivery_prs` 为空的项没有被写成已交付。
- **原生 RPC：** `native_parent_rollup_available: false`，写明不存在 `kanban.link`/`patch`，用评论回链，没有虚构接口。