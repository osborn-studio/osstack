from pathlib import Path
import subprocess,json,hashlib,datetime,re
repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';up='/Volumes/AIMATE_WORK/Developer/CodeX/cursor-plugins';main='e26f6d2ca81628b565d2db0fd047fcb041fa8a45';pin='99b609a72323b70204eab407c622f436e858e112';o=Path(__file__).parent
bindings=[]
def read(path,rev=main,repository=repo):
 b=subprocess.check_output(['git','-C',repository,'show',rev+':'+path]);bindings.append({'repository':repository,'revision':rev,'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});return b.decode()
cap=json.loads(read('docs/design/2026-10-27-joint-engineering/capability-map.json'));work=json.loads(read('docs/design/2026-10-27-joint-engineering/work-packages.json'));ledger=json.loads(read('docs/design/2026-10-27-joint-engineering/execution-ledger.json'))
prs={
288:('四方法+真实回答回执验证工具','verification-kit',['PS01','PS02','PS08','PS09','PS13'],['scripts/smoke-engineering-decision.mjs','osstack-methods-skill/SKILL.md'],'确定性CLI→daemon→SQLite；不是真provider或正式方法准入'),
289:('skills check实际失败退出码修复','skills-check-exit',['PS08','PS09'],['packages/skills/src','scripts/smoke-skills-check.mjs'],'同输入missing-ref RED→GREEN；不是宿主自主修复证明，smoke脚本由291补齐'),
290:('两宿主历史证据读取+证据指南修正','joint-host-effects',['PS13','PS20'],['osstack-methods-skill/references/evidence.md'],'只读已修复缺陷材料；无现场产品驱动，无因果收益；Claude存在未读误称未提供'),
291:('可重复五case skills-check验证','skills-check-verification',['PS08','PS09','PS13'],['scripts/smoke-skills-check.mjs'],'实际healthy/missing-ref/drift/mixed/empty；不是任意应用生成器；宿主辅助实验非全项通过'),
292:('四命名入口+Codex/Claude可导出布局','osstack-method-entrypoints',['PS01','PS20','PS21'],['scripts/export-osstack-methods.mjs','osstack-methods-skill/entries'],'导出不是安装；四入口不等于四方法，scope不含MethodBinding'),
293:('feature/refactoring两方法+有限原生发现实验','method-feature-refactoring',['PS01','PS04','PS20'],['osstack-methods-skill/references/feature.md','osstack-methods-skill/references/refactoring.md'],'材料累计6；Claude help原生读取限定通过；Codex整体观测不充分，非全方法使用'),
294:('两feature验证旅程+实际回执/功能地图','method-verification-journey',['PS08','PS09','PS13'],['scripts/method-verification-journey.mjs'],'固定healthy/missing-ref；coordinator运行并非模型自主；Claude507词停止，Codex phase2记录env边界失败'),
295:('独占模型证据投影包','method-evidence-projection',['PS13','PS20'],['scripts/project-method-journey-evidence.mjs'],'exact2files/closed schema/保留失败未知；不认证producer/重跑原checker/提高任务完成等级'),
296:('代码审查第7方法+packet读取实验','method-code-review',['PS06','PS07','PS13'],['osstack-methods-skill/references/code-review.md'],'实际代码审查质量未由导出证明；packet Codex有限/Claude515词失败，不修复旧实验'),
297:('影响面与性能测量第8/9方法','method-impact-performance',['PS07','PS14'],['osstack-methods-skill/references/change-impact.md','osstack-methods-skill/references/performance-measurement.md'],'方法/导出/静态挑战；不等于运行真实profile或完成性能改进'),
298:('任务深化与架构第10/11方法','method-framing-architecture',['PS03','PS04','PS23'],['osstack-methods-skill/references/task-framing.md','osstack-methods-skill/references/architecture-design.md'],'方法可读；架构执行价值无完整宿主验证'),
299:('会话连续性第12方法+framing实际实验','method-continuity-delivery',['PS19','PS24'],['osstack-methods-skill/references/session-continuity.md'],'不接线恢复runtime；framing两host均LIMITED，不能记continuity宿主通过'),
300:('PR readiness第13方法+4合成PR分类实验','method-pr-readiness-delivery',['PS17','PS18'],['osstack-methods-skill/references/pr-readiness.md'],'方法为一次状态/授权修复；无默认watcher；Codex LIMITED/Claude FAILED，无实际forge修复/merge')}
merges={}
for line in subprocess.check_output(['git','-C',repo,'log',main,'--first-parent','--format=%H %s'],text=True).splitlines():
 m=re.match(r'(\w+) Merge pull request #(\d+) ',line)
 if m:merges[int(m[2])]=m[1]
rows=[]
for number,(title,doc,ps,paths,limit) in prs.items():
 docpath=f'docs/implementation/{doc}/README.md'
 try:read(docpath)
 except subprocess.CalledProcessError:
  docpath='docs/implementation/method-change-impact/README.md';read(docpath)
 sha=merges[number];assert subprocess.run(['git','-C',repo,'merge-base','--is-ancestor',sha,main]).returncode==0
 changed=subprocess.check_output(['git','-C',repo,'diff','--name-only',sha+'^1',sha],text=True).splitlines()
 rows.append({'pr':number,'merge_commit':sha,'state':'merged_in_snapshot','capability':title,'pstack_groups':ps,'joint_work_items':sorted({j for c in cap['capabilities'] if c['id'] in ps for j in c['joint_work_items']},key=lambda s:int(s[1:])),'primary_artifacts':paths,'evidence_readme':docpath,'limits':limit,'changed_paths':changed,'formal_joint_gate_pass_asserted':False})
# Each entry is a bounded delivery view, not a closure of the larger PS group.
status={
'PS01':('partial_delivered','13共享方法、四入口路由/帮助；没有单一runtime编译/强制执行通道','poteto-mode/SKILL.md'),
'PS02':('partial_delivered','investigation可用；how/why/teach为方法吸收，没有专门历史取证工具或全面效果验证','poteto-mode/playbooks/investigation.md'),
'PS03':('partial_delivered','task-framing已合并；实际两宿主均LIMITED，尚非任务执行收益证明','sharpen/SKILL.md'),
'PS04':('partial_delivered','architecture/feature/refactoring可用；独立多原型arena和完整采纳循环未交付','architect/SKILL.md'),
'PS05':('candidate_unmerged','301含覆盖式并行指南；无新增公平调度/竞赛执行器','swarm/SKILL.md'),
'PS06':('partial_delivered','code-review材料+本项目独立审查审计实践；产品化跨模型评审/资格未闭合','interrogate/SKILL.md'),
'PS07':('partial_delivered','change-impact材料/关键前提检查；普遍宿主效果未验证','blast-radius/SKILL.md'),
'PS08':('partial_delivered','create-verification材料+两种真实CLI例子/五case driver/两行journey；任意项目自动生成完整旅程未证明','create-verification-skill/SKILL.md'),
'PS09':('partial_delivered','maintain材料+健康/归属/清理验证；尚无完整功能地图漂移维护的真实缺陷闭环','maintain-verification-skill/SKILL.md'),
'PS10':('deferred','形式化生成/维护与代码mutation对应尚未作为pstack能力实现','create-formal-verification-skill/SKILL.md'),
'PS11':('deferred','状态图/反例解释工具未移植，不把普通Mermaid文档当模型检验','statechart/SKILL.md'),
'PS12':('candidate_unpublished','9c技能创建维护吸收reflect/correct局部，尚未发布；持久经验draft→评审→采纳机制未闭合','reflect/SKILL.md'),
'PS13':('partial_delivered','原始回执/manifest/hash/错误保留及安全投影已可用；证据完整性不认证身份/历史真实性','show-me-your-work/SKILL.md'),
'PS14':('partial_delivered','性能审查方法与合成数例可用；无因果性能提升结果','benchmark-checklist/SKILL.md'),
'PS15':('deferred','有预算hillclimb/盲评尚未实现；当前有限host probe不是效果benchmark','poteto-mode/playbooks/hillclimb.md'),
'PS16':('candidate_unmerged','301协作brief/覆盖/共享资源指南；现会话多agent是工程实践非新增控制runtime','poteto-mode/playbooks/orchestrate.md'),
'PS17':('partial_delivered','PR readiness材料+候选绑定实践；栈前沿自动校验服务未接线','poteto-mode/playbooks/autopilot-stack.md'),
'PS18':('partial_delivered','一次forge状态分类方法；未移植watch-pr观察器，不把既有github组件当本批新增','poteto-mode/scripts/watch-pr/policy.ts'),
'PS19':('partial_delivered','session-continuity材料可用；恢复schema/spec不等于J12运行态恢复','poteto-mode/playbooks/pause-safely.md'),
'PS20':('partial_delivered','四入口双host导出，有限读取/native help观察；无全方法等价/强制context/资格激活','setup-pstack/SKILL.md'),
'PS21':('partial_delivered','更早281来源快照组件与合同、292材料源清单；实际采用闭包/资格/漂移激活未闭合','poteto-help/SKILL.md'),
'PS22':('deferred','Benny/外部事件intake补偿未启用或移植','poteto-mode/playbooks/orchestrate.md'),
'PS23':('partial_delivered','caller-first architecture、验证材料与文档；三条冻结地图和冷用户验收未全通过','architect/SKILL.md'),
'PS24':('partial_delivered','continuity/解释+301简报候选；无全局记忆自动化；视频/Bot/个人风格暂缓','recall/SKILL.md')}
psrows=[]
for c in cap['capabilities']:
 if not c['id'].startswith('PS'):continue
 state,desc,source=status[c['id']];source='pstack/skills/'+source;read(source,pin,up)
 psrows.append({'id':c['id'],'title':c['title'],'status':state,'delivery':desc,'joint_work_items':c['joint_work_items'],'acceptance_ids':c['acceptance_ids'],'legacy_source_refs':c['source_refs'],'original_anchor':{'commit':pin,'path':source},'merged_prs':[r['pr'] for r in rows if c['id'] in r['pstack_groups']],'whole_capability_complete':False,'runtime_gate_pass_asserted':False})
for p in ['osstack-methods-skill/SKILL.md','osstack-methods-skill/EXPORT.md','docs/implementation/method-native-discovery/README.md','docs/implementation/method-packet-host-consumption/README.md','docs/implementation/method-continuity-delivery/host-report.md','docs/implementation/method-pr-readiness-delivery/host-report.md']:read(p)
read('osstack-methods-skill/references/parallel-work.md','50ed89fbe1fa9e7ebba520214390f97725164728');read('osstack-methods-skill/references/skill-authoring.md','9cbb463af972d6fc0ad5265971b966ba2c35523e')
priority=Path('/Users/osborn/.codex/attachments/d2b7ff61-46b9-4fd6-accd-a91e8df6baab/已粘贴的文本.txt')
result={'kind':'read_only_capability_reconciliation_not_ledger_update','as_of':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':main,'merged_state_basis':'fixed Git first-parent merge commits and ancestry; not live forge polling','user_priority':{'path':str(priority),'sha256':hashlib.sha256(priority.read_bytes()).hexdigest()},'named_methods_merged':13,'exported_entries_merged':4,'prs':rows,'pstack_capabilities':psrows,'pending':[{'pr':301,'head':'50ed89fbe1fa9e7ebba520214390f97725164728','state':'Ready_unmerged_per_root_snapshot','scope':'parallel supporting guide and concise reporting; no new named method'},{'branch':'codex/method-skill-authoring','head':'9cbb463af972d6fc0ad5265971b966ba2c35523e','state':'audited_candidate_unpublished_per_root','scope':'14th shared method; no new installed entry'}],'joint_mapping_rule':'PS→J association is design traceability, not formal J acceptance closure. No J gate granted by this reconciliation.','ledger_observation':{'top_level_main_sha':ledger.get('main_sha'),'historical_next_continuity_state':ledger.get('next_continuity_wave',{}).get('status'),'problem':'historical wave fields retain older snapshots; do not override Git merge facts or imply delivery absence','29_cards':'Live OSStack board was not queried; no asserted card-ID completeness or automatic status changes. Root must join actual card registry to this capability view.'},'priorities':[{'rank':1,'gap':'真实项目验证维护闭环','groups':['PS08','PS09'],'joint':['J03','J06','J09','J10','J23'],'slice':'为现有两feature地图建立源码变化→漂移检测→区分文档/harness/product→同路径重验→保留失败的完整实用维护流程；先覆盖一个真实已确认漂移或缺陷，不制造缺陷冒充现场问题。','acceptance':'原始变化与失败、原地图全部行状态、分类依据、授权内修复、相同driver GREEN、blocked不删场景、cleanup后原始证据仍可核验。','boundary':'D2a实际工具增量可继续；不得声称冻结J03/J09通过。'},{'rank':2,'gap':'宿主真正完成一个可复用bug-fix工作单元','groups':['PS01','PS06','PS08','PS20'],'joint':['J04','J07','J09','J23','J25'],'slice':'在已知授权的隔离真实仓库/固定缺陷上完成读取方法→真实RED→修复→相同GREEN→报告，至少一个宿主完整闭环；另一个按同源场景独立验收，不以模拟回答或coordinator代执行冒称原生自主。','acceptance':'独立冻结输入/成功与非目标判据，真实工具动作/候选/source-build/前后态/失败/清理可核验；不靠模型自报或只看词数；未知identity保留。','boundary':'事前明确执行权限与预算；不改变J身份/激活规则，不承诺跨宿主等价或因果收益。'},{'rank':3,'gap':'单一用户能力进度投影','groups':['PS13','PS21','PS24'],'joint':['J26'],'slice':'将29大卡、PS24组/J工作、实际文件、merge事实、证据等级和下一缺口连为一个只读可查询清单；中央统一维护，历史波次仍不可改写。','acceptance':'每卡有归属能力/范围/证据/merge状态；候选不算merged；已合并方法不被planned门槛遮蔽；formal gate与D2a可用性双列；任何总数有明确分母。','boundary':'不新增数据库/另一控制面；不把本对账当既已完成该工具。'}],'source_bindings':bindings,'executed_this_task':['read fixed Git objects and merge ancestry','read original pinned sources','write scratch report only'],'not_executed':['models','product tests','live OSStack board query','PR mutation','formal acceptance']}
(o/'pstack-map.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
md=['# pstack能力交付对账','',f'固定主线 `{main}`；原始pstack `{pin}`。本报告只读，不改账本或资格。合并事实来自本地Git一父链与祖先验证，PR301 Ready状态由主线程当前快照提供，未另行查询实时forge。','', '## 核心结论','', '已合并的实际能力是：13种共享工程方法、4个可导出入口、真实本地验证driver与两feature旅程、保留证据及模型包投影。它们已经可作为材料或工具使用，不应该因为正式J门槛未完成就一概写成“未实现”。但方法文件、导出、有限宿主读取，也不能算整个pstack能力组或联合runtime已完成。','', 'PR301的并行/简报指南仍待合并；skill-authoring第14方法仍是未发布候选。本次不把二者计入主线13方法。','', '## 已合并交付逐项落点','', '| PR | 能力交付 | PS组 / J关联 | 证据与关键限制 |','|---|---|---|---|']
for r in rows:md.append(f"| #{r['pr']} `{r['merge_commit'][:8]}` | {r['capability']} | {', '.join(r['pstack_groups'])} → {', '.join(r['joint_work_items'])} | `{r['evidence_readme']}`；{r['limits']} |")
md+=['','J列是来源能力的设计关联，不表示该PR实现了列出的所有J项。尤其J03的冻结session-answer-receipt/bug-fix注册driver、J04强制材料回执、J09正式旅程、J23资格不是当前D2a脚本的别名。更早#272/#273/#281提供规范化/共享合同/来源快照组件，#274/#284/#286提供恢复规格/组合证据，均不据此自动放行runtime。','','## 24组能力状态','', '| PS | 状态 | 已有与缺口 | J项 |','|---|---|---|---|']
labels={'partial_delivered':'部分已交付 / 完整能力待验证','candidate_unmerged':'候选未合并','candidate_unpublished':'候选未发布','deferred':'暂缓 / 本批未实现'}
for c in psrows:md.append(f"| {c['id']} {c['title']} | {labels[c['status']]} | {c['delivery']} | {', '.join(c['joint_work_items'])} |")
md+=['','## 宿主实际使用不能合并成一个PASS','', '- #290：显式读取历史RED/GREEN并给诊断，不是现场修复或原生发现；Claude有已提供未读误称缺失。','- #293：Claude v2限定help原生调用与两引用读取通过；Codex目录/执行分进程、原始完整前态及resolved model缺口，整体inconclusive。','- #294：协调者执行一次真实driver，不是模型自主执行。Claude阶段1超507词停止；Codex阶段2读取所提供的环境记录违反冻结字面边界，非live凭据泄露。','- #296：packet读取Codex有限，Claude515词违反500限制；不是新code-review方法的真实行为验证。','- #299：实验测已合并task-framing，不测新continuity；两host均LIMITED，Claude比较构建/未来交付范围有缺口。','- #300：真实模型只对合成PR材料分类，Codex LIMITED、Claude FAILED；未执行真实forge修复，不能用正确分类外推完整PR闭环。','', '## 最优先补齐的完整缺口','']
for q in result['priorities']:md += [f"### {q['rank']}. {q['gap']}",'',q['slice'],'','验收：'+q['acceptance'],'','边界：'+q['boundary'],'']
md+=['## 29大卡与旧账本的读法','',f"主线execution-ledger顶层仍指向 `{ledger.get('main_sha')}`，next_continuity_wave仍保留 `{ledger.get('next_continuity_wave',{}).get('status')}`。这些是历史快照，不是#299尚未合并的证明。需要统一投影，而不是反复新增孤立波次。",'', '本任务未读取实时OSStack看板，不能伪造29卡逐ID完整对账。主线程应将真实卡列表与本报告PS/J/PR/文件证据相连：每卡展示已交付子能力、仍缺验收、当前候选和下一动作。不要用PR数或13/58推算完成百分比；58上游skills、23playbooks、24PS组、32J项和29看板卡不是同一种分母。','', '原始来源锚点、文件摘要、每个PR合并diff路径和能力映射完整保存在同目录pstack-map.json。未调用模型、全仓测试、产品CLI或默认数据库。']
(o/'pstack-map.md').write_text('\n'.join(md)+'\n')
print('wrote',len(rows),'merged PRs',len(psrows),'PS groups',len(bindings),'source bindings')
