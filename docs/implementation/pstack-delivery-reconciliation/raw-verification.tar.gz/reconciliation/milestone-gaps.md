# 联合交付对账：固定已合并 main

基线 `e26f6d2ca81628b565d2db0fd047fcb041fa8a45`；32 项全部保留原计划边界。本次只读原始 Git 对象和已保存证据，未跑测试/模型、未修改账本或状态。

**结论：四入口、13 共享方法、严格契约、source inspector、离线恢复/ broker 规格和真实验证工具是实际交付；尚不能将任何完整 J 里程碑记为验收完成。** 全部126 gate仍为 specified_not_run；32项账本完整验收均未执行。这不否认已完成的组件回归。

J15 的四入口是材料入口，正式要求还包括持久问答、版本、权限与纠偏；J19 的连续性方法是接续/交接指导，正式要求还包括项目隔离检索、失效与经验晋升。两者可记部分交付，不能记运行时完成。

下表证据路径均来自固定 main；JSON保存原 outputs、acceptance IDs、每个实际子gate及其依赖，避免按编号臆造子项。

| 项目 | 现有交付/基础 | 尚缺的原计划边界 | 固定证据 |
|---|---|---|---|
| J01 共享身份、完成与资格契约 | 严格身份/完成/资格/恢复契约及原始JSON、canonical、交叉字段和变异回归已交付。 | JP-01c不是预冻结且具备可信独立principal的正式JA59/70；JA01真实local_verified/observed_turn区分与JA02可信宿主准入未由结构测试替代。 | `docs/implementation/joint-contract-acceptance/README.md` |
| J02 共用来源快照与分型注册 | typed registry、v1兼容和opt-in source inspector可用；固定Git对象/路径/预算检查已有实现。 | J02b采用依赖闭包、边来源、图预算/身份冲突与真实JA03漂移失效未闭合；inspector明确dependency_resolution=not_performed、identity=caller_asserted。 | `docs/implementation/joint-source-inspection/README.md` |
| J03 session-answer-receipt 驱动夹具 | 现有CLI/daemon验证工具和固定两case旅程提供真实原始回执与证据。 | 尚未交付计划中的method-control/session-answer-receipt统一驱动及JA05/06/44；不能把已有smoke重命名为正式切片。 | `docs/implementation/verification-kit/README.md`、`docs/implementation/method-verification-journey/README.md` |
| J04 必需方法材料与 v2 调用回执 | 13共享方法材料与现有execution-context基础可用。 | 尚未实现强制MethodBinding材料装载、持久快照/预算裁剪/v2 receipt完整链；材料可读不等于运行时必经、可信角色接线或JA07/08/09/46/53通过。 | `docs/implementation/osstack-method-entrypoints/README.md`、`osstack-methods-skill/SKILL.md` |
| J05 检查映射与单方法纯编译 | 共享方法含验证编写指导；尚无本计划recipe compiler交付证据。 | 纯recipe编译/check映射与规定输入输出仍需实现；实际J05.scoped还要求J25.e0 continue/shrink，不可仅依包级J02/J06。 | `docs/implementation/verification-kit/README.md` |
| J06 使用草图与三条功能地图 | feature-map模板、五case source验证及固定healthy/missing-ref两行图已交付。 | 不是计划的repro/wait/cancel三张图与统一usage-sketch回执；JA12/13仍未正式执行。 | `docs/implementation/skills-check-verification/README.md`、`docs/implementation/method-verification-journey/README.md` |
| J07 产物消费与同候选评审 | 真实driver归档、严格两文件证据投影与输入完整性检查可用。 | 尚无host-authoritative method artifact/same-candidate资格链；projection仅保留声明和bytes一致性，不证明原运行真实性或J07接受。 | `docs/implementation/method-evidence-projection/README.md` |
| J08 首次受限试验准入 | 分层准入设计已明确无副作用host边界、正控制和真实入口复用。 | method-host-admission与完整首次trial未实现；J08.admission_boundary/JA02+71须真实可信入口，完整trial还要J03/J07/J12等，不能以设计门槛测试通过替代。 | `docs/design/2026-10-27-joint-engineering/gate-layers.md` |
| J09 首个本地 bug-fix 方法旅程 | bug-fix方法及真实CLI缺陷修复/回归工作流有交付。 | 计划内recipe驱动本地bug-fix端到端旅程与method report未交付；JA18不由任意修bug或smoke自动满足。 | `docs/implementation/verification-kit/README.md`、`osstack-methods-skill/references/bug-fix.md` |
| J10 方法资格与激活漂移管理 | 方法资格相关严格契约已有基础。 | 持久资格、active漂移失效、改进与迁移流程未交付；J10.protocol/scoped/recovery不同，scoped还需J25.e1和method_context证据。 | `docs/implementation/joint-contract-acceptance/README.md`、`docs/design/2026-10-27-joint-engineering/gate-layers.md` |
| J11 恢复回执目标 schema 规格 | 真实home目录/旧hold和candidate48 DDL、逐字段删除/producer依赖回归、独立broker候选DDL已交付。 | O03及正式JA20/47未关闭；候选DDL未注册运行时迁移，不是J12；结构/SQLite回归不是正式oracle资格。 | `docs/implementation/joint-recovery-retarget/README.md`、`docs/implementation/joint-recovery-composition/README.md`、`docs/implementation/joint-broker-spec/README.md` |
| J12 目标 schema 恢复与操作员处置 | 离线schema/bootstrap/旧hold与broker组合测试可复用；既有graph recovery基础存在。 | operator-recovery host/真实操作员授权、CAS、跨进程重建和恢复处置未交付；不得迁移默认home、释放unknown producer或补发未知action。 | `docs/implementation/joint-recovery-composition/README.md`、`docs/implementation/joint-broker-spec/README.md` |
| J13 主控事件模型与累计预算 | 已有engineering持久store/DDL基础。 | 新的controller事件驱动、累计预算/恢复链尚未实现；现有存储文件存在不能证明JA22/23。 | `docs/design/2026-10-27-joint-engineering/work-packages.json` |
| J14 Loop/Graph 准入与单次启动 | 既有Loop/Graph与executor基础存在。 | 联合准入/单次launch接线与其恢复前置未完成；不可根据现有Graph能够运行推导JA24。 | `docs/design/2026-10-27-joint-engineering/work-packages.json`、`docs/design/2026-10-27-joint-engineering/gate-layers.md` |
| J15 统一入口、范围纠正与路由 | 四命名入口、Codex/Claude可导出布局和13方法已合入；可按当前用户授权使用材料。 | 尚无持久问答/版本/纠偏router。JA25多问题continue不猜、JA63保留未闭合问题、JA67人类授权来源/防owner自报，不能以四份SKILL替代。 | `docs/implementation/osstack-method-entrypoints/README.md`、`osstack-methods-skill/SKILL.md`、`docs/design/2026-10-27-joint-engineering/acceptance-cases.json` |
| J16 跨方法与监督的联合旅程 | 已有真实验证器旅程和小规模宿主材料使用观察。 | 联合method+持续监督+恢复完整旅程与crash integration未交付；材料使用实验不能替代JA26/27。 | `docs/implementation/method-verification-journey/README.md`、`docs/implementation/method-native-discovery/README.md` |
| J17 容量、写集合与集成候选 | JP-17a独立broker namespace真实SQLite候选DDL/held orphan/不可变decision防护可用。 | 0→1未预留、未注册runtime；JP-17b恢复与可信proof、JP-17c容量/write-set/integration routing未交付。并行子代理的人工分工不是broker实现。 | `docs/implementation/joint-broker-spec/README.md`、`docs/implementation/joint-recovery-composition/README.md` |
| J18 竞争与覆盖模式的多候选扩展 | 已有独立审查/不同候选比较经验，不属于新运行时交付。 | method candidates、coverage/integration candidate selection及JA29未实现；模型意见数量不构成正确性证据。 | `docs/design/2026-10-27-joint-engineering/work-packages.json` |
| J19 上下文恢复与受控经验 | session-continuity方法保留当前授权核对、owner/dirty/base/next observer交接；反思指导只生成候选。 | 项目隔离检索/provenance/expiry/受控lesson promotion未实现；JA30跨项目与指令污染、JA69坏例/邻近好例抗全拒绝仍需真实验证。 | `docs/implementation/method-session-continuity/README.md`、`osstack-methods-skill/references/session-continuity.md`、`docs/design/2026-10-27-joint-engineering/acceptance-cases.json` |
| J20 事件监督、低打扰与增量简报 | 连续负责/quiet的来源已经抽取为方法边界。 | 事件监督、quiet状态、增量brief、durable未决义务与恢复未实现；Codex主线程持续工作不等于OSStack新supervisor。 | `docs/implementation/method-session-continuity/README.md`、`docs/design/2026-10-27-joint-engineering/work-packages.json` |
| J21 远端子主管与父子回执 | 远程subcontroller合同/计划存在。 | 真实parent receipt、remote boundary与恢复未实现；属于pstack优先后的暂后置范围，非取消原验收。 | `docs/design/2026-10-27-joint-engineering/work-packages.json`、`docs/design/2026-10-27-joint-engineering/gate-layers.md` |
| J22 外部事件与授权公开承诺 | external intake/public commitment边界已有设计。 | 真实外部事件接线、承诺权限/恢复链未交付；方法或原评论不能赋予对外写权限。 | `docs/design/2026-10-27-joint-engineering/work-packages.json`、`docs/design/2026-10-27-joint-engineering/gate-layers.md` |
| J23 宿主与执行器资格测量 | 有Codex/Claude真实有限材料发现/使用实验，失败和限制保留。 | 无完整qualify-engineering-host/support-cell矩阵；不同模型名不证明独立principal，显式读文件不等nativeSkill、目录发现不等执行，不能签JA34。 | `docs/implementation/method-native-discovery/README.md`、`docs/implementation/method-packet-host-consumption/README.md` |
| J24 有效版本、升级与恢复演练 | 既有engineering upgrade guard与真实升级/清理测试存在。 | 联合effective-version/恢复演练及support-cell全矩阵未交付；单次CLI升级测试不签JA35。 | `docs/design/2026-10-27-joint-engineering/work-packages.json`、`packages/cli/src/engineering-upgrade-guard.ts` |
| J25 早期方法价值实验 | 有有限host行为/共享材料验证与原始失败，能提供后续实验输入。 | 未执行冻结成本/任务/holdout的E0/E1价值实验；不能从少量合成任务或模型读材料推导因果收益/成本优势。 | `docs/implementation/method-review-behavior/README.md`、`docs/implementation/method-packet-host-consumption/README.md`、`docs/design/2026-10-27-joint-engineering/gate-layers.md` |
| J26 来源能力与当前交付投影 | capability index、交付账本、离线validator及实际feature-map已有材料。 | 尚未交付计划中的只读capability/current-delivery可执行projection及JA37/60；文档清单不等运行时支持声明。 | `docs/design/2026-10-27-joint-engineering/capability-index.md`、`docs/design/2026-10-27-joint-engineering/execution-ledger.json` |
| J27 灰度与支持范围内启用 | 设计runtime_enabled=false；无新联合support-cell启用证据。 | local-opt-in/default-enable/full-original-completion分别有不同依赖，不能由先决PR合并自动启用；原始legacy门槛仍保留。 | `docs/design/2026-10-27-joint-engineering/gate-layers.md`、`docs/design/2026-10-27-joint-engineering/execution-gates.json` |
| J28 高后果状态不变量形式化试点 | 有限形式状态验证已有计划。 | 指定TLA模型/check入口未交付，JA39未执行；单元状态机测试不自动成为形式证明。 | `docs/design/2026-10-27-joint-engineering/work-packages.json` |
| J29 性能与有预算的改进循环 | performance-measurement指导及明确标注的合成算术例已交付。 | 真实budgeted improvement/end-to-end成本性能实验与JA40未执行；算术正确不等真实性能收益。 | `docs/implementation/method-performance-measurement/README.md`、`osstack-methods-skill/references/performance-measurement.md` |
| J30 Forge 观察与栈前沿验证 | PR-readiness方法和本项目人工forge/CI取证流程已交付，当前head/base与review/integration分轴。 | 未交付新Forge observer/stack frontier/runtime method-report；无自动watch、merge授权或JA41/57正式资格。 | `docs/implementation/method-pr-readiness/README.md`、`osstack-methods-skill/references/pr-readiness.md` |
| J31 清理前保全与应用回执修复 | 真实Session finally/held admission/terminal fence/confirmed stop及applied evidence cleanup相关产品切片已合入。 | 不等于完整保留前清理资格；跨进程unknown producer/DEBT02、所有dirty/unlanded资源保全与JA42/56正式证据仍需覆盖。 | `docs/implementation/joint-session-cleanup-retarget/README.md`、`docs/implementation/joint-terminal-post282/README.md`、`docs/design/2026-10-27-joint-engineering/acceptance-cases.json` |
| J32 联合四组对照与冷用户验收 | 已有少量宿主观察，可帮助冻结未来任务集。 | 无baseline/F/P/F+P四臂对照、独立冷用户复现与完整成本盲评；JA43未执行。 | `docs/design/2026-10-27-joint-engineering/work-packages.json`、`docs/implementation/method-native-discovery/README.md` |

## pstack 优先的建议次序

1. **D2a usable pstack capability**：先完成已在途PR301与第14 skill-authoring切片的实际main重验/发布；本报告不把未合入内容计入e26。随后按用户原始优先清单和能力缺口选择小切片，避免只增加总结文档。 现有授权内材料/工具交付不被额外虚构J01审批阻塞；仍不签runtime gate。
2. **D2a real user journey**：用现有真实CLI、验证器、证据投影完成冷调用者可复现的创建/维护verification与skill authoring旅程；记录失败、unknown、产物和原始命令，不用词串测试替代行为。 单场景可用性与正式J06/J09/价值资格分开。
3. **Formal component prerequisites**：落实原J01.contracts所需可解析principal/预冻结oracle职责和现成结构证据；复核O06。由原直接overrides并行推进J02b采用依赖闭包、J03统一回执驱动与J11正式spec验收。 不自造human-only/外部组织要求；不以本独立agent身份或Sonnet意见代替原资格。
4. **pstack runtime minimum useful chain**：J03→J06与J25.protocol/e0；依现有门槛推进J04、J05、J07。并行建设无副作用J08.admission_boundary/J01.scoped；J12安全恢复满足后才做完整J08/J09实际trial。 以exact_stage_gates为准，包级顺序不能忽略E0/恢复/host边界。
5. **Firstmate support only where required**：保留J11/J12/J31真实安全前置；J13–J22持续监督/容量/remote/external全面扩展暂后置。J15/J19材料先可用，运行时问答/检索晋升另开明确实施切片。 后置是本次优先级建议，不修改原依赖、不删除原能力、不擅自启用J27。
6. **value and expansion**：真实小链可跑后完成J23/J25测量，再按证据决定J10/J16/J17及后续扩展；J29性能与J32四臂实验保留真实工作量/成本/失败，不提前宣布吸收完成。 无收益或样本不足如实报告，不能模型投票决定有效。

## 对账与声明边界

- 不把 PR301 或第14方法提前记进本基线；未合入不等于没有工作成果。
- 不把所有 shared-path 存在当作新功能完成；JSON逐条保存计划路径存在性，J11实际目录迁移已单独指出。
- J01.contracts 的组件证据与 J01.scoped 的真实宿主证据分层；J02/J03/J04/J11可按原组件override推进，不能误造J08循环。
- J05.scoped仍受J25.e0约束；J12/J17恢复与schema-spec并非同一阶段；J27 local/default/full完成条件各自保留。
- 可在工程账本增加component/material/tooling部分交付引用；不要将旧 milestone planned 直接改 done，或把本报告作为正式oracle签名。
- 未重新执行历史测试、逐一复核全部原始归档或验证远程CI；本报告是固定版本能力与证据边界对账，不是新的运行资格。
