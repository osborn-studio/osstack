from pathlib import Path
import json,hashlib
p=Path(__file__).parent;d=json.loads((p/'pstack-map.json').read_text())
js={272:('J01',['J02']),273:('J01',['J04','J07']),274:('J11',['J12']),275:('J02',['J01']),276:('J02',['J10']),277:('J31',['J03']),278:('J31',['J03']),279:('J31',['J12']),280:(None,['J26']),281:('J02',['J26']),282:('J02',['J10']),283:('J01',['J08']),284:('J17',['J11']),285:('J01',[]),286:('J11',['J17','J12']),288:('J03',['J06','J09']),289:('J09',['J03']),290:('J23',['J07','J25']),291:('J03',['J06']),292:('J15',['J04','J23']),293:('J06',['J23']),294:('J03',['J06','J07']),295:('J07',[]),296:('J07',['J06','J23']),297:('J06',['J29']),298:('J06',['J05']),299:('J19',[]),300:('J30',['J07'])}
for r in d['prs']:
 r['design_associations']=r.pop('joint_work_items');r['primary_j'],r['supporting_j']=js[r['pr']];r['primaryJ']=r['primary_j'];r['supportingJ']=r['supporting_j']
 r['scope_relation']='D2a_material_tool_or_observation_contribution_not_formal_output' if r['pr']>=288 else 'component_or_offline_specification_not_complete_acceptance'
 if r['pr']==280:r['scope_relation']='design_control_documents_only_no_primary_product_output'
d['joint_mapping_rule']='primary_j is one actual delivery association; supporting_j is bounded concrete support; design_associations only preserve broad source traceability and MUST NOT drive status aggregation. D2a contributions do not close formal output acceptance.'
d['formal_boundary_crosscheck']={'source':'cleanup_regression fixed-main e26 reconciliation','gates_specified_not_run':126,'milestone_acceptance_complete':0,'milestone_count':32,'note':'component/spec/code/method delivery still counted independently; these are not zero useful delivered capabilities','report_expected':'milestone-gaps.json/md in same reconciliation folder; root joins exact final files'}
(p/'pstack-map.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
md=(p/'pstack-map.md').read_text();a=md.index('## 较早共享基础');b=md.index('## 24组能力状态')
section=['## 合并事实与实际交付落点','','每条仅一个primary J主落点，supporting J最多三项有实际支撑的关系。这里的D2a材料/工具贡献与formal output分开；宽泛来源设计关联只保存在JSON `design_associations`，不得用于累计完成状态。#280为设计控制文档，没有单项产品主落点。','','| PR / merged SHA | 已交付能力 | primary J / supporting J | 验收限制与证据 |','|---|---|---|---|']
for r in d['prs']:
 section.append(f"| #{r['pr']} `{r['merge_commit'][:8]}` | {r['capability']} | {r['primary_j'] or '无产品主项'} / {', '.join(r['supporting_j']) or '—'} | {r['limits']}；`{r['evidence_readme']}` |")
section+=['','以上28个相关合并PR是证据库存，不是进度分母；#287是issue不计为实施PR。JSON提供每条完整mergedSHA、精确改动路径、primary_j、supporting_j、scope_relation与acceptance_limit。','','更早#272/#273/#281提供严格规范化/共享合同/来源检查，#274/#284/#286提供home/broker离线规格及组合证据。#281仅J02a source inspection，#284仅JP-17a离线schema_spec，不能升级完整采用闭包或部署broker。#277/#278/#279为真实Session修复，不能升级全恢复旅程。','', '独立C按固定main e26核对：126个formal gate仍specified_not_run，32项milestone没有完整验收。这个结论不否认上表可用组件/脚本/材料；它只限制formal验收声明。J15四入口可用不等于持久问答与授权接线，J19连续性材料不等于隔离检索与经验晋升。','']
md=md[:a]+'\n'.join(section)+'\n'+md[b:];(p/'pstack-map.md').write_text(md)
print('json',hashlib.sha256((p/'pstack-map.json').read_bytes()).hexdigest());print('md',hashlib.sha256((p/'pstack-map.md').read_bytes()).hexdigest())
