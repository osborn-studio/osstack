# pstack能力交付对账

固定主线 `e26f6d2ca81628b565d2db0fd047fcb041fa8a45`；原始pstack `99b609a72323b70204eab407c622f436e858e112`。本报告只读，不改账本或资格。合并事实来自本地Git一父链与祖先验证，PR301 Ready状态由主线程当前快照提供，未另行查询实时forge。

## 核心结论

已合并的实际能力是：13种共享工程方法、4个可导出入口、真实本地验证driver与两feature旅程、保留证据及模型包投影。它们已经可作为材料或工具使用，不应该因为正式J门槛未完成就一概写成“未实现”。但方法文件、导出、有限宿主读取，也不能算整个pstack能力组或联合runtime已完成。

PR301的并行/简报指南仍待合并；skill-authoring第14方法仍是未发布候选。本次不把二者计入主线13方法。

## 合并事实与实际交付落点

每条仅一个primary J主落点，supporting J最多三项有实际支撑的关系。这里的D2a材料/工具贡献与formal output分开；宽泛来源设计关联只保存在JSON `design_associations`，不得用于累计完成状态。#280为设计控制文档，没有单项产品主落点。

| PR / merged SHA | 已交付能力 | primary J / supporting J | 验收限制与证据 |
|---|---|---|---|
| #272 `baf88ea3` | 严格raw JSON与canonical digest基础 | J01 / J02 | 组件实现/向量；不是完整J01 contracts或主机验收；`packages/protocol/src/joint-json.ts` |
| #273 `69859eec` | 共享方法/证据/资格合同与schema | J01 / J04, J07 | 严格合同/正负例；不证明JA01/02真实host权限和完成语义通过；`docs/implementation/joint-contracts-retarget/README.md` |
| #274 `baee1f6a` | home恢复schema/DDL/held fixture规格 | J11 / J12 | 规格和离线fixture；不部署恢复构建/生产迁移，不放行J12；`docs/implementation/joint-recovery-retarget/README.md` |
| #275 `a5fef9c4` | Firstmate行为能力输入契约 | J02 / J01 | Firstmate R01组件支撑共用边界；不是pstack方法启用或J02b整体；`packages/protocol/src/behavior-capability.ts` |
| #276 `28d116f3` | 行为注册表加载器组件 | J02 / J10 | Firstmate R02组件；不得视为采用闭包、运行准入或独立principal资格；`packages/core/src/behavior-registry.ts` |
| #277 `4924d224` | Session应用回执持久化修复 | J31 / J03 | 真实产品修复；完成回合不升级local_verified，非全恢复旅程；`packages/cli/src/session-send-receipt.test.ts` |
| #278 `0f6dc137` | Session start失败清理保全修复 | J31 / J03 | 实际daemon路径；保守保留未知状态，不代表J12恢复或终端全部能力；`docs/implementation/joint-session-cleanup-retarget/README.md` |
| #279 `d3fa7ef6` | Session terminal fence与释放语义 | J31 / J12 | 当前stop确认/失败回执边界；非全宿主进程树终止证明；`docs/implementation/joint-terminal-post282/README.md` |
| #280 `e9a9656a` | 联合设计和来源/交付文档主入口 | 无产品主项 / J26 | 设计/交付控制文档；无单一产品J实现，primaryJ为空不强贴一个完成项；`docs/design/2026-10-27-joint-engineering/README.md` |
| #281 `8fed8313` | J02a有界Git来源检查与快照 | J02 / J26 | source_inspection不冒充闭包snapshot；J02b来源认证/接收schema/实际采用闭包仍未实现；`docs/implementation/joint-source-retarget/README.md` |
| #282 `ede5aadc` | 行为注册表审计确认问题修复 | J02 / J10 | 加载器负缓存/预算/严格字段等加固；不自动签资格或runtime激活；`docs/implementation/joint-behavior-retarget/README.md` |
| #283 `697d0b9c` | J01组件与J08真实host边界设计分层 | J01 / J08 | 冻结设计/验证器修订；JA01/02原义务保留，未签任何gate；专属host入口为设计而非已接线；`docs/implementation/joint-nextwave-control/README.md` |
| #284 `3192b424` | broker schema/DDL/orphan离线规格 | J17 / J11 | J17.schema_spec生产者文件/离线测试；未部署broker、未分配生产schema、J11/J17不因此通过；`docs/implementation/joint-broker-spec/README.md` |
| #285 `bc061aeb` | JA59/70组件回归与跨语言校验 | J01 / — | 作者预期/独立语言回归，不是可信oracle；J01.contracts、JA59/70正式验收仍不签发；`docs/implementation/joint-contract-acceptance/README.md` |
| #286 `fd9cac81` | home与broker恢复离线组合验证 | J11 / J17, J12 | JA20/47调查材料/离线组合；非J01/J11/J17正式通过或runtime恢复实现；`docs/implementation/joint-recovery-composition/README.md` |
| #288 `4d31c3f5` | 四方法+真实回答回执验证工具 | J03 / J06, J09 | 确定性CLI→daemon→SQLite；不是真provider或正式方法准入；`docs/implementation/verification-kit/README.md` |
| #289 `64b203c3` | skills check实际失败退出码修复 | J09 / J03 | 同输入missing-ref RED→GREEN；不是宿主自主修复证明，smoke脚本由291补齐；`docs/implementation/skills-check-exit/README.md` |
| #290 `f92914e0` | 两宿主历史证据读取+证据指南修正 | J23 / J07, J25 | 只读已修复缺陷材料；无现场产品驱动，无因果收益；Claude存在未读误称未提供；`docs/implementation/joint-host-effects/README.md` |
| #291 `9debb0f9` | 可重复五case skills-check验证 | J03 / J06 | 实际healthy/missing-ref/drift/mixed/empty；不是任意应用生成器；宿主辅助实验非全项通过；`docs/implementation/skills-check-verification/README.md` |
| #292 `ca95aba1` | 四命名入口+Codex/Claude可导出布局 | J15 / J04, J23 | 导出不是安装；四入口不等于四方法，scope不含MethodBinding；`docs/implementation/osstack-method-entrypoints/README.md` |
| #293 `38eb42c0` | feature/refactoring两方法+有限原生发现实验 | J06 / J23 | 材料累计6；Claude help原生读取限定通过；Codex整体观测不充分，非全方法使用；`docs/implementation/method-feature-refactoring/README.md` |
| #294 `42dbdb0a` | 两feature验证旅程+实际回执/功能地图 | J03 / J06, J07 | 固定healthy/missing-ref；coordinator运行并非模型自主；Claude507词停止，Codex phase2记录env边界失败；`docs/implementation/method-verification-journey/README.md` |
| #295 `70924ee4` | 独占模型证据投影包 | J07 / — | exact2files/closed schema/保留失败未知；不认证producer/重跑原checker/提高任务完成等级；`docs/implementation/method-evidence-projection/README.md` |
| #296 `92088fe5` | 代码审查第7方法+packet读取实验 | J07 / J06, J23 | 实际代码审查质量未由导出证明；packet Codex有限/Claude515词失败，不修复旧实验；`docs/implementation/method-code-review/README.md` |
| #297 `711c45e7` | 影响面与性能测量第8/9方法 | J06 / J29 | 方法/导出/静态挑战；不等于运行真实profile或完成性能改进；`docs/implementation/method-impact-performance/README.md` |
| #298 `a9e480d3` | 任务深化与架构第10/11方法 | J06 / J05 | 方法可读；架构执行价值无完整宿主验证；`docs/implementation/method-framing-architecture/README.md` |
| #299 `7d3fc2bf` | 会话连续性第12方法+framing实际实验 | J19 / — | 不接线恢复runtime；framing两host均LIMITED，不能记continuity宿主通过；`docs/implementation/method-continuity-delivery/README.md` |
| #300 `e26f6d2c` | PR readiness第13方法+4合成PR分类实验 | J30 / J07 | 方法为一次状态/授权修复；无默认watcher；Codex LIMITED/Claude FAILED，无实际forge修复/merge；`docs/implementation/method-pr-readiness-delivery/README.md` |

以上28个相关合并PR是证据库存，不是进度分母；#287是issue不计为实施PR。JSON提供每条完整mergedSHA、可重放merge差异清单摘要、primary_j、supporting_j、scope_relation与acceptance_limit。

更早#272/#273/#281提供严格规范化/共享合同/来源检查，#274/#284/#286提供home/broker离线规格及组合证据。#281仅J02a source inspection，#284仅JP-17a离线schema_spec，不能升级完整采用闭包或部署broker。#277/#278/#279为真实Session修复，不能升级全恢复旅程。

独立C按固定main e26核对：126个formal gate仍specified_not_run，32项milestone没有完整验收。这个结论不否认上表可用组件/脚本/材料；它只限制formal验收声明。J15四入口可用不等于持久问答与授权接线，J19连续性材料不等于隔离检索与经验晋升。

## 24组能力状态

| PS | 状态 | 已有与缺口 | J项 |
|---|---|---|---|
| PS01 单入口任务路由与渐进方法组合 | 部分已交付 / 完整能力待验证 | 13共享方法、四入口路由/帮助；没有单一runtime编译/强制执行通道 | J04, J05, J06, J08, J09, J10, J15, J16, J32 |
| PS02 代码机制与历史动机取证 | 部分已交付 / 完整能力待验证 | investigation可用；how/why/teach为方法吸收，没有专门历史取证工具或全面效果验证 | J05, J06, J07 |
| PS03 意图校准与可纠正的问题模型 | 部分已交付 / 完整能力待验证 | task-framing已合并；实际两宿主均LIMITED，尚非任务执行收益证明 | J01, J05, J06, J15, J25 |
| PS04 从使用草图到原型证据的架构循环 | 部分已交付 / 完整能力待验证 | architecture/feature/refactoring可用；独立多原型arena和完整采纳循环未交付 | J05, J06, J18 |
| PS05 覆盖式并行与预先声明的竞赛 | 候选未合并 | 301含覆盖式并行指南；无新增公平调度/竞赛执行器 | J17, J18 |
| PS06 独立评审与意见裁决 | 部分已交付 / 完整能力待验证 | code-review材料+本项目独立审查审计实践；产品化跨模型评审/资格未闭合 | J06, J07, J09, J04, J25 |
| PS07 影响面与关键前提验证 | 部分已交付 / 完整能力待验证 | change-impact材料/关键前提检查；普遍宿主效果未验证 | J05, J06, J07 |
| PS08 可操控的验证基础设施与功能地图 | 部分已交付 / 完整能力待验证 | create-verification材料+两种真实CLI例子/五case driver/两行journey；任意项目自动生成完整旅程未证明 | J03, J06, J09 |
| PS09 验证基础设施的健康、归属与漂移维护 | 部分已交付 / 完整能力待验证 | maintain材料+健康/归属/清理验证；尚无完整功能地图漂移维护的真实缺陷闭环 | J06, J10, J23 |
| PS10 形式化验证生命周期 | 暂缓 / 本批未实现 | 形式化生成/维护与代码mutation对应尚未作为pstack能力实现 | J22, J28 |
| PS11 状态图与反例解释 | 暂缓 / 本批未实现 | 状态图/反例解释工具未移植，不把普通Mermaid文档当模型检验 | J06, J22, J28 |
| PS12 反思转结构化约束 | 候选未发布 | 9c技能创建维护吸收reflect/correct局部，尚未发布；持久经验draft→评审→采纳机制未闭合 | J19 |
| PS13 决策轨迹与证据归因 | 部分已交付 / 完整能力待验证 | 原始回执/manifest/hash/错误保留及安全投影已可用；证据完整性不认证身份/历史真实性 | J04, J07, J16, J19 |
| PS14 性能结论审查 | 部分已交付 / 完整能力待验证 | 性能审查方法与合成数例可用；无因果性能提升结果 | J25, J29 |
| PS15 有预算的 hillclimb 与盲评 | 暂缓 / 本批未实现 | 有预算hillclimb/盲评尚未实现；当前有限host probe不是效果benchmark | J13, J25, J29 |
| PS16 自包含单元与协调者边界 | 候选未合并 | 301协作brief/覆盖/共享资源指南；现会话多agent是工程实践非新增控制runtime | J13, J16, J17, J18, J19 |
| PS17 栈前沿与候选绑定验证 | 部分已交付 / 完整能力待验证 | PR readiness材料+候选绑定实践；栈前沿自动校验服务未接线 | J01, J07, J18, J30 |
| PS18 forge 观察器分类 | 部分已交付 / 完整能力待验证 | 一次forge状态分类方法；未移植watch-pr观察器，不把既有github组件当本批新增 | J30 |
| PS19 暂停与恢复对账 | 部分已交付 / 完整能力待验证 | session-continuity材料可用；恢复schema/spec不等于J12运行态恢复 | J12, J16, J19 |
| PS20 跨宿主方法适配 | 部分已交付 / 完整能力待验证 | 四入口双host导出，有限读取/native help观察；无全方法等价/强制context/资格激活 | J02, J04, J10, J23 |
| PS21 来源快照与能力资格验证 | 部分已交付 / 完整能力待验证 | 更早281来源快照组件与合同、292材料源清单；实际采用闭包/资格/漂移激活未闭合 | J02, J08, J10, J26, J01 |
| PS22 事件 intake 与补偿模式 | 暂缓 / 本批未实现 | Benny/外部事件intake补偿未启用或移植 | J22, J28 |
| PS23 使用方式驱动的接口与文档设计 | 部分已交付 / 完整能力待验证 | caller-first architecture、验证材料与文档；三条冻结地图和冷用户验收未全通过 | J03, J06 |
| PS24 历史上下文恢复与可理解的决策说明 | 部分已交付 / 完整能力待验证 | continuity/解释+301简报候选；无全局记忆自动化；视频/Bot/个人风格暂缓 | J06, J16, J19, J20 |

## 宿主实际使用不能合并成一个PASS

- #290：显式读取历史RED/GREEN并给诊断，不是现场修复或原生发现；Claude有已提供未读误称缺失。
- #293：Claude v2限定help原生调用与两引用读取通过；Codex目录/执行分进程、原始完整前态及resolved model缺口，整体inconclusive。
- #294：协调者执行一次真实driver，不是模型自主执行。Claude阶段1超507词停止；Codex阶段2读取所提供的环境记录违反冻结字面边界，非live凭据泄露。
- #296：packet读取Codex有限，Claude515词违反500限制；不是新code-review方法的真实行为验证。
- #299：实验测已合并task-framing，不测新continuity；两host均LIMITED，Claude比较构建/未来交付范围有缺口。
- #300：真实模型只对合成PR材料分类，Codex LIMITED、Claude FAILED；未执行真实forge修复，不能用正确分类外推完整PR闭环。

## 最优先补齐的完整缺口

### 1. 真实项目验证维护闭环

为现有两feature地图建立源码变化→漂移检测→区分文档/harness/product→同路径重验→保留失败的完整实用维护流程；先覆盖一个真实已确认漂移或缺陷，不制造缺陷冒充现场问题。

验收：原始变化与失败、原地图全部行状态、分类依据、授权内修复、相同driver GREEN、blocked不删场景、cleanup后原始证据仍可核验。

边界：D2a实际工具增量可继续；不得声称冻结J03/J09通过。

### 2. 宿主真正完成一个可复用bug-fix工作单元

在已知授权的隔离真实仓库/固定缺陷上完成读取方法→真实RED→修复→相同GREEN→报告，至少一个宿主完整闭环；另一个按同源场景独立验收，不以模拟回答或coordinator代执行冒称原生自主。

验收：独立冻结输入/成功与非目标判据，真实工具动作/候选/source-build/前后态/失败/清理可核验；不靠模型自报或只看词数；未知identity保留。

边界：事前明确执行权限与预算；不改变J身份/激活规则，不承诺跨宿主等价或因果收益。

### 3. 单一用户能力进度投影

将29大卡、PS24组/J工作、实际文件、merge事实、证据等级和下一缺口连为一个只读可查询清单；中央统一维护，历史波次仍不可改写。

验收：每卡有归属能力/范围/证据/merge状态；候选不算merged；已合并方法不被planned门槛遮蔽；formal gate与D2a可用性双列；任何总数有明确分母。

边界：不新增数据库/另一控制面；不把本对账当既已完成该工具。

## 29大卡与旧账本的读法

主线execution-ledger顶层仍指向 `92088fe55a2f985ca743fa1fabee0c081a6f672d`，next_continuity_wave仍保留 `ready_waiting_user_merge`。这些是历史快照，不是#299尚未合并的证明。需要统一投影，而不是反复新增孤立波次。

本任务未读取实时OSStack看板，不能伪造29卡逐ID完整对账。主线程应将真实卡列表与本报告PS/J/PR/文件证据相连：每卡展示已交付子能力、仍缺验收、当前候选和下一动作。不要用PR数或13/58推算完成百分比；58上游skills、23playbooks、24PS组、32J项和29看板卡不是同一种分母。

原始来源锚点、文件摘要、每个PR合并diff清单摘要/重放命令和能力映射完整保存在同目录pstack-map.json。未调用模型、全仓测试、产品CLI或默认数据库。
