# 看板机制核对（只读）

实际快照：2026-10-29T04:25:11Z，显式管理 socket `/tmp/osstack-debt-ledger.sock`，已安装 CLI 0.22.1。只执行三次 `kanban.board`，均包含 archived；未打开数据库、运行开发 CLI 或写卡。

| 看板 | 总卡数 | 状态 |
|---|---:|---|
| joint-firstmate-pstack | 71 | todo 29 / ready 1 / running 4 / blocked 2 / done 35 |
| firstmate-upgrade-roadmap | 50 | todo 35 / blocked 6 / done 9 |
| session-pilot-debt | 13 | todo 3 / blocked 2 / done 8 |

联合看板的 J01–J32 **恰好32项**：todo29、ready1（J02）、running2（J01/J11）、done0。其余39张小卡：done35、running2、blocked2，混有交付、验证、预检和协调活动。此处是看板状态，不是重新判定验收；不能把35张小卡的done作为J里程碑完成率。全部134卡的原生parent/child计数都是0，meta及task_id均为null。文字body/comments可能存在叙述关联，本次没有声称它们全部不存在。

## 已有能力及缺口

安装版core已有`link(parent_id, child_id)`和`kanban_card_links`，但语义是依赖排序，不是业务里程碑子任务汇总。链接可跨看板建立，单看板拓扑却排除跨板边；插入仅拒绝自环/缺端点，环在后续拓扑计算时才发现。不能直接把这种边当作任意业务父子关系。

**正在运行的daemon未暴露kanban.link/unlink/patch/update RPC。** 已有RPC为board、create、move、comment及订阅/事件方法。core有meta字段，但daemon create不转发meta/task_id/card_type；core patch仅支持title/body/priority/assignee，且未暴露通用RPC。不可虚构payload，也不应绕到直连数据库或stack导入命令补关系。

状态枚举为triage/todo/ready/running/blocked/done/archived；archived只允许回triage，其他转换宽松。状态本身不保证验收门槛，也没有原生父项完成度汇总。

## 最小可行整理

1. 由主线程在既有联合设计目录提交一份轻量映射，分开workstream/capability/milestone/delivery/verification/coordination；记录实际card ID、来源能力、owner、PR/证据和关系类型。`contributes_to`、`verifies`与`requires`分开，未知归属保留未定。
2. pstack优先工作可以按工作流→能力→具体交付→验证活动整理；只有材料确实对应J验收时才建立支持关系，不把D2a材料落地等同J运行时资格完成。Firstmate原看板和J正式验收保留独立统计。
3. 映射确认提交后，主线程可用现有`kanban.comment`给已有卡追加不可变映射链接与ID；未来create在body记录结构化文字。这里不修改现卡，不发送不支持的meta/parent参数。
4. 汇报分四栏：32项J验收状态、pstack能力覆盖、具体交付/PR状态、验证和协调活动。父项以验收证据收口，不以子卡done数量自动晋升。

JSON内给出精确只读payload与**尚未执行、须填入已审映射**的comment示例；安装版源码行号、全文hash和节选均随报告保留。链接/元数据写RPC若未来需要，可独立立项；本次无需新产品开发即可先纠正统计与逻辑归属。
