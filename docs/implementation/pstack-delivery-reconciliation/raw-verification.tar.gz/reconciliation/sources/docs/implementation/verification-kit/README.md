# Verification kit：第一批可使用的工程方法

本批优先吸收 pstack 的真实验证、功能地图、证据保全、缺陷修复和验证维护方法。基于 main `fd9cac8127dbfa5660d9c45e58a42da5ed642073`，属于联合主线程设计 D2a 的工程工具增量。它不建立第二套控制数据库、不新增方法授权，也不宣告 D2a 全旅程或 J01/J03/J04/J09 正式通过。

## 本批交付

- 在现有真实 CLI → 独立 daemon → SQLite 的回答回执 smoke 上增加只读预检、执行计划和清理后可复查的证据。
- [单功能地图](feature-map.md)按用户行为界定检查范围；确定性 Adapter 的结果不能外推到真实 Provider。
- [共用方法材料](../../../osstack-methods-skill/SKILL.md)由 Codex、Claude 显式读取，覆盖 investigation、bug-fix、create-verification 和 maintain-verification。不自动安装、不修改宿主配置，不要求固定模型。
- 审计、失败、验证候选和测试范围随交付记录保存；用户仍是 PR 审批与合并者。

## 推进顺序

| 批次 | 用户可得到的能力 | 放行证据 |
|---|---|---|
| 当前 | 一个真实功能的启动、预检、驱动、证据、清理闭环；四条共用方法材料 | 精确候选测试、实际 smoke、无副作用预检检查、Sonnet 审计 |
| 下一批 | 同一缺陷 RED→修复→相同路径 GREEN；功能地图漂移检查 | 实际缺陷与反例、保留失败记录；材料可读不等于宿主实际执行成功 |
| 随后 | Codex 与 Claude 的同任务接续、受限方法调用 | 对应宿主真实旅程；产品授权入口遵守既有 J01/J09 门槛 |
| 后续 | 多候选审查、PR 栈组合验证、经验结构化 | 独占写边界、head/base 绑定、独立检查与失败处置 |
| 专项 | 性能实验、盲评、形式化、外部事件 | 各自实验设计、预算和准入；不以单元测试替代 |

这是按价值排队，不是删除附件中的其余能力。34 个操作技能、24 个原则和23个 playbook 的研究映射仍以[来源目录](../../reports/2026-10-26-pstack/capability-catalog.md)及[联合能力映射](../../design/2026-10-27-joint-engineering/capability-index.md)为准。展示视频、个人风格、Bot UI 不占用本批交付顺序。

## 边界与账本

用户本轮明确恢复开发，取代此前设计暂停；旧 bootstrap/C30 未交付工件保持隔离。本批 OSStack 卡片为 `card_f2a2453a`。J01 身份准备 issue #287 仍待用户确认，只约束其对应的正式资格，不阻塞本批工具改进。跨宿主材料、确定性 fixture、正式方法准入是三个不同的状态；不能通过重命名状态把前者当作后者。

## 交付证据

[PR #288](https://github.com/osborn-studio/osstack/pull/288) 的精确候选、测试边界与限制见 [delivery.json](delivery.json)。实际 Sonnet 首轮 REVISE、修订后 PASS 与处置见 [audit.md](audit.md)；完整原始记录、失败和内容清单保存在 `evidence.tar.gz` 与 `evidence-manifest.json`。是否可以合并以该 PR 最新 head 的 GitHub 检查和 OSStack 卡片为准，不用旧 head 的检查替代。
