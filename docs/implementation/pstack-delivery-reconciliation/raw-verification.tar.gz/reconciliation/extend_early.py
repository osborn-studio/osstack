from pathlib import Path
import subprocess,json,re,hashlib
out=Path(__file__).parent;p=out/'pstack-map.json';d=json.loads(p.read_text());repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';main=d['main'];merges={}
for l in subprocess.check_output(['git','-C',repo,'log',main,'--first-parent','--format=%H %s'],text=True).splitlines():
 m=re.match(r'(\w+) Merge pull request #(\d+) ',l)
 if m:merges[int(m[2])]=m[1]
data={
272:('严格raw JSON与canonical digest基础',['J01'],['J02','J07','J11'],['PS13','PS21'],'packages/protocol/src/joint-json.ts','组件实现/向量；不是完整J01 contracts或主机验收'),
273:('共享方法/证据/资格合同与schema',['J01'],['J02','J04','J07','J08','J11'],['PS03','PS13','PS20','PS21'],'docs/implementation/joint-contracts-retarget/README.md','严格合同/正负例；不证明JA01/02真实host权限和完成语义通过'),
274:('home恢复schema/DDL/held fixture规格',['J11'],['J12','J17','J24'],['PS19','PS21'],'docs/implementation/joint-recovery-retarget/README.md','规格和离线fixture；不部署恢复构建/生产迁移，不放行J12'),
275:('Firstmate行为能力输入契约',['J02'],['J01','J04','J10','J23'],['PS20','PS21'],'packages/protocol/src/behavior-capability.ts','Firstmate R01组件支撑共用边界；不是pstack方法启用或J02b整体'),
276:('行为注册表加载器组件',['J02'],['J04','J08','J10','J23'],['PS20','PS21'],'packages/core/src/behavior-registry.ts','Firstmate R02组件；不得视为采用闭包、运行准入或独立principal资格'),
277:('Session应用回执持久化修复',['J31'],['J03','J07','J16'],['PS08','PS13','PS19'],'packages/cli/src/session-send-receipt.test.ts','真实产品修复；完成回合不升级local_verified，非全恢复旅程'),
278:('Session start失败清理保全修复',['J31'],['J03','J11','J12'],['PS08','PS13','PS19'],'docs/implementation/joint-session-cleanup-retarget/README.md','实际daemon路径；保守保留未知状态，不代表J12恢复或终端全部能力'),
279:('Session terminal fence与释放语义',['J31'],['J12','J16','J23'],['PS13','PS19'],'docs/implementation/joint-terminal-post282/README.md','当前stop确认/失败回执边界；非全宿主进程树终止证明'),
280:('联合设计和来源/交付文档主入口',[],['J01','J11','J26'],['PS13','PS21'],'docs/design/2026-10-27-joint-engineering/README.md','设计/交付控制文档；无单一产品J实现，primaryJ为空不强贴一个完成项'),
281:('J02a有界Git来源检查与快照',['J02'],['J01','J08','J10','J26'],['PS21'],'docs/implementation/joint-source-retarget/README.md','source_inspection不冒充闭包snapshot；J02b来源认证/接收schema/实际采用闭包仍未实现'),
282:('行为注册表审计确认问题修复',['J02'],['J04','J08','J10','J23'],['PS20','PS21'],'docs/implementation/joint-behavior-retarget/README.md','加载器负缓存/预算/严格字段等加固；不自动签资格或runtime激活'),
283:('J01组件与J08真实host边界设计分层',['J01','J08'],['J11','J17','J26'],['PS13','PS21'],'docs/implementation/joint-nextwave-control/README.md','冻结设计/验证器修订；JA01/02原义务保留，未签任何gate；专属host入口为设计而非已接线'),
284:('broker schema/DDL/orphan离线规格',['J17'],['J11','J12'],['PS19','PS21'],'docs/implementation/joint-broker-spec/README.md','J17.schema_spec生产者文件/离线测试；未部署broker、未分配生产schema、J11/J17不因此通过'),
285:('JA59/70组件回归与跨语言校验',['J01'],['J02','J08','J11'],['PS13','PS21'],'docs/implementation/joint-contract-acceptance/README.md','作者预期/独立语言回归，不是可信oracle；J01.contracts、JA59/70正式验收仍不签发'),
286:('home与broker恢复离线组合验证',['J11','J17'],['J12','J24'],['PS19','PS21'],'docs/implementation/joint-recovery-composition/README.md','JA20/47调查材料/离线组合；非J01/J11/J17正式通过或runtime恢复实现')}
early=[]
for n,(title,primary,support,ps,evidence,limit) in data.items():
 sha=merges[n];assert subprocess.run(['git','-C',repo,'merge-base','--is-ancestor',sha,main]).returncode==0
 b=subprocess.check_output(['git','-C',repo,'show',main+':'+evidence]);d['source_bindings'].append({'repository':repo,'revision':main,'path':evidence,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 early.append({'pr':n,'merge_commit':sha,'mergedSHA':sha,'state':'merged_in_snapshot','capability':title,'delivered_capability':title,'primaryJ':primary,'supportingJ':support,'J_classification':'analytical association, not completed milestone','pstack_groups':ps,'joint_work_items':primary+support,'primary_artifacts':[evidence],'evidence_readme':evidence,'limits':limit,'acceptance_limit':limit,'changed_paths':subprocess.check_output(['git','-C',repo,'diff','--name-only',sha+'^1',sha],text=True).splitlines(),'formal_joint_gate_pass_asserted':False})
primary={288:['J03','J06'],289:['J09'],290:['J23','J25'],291:['J03','J06'],292:['J02','J04'],293:['J06','J23'],294:['J03','J06'],295:['J07'],296:['J07','J06'],297:['J06','J29'],298:['J05','J06'],299:['J19'],300:['J30']}
for r in d['prs']:
 r['mergedSHA']=r['merge_commit'];r['delivered_capability']=r['capability'];r['primaryJ']=primary[r['pr']];r['supportingJ']=[j for j in r['joint_work_items'] if j not in r['primaryJ']];r['acceptance_limit']=r['limits'];r['J_classification']='D2a contributor mapping only, not formal milestone completion'
d['prs']=sorted(early+d['prs'],key=lambda r:r['pr']);d['scope_note']='28 relevant merged PRs in 272–300; #287 is not a merged implementation PR here. This count is evidence inventory, not progress or the user\'s 29 cards.'
for c in d['pstack_capabilities']:c['merged_prs']=[r['pr'] for r in d['prs'] if c['id'] in r['pstack_groups']]
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
md=(out/'pstack-map.md').read_text();block=['## 较早共享基础与产品修复（272–286）','','此表是来源/支撑关系，不是用Firstmate基础工作冒充pstack完整体验。primaryJ为分析归属，子规格名称以原始证据为准。','','| PR / merged SHA | 已交付能力 | primary J / supporting J | 验收限制 |','|---|---|---|---|']
for r in early:block.append(f"| #{r['pr']} `{r['merge_commit'][:8]}` | {r['capability']} | {','.join(r['primaryJ']) or '无单项实现'} / {','.join(r['supportingJ'])} | {r['limits']}；`{r['evidence_readme']}` |")
block+=['','272–300中的28个相关合并PR只构成证据索引。#287不在合并实施PR清单；这28条既不是29张大卡，也不是完成率。机器JSON为每条提供完整mergedSHA、delivered_capability、primaryJ、supportingJ、acceptance_limit与merge diff路径。','']
md=md.replace('## 已合并交付逐项落点','\n'.join(block)+'\n## 已合并交付逐项落点');(out/'pstack-map.md').write_text(md)
print('total relevant PR records',len(d['prs']))
