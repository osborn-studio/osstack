**REVISE**

I read the pasted files only. I did not open `raw-verification.tar.gz`, re-run anything, or query the live board. The checks below are from cross-reading the pasted rollup, status doc, action log and board dump.

## Confirmed findings

**F1. Two PR #301 activity cards have stale re-read metadata, and no move receipt in the attached log.**
- `card_2cccba22` and `card_be3dc4a2` carry `new_fact.board_status_reread: false` and `recommended_status: "done…"`. The same objects carry `current_board_observation.status: "done"` at 04:39:34. Both cannot hold.
- `activity_counting.PR301_two_status_changes` still says the report "does not pretend stale board snapshot was reread", which no longer matches.
- `board-rollup-actions.jsonl` has no `kanban.move` for either card. Both cards show `completed_at` ≈ 1793248600.31 in `boards-after-rollup.json`, earlier than every logged mutation (≥ 1793248774.51).
- `delivery-status.md` says the two cards were closed per the new merge fact. That is observed on the board, but the attached log does not show who moved them or when.
- Fix: update the stale flag and note, and attach or cite the receipt for those two moves. If the receipt is in the tar.gz, only the stale flag is wrong.

**F2. The PR #301 PS mapping is not bidirectional at activity level.**
- `card_be3dc4a2` (evidence.md and pr-readiness.md, the compact report and evidence material shipped in #301) credits PS13 and PS17.
- #301's `pstack_groups` are PS05, PS16, PS18, PS19, PS24. PS13 and PS17 are not in that list, and neither PS's `merged_prs` contains 301.
- Conversely, PS18, PS19 and PS24 cite "PR301 compact report/evidence attribution" in their text, but neither #301 activity card credits those PS entries. `card_2cccba22` credits only PS05 and PS16.
- Fix: pick one direction. Either add PS13/PS17 to #301's groups and their `merged_prs`, or drop them from `card_be3dc4a2`. Also state which activity card backs PS18, PS19 and PS24.

**F3. `delivery_dimensions.delivered` diverges from the status doc and `delivered_or_reusable`.**
- J26: the dimensions field says "capability index、交付账本、离线validator及实际feature-map已有材料". The doc and `delivered_or_reusable` say "capability-index、交付账本及文档schema校验已存在；当前新增交付投影仅候选…".
- "实际feature-map" is not backed by J26's `evidence_paths`, and "离线validator" names no file. This is the only J item where `delivered_or_reusable` and `delivery_dimensions.delivered` differ materially.
- J15's dimensions field also omits the PR #301 sentence that the doc row and `delivered_or_reusable` carry.
- Fix: sync both fields to the doc text.

**F4. The legacy `suggested_board_status` contradicts the new started flag.**
- It holds maturity labels, not board statuses, and now sits beside `proposed_board_status` and `observed_board_status`.
- J10, J13, J14, J20 and J24 are labelled `partial_engineering_not_formally_accepted` but have `engineering_slice_started: false` and `proposed_board_status: todo`. A consumer filtering on the label would count five unstarted items as engineered.
- Fix: drop the field, rename it to a maturity field, or define it as "pre-existing foundation".

## Checked, no finding

- **Prior B1:** `board_execution_status` is gone. Observed, proposed and started are separate fields. 20 running and 12 todo in the rollup match `boards-after-rollup.json` and the receipts: 18 moves plus J01 and J11 already running. All 32 milestone comments are present, and the comment counts rise by exactly one.
- **Activity counts:** 39 cards, 37 done and 2 running, match the board. The task-kind sum is 39, and the old snapshot is labelled historical.
- **Prior B2, PS301 PR level:** #301's PS05, PS16, PS18, PS19 and PS24 each list 301 in `merged_prs`. J15 primary, J19 and J30 supporting match `primary_delivery_prs` and `supporting_prs`. PS24 no longer says "candidate".
- **Gap dimensions:** the distinct awaiting/unimplemented/unknown text matches the doc table.
- **Scope claims:** no formal gate is asserted, `formal_milestones_completed` is 0, and the 14th method is still a candidate.

## Optional items, left optional and not raised

- #301 lacks `merge_diff_inventory` and `J_classification`.
- The next-batch item 3 in the doc omits candidate SHA `9cbb463a`, though the JSON has it.
- The J26 validator path is not named.