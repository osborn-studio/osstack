import pathlib,json,subprocess,hashlib,datetime
S=pathlib.Path(__file__).parent;B=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/verification-kit-20261028/next-baseline');R=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-exit');O=S/'real-extra';O.mkdir(exist_ok=False)
env=json.loads((B/'environment.json').read_text());rows=[]
def run(name,args,cwd,extra=None):
 p=subprocess.run(args,cwd=cwd,env={**env,**(extra or {})},capture_output=True,timeout=45);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'argv':args,'cwd':str(cwd),'env_override':extra or {},'exit':p.returncode});(O/'commands.json').write_text(json.dumps(rows,indent=2));return p
origin=O/'origin';assert run('clone',['/usr/bin/git','clone','--no-hardlinks',str(B/'local-origin'),str(origin)],O).returncode==0
with (origin/'README.md').open('a') as f:f.write('Second fixture commit for real drift.\n')
assert run('add',['/usr/bin/git','add','README.md'],origin).returncode==0
assert run('commit',['/usr/bin/git','-c','user.name=Local Regression Fixture','-c','user.email=fixture@example.invalid','-c','commit.gpgsign=false','commit','-m','real drift'],origin).returncode==0
old=json.loads((B/'positive-input.json').read_text())['manifest']['sources'][0]['blessed_sha'];source={'id':'drift','origin':origin.as_uri(),'ref':'refs/heads/main','blessed_sha':old,'auto_minor':False};negative={**source,'id':'unreachable','ref':'refs/heads/not-present'}
results=[]
for name,sources,code in [('drift',[source],2),('mixed',[source,negative],1),('empty',[],0)]:
 h=O/(name+'-home');h.mkdir();config=h/'skills.config.yaml';config.write_text(json.dumps({'version':1,'sources':sources},indent=2)+'\n');before=hashlib.sha256(config.read_bytes()).hexdigest()
 p=run(name,['/opt/homebrew/opt/node@22/bin/node',str(R/'packages/cli/dist/bin.js'),'skills','check'],B/'cwd',{'OSSTACK_HOME':str(h)})
 results.append({'case':name,'expected_exit':code,'actual_exit':p.returncode,'manifest_sha256':before,'manifest_unchanged':before==hashlib.sha256(config.read_bytes()).hexdigest(),'stdout':p.stdout.decode()});assert code==p.returncode
if not all(x['manifest_unchanged'] for x in results):raise AssertionError('manifest mutation')
(O/'results.json').write_text(json.dumps({'candidate_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'cases':results},indent=2)+'\n');print(json.dumps(results,indent=2))
