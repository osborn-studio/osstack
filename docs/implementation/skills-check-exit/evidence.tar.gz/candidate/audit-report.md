**Verdict: PASS** for the code and unit tests as shown. The evidence claims are only partly supported (see Evidence).

This is a read-only review of the pasted text. I ran nothing and could not confirm that the diff matches SHA `9a063b97…`.

## Correctness
- `packages/cli/src/skills-command.ts` `check` counts `failed` on `!entry.ok`, counts `drifted` on `ok && drifted`, and `continue`s after a failure so the two counts never overlap.
- The exit logic `failed > 0 → 1`, else `drifted > 0 → 2`, else `0` matches the spec:
  - any failure exits 1
  - drift-only exits 2
  - healthy or empty exits 0
  - mixed failure and drift exits 1, with both counts still printed
- It fixes the reported bug. In `watcher.ts`, `no_matching_ref` becomes `{ ok: false, drifted: false }`, which previously fell through to `return 0`.
- The other failure reasons (`timeout`, `spawn_failed`, `git_exit_N`, `could_not_parse_sha`) follow the same path, so they are fixed too.
- `bless` is unaffected. It already rejects `!entry.ok`.

## Compatibility
- **Output format:** the summary changes from one line to two (`N source(s) failed to check.` then `N source(s) drifted from blessed_sha.`). The drift line is still last and its text is unchanged, so parsers of the old last line keep working. The existing drift test's substring assertion still passes.
- **Exit code 1:** it now means either a check failure or a usage error (`add`, `remove`, `bless`, unknown subcommand). That is inherent to the requested semantics, but worth noting.
- **Unverified consumers:** I can't see the dispatcher, docs, hooks or CI scripts. Anything that treats "nonzero from `skills check`" as "drift" would now also fire on failures. Grep for `skills check` consumers and any documentation of exit code 2.
- **Help text:** it doesn't document exit codes. Adding them is optional and in scope, but not required.

## Tests
- The 9-case `it.each` covers every semantic you listed:
  - missing ref, timeout and spawn failure
  - failure before and after drift
  - multiple failures
  - drift-only, healthy and empty manifests
- It also asserts both count lines, per-entry lines, and that `writeManifest` is never called.
- Gaps, all non-blocking:
  - The unit tests stub `checkAll`, so the `lsRemoteHead` → `ok:false` mapping is only covered by the real-repo run, not by a test.
  - Count assertions use `toContain`. An exact-line match would be stricter, since `"1 source(s)…"` also matches inside `"11 source(s)…"`.
  - There is no case for `blessed_sha: null`, which `checkSource` reports as `ok:true, drifted:true`, so exit 2. That behavior is unchanged but untested. A fresh install with the starter manifest (all `blessed_sha: null`) therefore exits 2, not 0. That fits "drift" but not "healthy".

## Evidence
- Supported by the code: baseline exit 0 on a nonexistent ref is exactly what the baseline code would produce.
- Not shown: the compiled candidate run against the same isolated `file://` repo. The materials contain a baseline observation only. Before claiming the fix verified end to end, rerun it and report:
  - nonexistent ref → exit 1, with `1 source(s) failed to check.`
  - exact blessed main → exit 0
  - moved head → exit 2
  - ideally one mixed manifest → exit 1 with both counts
- Candidate behavior is currently supported by unit tests and code reading only.

## Out-of-scope risk (no action required here)
`lsRemoteHead` resolves on the child's `exit` event, not `close`. Stdout can in principle be unflushed at that point, which would produce a false `no_matching_ref`. Before this change that was silently exit 0. Now it would surface as exit 1. Consider a follow-up to switch to `close`. I did not count it against this fix.