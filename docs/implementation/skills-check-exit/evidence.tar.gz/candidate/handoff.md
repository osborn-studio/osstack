# Skills check exit handoff

Frozen two-file uncommitted candidate; source and patch digests in `freeze.json`.

Behavior: any returned `ok:false` entry produces exit 1, with failure taking precedence over drift; drift without failures retains exit 2; all current or an empty manifest retain exit 0. Summary prints failed and drifted counts separately. Existing source detail lines and drift wording are preserved. No watcher, manifest persistence, startup imports or dependency changes.

RED was executed before the implementation edit: 9 new cases failed and 3 existing cases passed. Six failures were wrong exit semantics (including mixed order); three were missing failure-summary output. GREEN: 12/12 passed. Raw stdout/stderr, actual command exit, argv/cwd/environment overrides and source hashes are retained in `red.*` and `green.*`. Only the targeted Vitest file was run.

Caller compatibility: `packages/cli/src/bin.ts` directly returns `handleSkillsCommand` at lines 1202–1204; `cli-entry.ts` forwards the main result to `process.exit(code)` at lines 47–48, so no numeric conversion or special handling masks 1/2. Repository search found no program parsing the old summary line. `hermes-command.ts` documents a scheduled invocation and naturally receives the corrected failure status. `symphony-cron-runner.sh` merely mentions this command in a comment and actually invokes its separate watcher. Existing bless/list tests remain green; new check tests assert no manifest write.

The tests inject the registry check boundary and never query their example.invalid origins. Earlier real local file:// CLI RED is independently retained in next-baseline. Owner must rebuild CLI and perform actual CLI GREEN, full-suite validation and model audit before publication. No formal source/adoption/runtime gate or independent-principal qualification is issued.

Targeted Biome check: 2 files checked, exit 0, no fixes applied. Candidate source digests unchanged.
