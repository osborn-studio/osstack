import subprocess,pathlib,json,hashlib,datetime,sys,shutil
r=pathlib.Path(__file__).parent
base=r
repo=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-exit')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
paths=['packages/cli/src/skills-command.ts','packages/cli/src/skills-command.test.ts','packages/skill-registry/src/watcher.ts','packages/skill-registry/src/manifest.ts']
prompt='Audit this small CLI bug fix. The real compiled baseline with an isolated local file:// Git repo and a nonexistent ref printed unreachable/no_matching_ref but exited 0; healthy exact blessed main exited 0. Expected new semantics: any check failure exit1, drift-only exit2, healthy/empty exit0, mixed failure/drift preserves both counts and failure wins. Inspect correctness, compatibility, tests, evidence claims. No unrelated gates, installation or runtime authorization changes. Return PASS or REVISE with concrete findings. No tools or execution. Candidate SHA: '+sha+'\n'
manifest=[]
for p in paths:
 b=(repo/p).read_bytes();manifest.append({'path':p,'sha256':hashlib.sha256(b).hexdigest()});prompt+='\n===== '+p+' =====\n'+b.decode()
prompt += '\n===== Candidate diff =====\n' + subprocess.check_output(['git','diff','HEAD~1','HEAD'],cwd=repo,text=True)
(r/'audit-input.txt').write_text(prompt)
args=['/opt/homebrew/bin/claude','-p','--model','claude-sonnet-5-5','--effort','high','--output-format','json','--disable-slash-commands','--tools','','--strict-mcp-config','--mcp-config',str(r/'empty-mcp.json'),'--safe-mode','--no-session-persistence','--permission-mode','dontAsk','--setting-sources','','--settings',str(r/'settings.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'audit-input.txt').open() as inp,(r/'audit-response.json').open('w') as out,(r/'audit-stderr.txt').open('w') as err:
 try: code=subprocess.run(args,cwd=r,stdin=inp,stdout=out,stderr=err,timeout=900).returncode
 except subprocess.TimeoutExpired: code=124
binding={'candidate_sha':sha,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'model_requested':'claude-sonnet-5-5','files':manifest,'prompt_sha256':hashlib.sha256((r/'audit-input.txt').read_bytes()).hexdigest(),'response_sha256':hashlib.sha256((r/'audit-response.json').read_bytes()).hexdigest()}
try:
 v=json.loads((r/'audit-response.json').read_text());binding['modelUsage']=v.get('modelUsage');binding['is_error']=v.get('is_error');(r/'audit-report.md').write_text(v.get('result',''));print(v.get('result',''))
except Exception as e: binding['parse_error']=str(e)
(r/'audit-binding.json').write_text(json.dumps(binding,indent=2)+'\n');print('exit_code',code)
