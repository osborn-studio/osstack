import pathlib,json,subprocess,hashlib,datetime
R=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-exit')
S=pathlib.Path(__file__).parent
B=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/verification-kit-20261028/next-baseline')
O=S/'real-candidate-final';O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
env=json.loads((B/'environment.json').read_text())
results=[]
files=[R/'packages/cli/src/skills-command.ts',R/'packages/cli/src/skills-command.test.ts',R/'packages/cli/dist/bin.js']
files += [p for p in sorted((R/'packages').glob('*/dist/**/*')) if p.is_file() and p not in files]
bindings=[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in files]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
for label,expected in [('negative',1),('positive',0)]:
 h=B/(label+'-home');manifest=h/'skills.config.yaml';before=sha(manifest.read_bytes())
 argv=['/opt/homebrew/opt/node@22/bin/node',str(R/'packages/cli/dist/bin.js'),'skills','check']
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(argv,cwd=B/'cwd',env={**env,'OSSTACK_HOME':str(h)},capture_output=True,timeout=45)
 (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 baseline=json.loads((B/'results.json').read_text());base=next(x for x in baseline['cases'] if x['case']==label)
 results.append({'case':label,'argv':argv,'cwd':str(B/'cwd'),'home':str(h),'manifest_sha256':before,'manifest_unchanged':sha(manifest.read_bytes())==before,'started_at':start,'expected_exit':expected,'actual_exit':p.returncode,'baseline_exit':base['exit_code'],'assertion_passed':p.returncode==expected,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)})
unchanged=all(sha((R/x['path']).read_bytes())==x['sha256'] for x in bindings)
report={'candidate_sha':head,'cases':results,'bindings':bindings,'bindings_unchanged':unchanged,'scope':'Same pre-existing local Git origin, ref, manifest bytes, cwd and isolated environment as baseline. Candidate CLI executable path changes with checkout. Source failure remains source failure; regression passes when CLI exits nonzero. No network or default home.'}
(O/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
assert unchanged and all(x['assertion_passed'] and x['manifest_unchanged'] for x in results)
assert 'no_matching_ref' in (O/'negative.stdout').read_text()
assert 'up-to-date' in (O/'positive.stdout').read_text()
