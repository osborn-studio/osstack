import os,sys,json,pathlib,subprocess,hashlib,datetime
s=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/skills-check-exit-20261028'); r=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-exit')
label=sys.argv[1]
env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:'+os.environ['PATH'],OSSTACK_HOME=str(s/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack');env.pop('OSSTACK_SOCKET',None)
argv=['pnpm','--filter','@osstack/cli','exec','vitest','run','src/skills-command.test.ts']
bindings={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in ['packages/cli/src/skills-command.ts','packages/cli/src/skills-command.test.ts']}
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(argv,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
(s/(label+'.stdout')).write_bytes(p.stdout);(s/(label+'.stderr')).write_bytes(p.stderr)
(s/(label+'.json')).write_text(json.dumps({'argv':argv,'cwd':str(r),'environment_override':{k:env[k] for k in ['PATH','OSSTACK_HOME','OSSTACK_SCRATCH_ROOT']},'unset':['OSSTACK_SOCKET'],'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'source_sha256':bindings,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n')
print(p.stdout.decode());print(p.stderr.decode());print('ACTUAL_EXIT',p.returncode)
