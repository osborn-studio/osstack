import pathlib,subprocess,os,json,time,hashlib,datetime
r=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/skills-check-exit');s=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-host-effects-20261028/ci289');p=r/'packages/cli/src/upgrade-native.test.ts'
old=p.read_bytes();frozen=subprocess.run(['git','show','a567bd9f:packages/cli/src/upgrade-native.test.ts'],cwd=r,capture_output=True,check=True).stdout
assert old==frozen
(s/'instrumentation-original.test.ts').write_bytes(old)
text=old.decode();start=text.index("  it.each(['permit_missing','operation_missing','both_missing']");end=text.index("  it('clears an orphan permit",start);part=text[start:end]
part=part.replace("async missing=>{", "async missing=>{\n    const __start=performance.now();let __last=__start;const __mark=(phase:string)=>{const now=performance.now();console.error('STAGE '+JSON.stringify({case:missing,phase,ms:now-__last,total_ms:now-__start}));__last=now;};")
part=part.replace('const f=await fixture();const port=new ManagedNativeUpgradePort(f.input,f.backend);', "const f=await fixture();__mark('fixture');const port=new ManagedNativeUpgradePort(f.input,f.backend);__mark('port_constructor');")
part=part.replace(".state).toBe('verified');await port.close();", ".state).toBe('verified');__mark('coordinate');await port.close();__mark('port_close');")
part=part.replace("const status=await f.journal.status(f.plan.digest,'first');", "const status=await f.journal.status(f.plan.digest,'first');__mark('journal_status');")
part=part.replace('for(const c of f.config.consumers)await f.backend.stop(c.label,new AbortController().signal);', "for(const c of f.config.consumers)await f.backend.stop(c.label,new AbortController().signal);__mark('stop_consumers');")
part=part.replace('const recovery=new ManagedNativeUpgradePort(f.input,f.backend);', "__mark('remove_fences');const recovery=new ManagedNativeUpgradePort(f.input,f.backend);__mark('recovery_constructor');")
part=part.replace("services_observed:false});", "services_observed:false});__mark('reconcile');")
part=part.replace('await recovery.complete();', "await recovery.complete();__mark('repeat_complete');")
part=part.replace('await recovery.close();', "await recovery.close();__mark('assertions_and_close');")
new=(text[:start]+part+text[end:]).encode();(s/'instrumented.test.ts').write_bytes(new)
env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:'+env['PATH'],OSSTACK_HOME=str(s/'profile-home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack');env.pop('OSSTACK_SOCKET',None)
a=['pnpm','--filter','@osstack/cli','exec','vitest','run','src/upgrade-native.test.ts','-t','cleans completed history with stopped consumers']
record={'argv':a,'cwd':str(r),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(old).hexdigest(),'instrumented_sha256':hashlib.sha256(new).hexdigest(),'environment_override':{'PATH':env['PATH'],'OSSTACK_HOME':env['OSSTACK_HOME'],'OSSTACK_SCRATCH_ROOT':env['OSSTACK_SCRATCH_ROOT']},'unset':['OSSTACK_SOCKET']}
try:
 p.write_bytes(new)
 x=subprocess.run(a,cwd=r,env=env,capture_output=True,timeout=140)
 (s/'stage-profile.stdout').write_bytes(x.stdout);(s/'stage-profile.stderr').write_bytes(x.stderr);record.update(exit_code=x.returncode,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=hashlib.sha256(x.stdout).hexdigest(),stderr_sha256=hashlib.sha256(x.stderr).hexdigest())
 print(x.stdout.decode());print(x.stderr.decode())
finally:
 p.write_bytes(old);record['restored_exactly']=p.read_bytes()==frozen
 (s/'stage-profile.command.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
