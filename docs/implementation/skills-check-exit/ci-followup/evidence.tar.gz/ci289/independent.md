# PR289 4dddf67a independent read-only check

Recorded: 2026-10-28T07:30:29.398949+00:00

**Conclusion: no blocking coverage regression found in this diff.** It separates setup and behavior budgets and materially increases the permitted time. This is a source and installed-runner inspection, not an executed test result. No product files were edited and no test/model calls were run by this reviewer.

## Exact scope

- Previous candidate: `a567bd9f1e7c196fbe2dea1661f6da450c42b68c`.
- Reviewed candidate: `4dddf67ab6e293161aab8f59b57392d1c693a298`.
- Only committed changed file: `packages/cli/src/upgrade-native.test.ts`; 24 additions, 15 deletions.
- Old file SHA256: `fc76e5514c341a2ab244d173b584eeb0f1299750c4ea777af5fa3199e3135fcc`.
- New file SHA256: `8c16c18d81d1886a4045bfbe56e5d4d6526b4ce2e08d19f66f8d3e681e60c21b`.
- Working tree contains four generated knowledge/dist changes from the main validation worker. They were not treated as part of this committed diff or modified here.

## Coverage preserved

The three values remain exactly `permit_missing`, `operation_missing`, `both_missing`. `describe.each` creates one distinct suite with one behavior test for each value. Each test invokes `fixture()` from its own beforeEach; setup is not shared across the three variants.

The entire fixture and file-scoped cleanup text is byte-equivalent between candidates. The fixture still creates two separate SQLite homes and child processes, stages old/new releases, observes real socket identities, constructs the same two-home upgrade plan, and uses actual `coordinateUpgrade`. This is the existing deterministic backend fixture with real file/process/SQLite operations; it does not exercise launchctl itself.

Every relevant operation remains:

1. Complete the two-home upgrade and require verified state; close its port.
2. Snapshot the resulting journal status and physically stop both consumer processes.
3. Delete the same permit/operation files for each crash variant.
4. Construct a recovery port and call `reconcileForward` against the original journal digest and a 30-second AbortSignal.
5. Require verified cleanup-only result with `services_observed:false`.
6. Call `complete()` again to check repeat cleanup does not fail.
7. Require starts still equal 4, journal records unchanged, restart permit absent, operation marker absent; close recovery port in finally.

Both old and new blocks contain **six `expect(...)` expressions**, with the predicates retained: verified initial upgrade, recovery result object, start count, journal records, and the two absent markers. No assertion was replaced by skip, mock, weaker predicate or retry.

## Failure and cleanup semantics

Installed Vitest is 3.2.6. Its `chunk-hooks.js:1558-1599` catches beforeEach/test failures and then separately calls afterEach. `callSuiteHook` at lines 1423-1450 traverses parents for afterEach, so the file-level cleanup at test source line 18 remains applicable after an ordinary beforeEach exception. It kills the recorded child handles and removes all recorded roots. The registration arrays are populated during fixture allocation/spawn, so partial fixture creation does not depend on assigning `f` successfully to be tracked.

The new beforeEach wraps `coordinateUpgrade` and its verified assertion in `try/finally` with `port.close()`. Compared with the previous sequence, a rejected upgrade or failed verified assertion now closes the constructed port before propagating. Failures during fixture construction are covered by the same file-level resource tracking; there is no uninitialized `f`/`status` access from the behavior body because Vitest skips that body when beforeEach fails.

**Limit:** this does not establish universal hard-timeout cleanup. Vitest's timeout wrapper (lines 1852-1905) rejects the hook Promise and aborts its test context; it does not terminate arbitrary ongoing JavaScript. This beforeEach does not pass the context signal into `coordinateUpgrade`. Thus, on a true hook timeout, underlying asynchronous preparation could still be settling while afterEach begins. That async-cancellation limitation also existed when the same operations lived in the old timed test body. The candidate improves normal error closure but must not be described as proving all work terminates at timeout. No fault-injected timeout experiment was performed here.

## Budget accounting

| Scope per crash variant | Previous | Candidate |
| --- | --- | --- |
| Full fixture, two-home upgrade and crash preparation | Inside the single 30s test budget | Explicit beforeEach budget 60s |
| Recovery/assertions/recovery port close | Same shared 30s budget | Separate test budget 30s |
| File-level cleanup | Existing default hook budget | Unchanged default hook budget |

The setup-plus-behavior allowance therefore rises from **30 seconds to 90 seconds per variant**, excluding framework overhead and afterEach. The installed Node Vitest configuration resolves the unchanged default hook budget to 10 seconds (`vitest/dist/chunks/coverage.DfSpMS-b.js:3922`); that is an additional cleanup allowance, not part of the new 90 seconds. Across three variants, the nominal setup+behavior ceiling rises from 90 to 270 seconds. Actual duration still requires measured logs.

The source comment explicitly says preparation receives its own budget and this is not a performance optimization. The commit title also describes separate budgets. The PR description should retain the concrete **60s setup + 30s behavior** explanation and must not claim the total deadline was unchanged. The internal upgrade plan remains unchanged (`max_total_ms:100000`, per-step 20000, expiration 120000); these independent product bounds were not loosened by the diff.

## Evidence boundary

No new test execution, full regression, model review or production operation is claimed here. Root owns the running full suite and actual Sonnet audit. This report supports source-level preservation and accurate budget interpretation only.

Installed runner SHA256: `5e0b0ece2242e3475a0312a375fac6e47287602792d7f4999d2d733ecda2d69a`.
