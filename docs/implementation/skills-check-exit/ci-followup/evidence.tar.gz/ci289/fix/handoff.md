# Completed-history cleanup test budget split

Only `packages/cli/src/upgrade-native.test.ts` was changed. Three missing-fence cases now each use a scoped `beforeEach` to prepare a fresh real two-home fixture, complete a full native upgrade, close the initial port, observe the resulting journal, stop both upgraded processes, and delete the specified fence(s). Setup has an explicit 60-second timeout; each cleanup test retains its existing 30-second timeout and 30-second recovery abort signal.

All cleanup predicates remain: verified_history_fence_cleanup_only, services_observed:false, repeated complete idempotence, exactly four total process starts, journal records unchanged, and both fences absent. Both native consumers and all physical setup operations remain. The initial port is now closed in finally if preparation assertions fail. The existing owner child/root cleanup remains unchanged. No production file, integrity check, or native hash verification was weakened.

This expands the maximum total per-case experiment budget from shared30s to setup60s+cleanup30s. It separates preparation from the behavior under test, not a performance optimization. Local stage observations support the distinction; they do not establish the precise Linux CI cause. See the immutable parent diagnosis and stage-profile artifacts.

Validation: complete upgrade-native.test.ts 25/25 and skills-command.test.ts 12/12 passed in one targeted run; actual process exit0. Targeted Biome checked the changed file, no fixes, exit0. git diff --check exit0. Commands, times, raw stdout/stderr and hashes are preserved. Full repository tests, typecheck, model audit and CI are owner follow-up obligations; no commit or PR change was made here.
