# PR289 repeated upgrade-native CI timeouts

## Findings and certainty

The repeated failure is confirmed on PR289 head `a567bd9f1e7c196fbe2dea1661f6da450c42b68c`, run `40645757136`, check job `122675109897`, attempt 1. Exactly permit_missing and operation_missing hit the outer 30,000 ms test timeout, at 30,038 and 30,204 ms. The adjacent both_missing case passed at 29,723 ms. Whole file: 25 cases, 2 failed, 327,388 ms. CI used Node v22.23.4. Full original job log is retained, with derived excerpts kept separately.

The same test source bytes appeared in the earlier PR286 diagnosis. That failure recorded permit 30,126 ms, operation 30,175 ms, both 29,753 ms, whole file 328,225 ms. PR285's successful comparison was 21,562/21,420/21,794 ms and 236,855 ms respectively, on Node22.23.3 and a different runner image. These observations show repeatable budget pressure affecting all three cases, including the case which barely passes. They do not distinguish runtime performance, filesystem/fsync latency, CPU scheduling, or runner contention. No blind rerun is warranted by this diagnosis.

Git diff from fd9 main to the current head is empty for the tested file and native port/backend. This CLI skills-check change does not alter those execution inputs. Source equality alone is not runtime equality.

## Confirmed test-design mechanism

The outer 30-second limit at upgrade-native.test.ts:159 covers all of: two-home filesystem/SQLite fixture, two real child startups, full coordinateUpgrade, closing initial port, querying journal, stopping both upgraded processes, deleting chosen fences, constructing recovery, reconciling already-completed history, repeated complete and assertions. AbortSignal.timeout(30000) starts only at reconcile, so it does not isolate the behavior named by the test. Thus this test conflates potentially expensive full-upgrade preparation with completed-history cleanup. This is a confirmed budget-boundary problem, not proof of the exact CI slow phase.

Source also confirms repeated full Node executable hashing: ManagedNativeUpgradePort.assertOperation → assertPins → loadInstallation → SHA256(readFileSync(config.node)); coordinator authority/lease checks invoke this repeatedly. It is a plausible platform-sensitive cost. The local runtime executable size is recorded in local-runtime.json; the CI executable's size and hash timing were not measured. Do not claim hashing is the proven CI root cause, cache the security check, or skip verification based on this evidence.

## Bounded actual stage measurement

Owner authorized temporary timing instrumentation of the exact test, followed by exact restoration. Only the three named cases ran, with original 30-second case timeout unchanged; result 3 passed, 22 skipped. Raw command, input hashes, stdout/stderr and derived stage JSON are retained. Instrumentation logged monotonic deltas and did not replace any assertion, child, DB, upgrade call or stop operation.

| Case | Local preparation through fence deletion | Local recovery construction through assertions/close | Full coordinate within preparation |
|---|---:|---:|---:|
| permit_missing | 804.618 ms | 14.289 ms | 343.053 ms |
| operation_missing | 491.602 ms | 12.972 ms | 314.182 ms |
| both_missing | 493.303 ms | 10.947 ms | 315.232 ms |

This demonstrates local preparation dominates these cases; it does not reproduce the Linux CI timeout or measure its stage distribution. Node/platform details are recorded separately. The repository test was restored byte-for-byte to the original Git object; git diff --exit-code for it returned 0. No other product or repository file was changed.

## Minimal recommended follow-up

Use a nested describe.each for the three missing-fence states. A scoped beforeEach with its own explicit 60-second setup budget should perform the same fresh two-home fixture, real full upgrade, close, journal observation, stopping both consumers, and selected fence deletion. Keep these preparation assertions intact. Keep each case's existing 30-second budget on construction/reconcile/repeated complete, unchanged journal records, starts still exactly four, both fences absent, and services_observed:false. Preserve current resource-owner afterEach cleanup and close each initial/recovery port with finally so failed setup does not leave a lock pending.

This explicitly changes the experiment's maximum budget from one shared 30 seconds to separate setup 60 seconds plus case 30 seconds; it is not a claimed speedup or an unchanged total budget. It isolates the intended cleanup behavior while preserving real preparation. No production hash, native lifecycle predicate, assertion, consumer count, or timeout for cleanup should be weakened. Actual Linux CI validation of the resulting candidate remains required; if setup itself fails, retain that distinct failure rather than retrying silently.

No final fix, commit, PR update, CI rerun, management write, paid-model call or full-suite test was performed by this diagnostic task.
