# Audit result

**A (4dddf67): PASS**
**B (efd53f6): REVISE**

---

## A: PASS

I found no defect that hides a product bug or loses coverage.

**Coverage and assertions**
- Every original assertion survives: `verified` state, the `reconcileForward` result shape (`verified_history_fence_cleanup_only`, `services_observed:false`), idempotent `complete()`, `starts()===4`, journal records unchanged, and both permit and operation files absent.
- Setup differs only in that `port.close()` is now in `finally`. The old code skipped it if the `verified` assertion failed, so this is a small improvement.
- The `verified` assertion now sits in `beforeEach`. A failure there is reported as a hook failure instead of a test failure, but it still fails the suite.

**Isolation and cleanup**
- The file-level `afterEach` still covers `roots` and `children` for the nested tests.
- Stopped children are handled safely. `stop()` waits for exit, and the `afterEach` SIGKILL path checks `exitCode`/`signalCode` before waiting.
- Each `describe.each` case has exactly one `it`, so there are still three fixtures with no shared state.

**Types and lifecycle**
- `let f` and `let status` are assigned in the hook and read in the test closure. TS will not flag use-before-assign across closures.
- `Awaited<ReturnType<UpgradeJournal['status']>>` is valid with the value import.
- The explicit hook timeout (60000) overrides the default `hookTimeout`.

**Non-blocking caveats, to carry into the PR text**
1. The change is not shown to fix the CI failure. The 37 passing tests ran where preparation takes about 0.5–0.8s. The CI evidence is three runs clustered at about 30s (two timeouts, one pass at 29723ms), against a local gap of roughly 40–60×. That pattern looks more like a fixed ~30s stall than uniform slowness. The 60s budget is a guess. If the stall is in preparation it is now silently absorbed, and if it is in cleanup it will now fail with clear attribution. The PR must not claim a fix.
2. A cheap improvement would be logging the preparation elapsed time in the hook. That keeps the extra budget from erasing the signal.
3. Test IDs changed (`describe` plus a new `it` title). Update any quarantine, retry or flaky-test lists that key on the old names.
4. If the 60s hook timeout fires, `afterEach` can run while the abandoned fixture is still spawning children, which would leak them. The old 30s test had the same risk, so it is not a regression.

---

## B: REVISE

**1. Missing-evidence taxonomy applied to Claude only.**
- The Codex commands read no manifest. Its five invocations read the skill files, `rg --files`, the old source, the summaries and outputs, `results.json`, and the `jq`/`nl`/`wc`/`shasum` calls.
- Yet the Codex assessment's C5 evidence says "missing actual manifests correctly prevents independent same-input confirmation", and the README does not mention it.
- That statement needs classifying as not provided, provided but unread, or absent. Otherwise the README flags the Claude error while leaving a possible identical one in Codex unexamined.

**2. The Codex row omits unfavorable qualifiers that the evaluation records.**
- C5 is only `bounded` and C7 is `met_with_scope_limit`.
- The README drops the harness warnings (rollout state db discrepancy, `falling_back`).
- The README does not use the PR's own execution / behavior / harness / cleanup / coverage axes for either host. No cleanup or termination observation is stated.
- "Five read-only shell commands" is also loose: the fifth invocation runs five utilities.

**3. "Recorded before invocation" is supported for Claude only.**
- The Claude evaluation carries `expectations_sha256`. The Codex evaluation shows no hash or timestamp for its frozen expectations.
- Either cite the Codex pre-invocation hash from the manifest or soften the claim.

**4. "Both executions were read-only" is enforced for one host and observed for the other.**
- Claude had a tool allowlist (Glob/Grep/Read).
- For Codex, the README rests only on the observed command list. The sandbox mode is not in the evidence, and the CLI wrote its own state (the db warnings).
- Say "the observed commands were read-only" for Codex.

**5. Confounds and the evaluator are not fully disclosed.**
- The Codex evaluation states "task prompt also constrained behavior". The README says only that prompts differ.
- Both hosts were given the historical RED/GREEN outcomes of an already-fixed bug. "Correctly diagnosed" therefore measures comprehension of supplied evidence, not investigation.
- The README says the models are not independent oracles. It does not say who authored the expectations and applied the evaluations. Per `evidence.md`'s own same-author rule, that should be stated.

**6. "Observed method use" and "useful investigation behavior" overreach.**
- The evidence shows the hosts read the files and produced reports matching author-written expectations. Reading is not shown to be use, and "useful" implies value with n=1 and no control.
- Retitle to "observed method reading" or qualify "use". Drop "useful", or tie it to the specific criteria met.

**7. The `host-usage.md` cells do not say what was tested.**
- The runs used an `inputs/` copy of the PR288 files, not the documented checkout request template.
- The hosts got different entries: Codex had investigation, Claude had investigation plus bug-fix.
- Both consumed the pre-change `evidence.md`. No host has read the new "Reading existing evidence" text.
- Add that to the cells, since the file itself says to preserve material versions and not call partial copies equivalent.

**8. Referenced artifacts are not in the diff, and redaction effects are unstated.**
- `evidence.tar.gz` and `evidence-manifest.json` are linked, but the diff does not show them. Confirm they are in the commit. Otherwise the links dangle and the "hashes each archived file" claim cannot be checked.
- The Codex transcript contains `shasum` values computed on unredacted files. If any of those files were later redacted, the embedded hashes no longer match the archived bytes.
- The README should say which files were redacted and what that does to the conclusions, as `evidence.md` requires.

**9. The new `evidence.md` rules are not in its own template.**
- The four evidence states (not provided / provided but unread / read but not verified / verified for a predicate) appear only in prose.
- Add an "Input evidence inventory and read status" line to the record template so the rules can actually be applied and audited.

**10. The proposed next experiment cannot test the change it follows from.**
- The README concedes a no-method control is required for any causal claim, but the design does not include one.
- It has no old-vs-new `evidence.md` arm, which is the only thing the unverified wording change needs.
- It has no repeated trials per arm, no pinned and attested model (Codex's was unattested), and no pre-registered scoring with a threshold. The scorer should be mechanical or independent of the method author.
- The positive control is undefined. There is no negative control either, such as a genuinely absent artifact next to a supplied-but-unread manifest, and no token-budget criterion.
- "Each host selects a bounded verification action" breaks comparability. Use the same predicate, prompt and action space, and state the isolation requirements from `evidence.md`.
- "After the current PRs settle" is not a bounded trigger.

**Verified accurate**
- Token figures: 198,949 input, 163,072 cached.
- The 2,335-entry binding list.
- Claude's 28 Reads plus one Glob (29 tool uses).
- Claude's model attestation.
- The manifest-unread correction.
- The narrowing of the "only one file changed" claim.
- The relative link `../../docs/implementation/joint-host-effects/README.md`.