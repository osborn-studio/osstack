import subprocess,json,hashlib,os,datetime
from pathlib import Path
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-feature-map')
s=Path(__file__).parent
names=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
def snapshot():
 return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names if n and (root/n).is_file() and not (root/n).is_symlink()}
before=snapshot()
(s/'full-before.json').write_text(json.dumps(before,indent=2))
meta={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'status_before':subprocess.check_output(['git','status','--porcelain'],cwd=root).decode(),'tracked_files':len(before)}
env=dict(os.environ,PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
with (s/'full.log').open('wb') as f:
 result=subprocess.run(['pnpm','test'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
after=snapshot();(s/'full-after.json').write_text(json.dumps(after,indent=2))
meta.update(exit=result.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),changed_files=[n for n in before if before[n]!=after.get(n)])
(s/'full-result.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta));raise SystemExit(result.returncode)
