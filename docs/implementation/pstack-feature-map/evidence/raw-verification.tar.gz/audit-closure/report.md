# Closure review: PASS

This is a source-reading review only. I did not run anything, and I make no runtime or host claims. The RED/GREEN results, the pre-fix full run and the 40-test count are your reports, which I took as given.

## Checked items

**1. Stale-export classification: closed.**
- The `typeof` check sits inside the `try`, so the `fail('knowledge_unavailable')` it throws is caught and rethrown as the same code. This is harmless.
- `knowledge_unavailable` is already in the exit-3 list, and `details` stays `{}`. The test's `deepEqual` on stderr matches that.
- The test copies the script into a temp tree with a `package.json` of `type: module`, so the stub loads as ESM. Without that file it could pass vacuously through a syntax-error import failure. Under that setup the old code reaches the call and throws a TypeError, which fits your two old-RED results.
- The case I raised earlier (module loads but lacks the export) is now covered for both a missing and a null export.

**2. Help precision: closed.**
- "selection budget" now correctly separates `selection_budget` (exit 3) from `file_too_large` (exit 2).
- The two new lines are accurate as far as I can tell. The 2-character minimum comes from the earlier audit's reading of `pack.ts`, which I have not seen myself.
- The `/not product/` assertion still matches "not product success" on a single line.

**3. Test title: closed.**
- "CLI returns expected JSON/help and rejects invalid arguments" matches what the body asserts: exit 0 with 2 selected leaves, help text, and exit 2 with empty stdout and `invalid_arguments`.
- It no longer claims "no input read", "bounded", or an observer that doesn't exist.
- By my tally the file now holds 40 tests, matching your count.

**4. Leaf/README/index consistency: consistent.**
- `user_outcome` and `surfaces` are identical between the index and each leaf. All leaf entries are `cli`, so `validateLeaf` identity checks hold.
- The packet→journey dependency, null owners and empty `covered_entry_ids`/`last_live_evidence` agree across the README, index and leaves.
- The README's source/driver pin description matches the pins in each leaf. The README exit tables and the leaf `observations` exit semantics agree with each other and with the code's exit mapping.
- The README's sample observation uses `checkout`, which exists in the maintenance leaf.
- The README's bounds (32 IDs, 8 leaves, 32 KiB, 128 KiB) match `LIMITS` and the list maximum.
- The three repository-index CLI tests are green in your final run. That is the evidence that the index `sha256` values match the leaf bytes.

## Remaining concerns (non-blocking)

1. **Unsearchable queries.** A query with no tokens of two or more characters still returns `no_match` with exit 1. The help now says short tokens are ignored but not that the outcome is `no_match`. The README's "Valid query, no match" is slightly generous for that case. This is documentation only. The README also doesn't repeat the 2-character and CJK-spacing note, which is acceptable because the help carries it.
2. **Narrow guard.** The fix covers a missing or non-function export. A stale build that exports a function but throws, or returns an unexpected shape, still surfaces as `internal_error` with exit 2. Build freshness is also not bound into the result. Neither is a regression.
3. **Pin and digest values not recomputed.** I did not recompute any of the six pin digests or the index `sha256` values, and I did not count their hex lengths. The schema only checks that pins are non-empty text, so a malformed pin would not be caught by it. The independent report's pin check and the green repository-index tests are the evidence here.
4. **Attribution.** The full `pnpm test` pass belongs to pre-fix `9e37bfa0`. The final source is evidenced only by the 40-test file, not by a full-suite run. The patch is confined to the script and its test, but I'm not extending the full-run result to it. The four preexisting `dist` modifications also remain a stated caveat.
5. **Unchanged earlier items.** The untested branches (`file_changed`, `observer_failed`, exit 3 for `content_drift` and `selection_budget`) and the duplicate-key last-wins behavior from the earlier review are untouched. None of them blocks this closure.

No revision is needed. If you want to tidy up, one README line on the tokenization caveat and the `no_match` outcome would address concern 1.