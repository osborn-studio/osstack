# Offline feature-map selector: bounded W18 delivery

Draft for the implementation README. Prepared from retained records; final publication/archive bindings and audit disposition must be attached before treating it as closeout. This analysis is by a context-familiar worker, not a fresh cold-use acceptance.

## What this delivers

A callable, offline selector ranks only local index metadata through the existing public `searchKnowledgePacks` BM25 export. It opens selected leaf bodies after ranking and expands required dependencies. Three actual CLI task leaves describe fixed-five map maintenance, the full skills-check journey, and retained-evidence packet projection/checking. Packet requires journey material; maintenance need not load the whole library. No referenced product command runs merely because its leaf is returned.

The result preserves query/dependency reasons, omitted scope, content hashes, caller-reported freshness/prerequisites, unassigned maintenance ownership and unverified coverage. Local closed formats and bounded regular-file reads reject invalid paths, cycles, missing required leaves, content changes and excess budgets. Empty evidence stays draft; execution remains not_run. This is not a protocol/admission change or a new method/host/runtime permission.

Read [the user instructions](../../verification/features/README.md) for the actual selector and the separately authorized drive recipes. Every source/driver pin identifies actual named file bytes, not arbitrary Git freshness or complete transitive build provenance. This independent expression retains pstack/poteto attribution and Lauren Tan's MIT license pin in the user README.

## Verification records and original failures

- Author TDD began with a missing new module: expected new-feature RED, not a historical product regression. Initial 20 checks then grew to 35. A root-added aggregate-budget probe caught the fifth body being read before total-budget rejection (five actual reads versus expected four); the old failure and candidate were retained, and the pre-read remaining-budget check repaired it.
- The repository-index suite reached **38 passed**, including actual CLI queries for maintenance, journey and packet with its required journey. These are selector executions, not execution of maintenance/journey/project/check tools. The author lint attempt found Biome ignored the MJS files; this is recorded as no lint coverage, not a successful lint run.
- Independent frozen black-box vectors recorded **59 passes and one fixture error before the product call out of 60**. V22 reused a temporary directory named `unknown`, causing EEXIST. A uniquely named fixture reran the same assertions and passed; the original result remains intact. Do not summarize the original run as 60/60. Separate independent actual CLI selection/query-correction checks and existing-entry parse checks each passed 4/4.
- A Sonnet 5.5 static review returned **PASS_WITH_CONCERNS**, with no confirmed blocker; it explicitly did not execute tests and did not read the final three leaves, scratch helper or built export. Concerns included lexical/token limitations, missing/non-callable knowledge export classification, ambiguous budget help and an overclaiming test name. That review is not runtime verification or CI success.
- The post-audit correction adds an explicit callable-export guard, clarifies help and narrows the test title. Two new CLI regressions failed against old source `5b734095…` and the focused suite then reached **40 passed / 0 failed / 0 skipped** against working source `53d78a66…` and tests `56c42968…`, per the retained post-audit binding. This is a later focused result, not a retroactive change to the earlier 38-test candidate or full-suite identity. Final audit closure remains a separate record to attach.
- Publication documentation checks actually executed the README's three selector calls and its null/unknown observations JSON. All exited 0 with expected selected IDs; freshness/prerequisites remained unknown and execution not_run. Five shell blocks were only parsed with `zsh -n`; seven documented command lines were checked against the source contracts. No maintenance, journey, projector or packet-check drive was executed. These fresh selector records are separate from the earlier static hash/link inspection.

Evidence source directories in the retained raw bundle should preserve `author/`, `independent/`, `audit/`, `docs/publication-check/`, the old REDs, corrected fixtures and candidate bindings. Archive path and member-verification receipt are pending root publication; no in-progress audit/full directory has been archived by this worker.

## Full workspace regression

Root's `full-result.json` records `pnpm test` exit **0**, from **2026-10-30T06:17:14.024084+00:00** to **2026-10-30T06:25:34.245138+00:00**, at commit **9e37bfa052f7336aac880b48732bf9436b6f4c78**. This worker parsed `full.log` by unique package summary and checked every passed+skipped total. There are **22 unique package suites**, **7261 passed tests**, **5 skipped tests**, **493 passed test files** and **4 skipped test files**.

| Package | Passed tests | Skipped tests |
| --- | ---: | ---: |
| packages/contracts | 15 | 0 |
| packages/compliance | 17 | 0 |
| packages/github | 224 | 0 |
| packages/knowledge | 44 | 0 |
| packages/runtime | 1 | 0 |
| packages/neat-eval | 16 | 0 |
| packages/protocol | 1012 | 0 |
| packages/governance | 301 | 0 |
| packages/knowledge-cloud | 36 | 0 |
| packages/graph | 257 | 0 |
| packages/core | 1301 | 0 |
| packages/plugins | 1 | 0 |
| packages/hermes-adapter | 22 | 0 |
| packages/skills | 2 | 0 |
| packages/autonomy | 201 | 0 |
| packages/skill-registry | 43 | 0 |
| packages/agents | 361 | 0 |
| packages/config | 30 | 0 |
| packages/loop | 515 | 0 |
| packages/conformance | 9 | 0 |
| packages/supervisor | 88 | 0 |
| packages/cli | 2765 | 5 |

The root byte comparison records **8,914 tracked files unchanged before/after**. Four freshly built `packages/knowledge/dist/index.*` files were already dirty at run start; the feature README was untracked. This is an exact candidate/workspace-byte observation, **not** a clean committed-tree full run. The full run belongs to pre-audit candidate `9e37bfa0`; the later export-guard/help change has its separate 40-test focused verification and must not inherit a claim that this full suite ran on those later bytes. The package counts do not include standalone script-test counts.

Parser output: `docs/full-package-summary.json`; original log digest: `56ed73ec862ccb8638bf7b95c4d7d3fba979ba4f2bb95d866a333e5c64fe335f`. The parser confirms log arithmetic and unique package names. It reads the root's tracked-byte record, rather than independently recreating unavailable pre-run state.

## Remaining scope

This is bounded W18 local material retrieval, not full original W18 acceptance. Real leaves are all CLI; a synthetic multi-entry fixture only tests coverage bookkeeping. Actual cross-surface driving, authoritative evidence resolution, host/recipe delivery and complete A35/A48 remain unverified. No fresh native host, model, old C0 replay or Firstmate deep runtime was run.

W19 still owns configured maintenance responsibility, health queries, relevant change triggers, fault classification and actual tool-repair/re-drive under A45. Periodic work remains unconfigured/off; no scheduler or notifications are introduced. Source/build and local digests are not authenticated principal or compiler provenance. C0, C1, C2 and original whole-capability gates remain incomplete; this implementation does not change their status.

Final publication should bind the final source/tree, review dispositions, focused/full candidate distinctions, retained original failures, source notices and independently checked archive membership. No blanket acceptance claim follows from this README.
