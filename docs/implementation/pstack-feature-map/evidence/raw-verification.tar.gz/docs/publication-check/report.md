# Publication README check

Actual checks performed against source 9e37bfa0 and the current five feature docs, with complete stdout/stderr/exit and command records retained here:

- README three selector commands: exit 0 each; selected maintenance, journey, and packet + required journey respectively.
- README observations JSON: parsed and used unchanged in an actual maintenance selector call; exit 0. Null bindings and unknown prerequisites remain unknown, caller entry observations empty, execution not_run.
- Five shell blocks: zsh -n exit 0 each, without execution of their body.
- Seven documented node command lines: option shape matches exact entry contracts. Project/check are distinct; check has no scope. JSON/index/leaf digests and current reader/wrapper source bindings are recorded in report.json.

No defect observed in these checks. This is fresh selector execution evidence, not the earlier static report and not a maintenance/journey/projector/product run. All selected entries remain unverified, evidence draft, availability unknown. Source bindings checked against Git 9e37bfa0 match current files.

No product/docs/ledger/PR/full-suite changes. No Firstmate, model or host task. Archive membership verification remains pending the root-provided frozen archive; active audit/full files were not archived.
