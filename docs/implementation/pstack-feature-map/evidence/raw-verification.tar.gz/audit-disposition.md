# Root disposition of actual Sonnet source audits

Initial PASS_WITH_CONCERNS and later limited closure PASS are retained unedited in audit/ and audit-closure/. Static reviews did not execute products or establish provider/principal/host qualification.

1. Existing lexical BM25 tokenization retained; help now names short-token and CJK limitations. No new ranking engine.
2. Confirmed missing/nonfunction search export misclassification repaired from internal_error/2 to knowledge_unavailable/3. Same two tests old RED, final40 GREEN; independent two bad exports plus normal control old/new (six CLI runs) agree.
3. Help now distinguishes selection_budget/3 from file-size invalid input/2.
4. Test title narrowed to asserted output/argument behavior; no unsupported no-read claim.
5. Suggested extra branch coverage remains optional; original independent vectors and author tests keep their own coverage, not blanket exhaustive proof.
6. Initial review lacked authored leaves/build/scratch helper. Separate independent actual file pins/CLI checks and limited closure supplied leaves/README establish only their recorded scope.
7. JSON.parse duplicate keys remain last-wins; raw selected bytes have content binding. No duplicate-key rejection contract added.
8. Unsupported file types means nonregular files; no suffix restriction introduced.

Closure remaining concerns retained: no-token query returns no_match; callable stale implementation exceptions remain internal_error; no authenticated build provenance; digest recomputation comes from actual independent checks, not model assertion; full7261/5 belongs to9e37 with initial4freshdist changes. No third audit or full reattribution.
