# W18 author evidence

Two script files only, no commit. Final bindings are in final-binding.json. Root owns the shared worktree and fresh generated dist.

- red: missing new module, a new-feature TDD starting failure; not an old product bug.
- green-1: 20 initial checks.
- green-final: 35 checks before total-read-budget refinement.
- initial-candidate/: exact pre-budget-refinement source/test copies.
- budget-red: fifth body was read before total-byte rejection (5 actual reads vs expected 4).
- budget-green: 35 checks after fstat remaining-budget check; concurrent growth has a bounded +1 sentinel read, not an OS fence.
- repository-green: final 38 checks, including three real repository-index CLI selections.
- actual-*: complete selector stdout/stderr/argv for those three selections. They do not execute the referenced product tools.
- lint-observation: configured Biome ignored both MJS files, so this is not lint success.

No full suite, model, DB, network or journey drive was run by this author. The shared knowledge build was supplied by root, not independently rebuilt or authenticated here. Caller metadata, local SHA and material completion are not execution or provider qualification.
