# 缺失 knowledge 搜索导出：后审计独立复验

确认旧缺陷已由新源码关闭。此项为原 60 检查之外的后审计补充，不重标原结果。

三种隔离导出各用同一输入，对旧源 `5b734095…` 和新源 `53d78a66…` 各运行一次真实 Node CLI：

| 导出 | 旧源 | 新源 |
|---|---|---|
| import 成功，但无 searchKnowledgePacks | exit2 / internal_error，违反契约 | exit3 / knowledge_unavailable |
| searchKnowledgePacks=42，非函数 | exit2 / internal_error，违反契约 | exit3 / knowledge_unavailable |
| 可调用函数，返回指定合法命中 | exit0 / complete / not_run | exit0 / complete / not_run |

六次输入文件哈希均未改变，原 stdout/stderr/argv、源字节、模块字节和时间保留在各独立 case 目录。新旧 production diff 仅导出类型检查及 help 澄清，排序、schema 与 leaf 读取算法未变。正常对照函数为受控 stub，只用于检验调用通路，不冒称 BM25 独立算法验证；未重复全仓、产品驱动、C0 或模型实验。

原 independent/manifest.json 哈希仍为 `ea094608e52878f1614102a6d1c0e9946064f80944ebfca534132b984a59e3db`；本新目录另行封存。
