from pathlib import Path
import json,hashlib,subprocess,datetime,difflib
r=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-feature-map-20261030/independent/audit-knowledge-export');parent=r.parent;w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-feature-map')
sha=lambda b:hashlib.sha256(b).hexdigest()
old=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-feature-map-20261030/author/audit-fix-preparation/original-source.mjs').read_bytes();new=(w/'scripts/method-feature-map.mjs').read_bytes()
assert sha(old)=='5b734095d48ad02642e2bef0d454bea77d42f4db64732fea3fc6f0dc2b1f3c76';assert sha(new)=='53d78a66b5c16d3bcb5e66f9e2d20a7557f7a0c7762bf7e3d458f9200624c383'
(r/'old-source.mjs').write_bytes(old);(r/'new-source.mjs').write_bytes(new);(r/'source.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='old5b734',tofile='new53d78')))
criteria=json.loads((r/'criteria.json').read_text());all=[]
for label,source in [('old',old),('new',new)]:
 for control in criteria['controls']:
  directory=r/(label+'-'+control['id']);(directory/'scripts').mkdir(parents=True);(directory/'packages/knowledge/dist').mkdir(parents=True);(directory/'inputs').mkdir()
  (directory/'package.json').write_text('{"type":"module"}\n');script=directory/'scripts/method-feature-map.mjs';script.write_bytes(source);module=directory/'packages/knowledge/dist/index.js';module.write_text(control['module_bytes'])
  inputs=[]
  for name in ['index.json','maintenance.json','journey.json','packet.json']:
   b=(parent/'run-01/v01'/name).read_bytes();(directory/'inputs'/name).write_bytes(b);inputs.append({'path':name,'bytes':len(b),'sha256':sha(b)})
  argv=['/opt/homebrew/opt/node@22/bin/node',str(script),'--index',str(directory/'inputs/index.json'),'--query','maintenance'];env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':str(r/'runtime')};rec={'candidate':label,'case':control['id'],'argv':argv,'cwd':str(directory),'env':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(source),'module_sha256':sha(module.read_bytes()),'inputs':inputs}
  c=subprocess.run(argv,cwd=directory,env=env,capture_output=True,timeout=5);(directory/'stdout').write_bytes(c.stdout);(directory/'stderr').write_bytes(c.stderr)
  rec.update(exit_code=c.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(c.stdout),stderr_sha256=sha(c.stderr));rec['inputs_unchanged']=all(sha((directory/'inputs'/x['path']).read_bytes())==x['sha256'] for x in inputs) if False else not any(sha((directory/'inputs'/x['path']).read_bytes())!=x['sha256'] for x in inputs)
  if control['id']!='KE03':
   actual=json.loads(c.stderr);rec['actual_error']=actual['error'];rec['meets_frozen_expectation']=c.returncode==3 and actual['error']=='knowledge_unavailable' and c.stdout==b''
  else:
   actual=json.loads(c.stdout);rec['meets_frozen_expectation']=c.returncode==0 and c.stderr==b'' and actual['selection_status']=='complete' and [x['feature_id']for x in actual['selected']]==['maintenance'] and actual['selected'][0]['execution_status']=='not_run'
  (directory/'command.json').write_text(json.dumps(rec,indent=2)+'\n');all.append(rec)
summary={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'confirmed_old_defect_closed_by_new_source','old':[{'case':x['case'],'exit':x['exit_code'],'error':x.get('actual_error'),'expected':x['meets_frozen_expectation']}for x in all if x['candidate']=='old'],'new':[{'case':x['case'],'exit':x['exit_code'],'error':x.get('actual_error'),'expected':x['meets_frozen_expectation']}for x in all if x['candidate']=='new'],'all_input_hashes_unchanged':not any(not x['inputs_unchanged']for x in all),'scope':'Six independent CLI calls using copied exact old/new sources and controlled imported module. Not original 60 checks, not new BM25/full/product/native-host validation.'}
assert [x['meets_frozen_expectation']for x in all]==[False,False,True,True,True,True]
(r/'report.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
