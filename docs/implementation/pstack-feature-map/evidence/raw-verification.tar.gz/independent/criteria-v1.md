# W18 独立验收预冻 v1

记录时间：2026-10-30T06:08:36.347336+00:00。未查看新实现或作者结果、未执行候选；不主张早于作者一切实现活动。

- **FM01 Metadata-only ranking and selected-only reads**：Rank index metadata; unrelated body containing query bait must never be read. Digest selected exact bytes; retain reasons and omitted IDs.
- **FM02 Required closure**：Packet requires low-ranking journey; both read with limit1. Maintenance does not acquire journey merely through internal driver use. No silent drop on closure limits.
- **FM03 Closed input and graph**：Reject malformed/unknown fields according to frozen contract, duplicate IDs, unknown dependencies and cycles. No product actions.
- **FM04 Finite bounds**：Index<=65536 bytes/32 IDs, query<=4096 bytes, limit integer1..5, closure<=8, leaf<=32768 bytes,total<=131072; boundary accepted when otherwise valid, excess refused without truncating required content.
- **FM05 Files and path**：Reject path escape and unsupported file types. Freeze symlink policy from author contract before implementation read; exercise leaf link,parent link,root alias and traversal. Do not call alias checks an OS sandbox.
- **FM06 Missing and changed material**：Selected/required missing or same-size content different from index pin cannot count complete matching read. Unrelated malformed body must not be loaded merely to validate all leaf contents.
- **FM07 Explicit freshness**：Missing source/driver observations unknown; supplied exact observations may match only those comparisons; distinct source or driver mismatch drift. Historical last-live claims remain draft/unverified.
- **FM08 Prerequisites and ownership**：Explicitly missing data/auth/entitlement/runtime blocked; unobserved unknown; caller declarations labeled. No credential probing or arbitrary not-applicable pass; absent owner unassigned.
- **FM09 Coverage and authority**：Two-entry fixture with one covered never asserts both covered; selected leaves do not prove actual entries driven. Exit0/selection complete not product pass, evidence authentication, host delivery, formal A35/A48/C0 or model understanding.
- **FM10 Correction and no match**：Two independent queries choose differing relevant sets and material identities; retain earlier result; no match explicit, no hidden fallback to all leaves.
- **FM11 Actual entrypoints**：Run actual selector CLI against three delivered leaves and validate exact command/flags against existing entry implementations; no product drive or old C0 rerun implicit in this review.
- **FM12 Reproducible bounded evidence**：Record source/compiled bindings if used, exact inputs/argv/output/exits and read-seam events; preserve expected failures and harness mistakes. Inputs immutable and no production/central writes.

30 个具体输入配方和预期见 criteria-v1.json。接口/状态码/读 seam 与 symlink 策略待作者契约后另档绑定；不覆盖原预期。本轮未计通过，原 C0、A35/A48 完整验收边界不变。
