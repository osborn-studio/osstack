# W18 有限独立验证

**未发现本次有界向量中的确认产品缺陷。** 验证对象是源码 SHA-256 `5b734095d48ad02642e2bef0d454bea77d42f4db64732fea3fc6f0dc2b1f3c76`，实际索引 `1379f90e278a8ef5f0bc12be241bff2b09e421a7c129ac1cddb226643085a6f1`。测试时 HEAD 为 `0294c2dc956eb422dba584111c0e519ef941ed5c`，新文件尚未被本报告认定为已提交候选；绑定真实文件字节。

## 实际检查

- 预冻 12 准则、30 输入配方展开成 60 项 API/文件/CLI 检查。首轮 59 项通过；另 1 项验证器夹具目录重名，mkdir EEXIST 发生在产品调用前。原错误完整保留，只给该项换独立目录再执行，相同期望通过。不能将其写成产品 RED→GREEN。
- metadata bait 及无关损坏正文均未被读取；required 低排名依赖照常加载，维护场景不因为驱动内部调用而加载全库。读取事件为 API diagnostic seam，已读源码核其位于实际有界读取后；不称系统级 I/O 监控。
- 64 KiB/32 IDs、4 KiB UTF-8 query、1–5 limit、8 叶闭包、32 KiB 单叶、128 KiB 总量的边界及超限得到对应接受/拒绝；无 required 裁剪。重复、未知依赖、循环、路径逃逸、叶/父路径 symlink、目录/FIFO、缺件、同长度摘要漂移按约束拒绝。index parent alias 正控制接受，terminal index symlink 拒绝。
- 缺观察保持 unknown；source/driver 不同分别 drift；四类前提的 met/missing/unknown 输入分别保留 reported_met/blocked/unknown。材料完整可 exit0，但 execution 均 not_run，历史 evidence 保持 draft/unverified。双入口 fixture 只声明单入口 covered 时，所有入口仍 unverified，不升级实际覆盖。
- 真实 CLI 四次：维护只选 maintenance，完整旅程只选 journey，packet 选 packet+journey，无匹配 exit1。五个实际文档/索引文件调用前后哈希不变，所选正文、字节数和索引摘要一致。六个 source/driver pin 分别与实际文件一致。
- 三叶四条 user_route 用公开旧 CLI `parseOptions` 实际解析通过；变量仅替换为绝对自有占位路径，没有驱动产品或执行 shell 教程。源读核对维护0/1/2、journey0/1/2、projection/check0/1/2及 full/check 参数，未见新授权或新证据权威宣传。

## 不能据此声明的内容

这是窄材料检索与状态描述验证，不是完整 W18/A35/A48、C0 或 formal gate 通过。真实三场景都是 CLI；packet 的两个命令也不是两个表面。未做模型/宿主消费、证据 authority resolver、Firstmate 深运行、产品 full5 重跑、全仓回归或 C0 重复。原 last-live/covered 均空，符合尚未驱动的事实。

没有穷举全部 schema/编码错误或并发 race；symlink 和快照检查不是 OS sandbox。没有验证转移闭包外任意依赖的构建真实性。root 在独立执行前修复的预算前置检查归 root 回归，不能算本独立发现。

## 原件

`criteria-v1.json` / `prefreeze-manifest.json` 是查看实现前冻结；`contract-binding-v1.json` 和 `wire-observations.json` 明确状态/路径语义。`blackbox-v1.mjs` 保留原冻结脚本；v2 仅在执行前增加断言前落原始结果，不改变预期。`run-01/` 保留首轮全部结果、每次 API 原返回与夹具；`v22-corrected/` 仅补未调用产品的一项。FIFO 无字节 payload，已仅删除本次测试自有 FIFO，原类型与拒绝证据另存 `owned-fifo-cleanup.json`。其余失败/输入未覆盖。

`actual-cli/` 包含真实命令、stdout/stderr、文档前后哈希和源码 pins。`entry-parse-results.json` 为解析而非执行证据；`source-build-binding.json` 为实际使用代码/knowledge 构建字节。详细逐准则映射见 `report.json`。
