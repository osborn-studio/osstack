import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const [modulePath, out] = process.argv.slice(2);
if (!path.isAbsolute(modulePath || '') || !path.isAbsolute(out || '')) throw Error('absolute module/output required');
await fs.mkdir(out, {recursive:false});
const mod = await import(pathToFileURL(modulePath));
const sha=b=>createHash('sha256').update(b).digest('hex');
const enc=x=>Buffer.from(JSON.stringify(x));
const cases=[];
let callNumber=0;
async function retainCall(value) { await fs.writeFile(path.join(out,`call-${String(++callNumber).padStart(3,"0")}.json`),JSON.stringify(value,null,2)+"\n"); return value; }
const baseLeaf=id=>({schema_version:1,feature_id:id,user_outcome:`Goal ${id}`,source_revision:'source-one',driver_version:'driver-one',entries:[{id:'run',surface:'cli',user_route:'node example.mjs --fixed'}],preconditions:[{id:'build',kind:'runtime',description:'Matching build'}],drive_refs:['example.mjs'],observations:[{predicate_id:'end',observable:'Read end receipt',side_effects:[]}],gotchas:[],recovery_refs:['Preserve failure and use fresh output'],covered_entry_ids:['run'],known_gaps:['CLI only'],last_live_evidence:[]});
async function fixture(name,ids=['maintenance','journey','packet']) {
 const dir=path.join(out,name);await fs.mkdir(dir);
 const leaves=Object.fromEntries(ids.map(id=>[id,baseLeaf(id)]));
 const index={schema_version:1,features:ids.map(id=>({feature_id:id,user_outcome:leaves[id].user_outcome,keywords:[id],surfaces:['cli'],leaf_ref:`${id}.json`,sha256:'0'.repeat(64),required_feature_ids:id==='packet'?['journey']:[],maintenance_owner_ref:null}))};
 const f={dir,index,leaves,indexPath:path.join(dir,'index.json')};
 f.saveLeaf=async(id,bytes)=>{bytes=bytes??enc(leaves[id]);await fs.writeFile(path.join(dir,`${id}.json`),bytes);index.features.find(r=>r.feature_id===id).sha256=sha(bytes);};
 f.saveIndex=async(bytes)=>fs.writeFile(f.indexPath,bytes??enc(index));
 for (const id of ids) await f.saveLeaf(id);await f.saveIndex();return f;
}
const pad=(b,n)=>{assert.ok(b.length<=n,`fixture too large ${b.length}>${n}`);return Buffer.concat([b,Buffer.alloc(n-b.length,32)]);};
async function call(f, opts={}) {
 const reads=[];const start=performance.now();
 try {const result=await mod.selectFeatureMap({index:f.indexPath,query:'maintenance',...opts},{onRead:e=>reads.push(e)});return await retainCall({result,reads,ms:performance.now()-start});}
 catch(e){return await retainCall({error:{code:e.code??null,name:e.name,message:e.message,details:e.details??null},reads,ms:performance.now()-start});}
}
const ids=r=>r.result.selected.map(s=>s.feature_id);
const complete=r=>{assert.equal(r.error,undefined,JSON.stringify(r.error));assert.equal(r.result.selection_status,'complete');for(const s of r.result.selected)assert.equal(s.execution_status,'not_run');};
const code=(r,want)=>assert.equal(r.error?.code,want,JSON.stringify(r));
async function test(name,fn){let raw;try{raw=await fn();cases.push({name,status:'pass',raw});}catch(e){cases.push({name,status:'fail',error:{name:e.name,message:e.message,stack:e.stack},raw});}await fs.writeFile(path.join(out,'results.json'),JSON.stringify(cases,null,2)+'\n');}
await test('V01 selected only',async()=>{const f=await fixture('v01');const r=await call(f);complete(r);assert.deepEqual(ids(r),['maintenance']);assert.ok(r.reads.every(x=>!/(journey|packet)\.json$/.test(x.path)));assert.equal(r.result.selected[0].sha256,f.index.features[0].sha256);return r;});
await test('V02 body bait',async()=>{const f=await fixture('v02');f.leaves.packet.gotchas=['maintenance '.repeat(100).trim()];await f.saveLeaf('packet');await f.saveIndex();const r=await call(f);complete(r);assert.deepEqual(ids(r),['maintenance']);assert.ok(r.reads.every(x=>!x.path.endsWith('packet.json')));return r;});
await test('V03 required below rank',async()=>{const f=await fixture('v03');const r=await call(f,{query:'packet',limit:1});complete(r);assert.deepEqual(ids(r),['packet','journey']);return r;});
await test('V04 internal driver no dependency',async()=>{const f=await fixture('v04');f.leaves.maintenance.drive_refs=['scripts/method-verification-journey.mjs'];await f.saveLeaf('maintenance');await f.saveIndex();const r=await call(f);complete(r);assert.deepEqual(ids(r),['maintenance']);return r;});
await test('V05 no match',async()=>{const f=await fixture('v05');const r=await call(f,{query:'zzzunmatchedzzq'});assert.equal(r.result.selection_status,'no_match');assert.deepEqual(ids(r),[]);assert.ok(r.reads.every(x=>x.path.endsWith('index.json')));return r;});
await test('V06 correction',async()=>{const f=await fixture('v06');const a=await call(f);const before=JSON.stringify(a);const b=await call(f,{query:'packet'});complete(a);complete(b);assert.deepEqual(ids(a),['maintenance']);assert.deepEqual(ids(b),['packet','journey']);assert.equal(JSON.stringify(a),before);return {a,b};});
await test('V07 missing required',async()=>{const f=await fixture('v07');await fs.unlink(path.join(f.dir,'journey.json'));const r=await call(f,{query:'packet'});code(r,'required_material_missing');return r;});
await test('V08 same-size content',async()=>{const f=await fixture('v08');const p=path.join(f.dir,'maintenance.json');const b=await fs.readFile(p);await fs.writeFile(p,Buffer.from(b.toString().replace('Goal','Goad')));const r=await call(f);code(r,'content_drift');return r;});
await test('V09 unrelated malformed leaf',async()=>{const f=await fixture('v09');await fs.writeFile(path.join(f.dir,'packet.json'),'{broken');const r=await call(f);complete(r);assert.ok(r.reads.every(x=>!x.path.endsWith('packet.json')));return r;});
for (const [name,mut,want] of [
 ['duplicate',f=>f.index.features.push({...f.index.features[0]}),'invalid_index'],
 ['unknown',f=>f.index.features[0].required_feature_ids=['missing'],'unknown_dependency'],
 ['cycle',f=>{f.index.features[0].required_feature_ids=['journey'];f.index.features[1].required_feature_ids=['maintenance'];},'dependency_cycle'],
 ['extra-field',f=>f.index.unknown=true,'invalid_index']
])await test(name,async()=>{const f=await fixture(name);mut(f);await f.saveIndex();const r=await call(f);code(r,want);return r;});
for(const n of [65536,65537])await test(`V13 index bytes ${n}`,async()=>{const f=await fixture(`index-${n}`);await f.saveIndex(pad(enc(f.index),n));const r=await call(f);n===65536?complete(r):code(r,'file_too_large');return r;});
for(const n of [32,33])await test(`V13 IDs ${n}`,async()=>{const f=await fixture(`ids-${n}`,Array.from({length:n},(_,i)=>`feature-${i}`));const r=await call(f,{query:'feature-0'});n===32?complete(r):code(r,'invalid_index');return r;});
for(const n of [4096,4097])await test(`V14 query bytes ${n}`,async()=>{const f=await fixture(`query-${n}`);const q='é'.repeat(2048)+(n===4097?'x':'');assert.equal(Buffer.byteLength(q),n);const r=await call(f,{query:q});if(n===4096)assert.equal(r.error,undefined);else code(r,'invalid_arguments');return r;});
for(const n of [0,1,1.5,5,6])await test(`V15 limit ${n}`,async()=>{const f=await fixture(`limit-${n}`);const r=await call(f,{limit:n});[1,5].includes(n)?complete(r):code(r,'invalid_arguments');return r;});
for(const n of [8,9])await test(`V16 closure ${n}`,async()=>{const f=await fixture(`closure-${n}`,Array.from({length:n},(_,i)=>`feature-${i}`));for(let i=0;i<n-1;i++)f.index.features[i].required_feature_ids=[`feature-${i+1}`];await f.saveIndex();const r=await call(f,{query:'feature-0'});if(n===8){complete(r);assert.equal(ids(r).length,8);}else code(r,'selection_budget');return r;});
for(const n of [32768,32769])await test(`V17 leaf bytes ${n}`,async()=>{const f=await fixture(`leaf-${n}`);await f.saveLeaf('maintenance',pad(enc(f.leaves.maintenance),n));await f.saveIndex();const r=await call(f);n===32768?complete(r):code(r,'file_too_large');return r;});
for(const extra of [0,1])await test(`V18 aggregate ${131072+extra}`,async()=>{const list=['first','second','third','fourth',...(extra?['fifth']:[])];const f=await fixture(`aggregate-${extra}`,list);for(let i=0;i<list.length-1;i++)f.index.features[i].required_feature_ids=[list[i+1]];for(let i=0;i<4;i++)await f.saveLeaf(list[i],pad(enc(f.leaves[list[i]]),32768-(extra&&i===0?enc(f.leaves.fifth).length-1:0)));if(extra)await f.saveLeaf('fifth');await f.saveIndex();const r=await call(f,{query:'first'});extra?code(r,'selection_budget'):complete(r);return r;});
for(const ref of ['../outside.json','/outside.json','a\\b.json','./maintenance.json'])await test(`V19 path ${ref}`,async()=>{const f=await fixture(`path-${cases.length}`);f.index.features[0].leaf_ref=ref;await f.saveIndex();const r=await call(f);assert.ok(r.error);assert.ok(r.reads.every(x=>x.path.endsWith('index.json')));return r;});
await test('V20 leaf symlink',async()=>{const f=await fixture('leaf-link');await fs.rename(path.join(f.dir,'maintenance.json'),path.join(out,'outside.json'));await fs.symlink(path.join(out,'outside.json'),path.join(f.dir,'maintenance.json'));const r=await call(f);code(r,'symlink');return r;});
await test('V20 parent symlink',async()=>{const f=await fixture('parent-link');await fs.mkdir(path.join(out,'outside-dir'));await fs.copyFile(path.join(f.dir,'maintenance.json'),path.join(out,'outside-dir','leaf.json'));await fs.symlink(path.join(out,'outside-dir'),path.join(f.dir,'linked'));f.index.features[0].leaf_ref='linked/leaf.json';await f.saveIndex();const r=await call(f);code(r,'symlink');return r;});
await test('V20 root alias allowed',async()=>{const f=await fixture('alias-target');await fs.symlink(f.dir,path.join(out,'alias'));f.indexPath=path.join(out,'alias','index.json');const r=await call(f);complete(r);return r;});
await test('V20 terminal index symlink',async()=>{const f=await fixture('index-link');await fs.symlink(f.indexPath,path.join(f.dir,'alias.json'));f.indexPath=path.join(f.dir,'alias.json');const r=await call(f);code(r,'symlink');return r;});
await test('V21 directory',async()=>{const f=await fixture('directory');await fs.unlink(path.join(f.dir,'maintenance.json'));await fs.mkdir(path.join(f.dir,'maintenance.json'));const r=await call(f);code(r,'not_regular');return r;});
await test('V21 FIFO bounded',async()=>{const f=await fixture('fifo');const p=path.join(f.dir,'maintenance.json');await fs.unlink(p);const mk=spawnSync('/usr/bin/mkfifo',[p]);assert.equal(mk.status,0);const r=await call(f);code(r,'not_regular');assert.ok(r.ms<2000);return r;});
await test('V22 unknown freshness and ownership',async()=>{const f=await fixture('unknown');const r=await call(f);complete(r);const s=r.result.selected[0];assert.deepEqual(s.freshness,{source:'unknown',driver:'unknown'});assert.equal(s.availability,'unknown');assert.equal(s.maintenance_owner_ref,null);assert.equal(s.evidence_status,'draft');assert.deepEqual(s.unverified_entry_ids,['run']);return r;});
// Observations wire/status enumeration supplied separately before first execution.
const wire=JSON.parse(await fs.readFile(new URL('./wire-observations.json',import.meta.url),'utf8'));
for(const variant of ['source','driver','match'])await test(`V23/24 ${variant}`,async()=>{const f=await fixture(`freshness-${variant}`);const o={schema_version:1,features:[{feature_id:'maintenance',source_revision:variant==='source'?'source-two':'source-one',driver_version:variant==='driver'?'driver-two':'driver-one',preconditions:[],observed_entry_ids:['run']}]};const p=path.join(f.dir,'observations.json');await fs.writeFile(p,enc(o));const r=await call(f,{observations:wire.parameter==='path'?p:o});complete(r);const s=r.result.selected[0];assert.equal(s.freshness.source,variant==='source'?'drift':'matches_reported');assert.equal(s.freshness.driver,variant==='driver'?'drift':'matches_reported');assert.deepEqual(s.unverified_entry_ids,['run']);assert.equal(s.evidence_status,'draft');return r;});
for(const kind of ['data','auth','entitlement','runtime'])for(const state of ['missing','unknown','met'])await test(`V25 ${kind}/${state}`,async()=>{const f=await fixture(`prereq-${kind}-${state}`);f.leaves.maintenance.preconditions[0].kind=kind;await f.saveLeaf('maintenance');await f.saveIndex();const o={schema_version:1,features:[{feature_id:'maintenance',source_revision:null,driver_version:null,preconditions:[{id:'build',status:wire.status[state]}],observed_entry_ids:[]}]};const p=path.join(f.dir,'observations.json');await fs.writeFile(p,enc(o));const r=await call(f,{observations:wire.parameter==='path'?p:o});complete(r);assert.equal(r.result.selected[0].preconditions[0].status,{missing:'blocked',unknown:'unknown',met:'reported_met'}[state]);return r;});
await test('V27 two-entry bookkeeping',async()=>{const f=await fixture('two-entry');f.leaves.maintenance.entries.push({id:'rpc',surface:'rpc',user_route:'named.rpc.method'});f.index.features[0].surfaces.push('rpc');f.leaves.maintenance.last_live_evidence=[{ref:'retained/old',sha256:'a'.repeat(64)}];await f.saveLeaf('maintenance');await f.saveIndex();const r=await call(f);complete(r);const s=r.result.selected[0];assert.deepEqual(s.declared_covered_entry_ids,['run']);assert.deepEqual(s.unverified_entry_ids,['run','rpc']);assert.equal(s.evidence_status,'unverified');return r;});
for(const args of [['--bad'],['--index'],['--index','missing','--query','x','--limit','0']])await test('V29 CLI '+args.join(' '),async()=>{const r=spawnSync(process.execPath,[modulePath,...args],{encoding:'utf8',timeout:5000,maxBuffer:1048576,env:{PATH:process.env.PATH,OSSTACK_SCRATCH_ROOT:out}});assert.equal(r.status,2);assert.equal(r.stdout,'');assert.ok(JSON.parse(r.stderr).error);return {args,status:r.status,stdout:r.stdout,stderr:r.stderr};});
const summary={module:modulePath,source_sha256:sha(await fs.readFile(modulePath)),total:cases.length,passed:cases.filter(x=>x.status==='pass').length,failed:cases.filter(x=>x.status==='fail').length,scope:'offline API real files plus CLI misuse; no product drives/model/full; actual leaf CLI followup separate'};
await fs.writeFile(path.join(out,'summary.json'),JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));process.exitCode=summary.failed?1:0;
