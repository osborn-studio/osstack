# W17 / A39 有限冷使用验收

固定 main `01ec1852ffcf0cff4f1e4a0632b1ae3a8ddc1211`。选择缺行地图的真实预检拒绝，再仅修自有副本，用同一现有维护CLI新output恢复。恢复后的一次五例真实运行同时满足正常终点；不重复驱动，不强制投影。

教程应公开正常接口、闭合地图契约、退出语义、证据路径和一般恢复原则，不写本次具体坏行、构造脚本或执行答案。冷执行者只拿neutral任务、教程和待检输入副本；oracle独立保留。

**CU01 真正cold与材料界限**：执行agent由root新建无继承历史，不预读作者结果/criteria/oracle/旧实验；只获最小教程、任务与本次绝对路径，可读教程明确链接的canonical地图和本次实际结果。记录其初始prompt和工具trace；无法证明上下文边界则此轴unknown，不把熟悉历史的本组agent改称cold。

**CU02 固定来源与准备状态**：执行前绑定main01ec、实际checkout/source/build与教程字节。环境由root准备已安装/构建且保持dist；本轮不验证冷安装速度。若环境不可用，blocked而非修改产品或换旧日志。

**CU03 真实输入拒绝**：用现有CLI和给定待检地图执行，预期结构无效返回exit2/map_case_set；失败output不创建，无journey/driver启动。保留原argv/cwd/env最小声明/时间/exit/stdout/stderr，不将预检拒绝叫产品故障。

**CU04 可理解的诊断**：coldagent依据实际错误及公开地图契约解释结构无效，区分输入/工具/产品，指出可恢复动作；不靠额外oracle指导，不虚构运行了五例。若需要人工给修法，记录intervention并将独立恢复轴limited。

**CU05 同入口恢复且仅授权写**：保留原给定地图/失败日志；仅在自有scratch新地图修正或从canonical重新复制，用同maintain-skills-check-map入口和新output重试。不得改生产代码/测试/默认home/既有证据，不能降谓词或将产品失败改成成功预期。

**CU06 真实正常fixed5终点**：恢复后CLI exit0/status consistent、execution_path runJourney，真实five rows完整顺序healthy/missing-ref/drift/mixed/empty，产品exit0/1/2/1/0、对应状态healthy/failed/drift/failed/empty，driver均0。每例完整行为/evidence通过，不以overall exit0单独证明。正常终点由恢复成功一次满足，不另要求重复drive。

**CU07 证据可查与来源不变**：实际maintenance/journey/case manifest、原stdout/stderr和map-before保留，校验成员bytes/hash，运行内map before/after相等，原任务输入不变，生产source/build绑定前后未被cold修改。哈希是内容一致性，不是身份认证。

**CU08 资源所有权与清理**：显式scratch，开发CLI不碰默认OSSTACK_HOME/管理socket；五case原fixture应实际不存在且原回执保留，unknown cleanup不报成功。只清自己资源；不声称所有后代/OS隔离/全局副作用无。

**CU09 解释结果而非照报退出码**：cold最终报告能解释预期missing-ref失败和drift仍可让验证通过、empty不等于健康来源，给失败/成功证据位置及作用范围。不要求固定词数或字符串相等，人工按事实评语义。

**CU10 有限结论与停止**：这是A39一个已构建环境的教程可用性试点，不完成W17全部、C0全部、W18/W19或C1/C2，不是native hostCLI/独立principal资格。正常预期为一次预检拒绝+一次恢复执行；意外环境/权限/产品失败保留blocked，不自动追加试验翻绿。无新模型审计或旧host重跑。

此冻结发生在cold执行前。作者教程与fixture准备不是cold执行结果；新代理能完成不等于真实人类用户或任一native宿主已完成。
