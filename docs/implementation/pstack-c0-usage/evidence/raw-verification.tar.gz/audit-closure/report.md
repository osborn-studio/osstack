**结论：处置足够关闭首审的措辞和披露类意见，但不足以撤掉 concerns。** 建议维持 `PASS_WITH_CONCERNS`，范围限定为"已构建环境、既有接口、一次输入拒绝加一次恢复"。C5 的措辞未改完，其余五项各有小残余。

我只依据你贴出的文本判断，没有重算任何 hash，也没有重审首审范围外的内容（如"241 项设计文档验证"）。

| 项 | 处置 | 判断 |
|---|---|---|
| C1 | 补了新 shell 恢复提示，说明是 Python 等价调用，保存了 `92700fcf` 测试版教程 | 足够，有残余 |
| C2 | 补了 journey 源码 | 足够，有小残余 |
| C3 | 改成"请求 `fork_turns=none`、未经外部审计"，披露了 prompt 预告、`git status` 可见路径和 criteria 位置 | 基本足够，有残余 |
| C4 | 披露了六个 docs 修改和两个未跟踪目录，补了停写后快照，给了 `merge-proof.json` | 基本足够，有残余 |
| C5 | 只加了"预写判据由另一协作代理完成，不等同独立身份认证" | **不足** |
| C6 | 明写未用默认 canonical 示例，也未执行可选投影 | 披露足够，但见下面的新发现 |

## 仍需保留的 concerns

1. **C5：README 前后矛盾，冻结顺序仍无绑定。**
   - 首段仍写"独立判据在冷读执行前冻结"，小节标题仍是"独立判据结果与限制"，后文却说判据"不等同独立身份认证"。
   - `cold-freeze.json` 只绑定教程和 prompt，不含 criteria 的 hash。独立报告自己也承认 dispatch 没有独立时间戳。
   - 先后顺序因此只靠 criteria 自报的 `frozen_utc` 和 root 的记录。
   - 建议改成"预先书写的判据（SHA `1830eb1f…`），冻结顺序由 root 记录，未被 hash 绑定"。

2. **C3：术语仍超出 CU01 的 unknown。**
   - 标题和正文仍用"冷读""冷代理"，"新代理请求无继承历史"一句缺少 `fork_turns=none` 的请求限定。
   - 建议给"冷"下定义：指无继承历史的请求，不代表排他上下文。
   - README 只给 8 项通过加两项例外的计数，可以接受，但应指向 `graded-results.json`。

3. **C1：测试后改动没有 diff。**
   - 你说最新教程"只增"变量提示和快照措辞，但 `author/tested-tutorial.md` 与最新版的 diff 没有提供，我无法确认"只增"。请附 diff 和两个 hash。
   - 教程仍保留"同一个 shell 脚本中按顺序执行、保留变量"，与新提示并存，略矛盾。
   - 新提示只是文字说明，没有可粘贴的重建命令，且未实测。

4. **C2：依据现在足够，只差版本绑定。**
   - 源码里 `runJourney` 对每个案例依次跑 doctor 和 drive，doctor 须满足 `ready===true`、`executed===false`、`cases` 恰为 `[id]` 且输出目录尚不存在。
   - doctor 记录写在 journey 顶层，不在案例 manifest 里，这解释了首审"案例清单里没有 doctor"的疑问。
   - 佐证：5×2×3 个 stdout/stderr/command 文件加 `journey.json`、`feature-map.md`，刚好 32，与独立报告的 32 成员一致。这是算术推断，不是我核验的结果。
   - 残余一：所供源码（`b030e182…`）应与 `journey.json` 里的 `tool_files` 哈希对上，目前没有。
   - 残余二：`maintain-skills-check-map.mjs` 仍未提供，"维护入口经 `runJourney`"只靠 `execution_path` 自报。教程里"工具自己调用 doctor"可改成"维护入口经 `runJourney` 调用"。

5. **C4：树比对证据偏弱。**
   - 停写后快照（05:27:58，`changed: []`）已补上观察窗口缺口，脏树披露也够了。
   - `merge-proof.json` 只有三个值，没有命令输出，字段含义也没说明。
   - README 没写被测 checkout 的 HEAD 是 `c8398318`（即 control_merge）。
   - 建议 README 引用该文件并标为 root 记录，写明测试树是 `c8398318`，不声称它等于 main，并点名未跟踪的 `docs/verification/` 就是被测教程。

6. **C6：可选投影段可能与工具自述冲突。**
   - 所供 journey 源码写入 `feature-map.md` 的文案是 "Existing two-case projection does not accept this scope"。
   - 教程可选段却要求对五案例 journey 用 projector 加 `--scope full`。
   - projector 源码没提供，我无法判断是冲突还是 projector 已更新。
   - README 已声明未实测，披露没问题，但教程本身该段应标"未验证"，或补 projector 源码或 `--help`。

CU01 unknown、CU08 limited、工具预算和身份、原 A39 状态都按你的要求保持原样，我没有升级任何一项。