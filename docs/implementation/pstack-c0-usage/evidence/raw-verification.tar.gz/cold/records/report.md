# Cold reader 使用记录

本次仅依最小教程检查指定待检地图。未读取产品源码、其他代理记录或历史实验，未启动模型 CLI、联网服务、管理实例、后台任务、全仓测试或可选投影。

第一次尝试：维护入口退出 2，stderr 为 {"status":"blocked","exit_code":2,"error":"map_case_set"}，未创建 attempt-01 目录。原输入只有 healthy、missing-ref、drift、mixed 四行，缺少教程要求的 empty；这属于输入契约拒绝，不是产品断言失败。

恢复：只在 /Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/runtime/method-control-20261030T052108Z-63611/map.json 补入 empty / 0 / empty；map-original.json 与 SOURCE_MAP 保持一致，原输入未改。使用同一入口和新目录 attempt-02，退出 0、consistent、execution_path=runJourney、map.unchanged=true，五行 matches=true。

| case | 实际产品退出码 | 实际产品状态 | 验证 | driver 退出码 |
| --- | --- | --- | --- | --- |
| healthy | 0 | healthy | passed | 0 |
| missing-ref | 1 | failed | passed | 0 |
| drift | 2 | drift | passed | 0 |
| mixed | 1 | failed | passed | 0 |
| empty | 0 | empty | passed | 0 |

healthy 表示固定来源可检查；missing-ref 是缺失引用失败；drift 是当前来源与认可版本不同；mixed 是失败与漂移并存且失败优先；empty 表示没有检查来源，不能证明来源健康。负例产品退出 1/2 是已验证的预期行为。driver 退出 0 只表示验证成功，不表示负例来源被修复。

收尾核对：journey.status=passed，五项 cleanup.status=passed 且 fixture_removed=true；记录的五个具体 fixture 路径均已不存在。五个案例 manifest 列出的 145 份文件仍可读，大小及 SHA-256 相符；必需顶层证据亦可读。未断言所有后代进程已终止。

证据根：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/runtime/method-control-20261030T052108Z-63611
执行和操作记录：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/records
维护证据：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/runtime/method-control-20261030T052108Z-63611/attempt-02/maintenance.json
旅程证据：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/runtime/method-control-20261030T052108Z-63611/attempt-02/journey/journey.json
独立留存检查：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/records/12-verify-retained.stdout
修改理由和实际 argv：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/records/09-correct-owned-map.json
每步 JSON 记录 argv、cwd、必要环境、UTC 开始/结束时间、退出码和 stdout/stderr 路径。00–12 为教程阅读、准备、两次执行、修正和证据读取核对；run.py 与 verify-retained.py 保留记录方法。

源码版本/状态与 Node：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/runtime/method-control-20261030T052108Z-63611/checkout-revision.txt、checkout-status.txt、node-version.txt。
协调者预建日志：/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/install.log 和 /Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/build.log（本代理未读取、未重建）；本次来源/构建绑定在各案例 bindings.json 与 journey 收据中保留。

范围限制：仅验证固定五例的教程冷使用与输入拒绝后恢复；不证明任意项目覆盖、模型自主操作、正式资格或整个 W17/C0 通过，也不能称为接口首次冻结前实验。留存哈希和绑定不能认证独立来源或证明编译调用。本次无残余阻塞。
