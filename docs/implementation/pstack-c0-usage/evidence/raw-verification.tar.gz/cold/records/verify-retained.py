import sys,json,pathlib,hashlib,os,datetime
root=pathlib.Path(sys.argv[1]);out=root/'attempt-02'; journey=out/'journey'
m=json.loads((out/'maintenance.json').read_text());j=json.loads((journey/'journey.json').read_text())
assert m['status']=='consistent' and m['exit_code']==0 and m['execution_path']=='runJourney' and m['map']['unchanged'] is True
assert j['status']=='passed'
expected={'healthy':(0,'healthy'),'missing-ref':(1,'failed'),'drift':(2,'drift'),'mixed':(1,'failed'),'empty':(0,'empty')}
assert len(m['rows'])==5 and set(r['case_id'] for r in m['rows'])==set(expected)
for row in m['rows']:
    assert row['matches'] is True
    assert (row['actual']['product_exit'],row['actual']['product_status'])==expected[row['case_id']]
assert len(j['features'])==5
retained=[]
for relative in ['map-before.json','maintenance.json','journey/feature-map.md','journey/journey.json','journey/journey-manifest.json']:
    p=out/relative;b=p.read_bytes();retained.append({'path':str(p),'readable':True,'bytes':len(b)})
checks=[]
for f in j['features']:
    case=f['case_id'];assert f['verification']=='passed' and f['driver_exit']==0
    assert (f['product_exit'],f['product_status'])==expected[case]
    case_root=journey/'cases'/case
    manifest_bytes=(case_root/'manifest.json').read_bytes()
    assert hashlib.sha256(manifest_bytes).hexdigest()==f['manifest_sha256']
    manifest=json.loads(manifest_bytes)
    files=[]
    for entry in manifest['files']:
        p=case_root/entry['path'];assert p.resolve().is_relative_to(case_root.resolve())
        b=p.read_bytes();assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256']
        files.append({'path':entry['path'],'bytes':len(b),'readable':True,'hash_matches':True})
    cleanup=json.loads((case_root/'cleanup.json').read_text())
    assert cleanup['status']=='passed' and cleanup['fixture_removed'] is True
    fixture=pathlib.Path(cleanup['fixture_path']);assert fixture.is_relative_to(out)
    exists=os.path.lexists(fixture);assert exists is False
    checks.append({'case_id':case,'product_exit':f['product_exit'],'product_status':f['product_status'],'driver_exit':f['driver_exit'],'verification':f['verification'],'cleanup':cleanup,'fixture_exists_at_check':exists,'retained_files':files})
source=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold/task-map.json')
assert source.read_bytes()==(root/'map-original.json').read_bytes()
result={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','maintenance_status':m['status'],'execution_path':m['execution_path'],'map_unchanged_during_run':m['map']['unchanged'],'original_input_unchanged':True,'journey_status':j['status'],'required_files':retained,'cases':checks,'limitations':['仅核对固定五例冷使用路径。','未运行模型、原生宿主、可选投影或全仓测试；不是正式资格或整个 W17/C0 通过。','fixture 路径不存在不证明所有后代进程终止。','哈希一致性不认证独立来源，也不证明编译调用。']}
print(json.dumps(result,ensure_ascii=False,indent=2))
