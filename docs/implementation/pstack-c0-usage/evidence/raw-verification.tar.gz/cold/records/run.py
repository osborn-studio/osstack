import os, sys, json, subprocess, datetime, pathlib
ROOT=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/cold')
CWD='/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-c0-usage'
RECORDS=ROOT/'records'
ENV=os.environ.copy()
ENV['PATH']='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin'
ENV['OSSTACK_SCRATCH_ROOT']=str(ROOT)
os.umask(0o077)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(label, argv, reason, env=ENV):
    start=now()
    p=subprocess.run(argv,cwd=CWD,env=env,capture_output=True)
    end=now()
    (RECORDS/(label+'.stdout')).write_bytes(p.stdout)
    (RECORDS/(label+'.stderr')).write_bytes(p.stderr)
    (RECORDS/(label+'.json')).write_text(json.dumps({'argv':argv,'cwd':CWD,'environment':{k:env[k] for k in ['PATH','OSSTACK_SCRATCH_ROOT','OSSTACK_HOME'] if k in env},'started_at':start,'finished_at':end,'exit_code':p.returncode,'stdout':str(RECORDS/(label+'.stdout')),'stderr':str(RECORDS/(label+'.stderr')),'reason':reason},ensure_ascii=False,indent=2)+'\n')
    return p
if __name__=='__main__':
    tutorial='/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-c0-usage/docs/verification/method-control-tutorial.md'
    p=run('00-tutorial',['cat',tutorial],'保存并按最小教程执行；此前已只读查看同一教程。')
    if p.returncode: sys.exit(p.returncode)
    t=ROOT/'runtime'/('method-control-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid()))
    ENV['OSSTACK_HOME']=str(t/'home')
    p=run('01-create',['mkdir','-p',str(t/'home')],'在自有 scratch 下创建隔离场景与 OSSTACK_HOME。')
    if p.returncode: sys.exit(p.returncode)
    SOURCE=str(ROOT/'task-map.json')
    for label,argv,reason,dest in [
      ('02-copy-map',['cp',SOURCE,str(t/'map.json')],'只操作输入的自有副本。',None),
      ('03-preserve-original',['cp',str(t/'map.json'),str(t/'map-original.json')],'保留不可变输入副本。',None),
      ('04-revision',['git','rev-parse','HEAD'],'按教程记录 checkout 版本。','checkout-revision.txt'),
      ('05-status',['git','status','--short'],'按教程记录 checkout 状态，不读取源码。','checkout-status.txt'),
      ('06-node',['node','--version'],'按教程记录 Node 版本。','node-version.txt')]:
        p=run(label,argv,reason)
        if dest: (t/dest).write_bytes(p.stdout)
        if p.returncode: sys.exit(p.returncode)
    (RECORDS/'context.json').write_text(json.dumps({'tutorial_root':str(t),'source_map':SOURCE,'tutorial':tutorial,'build_logs':['/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/install.log','/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030/build.log'],'build_log_note':'协调者提供，未读取；不重建。','scope':'仅教程冷使用路径；无可选投影。'},ensure_ascii=False,indent=2)+'\n')
    output=t/'attempt-01'
    p=run('07-attempt-01',['node','scripts/maintain-skills-check-map.mjs','--map',str(t/'map.json'),'--output',str(output)],'使用教程维护入口检查未修改地图；新输出目录由工具创建。')
    pathlib.Path(str(output)+'.stdout').write_bytes(p.stdout)
    pathlib.Path(str(output)+'.stderr').write_bytes(p.stderr)
    pathlib.Path(str(output)+'.exit').write_text(str(p.returncode)+'\n')
    print(json.dumps({'tutorial_root':str(t),'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace'),'output_exists':output.exists()},ensure_ascii=False,indent=2))
