# C 独立核验：有限冷使用闭环

**有限流程已完成，观察边界保留；不签整个 A39/W17/C0 通过。** 按原 CU01–10，8 项在所列范围通过，CU01 排他冷上下文为 unknown，CU08 全局资源观察为 limited。本轮只读，没有重跑产品、自检脚本或模型。

两次同一维护入口：05:21:08.749Z 的第一次 exit2 / map_case_set，stdout 空且 attempt-01 不存在；自有地图只补 empty/0/empty 一行，原四行及原输入不变；05:21:27.777Z 的第二次新 output exit0 / consistent / runJourney。恢复后实际产品结果 healthy0、missing-ref1、drift2、mixed1、empty0，driver 均0，raw source数/失败数/漂移数与输入对应。报告对预期负例、empty及driver语义解释准确。

本轮独立读取并核验 journey manifest 的32成员、五个case manifest共145成员及其manifest摘要；五fixture现时均不存在，证据仍在。五份binding逐字相同，source1065/build2352条目与现时文件hash/size一致；root产品前后1493条目完全相等且现时逐项匹配。地图运行内hash一致，恢复图语义等canonical。构建是协调者预先准备，不能叫冷安装验收。

## 必须保留的记录限制

- root请求 fork_turns=none 并记录spawn成功；不能独立证明全部隐藏上下文或认证principal。冻结在已记录产品调用之前，dispatch文件本身没有独立事件时间戳。
- run.py是coldagent自记，不是完整工具trace。00教程记录明确承认此前已查看同一教程；本报告不将00–12视作全部阅读/工具事件。
- “独立留存检查”是同一coldagent自写自跑，准确名称应为自检。其脚本核5case共145成员，但顶层5文件只检查可读/长度，没有逐项核journey manifest32成员、live source/build。本轮C补核，不追认cold已做。
- run.py继承环境、只记录必要子集，外层subprocess无强制超时；600秒为任务约定。真实产品driver另有预算/最小环境记录。没有OS围栏、管理home全局审计或全后代终止证明。
- coldagent以Python subprocess适配教程命令，未逐字执行全部shell示例。结果支持这名fresh-request协作agent完成教程路径，不证明任意人类/native宿主或复制粘贴shell全覆盖。

原教程SHA92700fcf、criteriaSHA1830eb1f不变；原失败和自记脚本均保留。此一次恢复后的正常fixed5终点不替代W18相关叶子检索、W19通用维护或C1/C2。分轴原件路径和校验明细见JSON。
