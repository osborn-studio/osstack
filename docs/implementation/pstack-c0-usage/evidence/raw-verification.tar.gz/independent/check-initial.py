import pathlib,json,hashlib,os,datetime,subprocess
r=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-c0-usage-20261030');o=r/'independent';rec=r/'cold/records';rt=pathlib.Path(json.loads((rec/'context.json').read_text())['tutorial_root']);success=rt/'attempt-02';j=success/'journey';repo=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-c0-usage')
h=lambda b:hashlib.sha256(b).hexdigest()
J=lambda p:json.loads(pathlib.Path(p).read_text())
def write(n,v):(o/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n' if not isinstance(v,str) else v)
assert h((r/'criteria/criteria.json').read_bytes())=='1830eb1f8e2c987b206bc0b29546db50a3656fb53f39df204e2b2811962825fd'
f=J(r/'cold-freeze.json');assert h((r/'cold-prompt.txt').read_bytes())==f['prompt_sha256']; tutorial=repo/'docs/verification/method-control-tutorial.md';assert h(tutorial.read_bytes())==f['tutorial_sha256'];assert (rec/'00-tutorial.stdout').read_bytes()==tutorial.read_bytes()
assert (r/'cold/task-map.json').read_bytes()==(r/'criteria/fixtures/task-map.json').read_bytes()==(rt/'map-original.json').read_bytes()
before=J(rt/'map-original.json');after=J(rt/'map.json');canonical=J(r/'criteria/fixtures/canonical-map.json');assert before['features']==after['features'][:4] and after==canonical
assert (success/'map-before.json').read_bytes()==(rt/'map.json').read_bytes()
a,b=J(rec/'07-attempt-01.json'),J(rec/'10-attempt-02.json');assert a['exit_code']==2 and b['exit_code']==0 and a['argv'][:5]==b['argv'][:5] and a['argv'][5:]==['--output',str(rt/'attempt-01')] and b['argv'][5:]==['--output',str(success)]
assert not os.path.lexists(rt/'attempt-01');err=J(rec/'07-attempt-01.stderr');assert err=={'status':'blocked','exit_code':2,'error':'map_case_set'}
assert not (rec/'07-attempt-01.stdout').read_bytes()
for i,key in [('01','07-attempt-01'),('02','10-attempt-02')]:
 for ext in ['stdout','stderr']:assert (rt/f'attempt-{i}.{ext}').read_bytes()==(rec/f'{key}.{ext}').read_bytes()
 assert int((rt/f'attempt-{i}.exit').read_text())==J(rec/f'{key}.json')['exit_code']
m=J(success/'maintenance.json');journey=J(j/'journey.json');assert J(rec/'10-attempt-02.stdout')==m
assert m['status']=='consistent' and m['execution_path']=='runJourney' and m['map']['unchanged'] and m['map']['before_sha256']==m['map']['after_sha256']==h((rt/'map.json').read_bytes())
assert m['journey']['receipt_sha256']==h((j/'journey.json').read_bytes()) and m['journey']['manifest_sha256']==h((j/'journey-manifest.json').read_bytes()) and m['journey']['receipt_matches_returned'] is True
checked=[]
def manifest(base,name):
 d=J(base/name)
 for x in d['files']:
  p=base/x['path'];assert p.resolve().is_relative_to(base.resolve()) and p.is_file() and not p.is_symlink(); data=p.read_bytes(); assert len(data)==x['bytes'] and h(data)==x['sha256'];checked.append({'path':str(p.relative_to(r)),'bytes':len(data),'sha256':h(data)})
 return d
jm=manifest(j,'journey-manifest.json');cases=[];ids=['healthy','missing-ref','drift','mixed','empty'];expected=[(0,'healthy',1,0,0),(1,'failed',1,1,0),(2,'drift',1,0,1),(1,'failed',3,1,1),(0,'empty',0,0,0)]
assert [x['case_id'] for x in journey['features']]==ids and [x['case_id'] for x in m['rows']]==ids and journey['status']=='passed'
binding_bytes=None
for cid,feat,row,exp in zip(ids,journey['features'],m['rows'],expected):
 c=j/'cases'/cid; cm=manifest(c,'manifest.json'); product=J(c/(cid+'.json'));receipt=J(c/'receipt.json');run=J(c/'run.json');cleanup=J(c/'cleanup.json');inp=J(c/(cid+'.input.json'));raw=(c/(cid+'.stdout')).read_text()
 assert h((c/'manifest.json').read_bytes())==feat['manifest_sha256']==next(x['sha256'] for x in jm['case_manifests'] if x['case_id']==cid)
 assert (feat['product_exit'],feat['product_status'])==exp[:2] and feat['verification']=='passed' and feat['driver_exit']==0 and row['matches']
 assert (row['actual']['product_exit'],row['actual']['product_status'])==exp[:2]
 assert product['exit_code']==exp[0] and product['process_started'] and product['direct_child_exit_confirmed'] and not product['timed_out'] and not product['output_limited'] and product['verification_status']=='passed'
 assert h((c/(cid+'.stdout')).read_bytes())==product['stdout_sha256'] and not (c/(cid+'.stderr')).read_bytes() and h(b'')==product['stderr_sha256']
 assert f'Checking {exp[2]} source(s)' in raw and f'{exp[3]} source(s) failed to check.' in raw and f'{exp[4]} source(s) drifted from blessed_sha.' in raw
 assert len(inp['sources'])==exp[2] and product['input_unchanged'] and product['manifest_before_sha256']==product['manifest_after_sha256']==h((c/(cid+'.input.json')).read_bytes())
 assert receipt['status']=='passed' and receipt['driver_exit']==0 and receipt['behavior']=='passed' and receipt['failure'] is None and receipt['run_id']==run['run_id']
 assert cleanup==receipt['cleanup']==feat['cleanup'] and cleanup['status']=='passed' and cleanup['fixture_removed'] and not os.path.lexists(cleanup['fixture_path']) and pathlib.Path(cleanup['fixture_path']).is_relative_to(j/'scratch')
 assert product['argv'][1:]==['skills','check'] and pathlib.Path(product['argv'][0]).resolve()==(repo/'packages/cli/dist/bin.js').resolve()
 assert pathlib.Path(product['environment']['OSSTACK_HOME']).is_relative_to(pathlib.Path(cleanup['fixture_path']))
 assert run['git_head']==f['checkout'] and run['bindings']==run['final_bindings'] and run['bindings_unchanged']
 bb=(c/'bindings.json').read_bytes()
 if binding_bytes is None:binding_bytes=bb
 else:assert bb==binding_bytes
 cases.append({'case_id':cid,'product_exit':exp[0],'product_status':exp[1],'source_count':exp[2],'failed_count':exp[3],'drift_count':exp[4],'driver_exit':0,'manifest_members':len(cm['files']),'fixture_absent':True,'descendants':'not_attested','raw_stdout_sha256':product['stdout_sha256']})
binds=json.loads(binding_bytes);livecounts={}
for axis in ['source','build']:
 fs=binds[axis]['files'];livecounts[axis]=len(fs)
 for x in fs:
  data=(repo/x['path']).read_bytes();assert len(data)==x['bytes'] and h(data)==x['sha256']
bef,aft=J(r/'product-before.json'),J(r/'product-after.json');assert bef==aft and len(bef)==1493
for p,sh in aft.items():assert h((repo/p).read_bytes())==sh
recordsummary=[]
for p in sorted(rec.glob('[0-9][0-9]-*.json')):
 d=J(p);assert all(x in d for x in ['argv','cwd','started_at','finished_at','exit_code','stdout','stderr']);assert pathlib.Path(d['stdout']).is_file() and pathlib.Path(d['stderr']).is_file();recordsummary.append({'path':str(p.relative_to(r)),'exit_code':d['exit_code'],'started_at':d['started_at'],'finished_at':d['finished_at']})
assert f['time']<a['started_at']<a['finished_at']<b['started_at']<b['finished_at']
findings=[{'id':'L01','classification':'trace_limit','fact':'fork_turns=none请求及spawn成功由root记录；不能独立证明全部隐藏上下文、模型身份或OS隔离。'},{'id':'L02','classification':'self_record_not_full_trace','fact':'records/run.py仅记录经run()调用的子进程；00-tutorial.reason承认此前已只读查看同教程。无外部完整工具事件流，不能断言所有阅读/写入仅限这些记录。'},{'id':'L03','classification':'self_check_label','fact':'report称12-verify-retained为独立留存检查，但它由同一coldagent编写并运行，应称自检。本轮C另行只读核验不重跑该脚本。'},{'id':'L04','classification':'self_check_coverage','fact':'cold verify-retained.py实际hash校验5个case共145成员与case manifest；顶层5文件仅readable/bytes，未逐项验证journey-manifest的32成员，也未复核live source/build列表。C现补核这些范围，不追认cold已核。'},{'id':'L05','classification':'budget_environment_limit','fact':'run.py继承环境，仅记录PATH/scratch/home子集，subprocess.run无timeout/output bound；600秒为任务约定。真实driver自己的预算/最小环境有记录，不等于整个agent OS围栏。'},{'id':'L06','classification':'tutorial_use_not_literal_shell_test','fact':'coldagent用Python subprocess适配教程命令并自写核验脚本，没逐字执行全部教程shell块；可证明该代理理解并完成有限路径，不证明复制粘贴shell脚本全覆盖。'}]
write('file-checks.json',{'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_product_executions':0,'original_input_sha256':h((r/'cold/task-map.json').read_bytes()),'repaired_map_sha256':h((rt/'map.json').read_bytes()),'only_semantic_map_change':'append empty/0/empty row; first four rows unchanged','repaired_map_matches_canonical_semantics':True,'journey_manifest_members':len(jm['files']),'case_manifest_members':sum(x['manifest_members'] for x in cases),'case_results':cases,'verified_manifest_payloads':checked,'live_binding_files_checked':livecounts,'five_bindings_exact_equal':True,'product_before_after_1493_and_current_equal':True,'recorded_operations':recordsummary,'tutorial_exact_frozen_read':True,'guard_order':'freeze before recorded product invocation; dispatch file has no independent event timestamp','findings':findings})
axes=[('CU01','limited','API请求fresh history和成功spawn已记录；无独立全上下文/全trace证明。',['cold-dispatch.json','cold-freeze.json','cold-prompt.txt']),('CU02','pass','固定prepared checkout/教程相符；源码1065与build2352逐文件现时相等、1493前后及当前相等。构建过程未由cold验证。',['product-before.json','product-after.json','cold-freeze.json']),('CU03','pass','真实记录exit2/map_case_set、空stdout、attempt-01不存在；验证器源码预检先于drive，未见该尝试journey。非全进程审计。',['cold/records/07-attempt-01.json','cold/records/07-attempt-01.stderr']),('CU04','pass','实际输入四行，冷报告正确解释缺empty、归因输入契约，记录同入口恢复理由。无独立外部trace来证明绝无其他提示。',['cold/records/08-inspect-input.stdout','cold/records/09-correct-owned-map.json','cold/records/report.md']),('CU05','pass','原任务图未变；自有图只补empty行，保持旧错误，argv同入口且新output；产品1493文件未变。仅上述范围。',['cold/records/09-correct-owned-map.json','product-stability.json']),('CU06','pass','真实compiledCLI五例回执/raw语义/输入数/exit0,1,2,1,0相符，driver全0，非injected。',['cold/records/10-attempt-02.json',str((j/'journey.json').relative_to(r))]),('CU07','pass','32顶层与145案例成员hash/size、case manifest绑定、map before/after、live source/build核对一致。自记日志非认证。',['file-checks.json']),('CU08','limited','显式隔离home/scratch、5fixture实际不存在、记录保留；无默认管理DB全局审计/全进程终止或OS fence证明。',['file-checks.json']),('CU09','pass','最终报告正确区分产品负例与driver、mixed优先级、empty无来源及清理边界。',['cold/records/report.md']),('CU10','pass','两次记录入口，一次失败一次恢复；未宣称完整W17/C0或native资格。未有完整工具trace，故不声称全会话操作穷尽。',['cold/records/report.md','cold/records/run.py'])]
write('graded-results.json',{'criteria_sha256':h((r/'criteria/criteria.json').read_bytes()),'tutorial_sha256':f['tutorial_sha256'],'checkout':f['checkout'],'main':f['source_main'],'overall':'bounded_workflow_completed_with_observation_limits','formal_gate_pass':False,'A39_complete_claimed':False,'new_product_or_model_calls':0,'axes':[{'id':i,'status':s,'finding':n,'evidence':e} for i,s,n,e in axes],'observability_unknowns':['complete hidden context','complete agent tool/read/write trace','OS/global side effects','all descendants termination'],'findings':findings})
write('report.md','''# C 独立核验：有限冷使用闭环

**有限流程已完成，观察边界保留；不签整个 A39/W17/C0 通过。** 按原 CU01–10，8 项在所列范围通过，CU01 冷上下文与 CU08 全局资源观察为 limited。本轮只读，没有重跑产品、自检脚本或模型。

两次同一维护入口：05:21:08.749Z 的第一次 exit2 / map_case_set，stdout 空且 attempt-01 不存在；自有地图只补 empty/0/empty 一行，原四行及原输入不变；05:21:27.777Z 的第二次新 output exit0 / consistent / runJourney。恢复后实际产品结果 healthy0、missing-ref1、drift2、mixed1、empty0，driver 均0，raw source数/失败数/漂移数与输入对应。报告对预期负例、empty及driver语义解释准确。

本轮独立读取并核验 journey manifest 的32成员、五个case manifest共145成员及其manifest摘要；五fixture现时均不存在，证据仍在。五份binding逐字相同，source1065/build2352条目与现时文件hash/size一致；root产品前后1493条目完全相等且现时逐项匹配。地图运行内hash一致，恢复图语义等canonical。构建是协调者预先准备，不能叫冷安装验收。

## 必须保留的记录限制

- root请求 fork_turns=none 并记录spawn成功；不能独立证明全部隐藏上下文或认证principal。冻结在已记录产品调用之前，dispatch文件本身没有独立事件时间戳。
- run.py是coldagent自记，不是完整工具trace。00教程记录明确承认此前已查看同一教程；本报告不将00–12视作全部阅读/工具事件。
- “独立留存检查”是同一coldagent自写自跑，准确名称应为自检。其脚本核5case共145成员，但顶层5文件只检查可读/长度，没有逐项核journey manifest32成员、live source/build。本轮C补核，不追认cold已做。
- run.py继承环境、只记录必要子集，外层subprocess无强制超时；600秒为任务约定。真实产品driver另有预算/最小环境记录。没有OS围栏、管理home全局审计或全后代终止证明。
- coldagent以Python subprocess适配教程命令，未逐字执行全部shell示例。结果支持这名fresh-request协作agent完成教程路径，不证明任意人类/native宿主或复制粘贴shell全覆盖。

原教程SHA92700fcf、criteriaSHA1830eb1f不变；原失败和自记脚本均保留。此一次恢复后的正常fixed5终点不替代W18相关叶子检索、W19通用维护或C1/C2。分轴原件路径和校验明细见JSON。
''')
bound=[]
for p in [r/'cold-freeze.json',r/'cold-dispatch.json',r/'cold-prompt.txt',r/'cold-input-binding.json',r/'product-before.json',r/'product-after.json',r/'product-stability.json',*sorted(rec.glob('*'))]:
 if p.is_file():bound.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())})
write('input-bindings.json',{'files':bound})
write('manifest.json',{'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':h(p.read_bytes())} for p in sorted(o.iterdir()) if p.is_file() and p.name!='manifest.json']})
print(json.dumps({'manifest_sha256':h((o/'manifest.json').read_bytes()),'grade_sha256':h((o/'graded-results.json').read_bytes()),'cases':cases,'live_counts':livecounts},ensure_ascii=False))
