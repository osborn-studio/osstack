# 审计结论：PASS_WITH_CONCERNS（限定在本切片）

教程与所供工具源码、记录的两次产品调用之间没有发现阻断性缺陷。README 对原 A39、原生宿主和后代进程清理基本没有夸大。下面的问题都是措辞、披露和教程可执行性方面的，不要求重跑实验。

## 一、已核对一致的部分

- **预检顺序**：`validateMap` 在 `mkdir(output)` 之前执行，与教程的"非法地图在驱动前被拒绝，不创建输出目录"一致。
  - 07 的 stdout 为空，stderr 为 `{"status":"blocked","exit_code":2,"error":"map_case_set"}`。
  - `map_case_set` 只能由 `validateMap` 抛出，而它早于 `mkdir`，所以可以推出输出目录未创建，不必依赖自述。
- **地图契约**：以下各项与源码逐条相符。
  - 非符号链接的普通文件，最大 64 KiB（O_NOFOLLOW 加 `size<=65536`）。
  - 顶层键、行键、五个固定 ID、退出码 0–255、四种状态。
  - `map-after.json` 只在地图运行中改变时才写。
  - 输出目录须不存在，且在 scratch 之内。
- **修正范围**：09 的 stdout SHA256（`f154e5…`）等于 attempt-02 的 `map-before`/`after_sha256`，大小 661 字节。这说明修正后的地图正是 09 所打印的内容，即原四行加 `empty/0/empty`，没有其他改动。
- **产品调用**：两次真实调用（07 返回 exit 2，10 返回 exit 0、`consistent`、`runJourney`）都在记录里，没有额外产品运行。
- **证据与五行**：五行结果与表一致。145 = 5×29 个文件的大小和 hash 由 12 号记录核对，五个 fixture 路径不存在，`descendant_termination: not_attested` 被如实保留。
- **教程字节**：`cold-freeze.tutorial_sha256`、`00-tutorial.stdout` 与所供教程文件三者 hash 相同。

## 二、需要修正的问题（非阻断）

**C1. 教程的 shell 块没有按原样执行过**
- 冷读者实际用 `run.py`（Python）重写了准备和第一次尝试，并靠 `context.json` 和每步写死的绝对路径衔接后续步骤。
- 教程说"同一个 shell 脚本按顺序执行、保留变量"。但它自己的流程要求在两次尝试之间停下来诊断和编辑，对于每次工具调用都是新 shell 的执行者，`tutorial_root`/`OSSTACK_HOME`/`OSSTACK_SCRATCH_ROOT` 会丢失。
- 建议教程补一句如何在新 shell 里重建这些变量。README 也应说明"记录的是 Python 等价复现，shell 块未原样执行"，否则"照教程调用"略强。

**C2. "工具自己调用每个案例的 doctor"无法从所供材料支持**
- `maintain-skills-check-map.mjs` 只调用 `runJourney`，没有 doctor。
- 各案例 manifest 的 29 个文件中也没有独立的 doctor 产物，只有一条 `<case>.command.json`。
- 其他脚本没有提供。建议降低断言强度，或给出源码依据。

**C3. 上下文隔离措辞超出证据**
- README 写"仅收到教程、任务输入和环境路径"。实际只有 dispatch 记录和 prompt 文件，没有 CU01 要求的工具 trace，也没有外部审计。
  - 子代理是否另外自动加载了 cwd 下的项目指令，无法判断。
  - 应改成"请求 `fork_turns=none`，派发成功，实际接收内容未经审计"。
- prompt 自身预告了恢复流程："若收到输入拒绝…保留…修正…恢复"。因此"可理解恢复"只能表述为"在任务 prompt 预告下"，README 未披露这一点。
- 冷读者的 cwd 就是作者 worktree。它自己记录的 `git status` 输出里有 `?? docs/implementation/pstack-c0-usage/` 和多个 `docs/design/*` 修改。`criteria.json`、`cold-prompt.txt` 位于其获授路径的上级目录。不读取这些文件只靠遵守 prompt，没有文件系统隔离。README 已声明"非强制隔离"，建议把这些具体暴露面写出来。
- 按冻结判据 CU01，边界无法证明时该轴应为 unknown/limited。README 没有 CU01–CU10 的逐项结论，标题"冷读"也建议改为"无继承历史请求的使用"一类说法。

**C4. 来源与脏树披露不完整**
- README 只说"四个 fresh dist 脏"。`05-status.stdout` 显示还有 6 个已跟踪的 `docs/design/*` 修改，以及 2 个未跟踪路径。其中 `docs/verification/` 就是被测教程本身（已由 hash 绑定，但仍应披露）。
- `product-stability.json` 范围只含 package/scripts/package.json/lock 共 1493 个文件，不含 docs。
  - 它的 `observed_at`（05:22:22）早于冷读者最后一条记录 12（05:22:31）和写报告的时间。该记录只读，风险低，但"前后比较"的窗口并未覆盖代理的全部活动。
  - "执行前"快照没有在所供材料中。
- "main `01ec…` 与发布候选树完全一致"没有证据支持。冻结记录里 checkout 的 HEAD 是 `c8398318…`，不等于 `01ec…`，两者关系未给出。建议标为 root 的断言，或附上树比对输出。

**C5. 判据"先于冷读冻结"的绑定较弱**
- `cold-freeze.json` 绑定了教程和 prompt 的 hash，没有绑定 `criteria.json`。先后顺序只依赖 criteria 内部自报的 `frozen_utc`。
- "独立判据"的独立性也没有证明，建议改为"预先书写的判据"。

**C6. 本次使用未验证的教程部分未在 README 列出**
- 默认 canonical `map.json` 被称为"合法示例"，但本次从未使用，所供材料中也未验证。
- 可选的 `project-method-journey-evidence.mjs`（`--scope`/`--check` 说法）没有执行，也没有源码。
- 建议在"未验证范围"中明列这两项。

## 三、可选改进（不阻断）

- 教程可加一张错误码对照表：`map_case_set` 同时覆盖数量不对、重复和未知 ID，报错不指出具体哪一行；JSON 解析失败给出的是不稳定的 message。本次注入的是"删最后一行"，是最易诊断的情形，"可理解恢复"的结论应限定于此。
- 教程把"地图运行中改变"写成 blocked 的原因。工具自己的限制说明是前后快照比较，A→B→A 的改动检测不到，措辞可对齐。
- 教程可附一段预期 stderr 示例。
- README 可明确写一句：原 A39 状态不变，仍是 `specified_not_implemented`，本批只是后验可用性观察。

## 四、对"是否夸大"的结论

- **原 W17/A39**：未夸大。README 明确"后验、不能证明接口冻结前的因果、不完成全部 W17/C0"。
- **上下文隔离**：核心声明基本诚实，但有 C3 所列的措辞和披露缺口，应按 C3 修订措辞。
- **独立验证**：README 已写明"独立复核尚在进行"，与现状一致。

**限定范围的结论**：在"已构建环境、既有接口、一次输入拒绝加一次恢复"的范围内，教程可用且结果记录一致；超出该范围的任何结论都不被这批材料支持。