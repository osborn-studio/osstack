from pathlib import Path
import subprocess,shutil,json,time,hashlib,os
P=Path(__file__).resolve().parent;T=P/'template';repo=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack');records=[]
node='/opt/homebrew/opt/node@22/bin/node'
def run(root,args,label,expected):
 env={'PATH':'/opt/homebrew/opt/node@22/bin:/usr/bin:/bin','HOME':str(P/'unused-home'),'OSSTACK_HOME':str(P/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack','LANG':'C','LC_ALL':'C'}
 argv=['/usr/bin/python3','tools/run-node.py',*args];start=time.monotonic();r=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=15)
 (P/(label+'.stdout')).write_bytes(r.stdout);(P/(label+'.stderr')).write_bytes(r.stderr)
 rec={'label':label,'argv':argv,'cwd':str(root),'environment':env,'exit_code':r.returncode,'expected_exit':expected,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()};records.append(rec);(P/'validation-records.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==expected,(label,r.returncode,r.stderr[:500]);print(label,r.returncode,round(rec['elapsed_seconds'],3))
# Two additional negative-check workspaces keep plain-invalid out of the host's fixed three cases.
for version in ['old','fixed']:
 root=P/'validation'/version;shutil.copytree(T,root)
 if version=='fixed':
  for f in ['scripts/export-osstack-methods.mjs','scripts/lib/osstack-method-export.mjs']:(root/f).write_bytes(subprocess.check_output(['git','show','a1cb1779d62107d2c4f101b98311f3ec39116ae1:'+f],cwd=repo))
 for case in ['incident','control-a','control-b']:run(root,['check',case,'check-'+case],version+'-'+case,1 if version=='fixed' and case=='incident' else 0)
 invalid=P/'validation'/(version+'-plain-invalid');shutil.copytree(T,invalid)
 for f in ['scripts/export-osstack-methods.mjs','scripts/lib/osstack-method-export.mjs']:(invalid/f).write_bytes((root/f).read_bytes())
 (invalid/'inputs/incident/osstack-methods-skill/entries/osstack-mode/SKILL.md').write_text('[x](../../references/missing.md)\n')
 run(invalid,['check','incident','negative'],version+'-plain-invalid',1)
 run(root,['test','missing-test'],version+'-missing-test',1)
 test="""import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { exportCase } from '../tools/export-case.mjs';
test('outside-code navigation is checked while legal inputs remain usable', async () => {
 const incident = await exportCase('incident', 'regression-' + randomUUID());
 assert.equal(incident.error, null); assert.equal(incident.timed_out, false);
 assert.equal(incident.source_inputs_unchanged, true);
 assert.equal(incident.exit_code, 1, 'a missing target outside the code example must be rejected');
 assert.equal(incident.output_created, false);
 for (const id of ['control-a','control-b']) {
  const result = await exportCase(id, 'legal-' + randomUUID());
  assert.equal(result.exit_code, 0); assert.equal(result.output_created, true);
 }
});
"""
 (root/'scripts/method-export-regression.test.mjs').write_text(test)
 run(root,['test','behavior-regression'],version+'-behavior-regression',1 if version=='old' else 0)
# Wrapper label grammar, existing result protection, and source symlink refusal.
root=P/'validation/old'
run(root,['check','incident','../escape'],'label-escape',1)
run(root,['check','incident','check-incident'],'duplicate-label',1)
sy=P/'validation/symlink';shutil.copytree(T,sy);f=sy/'scripts/lib/osstack-method-export.mjs';f.unlink();f.symlink_to(root/'scripts/lib/osstack-method-export.mjs');run(sy,['check','incident','symlink'],'source-symlink',1)
assert not (P/'unused-osstack').exists()
print('total',len(records))
