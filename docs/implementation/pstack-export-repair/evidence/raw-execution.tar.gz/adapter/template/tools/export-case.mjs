// Task-local execution adapter. No expected outcomes or product parser implementation.
import { lstat, mkdir, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = await realpath(fileURLToPath(new URL('../', import.meta.url)));
const SOURCE = ['scripts/export-osstack-methods.mjs', 'scripts/lib/osstack-method-export.mjs'];
const CASES = ['incident', 'control-a', 'control-b'];
const hash = b => createHash('sha256').update(b).digest('hex');
const json = v => JSON.stringify(v, null, 2) + '\n';
async function directory(path) {
  const info = await lstat(path);
  if (!info.isDirectory() || info.isSymbolicLink() || await realpath(path) !== path) throw Error('unsafe_directory');
}
async function collect(path, rel = '', files = [], budget = { nodes: 0, bytes: 0 }) {
  if (++budget.nodes > 256) throw Error('input_nodes_limit');
  const info = await lstat(path);
  if (info.isSymbolicLink()) throw Error('input_symlink');
  if (info.isDirectory()) {
    for (const name of (await readdir(path)).sort()) await collect(join(path, name), rel ? `${rel}/${name}` : name, files, budget);
  } else {
    if (!info.isFile() || info.size > 1048576) throw Error('input_file_limit');
    const bytes = await readFile(path); budget.bytes += bytes.length;
    if (budget.bytes > 8 * 1048576 || bytes.length > 1048576) throw Error('input_bytes_limit');
    files.push({ path: rel, bytes });
  }
  return files;
}
const bindings = files => files.map(f => ({ path: f.path, bytes: f.bytes.length, sha256: hash(f.bytes) }));
async function snapshot(caseId) {
  await directory(join(ROOT, 'scripts')); await directory(join(ROOT, 'scripts/lib'));
  await directory(join(ROOT, 'inputs')); await directory(join(ROOT, 'inputs', caseId));
  const source = [];
  for (const path of SOURCE) {
    const info = await lstat(join(ROOT, path));
    if (!info.isFile() || info.isSymbolicLink() || info.size > 1048576) throw Error('unsafe_source');
    source.push({ path, bytes: await readFile(join(ROOT, path)) });
  }
  const input = await collect(join(ROOT, 'inputs', caseId, 'osstack-methods-skill'));
  return { source, input };
}
async function copy(files, destination) {
  for (const file of files) {
    const target = join(destination, file.path);
    const rel = relative(destination, target);
    if (!rel || rel.startsWith(`..${sep}`) || rel === '..') throw Error('copy_escape');
    await mkdir(resolve(target, '..'), { recursive: true });
    await writeFile(target, file.bytes, { flag: 'wx', mode: 0o600 });
  }
}
export async function exportCase(caseId, label) {
  if (!CASES.includes(caseId) || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$/.test(label)) throw Error('invalid_case_or_label');
  await directory(ROOT); await directory(join(ROOT, 'results'));
  const before = await snapshot(caseId);
  const runRoot = join(ROOT, 'results', `export-${label}`);
  await mkdir(runRoot, { mode: 0o700 }); // Exclusive: no overwrite or cleanup of prior evidence.
  const stage = join(runRoot, 'stage'); await mkdir(stage);
  await copy(before.source, stage); await copy(before.input, join(stage, 'osstack-methods-skill'));
  for (const name of ['home', 'tmp', 'scratch']) await mkdir(join(runRoot, name));
  const output = join(runRoot, 'export');
  const argv = ['scripts/export-osstack-methods.mjs', '--host', 'claude', '--output', output];
  const environment = { PATH: '/opt/homebrew/opt/node@22/bin:/usr/bin:/bin', HOME: join(runRoot, 'home'), TMPDIR: join(runRoot, 'tmp'), OSSTACK_HOME: join(runRoot, 'unused-osstack'), OSSTACK_SCRATCH_ROOT: join(runRoot, 'scratch'), LANG: 'C', LC_ALL: 'C' };
  const record = { executable: process.execPath, argv, cwd: stage, environment, case_id: caseId, label, source: bindings(before.source), inputs: bindings(before.input), started_at: new Date().toISOString(), timeout_seconds: 10, output_limit_per_stream: 1048576 };
  await writeFile(join(runRoot, 'command.json'), json(record), { flag: 'wx' });
  const observed = await new Promise(resolveResult => {
    const child = spawn(process.execPath, argv, { cwd: stage, env: environment, stdio: ['ignore', 'pipe', 'pipe'] });
    const parts = { stdout: [], stderr: [] }; const counts = { stdout: 0, stderr: 0 };
    let timed_out = false, output_limit_exceeded = false, error = null;
    const timer = setTimeout(() => { timed_out = true; child.kill('SIGKILL'); }, 10000);
    for (const name of ['stdout', 'stderr']) child[name].on('data', bytes => {
      const keep = Math.max(0, 1048576 - counts[name]); parts[name].push(Buffer.from(bytes.subarray(0, keep))); counts[name] += bytes.length;
      if (counts[name] > 1048576) { output_limit_exceeded = true; child.kill('SIGKILL'); }
    });
    child.on('error', e => { error = e.code ?? 'spawn_failed'; });
    child.on('close', (exit_code, signal) => { clearTimeout(timer); resolveResult({ exit_code, signal, timed_out, output_limit_exceeded, error, stdout: Buffer.concat(parts.stdout), stderr: Buffer.concat(parts.stderr), pid: child.pid ?? null, direct_child_closed: true }); });
  });
  await writeFile(join(runRoot, 'stdout'), observed.stdout, { flag: 'wx' });
  await writeFile(join(runRoot, 'stderr'), observed.stderr, { flag: 'wx' });
  const after = await snapshot(caseId);
  const result = { ...record, ...observed, stdout: observed.stdout.toString('utf8'), stderr: observed.stderr.toString('utf8'), stdout_sha256: hash(observed.stdout), stderr_sha256: hash(observed.stderr), ended_at: new Date().toISOString(), source_after: bindings(after.source), inputs_after: bindings(after.input), evidence: `results/export-${label}`, output_created: await lstat(output).then(() => true, e => { if (e.code === 'ENOENT') return false; throw e; }), source_inputs_unchanged: JSON.stringify(bindings(before.source)) === JSON.stringify(bindings(after.source)) && JSON.stringify(bindings(before.input)) === JSON.stringify(bindings(after.input)), cleanup: 'retained_owned_stage_and_evidence', descendant_termination: 'not_attested' };
  await writeFile(join(runRoot, 'result.json'), json(result), { flag: 'wx' });
  return result;
}
if (process.argv[1] && await realpath(process.argv[1]).catch(() => null) === await realpath(fileURLToPath(import.meta.url))) {
  try {
    if (process.argv.length !== 4) throw Error('usage: export-case CASE LABEL');
    const result = await exportCase(process.argv[2], process.argv[3]);
    process.stdout.write(json(result));
    process.exitCode = result.timed_out ? 124 : result.output_limit_exceeded ? 125 : result.error || !result.source_inputs_unchanged ? 126 : result.exit_code ?? 126;
  } catch (error) { process.stderr.write(json({ adapter_error: error.code ?? error.message })); process.exitCode = 126; }
}
