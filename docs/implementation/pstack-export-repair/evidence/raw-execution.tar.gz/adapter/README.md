# Fixed exporter repair adapter — author closeout

The frozen `template/` contains only historical production source at `4611fd6de998868e09fef042dc142bb52efaa6dd`, three neutral historical-source bundles and two task-local helpers. It has no repaired source, author regression test or expected-answer/oracle file. `freeze.json` records all 49 file hashes. No repository, model, default DB or installation was used in this adapter task.

## Interface supplied to host preparation

```text
/usr/bin/python3 tools/run-node.py check incident UNIQUE_LABEL
/usr/bin/python3 tools/run-node.py check control-a UNIQUE_LABEL
/usr/bin/python3 tools/run-node.py check control-b UNIQUE_LABEL
/usr/bin/python3 tools/run-node.py test UNIQUE_LABEL
```

The test branch runs only `node --test scripts/method-export-regression.test.mjs`. That new test may import `exportCase` from `../tools/export-case.mjs` and call `await exportCase(caseId, freshLabel)`. Labels are unique ASCII alnum/underscore/hyphen, maximum 64 characters, starting alphanumeric. A test can use `randomUUID()` to give each export a fresh label.

`exportCase` copies the current two production files and the chosen read-only input bundle to a new owned stage, then invokes the actual `scripts/export-osstack-methods.mjs --host claude --output <new-owned-path>` CLI. It contains no Markdown parser or outcome oracle. The returned result includes exit_code, stdout, stderr, error, timed_out, output_limit_exceeded, source_inputs_unchanged, output_created and evidence. Check and test therefore share the actual product entry point.

Wrapper records are in `results/invoke-LABEL/`; each actual product invocation records in `results/export-LABEL/`, including raw output, exact argv/cwd, minimal environment, source/input byte hashes, candidate stage and output. The existing directory must not be overwritten. Evidence/stages remain until the coordinator verifies and cleans owned resources. No automatic publication, install or cleanup claim is made.

## Actual offline validation

`validate.py` executed **15 coordinator commands**, recorded in `validation-records.json` and individual raw stdout/stderr files. These are not Claude calls or native permission checks.

| Checks | Actual results |
|---|---|
| Old incident / canonical control / legal-code control / plain-invalid | 0 / 0 / 0 / 1 |
| Fixed incident / canonical control / legal-code control / plain-invalid | 1 / 0 / 0 / 1 |
| Missing new test, old and fixed | Both exit1, file-not-found; explicitly **not behavior RED** |
| Same actual regression test bytes, old then fixed | Assertion RED then GREEN; test calls real CLI through exportCase |
| Escape label / duplicate label / source symlink | All refused, exit1 |

The 8 old/fixed check runs include plain-invalid only in coordinator copies; host templates have exactly three cases. Production children have 10-second and 1 MiB-per-stream bounds; wrapper check/test calls also have a 10-second bound and record cap/timeout facts. Observed command durations were 0.025–0.398 seconds. The author regression test and fixed candidate are kept only under `validation/`, and must never be copied into host inputs. Before delivery, all frozen template bytes were rechecked and the old/fixed test bytes were confirmed identical.

One preparation attempt tried to read an already cleaned previous host workspace and failed before candidate creation or product execution. `initial-preparation-failure.json` retains the cause/disposition; the final helper was written explicitly rather than silently depending on that removed path. No runtime validation failures were discarded.

## Bounds and pending work

The helper validates fixed cases, fresh labels, expected local directories and source/input symlinks, and never accepts an arbitrary output path or executable. It records a clean product environment, but it is **not an OS read/network fence** against arbitrary model-authored tests. It does not authenticate dependencies/principals or attest all descendants. Retained result artifacts and full model/tool traces still need independent review. Exceeding a cap or timing out is not a behavior pass; missing test files are not regression evidence.

B owns fresh host preparation. C owns independent final checks. Root alone authorizes the new actual Claude user turn; none occurred here. Template is frozen and no longer edited.
