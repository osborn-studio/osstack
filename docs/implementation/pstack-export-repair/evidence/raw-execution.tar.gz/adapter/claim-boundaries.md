# PS 与 J 回链建议：实际维护与历史修复任务

只读审阅时间点：本次新 Claude exporter 任务已启动，作者没有读取宿主输出或独立 hidden。本说明不预判其结果。依据：main `493caa4e46e616b1d7e9e1c87ed0a5775eae3ad1` 原始 `capability-index.md`、`work-packages.json`，以及 root 控制候选 `d99cf603cdccbc4a9758ec15b2e6b48a60d36fd4` 的交付状态/账本。后续结果只能由实际轨迹与独立验收补入，不覆盖历史记录。

## 能力回链与当前可主张边界

| PS 能力 | 本批具体证据贡献 | 不可据此主张 | 建议实际 J 落点 |
|---|---|---|---|
| PS01 单入口任务路由与渐进方法组合 | 共享入口与 bug-fix 材料已提供给新任务；若轨迹证明 osstack-mode 的实际选择及后续材料消费，才增加本次单任务路由观察 | 材料提供不等于已读；模型自报不等于原生选择；一次选择不证明稳定自动路由、强制方法通道或全部14方法效果 | 对新修复任务统一以 J09 为主要工程证据；入口观察仅材料贡献，可关联 J04/J15，不能签发其输出 |
| PS08 可操控的验证基础设施与功能地图 | 已有真实五 case driver、两行 journey。本轮维护在固定 main1bf 两行地图完成源码/实际驱动；新 exporter adapter 又提供真实 CLI 的固定可调用入口及旧/修版本校准 | 非任意项目自动生成地图/完整工具链；任务局部 helper 不等于 J03 注册 driver；15次协调者验证不等于 Claude 执行 | 维护主要 J06，支持 J03；新修复任务主要 J09，支持 J03/J07 |
| PS09 验证基础设施健康、归属与漂移维护 | 已独立核验两行地图的人工注入漂移→实际比较 RED→诊断 docs drift→只修一格→新 fixture 同路径 GREEN；4 fixture 清理、6 manifest 与源码/构建哈希保留 | 不是现场新产品缺陷；不是全部 skills-check case、通用维护服务或宿主自主维护；不证明活动资格指针/撤销/漂移运行态 | 主要 J06；支持 J03/J31 的真实驱动与清理证据。J10 仅设计关联，不算其 qualified/active 产品输出 |
| PS20 跨宿主方法适配 | 已有双布局导出及多个明确保留失败/限制的宿主实验。本次若 Claude 实际完成修复，可新增精确版本/材料/任务的一项工程观察 | 不复写旧 Claude 复合命令拒绝、Codex 测试证据限制；不证明跨宿主等价、所有模型/OS支持、可信 principal、完整停止/隔离资格或收益因果 | 新任务主要 J09；支持 J23 的受限观测，非 JA34 支持矩阵资格。J02/J04/J10 仍属未满足的设计义务 |

原 capability-index 的广义关联须作为设计索引保留：PS01→J04/J05/J06/J08/J09/J10/J15/J16/J32；PS08→J03/J06/J09；PS09→J06/J10/J23；PS20→J02/J04/J10/J23。上表新增的 J31/J07 等是具体证据支持，不应偷偷改写来源映射。尤其不要把同一原始回执在多个 J 上相加成完成率。

## 已完成与进行中分开记录

**验证维护已完成的 bounded 工程任务**：`card_9797778f`，源码 `1bf1f6caa0ac0ae7b05c3caa9bb44d7ce6517dd0`。作者包 SHA `2351b9625f9bcdcd07fe5e52aafa41179e05a0868787fc48ad86054a798e59fa`，独立复核 SHA `b1ea9caea5067a10733441b136f8e722b9c3111839e256765e8f04bb46908ff0`。地图比较失败→通过，产品 missing-ref 始终为预期 exit1、driver为0；没有产品补丁。工作树已清理，证据另存。可将“尚无维护实际闭环”改成“已完成一个明确注入、两行全覆盖的实际维护演练；通用及宿主自主维护未证”，不可改成 PS09 全部完成。

**新 exporter 真实修复仍待最终验收**：历史产品旧版 `4611fd6de998868e09fef042dc142bb52efaa6dd`，原修复 `a1cb1779d62107d2c4f101b98311f3ec39116ae1` 已在当前 main；新宿主材料基线为493caa4e。这是不同历史缺陷，不是旧1038任务重试，也不是新的 main 漏洞。作者15次协调者调用只证明 helper 可用及基线校准；缺测试文件两次失败明确不算行为 RED。新 Claude 的原生选择、8次实际 helper、测试先失败后通过、同输入/测试字节、独立隐藏正负例和写范围必须按最终原始证据单独记录。

即使完整通过，可写“Claude 在该固定历史导出缺陷任务上完成实际 RED→行为测试 RED→最小修复→同路径 GREEN，独立检查范围为……”。不可写“Claude/pstack 已通过全部验收”或“所有宿主修复闭环完成”。若失败或受限，保留具体执行/语义/权限/证据轴，而非把正常CLI返回模型回答称为任务成功。

## 正式 J 义务仍保留

- J03 要求两个注册 driver、同动作 registry/清理与 J01.contracts；本任务 local helper 不注册该运行时。
- J06 要求使用草图及复现/等待/取消三条地图、冷调用者和相关文档执行；两行 skills-check 地图不替代全项。
- J09 要求 J08 前置与 J03 注册 bug-fix-fixture、真实 host 坏变体及 JA18；本任务可增加关键工程证据，但不能绕过前置签发 J09.scoped。
- J07 的 host 管理产物完整性/旧候选阻止完成，J10 的 qualified/active 持久状态，J23 的精确支持单元/停止能力矩阵均未由此次 helper 实现。
- 保持 formal_gate_pass=false、runtime_enabled=false；活动卡 Done 与正式32项大里程碑完成不同。

## Root 文档与账本更新位置

1. `docs/implementation/pstack-export-repair/`：记录新任务原始轨迹、源/材料/adapter hash、独立验收、审计、失败与范围；保留前轮 `pstack-real-loops`。
2. `delivery-rollup.json` 的 `pstack_capabilities`、`next_complete_capability_queue`、`activity_relations` / `activity_evidence_bindings`：新增本次证据对象，单一 primary_j + 少量 supporting_j；旧记录不可改成新运行。
3. `delivery-status.md`：“现在可用”“下一批”和 PS08/PS09/PS20 行更新具体有证据的语句，仍为部分交付；数量保持4入口/14方法，不以方法数增加进度。
4. `execution-ledger.json` 的现有 `actual_pstack_loops` 留作先前试验快照；新 exporter 任务使用独立对象或不可覆盖的后续记录，链接其原始证据和 owner/card。不要让新成功回填旧 blocked。

中央文件由 root 独占更新；本任务没有修改任何这些文件、宿主文件或进程，也未读取独立 hidden。
