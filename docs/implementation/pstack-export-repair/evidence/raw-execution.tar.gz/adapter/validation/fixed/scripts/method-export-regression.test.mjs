import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { exportCase } from '../tools/export-case.mjs';
test('outside-code navigation is checked while legal inputs remain usable', async () => {
 const incident = await exportCase('incident', 'regression-' + randomUUID());
 assert.equal(incident.error, null); assert.equal(incident.timed_out, false);
 assert.equal(incident.source_inputs_unchanged, true);
 assert.equal(incident.exit_code, 1, 'a missing target outside the code example must be rejected');
 assert.equal(incident.output_created, false);
 for (const id of ['control-a','control-b']) {
  const result = await exportCase(id, 'legal-' + randomUUID());
  assert.equal(result.exit_code, 0); assert.equal(result.output_created, true);
 }
});
