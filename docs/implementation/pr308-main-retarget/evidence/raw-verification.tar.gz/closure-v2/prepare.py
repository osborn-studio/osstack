from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent;w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr308-main-retarget');old='7c8fb3e6247901b4f58003049cd060dfb4acacd8';git=lambda *a:subprocess.check_output(['git',*a],cwd=w);head=git('rev-parse','HEAD').decode().strip();assert head.startswith('6f870cb0')
prefix='docs/design/2026-10-27-joint-engineering/';a=json.loads(git('show',head+':'+prefix+'delivery-rollup.json'));b=json.loads(git('show',head+':'+prefix+'execution-ledger.json'));key='stack_status_context_slice';assert a[key]==b[key]
diff=git('diff',old,head);paths=git('diff','--name-only',old,head).decode().splitlines();assert set(paths)=={prefix+'delivery-rollup.json',prefix+'execution-ledger.json'}
(r/'fix.diff').write_bytes(diff);(r/'proof.json').write_text(json.dumps({'head':head,'base':old,'changed_paths':paths,'both_sections_equal':True,'section':a[key]},indent=2)+'\n')
prompt='''Narrow closure only for the one confirmed attribution finding in the previous actual REVISE below. Do not broaden review. The prior current mutable block paired head6d with old b4a parent-based CI fields. Verify the supplied two-file fix moves ALL old CI status/run/checkout/tests into an explicitly bound parent_based_ci object, and marks current6d/run40977980388 separately without claiming it proves future documentation heads. Both ledger/rollup objects are independently equal. Historical raw evidence remains immutable. No product/tests changed and no test reruns claimed. Treat current CI progress as a dated snapshot, not a promise of later status. End exact Verdict: PASS or Verdict: REVISE.\n\nORIGINAL REVISE\n'''+(r.parent/'closure/report.md').read_text()+'\nEXACT FIX DIFF\n'+diff.decode()+'\nINDEPENDENT PROOF/CURRENT SECTION\n'+(r/'proof.json').read_text()
(r/'audit-input.txt').write_text(prompt)
for n in ['run.py','settings.json','empty-mcp.json']:(r/n).write_bytes((r.parent/'closure'/n).read_bytes())
print(head,len(prompt.encode()))
