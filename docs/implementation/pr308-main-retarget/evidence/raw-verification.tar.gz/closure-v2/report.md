## Closure review: 6f870cb0 vs 7c8fb3e6

This is a static review of the pasted diff and the pasted section only. I ran nothing and read no repo files.

### Checks that hold

- **All old CI fields moved.** `ci_run`, `ci_applicable_success`, `ci_paid`, `ci_actual_checkout` and `parent_based_ci_tests` are all removed from the top level of the block. They now sit in `parent_based_ci`, with the same values (40930144304, 5, SKIPPED, c323e040…, 22/7207/7/0).
- **Parent-based CI is explicitly bound.** `parent_based_ci.head_sha` is `b4a2fc30…` and its `base_branch` is the parent branch. The top-level `head_sha` stays at `6d978973…`, so no CI field sits next to a head it doesn't describe.
- **Current CI is marked separately.** `current_ci` carries run 40977980388, head `6d978973…` and base `main`. The run matches `post307_dispatch.pr308.ci_run` from the original review.
- **No claim about future heads.** The status reads "in_progress; final documentation head will require its own CI", so it asserts nothing about later documentation heads and records no success.
- **Both objects are independently equal.** The two hunks are textually identical apart from line offsets, and the pasted section reports `both_sections_equal: true`.
- **Scope is narrow.** `changed_paths` lists only the ledger and rollup JSON files. That fits the claims that raw historical evidence is immutable and that no product or test files changed. I take the no-rerun statement as given.
- **Nothing else moved.** Every other field in the section is unchanged, including the PR308 candidate, archive, and post-merge validation values.

### Non-blocking notes

- `current_ci.status` has no timestamp of its own. Treat it as a dated snapshot, and take its date from the enclosing `post307_dispatch.observed_at`. An `observed_at` inside `current_ci` would make that self-contained, but that is optional.
- The new `parent_based_ci.base_branch` value is not in the material I was given, so I could not check it against git. It is consistent with the earlier finding that the old head was parent-based. Confirm it matches the real base of run 40930144304.
- Key naming differs slightly: `base_branch` in one object and `base` in the other. The nested `parent_based_ci.parent_based_ci_tests` name is redundant but keeps continuity with the old field.

The labeling defect from the prior REVISE is resolved.

Verdict: PASS