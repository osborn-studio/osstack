## Documentation closure review: 7c8fb3e6 vs 6d978973

This is a static review of the pasted material only. I ran nothing and read no repo files.

### Checks that hold

- **Ledger and rollup agree.** The three equal sections (`pr_candidate_snapshot_slice`, `stack_status_context_slice`, `post307_dispatch`) match, and the diffs account for the earlier rollup staleness. PR307 is `merged_scoped_slice` with head 8fd28911, run 40929858660 and merge commit de43f47c in both files.
- **Git binding is consistent.** In `git-binding.json`, `tree` equals `old_tree` (d0349614), the parents are b4a2fc30 and de43f47c, and `base` is de43f47c. This matches the README's "complete tree equals b4a" claim.
- **Fresh receipts agree with the prose.** The 172 GitHub tests, 14 candidate CLI tests, 241 docs tests and 1 hygiene test match across the receipts, the PR308 README and the stack-status banner. Vitest's local timestamps (17:11:06 and 17:11:34) match the command windows in UTC-7. The restore receipt shows a clean tree, and the downstream result shows three expected `gh` calls with no live forge.
- **Historical records are not rewritten.** The six preserved originals are listed as unchanged. The stack-status README banner marks the body as historical, and its PUBLIC_EXPORTS sentence now says the export change belongs to PR307 and is already in main.

### Unresolved finding: PR308 CI attribution

In the `stack_status_context_slice`, which is a current mutable block in both ledger and rollup, `head_sha` is 6d978973 (the main-based head). The CI fields beside it describe the old parent-based run:

```
"head_sha": "6d978973…"
"ci_run": 40930144304
"ci_applicable_success": 5
"ci_paid": "SKIPPED"
"ci_actual_checkout": "c323e040…"
```

Only `parent_based_ci_tests` carries the parent-based label. `post307_dispatch.pr308` in the same file gives the same head 6d978973 a different run, 40977980388, with `"validation": "running"`.

So one document pairs the same head with two different CI runs. The first pairing is true only if you know it was a run on the old b4a2fc30 head. This is a labeling defect, not a false fact. But it is the distinction you required between main-based PR308 awaiting current-head CI and old parent-based CI. The README's "does not relabel historical test runs" is contradicted by the field adjacency.

**Minimal fix, in both ledger and rollup:** move `ci_run`, `ci_applicable_success`, `ci_paid` and `ci_actual_checkout` into a `parent_based_ci` object (with `parent_based_ci_tests`). Add the old head `b4a2fc30` to that object. Keep `head_sha` 6d978973, with current CI tracked only through `post307_dispatch.pr308.ci_run` or an explicit `current_head_ci` field.

### Non-blocking notes

- Top-level `observed_at` (2026-10-29T05:24Z) is unchanged while `main_sha` is now de43f47c, which was created later. This was already true before the diff, and `main_observed_at` carries the real freshness. I did not count it as a contradiction.
- The PR308 README's "publication/ci-final" is shorthand. The actual directories are `pr-candidate-snapshot/ci-final` and `*/publication`.
- Test counts across populations are not reconcilable from what you pasted (local full 7207/5 skip, parent-based CI 7207/7 skip, PR307 CI 7189/7). I did not treat them as a contradiction.

### Not assessable

The "complete doc diff" omits several paths from `changed_paths`: `delivery-status.md`, `execution.md`, `project-operations.md`, `pstack-feature-queue.md`, the `ci-final/` README and its artifacts, and `stack-status-context/publication/*`. I could not check those for the current-versus-historical split, or whether any existing snapshot was modified rather than added.

Verdict: REVISE