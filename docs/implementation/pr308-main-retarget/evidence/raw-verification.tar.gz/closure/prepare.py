from pathlib import Path
import subprocess,json,hashlib
R=Path(__file__).parent;V=R.parent/'validation';W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr308-main-retarget');old='6d97897325efdeea47d86f3ae169c72907b74d6e';new='7c8fb3e6247901b4f58003049cd060dfb4acacd8'
git=lambda *args:subprocess.check_output(['git',*args],cwd=W)
h=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==new
paths=git('diff','--name-only',old,new).decode().splitlines();assert all(p.startswith('docs/') for p in paths)
base='docs/design/2026-10-27-joint-engineering/'
a=json.loads(git('show',new+':'+base+'delivery-rollup.json'));b=json.loads(git('show',new+':'+base+'execution-ledger.json'))
keys=['pr_candidate_snapshot_slice','stack_status_context_slice','post307_dispatch']
for k in keys:assert a[k]==b[k]
assert a[keys[0]]['status']=='merged_scoped_slice';assert a[keys[0]]['merge_commit']=='de43f47c29d5c08ae6e6c5eb366767320ffcdd0c';assert a[keys[1]]['base_branch']=='main';assert a[keys[1]]['status']=='draft_actual_main_revalidation'
oldpaths=git('ls-tree','-r','--name-only',old,'docs/implementation/stack-status-context/evidence','docs/implementation/pr-candidate-snapshot/publication/final').decode().splitlines()
proof=[]
for p in oldpaths:
 x=git('show',old+':'+p);y=git('show',new+':'+p);assert x==y;proof.append({'path':p,'sha256':h(x),'unchanged':True})
verification={'old_product_validation_head':old,'closure_head':new,'changed_paths':paths,'all_delta_docs_only':True,'equal_ledger_rollup_sections':keys,'historical_originals_preserved':proof,'fresh_summary_sha256':h((V/'summary.json').read_bytes()),'fresh_commands':json.loads((V/'summary.json').read_text())['commands']}
(R/'independent-proof.json').write_text(json.dumps(verification,indent=2)+'\n')
selected=[base+'delivery-rollup.json',base+'execution-ledger.json','docs/implementation/stack-status-context/README.md','docs/implementation/pr308-main-retarget/README.md']
full=git('diff',old,new,'--',*selected);(R/'scoped-docs.diff').write_bytes(full)
prompt='''Limited documentation closure review only. Do not re-review product or propose unrelated changes. Earlier actual tool-less static audit PASS found stale PR307 rollup vs ledger, current-vs-historical snapshot confusion and PUBLIC_EXPORTS parent wording. Review these fixes at 7c8fb3e6 relative to product-tested 6d978973. Current code is unchanged: all changed paths are docs only. Historical immutable snapshots retain their observation time and MUST NOT be rewritten as current state. Current authoritative blocks should distinguish merged307, main-based308 still awaiting current-head CI, and old parent-based CI. We independently executed fresh tests at6d: github172, candidateCLI14, docs241, hygiene1, lint/inventory/typecheck and injected 3PR ingestion/drift; originals provided below. These are actual host-executed receipts, not tests you ran. Model can statically evaluate evidence consistency only. No model/native runtime qualifications. Report confirmed unresolved contradictions only; end exactly Verdict: PASS or Verdict: REVISE. Do not treat immutable historical status records as automatically incorrect.\n'''
prompt+='\nINDEPENDENT GIT/RAW PROOF\n'+json.dumps(verification,indent=2)
prompt+='\nCURRENT MATCHING CENTRAL SECTIONS (rollup & ledger exact equal independently checked)\n'+json.dumps({k:a[k]for k in keys},indent=2)
prompt+='\nSCOPED COMPLETE DOC DIFF\n'+full.decode()
for p in selected[2:]:prompt+='\nCURRENT '+p+'\n'+git('show',new+':'+p).decode()
for name in ['github-tests.stdout','candidate-cli-tests.stdout','docs.stderr','hygiene.stdout','git-binding.json','downstream-result.json','restore-receipt.json']:
 prompt+='\nFRESH ORIGINAL '+name+'\n'+(V/name).read_text()
(R/'audit-input.txt').write_text(prompt)
for n in ['run.py','empty-mcp.json','settings.json']:(R/n).write_bytes((V/'audit'/n).read_bytes())
print('closure bytes',len(prompt.encode()),'historical verified',len(proof))
