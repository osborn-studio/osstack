from pathlib import Path
import subprocess,json,time,datetime,gzip,hashlib
root=Path(__file__).parent
repo='osborn-studio/osstack'; run='40977980388'
def call(args,name):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (root/(name+'.stdout')).write_bytes(p.stdout);(root/(name+'.stderr')).write_bytes(p.stderr)
 (root/(name+'.command.json')).write_text(json.dumps({'argv':args,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode},indent=2)+'\n')
 if p.returncode:raise RuntimeError(name+' exit '+str(p.returncode))
 return p.stdout
start=time.monotonic()
for n in range(1,17):
 r=json.loads(call(['gh','api',f'repos/{repo}/actions/runs/{run}'],f'poll-{n:02d}-run'))
 j=json.loads(call(['gh','api',f'repos/{repo}/actions/runs/{run}/jobs?per_page=100'],f'poll-{n:02d}-jobs'))
 assert r['head_sha']=='6d97897325efdeea47d86f3ae169c72907b74d6e'
 assert any(p['number']==308 and p['base']['ref']=='main' for p in r['pull_requests'])
 assert len(j['jobs'])==j['total_count']
 print(json.dumps({'poll':n,'status':r['status'],'conclusion':r['conclusion'],'jobs':[{'name':x['name'],'conclusion':x['conclusion'],'active':[s['name'] for s in x['steps'] if s['status']=='in_progress']} for x in j['jobs']]}),flush=True)
 if r['status']=='completed':
  (root/'run.json').write_bytes((root/f'poll-{n:02d}-run.stdout').read_bytes());(root/'jobs.json').write_bytes((root/f'poll-{n:02d}-jobs.stdout').read_bytes())
  b=call(['gh','run','view',run,'--repo',repo,'--log'],'complete-log')
  (root/'complete-log.log.gz').write_bytes(gzip.compress(b,mtime=0))
  print(json.dumps({'terminal':r['conclusion'],'log_bytes':len(b),'log_sha256':hashlib.sha256(b).hexdigest()}),flush=True)
  break
 if time.monotonic()-start>=15*60:print('BOUND_REACHED',flush=True);break
 time.sleep(60)
