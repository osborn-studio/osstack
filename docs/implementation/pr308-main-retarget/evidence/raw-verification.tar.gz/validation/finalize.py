from pathlib import Path
import json,re,hashlib,subprocess,stat,datetime
R=Path(__file__).parent;W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr308-main-retarget');h=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
commands=[json.loads(p.read_bytes()) for p in sorted(R.glob('*.command.json'))];assert all(c['exit']==0 for c in commands)
assert '172 passed' in (R/'github-tests.stdout').read_text();assert '# pass 14' in (R/'candidate-cli-tests.stdout').read_text();assert 'Ran 241 tests' in (R/'docs.stderr').read_text();assert '1 passed' in (R/'hygiene.stdout').read_text()
a=json.loads((R/'audit/binding.json').read_text());report=(R/'audit/report.md').read_text();verdicts=re.findall(r'(?im)^\s*(?:\*\*)?Verdict:\s*(PASS|REVISE)\b',report)
assert a['exit_code']==0 and not a['is_error'];assert verdicts and verdicts[-1]=='PASS',report
paths=[x['path']for x in json.loads((R/'generated-binding.json').read_text())['files']]
assert set(git('diff','--name-only').decode().splitlines())==set(paths)
# Parent explicitly authorized restoring these four generated files after the completed audit.
p=subprocess.run(['git','restore','--',*paths],cwd=W,capture_output=True);(R/'restore.stdout').write_bytes(p.stdout);(R/'restore.stderr').write_bytes(p.stderr);assert p.returncode==0
rows=[]
for item in json.loads((R/'generated-binding.json').read_text())['files']:
 b=(W/item['path']).read_bytes();assert h(b)==item['head_sha256'];rows.append({'path':item['path'],'sha256':h(b),'matches_head':True})
assert git('status','--porcelain=v1')==b''
(R/'restore-receipt.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':['git','restore','--',*paths],'exit':0,'files':rows,'status':'clean','no_tests_after_restore':True},indent=2)+'\n')
s={'head':'6d97897325efdeea47d86f3ae169c72907b74d6e','base':'de43f47c29d5c08ae6e6c5eb366767320ffcdd0c','tree':git('rev-parse','HEAD^{tree}').decode().strip(),'old_published_head':'b4a2fc30711d9c3ad5cddbc846839948f1810c56','tree_equal_old_published':True,'counts':{'github':{'passed':172,'failed':0},'candidate_cli':{'passed':14,'failed':0},'docs':{'passed':241,'failed':0},'hygiene':{'passed':1,'failed':0}},'commands':commands,'downstream':'New current-build public-function run with original fixed three-PR injected responses; no gh subprocess/DB/CLI calls','audit':{'requested_model':'claude-sonnet-5-5','binding':a,'verdict':verdicts[-1],'report_sha256':h((R/'audit/report.md').read_bytes())},'final_status':'clean','limitations':['No local full suite run; current head CI assessed separately.','Two scratch preparation errors retained; neither invoked the model or product tests.','Four generated knowledge dist bytes/patch/hashes saved before authorized restore; no tests run after restore.']}
(R/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
(R/'report.md').write_text('# PR308 actual-main targeted revalidation\n\nHEAD `'+s['head']+'`, base `'+s['base']+'`. Tree equals original published b4a2fc30 exactly. Fresh Node22 frozen install/build and all commands exited 0: GitHub172, candidate CLI14, docs241, hygiene1; lint, inventory and typecheck passed. Fixed three-PR public ingestion/topology/drift re-executed on fresh built code with injected raw responses, not real forge/DB operations.\n\nActual tool-less Claude Sonnet5.5 audit ended PASS; original prompt, response, version, modelUsage and hashes retained. Four generated dist files captured then restored with exact HEAD hashes; final tree clean. No full-suite rerun or new runtime qualification claimed. Two pre-execution scratch preparation mistakes are retained separately.\n')
files=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.json':
  b=p.read_bytes();files.append({'path':str(p.relative_to(R)),'sha256':h(b),'bytes':len(b),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
(R/'manifest.json').write_text(json.dumps({'files':files,'count':len(files)},indent=2)+'\n');print(json.dumps({'summary_sha256':h((R/'summary.json').read_bytes()),'manifest_sha256':h((R/'manifest.json').read_bytes()),'files':len(files),'audit_report_sha256':s['audit']['report_sha256']}))
