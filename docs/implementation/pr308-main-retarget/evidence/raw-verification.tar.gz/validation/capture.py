from pathlib import Path
import json,hashlib,subprocess,datetime
R=Path(__file__).parent;W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr308-main-retarget');h=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
paths=['packages/knowledge/dist/index.'+s for s in ['d.ts','d.ts.map','js','js.map']]
changed=git('diff','--name-only').decode().splitlines();assert set(changed)==set(paths)
(R/'knowledge-generated.patch').write_bytes(git('diff','--',*paths));g=R/'generated-before-restore';g.mkdir();rows=[]
for p in paths:
 b=(W/p).read_bytes();(g/Path(p).name).write_bytes(b);old=git('show','HEAD:'+p);rows.append({'path':p,'generated_bytes':len(b),'generated_sha256':h(b),'head_blob':git('rev-parse','HEAD:'+p).decode().strip(),'head_bytes':len(old),'head_sha256':h(old)})
(R/'generated-binding.json').write_text(json.dumps({'files':rows,'restored':False,'note':'Captured only; parent authorization required before restore'},indent=2)+'\n')
before=json.loads((R/'before-source.json').read_text());after=[]
for item in before['files']:
 p=item['path'];b=(W/p).read_bytes();after.append({'path':p,'sha256':h(b),'bytes':len(b)})
changes=[x['path'] for x,y in zip(before['files'],after) if x!=y];assert set(changes)==set(paths)
(R/'after-source-before-restore.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').decode().strip(),'files':after,'changed_paths':changes},indent=2)+'\n')
print('Captured four generated files; source-only bytes unchanged; no restore performed')
