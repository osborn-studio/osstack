# PR308 static review (retarget to main `de43f47c`)

This is a static read of the supplied diff and source only. I ran no tests, builds or git commands. Test counts and CI results quoted from the README and ledger are the authors' claims, not something I verified. I also could not check that the tree of `6d978973` equals `b4a2fc30`; I took that from your statement.

## 1. StatusContext mapping (`packages/github/src/stack.ts:85-97`)

| Row | Result in the old aggregation | Source |
|---|---|---|
| StatusContext `SUCCESS` | `SUCCESS/COMPLETED` (success) | `:91` |
| StatusContext `FAILURE`, `ERROR` | `FAILURE/COMPLETED` (failure) | `:92` |
| StatusContext `PENDING`, `EXPECTED`, `null`, missing or unrecognized | `conclusion: null`, so pending | `:94` |
| Anything else, including CheckRun | Unchanged | `:96` |

- **Enum coverage:** the five values match GitHub's `StatusState` enum (`EXPECTED`, `ERROR`, `FAILURE`, `PENDING`, `SUCCESS`).
- **Shape detection:** `__typename === "StatusContext"` is the primary signal. The state-shaped fallback for rows without a typename is guarded by `state !== undefined` (`:90`).
- **Real gh output:** `pr307.json` shows gh's real rollup output includes `__typename` on every row, so the primary path is the one that will run in practice.
- **Fail-safe:** the row is replaced wholesale with synthetic fields, so CheckRun-shaped fields on a context row (`conclusion: "SUCCESS"`, `status: "COMPLETED"`) cannot turn a missing or unknown state green. The test at `stack.test.ts:75-77` exercises this.
- **Precedence:** the existing failure > pending > success order is untouched (`:99-111`). Tests cover legacy failure over pending CheckRun, CheckRun failure over pending/success contexts, and legacy success not hiding a pending CheckRun.
- **Neutral/skipped:** these still count as success beside legacy success (`stack.test.ts:100-104`).

I found no logic defect in the new mapping.

## 2. Downstream ingestion and drift

- **What changes:** `ingestStack` feeds `mapRollupToCheckState` (`:128`). In `stack-cli.ts`, `ci_state` is written into card meta and the provenance comment, and `renderRunbook` prints it. Before the fix, a legacy `FAILURE` or `ERROR` showed as `pending` and `SUCCESS` also showed as `pending`. Now failures surface correctly.
- **What does not change:** the `CheckState` enum values, the `StackNode` schema, and edge and topological ordering. Card status is hard-coded to `"ready"`, and the `CI green` checklist item is seeded as pending, so the fix does not alter card flow or checklists.
- **Drift:** `detectDrift` maps `ci_failing` and `ci_pending` straight from `ciState`. The ingest-through-drift test (`stack.test.ts:106-123`) covers all five states and asserts the exact issue kinds, topology and argv.
- **Existing limit, not a regression:** re-ingest skips existing cards (`stack-cli.ts` `if (!isNewCard) continue`), so historical cards keep their stale `ci_state: pending`. The README states this.
- **Unverified:** `stack-cli.ts` imports only `ingestStack`, so there is no `detectDrift` caller in that file. I did not see `bin.ts` or other packages, so I cannot confirm there are no other `detectDrift` callers.

## 3. Tests

The tests are adequate and run offline through an injected runner. Gaps, all non-blocking:

- **Weak assertion (`stack.test.ts:75-77`):** `.not.toBe("success")` would also pass if the result were `failure`. The code returns `pending`, so assert `"pending"`.
- **Untested branch:** `state: null` without a typename takes the fallback path at `stack.ts:90` and returns pending. Nothing covers it.
- **Case sensitivity:** lowercase states (e.g. `"success"`) fall to pending. That is conservative and correct, but not pinned by a test.
- **Parse strictness:** `state` is now `z.string().nullable().optional()`. A non-string `state` on any rollup row throws, and `ingestStack` wraps that as a parse failure. Previously the field was ignored. GitHub emits strings, so this is theoretical.
- **No real fixture:** there is no captured real-gh StatusContext sample. The fixture shape (`context`, `state`, `targetUrl`) is consistent with gh's fields but is synthetic.
- **Style:** the new block uses semicolon-joined statements and unparenthesised arrow params, which differ from the surrounding file. The README says lint passed on the composed head, so I treat this as a nit.

## 4. Existing scope limits (unchanged, not regressions)

- `FAILING_CONCLUSIONS` (`stack.ts:77`) omits `ACTION_REQUIRED`, `STALE` and `STARTUP_FAILURE`. A completed CheckRun with those conclusions aggregates as success.
- `IN_PROGRESS_STATUSES` (`:78`) omits `WAITING` and `REQUESTED`. `pr307.json` shows gh emits `"conclusion": ""` (empty string, not null) for unfinished runs, so `conclusion == null` does not catch it. A `WAITING` or `REQUESTED` run therefore aggregates as success.
- Both gaps predate this diff, and the README says they are out of scope.

## 5. Does the retarget change semantics?

- **Product code:** the diff is self-contained: `stack.ts`, `stack.test.ts` and a patch changeset. The hunk pre-images (`@@ -68,6`, `@@ -80,7`) are consistent with the old source shown, so nothing here suggests main changed those regions.
- **Not verified:** the validation evidence is bound to base `6c9a3e8f`, not `de43f47c`. No test run on `de43f47c` is evidenced, and I cannot see whether other files between those commits affect `stack.ts` consumers. Run the github package tests on the retargeted head before merge if that matters to you.
- **Stack fix independence:** the diff adds none of the candidate-snapshot tool source, and the stack fix does not depend on it.

## 6. Documentation findings (non-blocking, introduced by this diff)

1. **Rollup and ledger disagree on PR307.** `delivery-rollup.json` records `head_sha 24bed464…`, status `draft_repaired_ci_running`, with no second-failure or inventory-repair data. `execution-ledger.json` records `8fd28911…`, status `draft_inventory_repaired_ci_pending`, plus `second_ci_failure` and `inventory_repair`. The rollup's `stack_status_context_slice` also lacks the `post_merge_validation` and `archive` blocks the ledger has. The rollup is stale relative to the ledger.
2. **PR307 lifecycle records are carried into PR308 and may be stale on main.** These are the `verification.md` note ("Draft… CI running"), `pr307.json` (OPEN, draft, head `9d54cfdc`, checks in progress), `osstack-published.json` (about 3,600 lines of unrelated board state labelled `final`), and the ledger and queue status edits. If `de43f47c` already contains PR307, these assert outdated state as current. I cannot determine this from the diff.
3. **README overclaims for this diff.** It says the PUBLIC_EXPORTS sync "is incorporated here", but no PUBLIC_EXPORTS change appears in the diff. This PR adds no exports, so none is needed, and the sentence describes the parent PR. It also contains future-tense and "not yet known" CI statements that will be stale at merge.
4. **Hygiene (low):** the committed receipts and manifest embed local absolute paths (`/Users/osborn/...`, `/Volumes/AIMATE_WORK/...`), and there is a roughly 1 MB binary archive.

## Summary

The legacy StatusContext mapping is correct and conservative. Failure beats pending beats success, CheckRun policy is untouched, and the ingest-and-drift behaviour is verified at the test level. The retarget does not alter product semantics in the hunks shown. The remaining issues are documentation consistency and test tightening, plus the unverified claim that the tree is identical to `b4a2fc30` and the absence of any run on the new base.

Recommended follow-ups: fix the rollup/ledger mismatch, confirm the PR307 records are still accurate on `de43f47c`, and tighten the `stack.test.ts:75-77` assertion to `"pending"`.

Verdict: PASS