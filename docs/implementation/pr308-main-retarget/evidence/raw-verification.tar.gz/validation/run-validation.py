from pathlib import Path
import subprocess,os,json,hashlib,datetime,sys
W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr308-main-retarget')
R=Path(__file__).parent
E=os.environ.copy();E.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack',OSSTACK_HOME=str(R/'unused-home'));E.pop('OSSTACK_SOCKET',None)
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=W,text=True).strip()
def record(name,args,expected=0):
 start=now()
 with (R/(name+'.stdout')).open('xb') as out,(R/(name+'.stderr')).open('xb') as err:
  p=subprocess.run(args,cwd=W,env=E,stdout=out,stderr=err)
 row={'argv':args,'cwd':str(W),'started':start,'finished':now(),'exit':p.returncode,'expected_exit':expected,'code_sha':git('rev-parse','HEAD'),'environment':{k:E[k]for k in ['PATH','OSSTACK_SCRATCH_ROOT','OSSTACK_HOME']},'outer_OSSTACK_SOCKET':'unset','stdout_sha256':sha((R/(name+'.stdout')).read_bytes()),'stderr_sha256':sha((R/(name+'.stderr')).read_bytes())}
 (R/(name+'.command.json')).write_text(json.dumps(row,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode!=expected:raise RuntimeError(name+' unexpected exit')
 return row
if __name__=='__main__':
 assert git('rev-parse','HEAD')=='6d97897325efdeea47d86f3ae169c72907b74d6e'
 assert git('status','--porcelain=v1')==''
 assert git('rev-parse','HEAD^{tree}')==git('rev-parse','b4a2fc30711d9c3ad5cddbc846839948f1810c56^{tree}')
 (R/'base-head.diff').write_text(git('diff','de43f47c29d5c08ae6e6c5eb366767320ffcdd0c','HEAD'))
 (R/'git-binding.json').write_text(json.dumps({'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'base':'de43f47c29d5c08ae6e6c5eb366767320ffcdd0c','old_head':'b4a2fc30711d9c3ad5cddbc846839948f1810c56','old_tree':git('rev-parse','b4a2fc30^{tree}'),'status':git('status','--porcelain=v1'),'parents':git('show','-s','--format=%P','HEAD')},indent=2)+'\n')
 paths=git('ls-files','packages','scripts').splitlines()
 snap=[{'path':p,'sha256':sha((W/p).read_bytes()),'bytes':(W/p).stat().st_size}for p in paths if (W/p).is_file()]
 (R/'before-source.json').write_text(json.dumps({'at':now(),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'parents':git('show','-s','--format=%P','HEAD'),'files':snap},indent=2)+'\n')
 record('node-version',['node','--version']);assert(R/'node-version.stdout').read_text().strip()=='v22.22.1'
 record('install',['pnpm','install','--frozen-lockfile'])
 record('build',['pnpm','build'])
 record('github-tests',['pnpm','--filter','@osstack/github','test'])
 record('candidate-cli-tests',['pnpm','test:pr-candidate'])
 record('lint',['pnpm','lint'])
 record('inventory',['node','scripts/generate-inventory.mjs','--check'])
 record('typecheck',['pnpm','typecheck'])
 record('docs',['/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-handoff-20261027/venv/bin/python','-m','unittest','discover','-s','docs/design/2026-10-27-joint-engineering','-p','test_validate_*.py'])
 record('hygiene',['pnpm','--filter','@osstack/governance','exec','vitest','run','src/knowledge-hygiene/osstack-config.test.ts'])
