from pathlib import Path
import subprocess,json,datetime,time,gzip,hashlib
r=Path(__file__).parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def call(name,args):
 start=now();p=subprocess.run(args,capture_output=True,timeout=180)
 (r/(name+'.stdout')).write_bytes(p.stdout);(r/(name+'.stderr')).write_bytes(p.stderr);(r/(name+'.command.json')).write_text(json.dumps({'argv':args,'start':start,'finish':now(),'exit_code':p.returncode},indent=2)+'\n');assert p.returncode==0,(name,p.stderr)
 return p.stdout
pr=json.loads(call('pr-initial',['gh','pr','view','309','--repo','osborn-studio/osstack','--json','headRefOid,baseRefName,isDraft,state,mergeable,statusCheckRollup,url']))
head=pr['headRefOid'];assert head=='fc272c631885fe39049c488dbfd60c708d2a6bdb' and pr['baseRefName']=='main' and pr['isDraft'] is True
run='40982097784'
(r/'target-binding.json').write_text(json.dumps({'head':head,'base':pr['baseRefName'],'run_id':run,'draft_required':True},indent=2)+'\n')
print('TARGET',run,head,flush=True)
for n in range(36):
 v=json.loads(call(f'poll-{n:02d}-run',['gh','api',f'repos/osborn-studio/osstack/actions/runs/{run}']))
 j=json.loads(call(f'poll-{n:02d}-jobs',['gh','api',f'repos/osborn-studio/osstack/actions/runs/{run}/jobs?per_page=100']))
 assert v['head_sha']==head;assert len(j['jobs'])==j['total_count']
 print(json.dumps({'poll':n,'status':v['status'],'conclusion':v['conclusion'],'jobs':[{'name':x['name'],'conclusion':x['conclusion'],'active':[s['name']for s in x['steps']if s['status']=='in_progress']}for x in j['jobs']]}),flush=True)
 if v['status']=='completed':
  (r/'run.stdout').write_bytes((r/f'poll-{n:02d}-run.stdout').read_bytes());(r/'jobs.stdout').write_bytes((r/f'poll-{n:02d}-jobs.stdout').read_bytes())
  log=call('complete-log',['gh','run','view',run,'--repo','osborn-studio/osstack','--log']);(r/'complete-log.log.gz').write_bytes(gzip.compress(log,mtime=0));assert gzip.decompress((r/'complete-log.log.gz').read_bytes())==log
  call('pr-final',['gh','pr','view','309','--repo','osborn-studio/osstack','--json','headRefOid,baseRefName,isDraft,state,mergeable,statusCheckRollup,url'])
  print('TERMINAL',v['conclusion'],len(log),hashlib.sha256(log).hexdigest(),flush=True);break
 if n==35: print('35_MINUTE_BOUND',flush=True);break
 time.sleep(60)
