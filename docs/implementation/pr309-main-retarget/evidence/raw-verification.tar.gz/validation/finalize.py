from pathlib import Path
import json,subprocess,hashlib,datetime,stat
R=Path(__file__).parent;W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr309-main-retarget');h=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
head='fc272c631885fe39049c488dbfd60c708d2a6bdb';base='a250ad88163132675d33dfe163c2e7e409443846'
assert git('rev-parse','HEAD').decode().strip()==head
commands=[json.loads(p.read_bytes())for p in sorted(R.glob('*.command.json'))];assert all(c['exit']==0 and c['code_sha']==head for c in commands)
assert '195 passed' in (R/'github-tests.stdout').read_text();assert '# pass 14' in (R/'candidate-cli-tests.stdout').read_text();assert 'Ran 241 tests' in (R/'docs.stderr').read_text();assert '1 passed' in (R/'hygiene.stdout').read_text()
v=json.loads((R/'frozen-vector-results.json').read_text());assert v['passed']==57 and not v['failed']
paths=[x['path']for x in json.loads((R/'generated-binding.json').read_text())['files']];assert set(git('diff','--name-only').decode().splitlines())==set(paths)
p=subprocess.run(['git','restore','--',*paths],cwd=W,capture_output=True);(R/'restore.stdout').write_bytes(p.stdout);(R/'restore.stderr').write_bytes(p.stderr);assert p.returncode==0
restored=[]
for f in json.loads((R/'generated-binding.json').read_text())['files']:
 b=(W/f['path']).read_bytes();assert h(b)==f['head_sha256'];restored.append({'path':f['path'],'sha256':h(b),'matches_head':True})
assert git('status','--porcelain=v1')==b''
(R/'restore-receipt.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':['git','restore','--',*paths],'exit':0,'files':restored,'status':'clean','no_tests_after_restore':True},indent=2)+'\n')
s={'head':head,'base':base,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'old_published_head':'f31e557a7d208815eeabd37d8dc9b4b7e3e352d1','tree_equal_old_published':True,'counts':{'github':195,'candidate_cli':14,'docs':241,'hygiene':1,'frozen_vectors':57,'undefined_control':'passed separately'},'commands':commands,'public_path':'packages/github/dist/index.js -> mapRollupToCheckState / ingestStack / detectDrift','scope_assessment':'Actual main delta changes only github stack classifier/tests plus changeset/docs/evidence. README claims conservative CheckRun mapping and unchanged legacy contexts; full github package and original57 vectors plus downstream injected scenario cover this surface. No dependency/package scripts/standalone driver changes require broader smoke. Candidate CLI14 revalidated the existing adjacent snapshot surface. No model or full suite in this task.','final_status':'clean','failures':[],'limitations':['Frozen expected vectors reused without changing oracle; only new candidate executed, no historical RED rerun.','Injected fixed forge responses; no live gh/network/CLI/DB mutation or model use.','No local full suite re-execution; future exact-head CI separately establishes full results.','Four fresh generated dist files saved then restored; no tests run after restore.']}
(R/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
(R/'report.md').write_text(f'''# PR309 actual-main targeted revalidation

HEAD `{head}`, base `{base}`, tree `{s['tree']}`. Tree equals published f31e557a exactly. Initial checkout clean. Fresh Node22 frozen install/build completed; GitHub195, standalone candidateCLI14, docs241 and hygiene1 passed. Lint/typecheck/inventory/changeset coverage all exited0 (one release-sensitive package).

The unchanged57 pre-frozen vectors all passed through this fresh compiled package public entry. A separate undefined control and public ingestion/drift/topology using the original three-PR fixed response bytes also passed. No old RED re-execution, real forge/DB calls, model use or local full-suite run occurred. Source/build/input hashes and actual argv/timestamps are preserved. This is a new run, not inherited historical evidence.

Review of README and actual diff found no new standalone driver, package script or dependency change requiring broader smoke beyond requested targeted coverage. The full GitHub package includes legacy status, conservative CheckRun and adjacent snapshot behavior. Root handles the static audit and PR/ledger actions.

Only four generated knowledge/dist files differed during checks. Their full bytes, hashes and patch were preserved, then only those four were restored and matched HEAD hashes. Final checkout clean; no tests ran after restoration. All executed commands exited0; no failures or retries were hidden.
''')
files=[]
for p in sorted(R.rglob('*')):
 if p.is_file() and '__pycache__'not in p.parts and p.name!='manifest.json':
  b=p.read_bytes();files.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':h(b),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
(R/'manifest.json').write_text(json.dumps({'files':files,'count':len(files)},indent=2)+'\n');print(json.dumps({'head':head,'summary_sha256':h((R/'summary.json').read_bytes()),'manifest_sha256':h((R/'manifest.json').read_bytes()),'files':len(files),'status':'clean'}))
