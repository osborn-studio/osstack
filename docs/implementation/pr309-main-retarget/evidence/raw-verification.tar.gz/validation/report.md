# PR309 actual-main targeted revalidation

HEAD `fc272c631885fe39049c488dbfd60c708d2a6bdb`, base `a250ad88163132675d33dfe163c2e7e409443846`, tree `afb6c366769e4a976823adfc89144efef81eb79b`. Tree equals published f31e557a exactly. Initial checkout clean. Fresh Node22 frozen install/build completed; GitHub195, standalone candidateCLI14, docs241 and hygiene1 passed. Lint/typecheck/inventory/changeset coverage all exited0 (one release-sensitive package).

The unchanged57 pre-frozen vectors all passed through this fresh compiled package public entry. A separate undefined control and public ingestion/drift/topology using the original three-PR fixed response bytes also passed. No old RED re-execution, real forge/DB calls, model use or local full-suite run occurred. Source/build/input hashes and actual argv/timestamps are preserved. This is a new run, not inherited historical evidence.

Review of README and actual diff found no new standalone driver, package script or dependency change requiring broader smoke beyond requested targeted coverage. The full GitHub package includes legacy status, conservative CheckRun and adjacent snapshot behavior. Root handles the static audit and PR/ledger actions.

Only four generated knowledge/dist files differed during checks. Their full bytes, hashes and patch were preserved, then only those four were restored and matched HEAD hashes. Final checkout clean; no tests ran after restoration. All executed commands exited0; no failures or retries were hidden.
