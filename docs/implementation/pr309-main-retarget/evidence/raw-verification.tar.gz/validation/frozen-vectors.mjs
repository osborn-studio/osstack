import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
const root='/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr309-main-retarget-20261030/validation';
const w='/Users/osborn/Developer/CodeX/.worktrees/osstack/pr309-main-retarget';
const frozen='/Volumes/AIMATE_WORK/tmp/osstack/runtime/checkrun-state-20261030/independent';
const head='fc272c631885fe39049c488dbfd60c708d2a6bdb';
const hash=b=>createHash('sha256').update(b).digest('hex');
const raw=await readFile(frozen+'/vectors.json'),manifest=JSON.parse(await readFile(frozen+'/manifest.json','utf8'));
assert.equal(hash(raw),manifest.members.find(x=>x.path==='vectors.json').sha256);
await writeFile(root+'/frozen-vectors.json',raw,{flag:'wx'});
const vectors=JSON.parse(raw);assert.equal(vectors.length,57);
const mod=await import(pathToFileURL(w+'/packages/github/dist/index.js'));
const rows=[];
for(const v of vectors){let actual,error;try{actual=mod.mapRollupToCheckState(v.input);}catch(e){error={name:e.name,message:e.message};}const passed=v.expected==='throws'?!!error:!error&&(Array.isArray(v.expected)?v.expected.includes(actual):actual===v.expected);rows.push({...v,actual,error,passed});}
const undefinedResult=mod.mapRollupToCheckState(undefined);assert.equal(undefinedResult,'unknown');
const previous=await readFile(frozen+'/validation/candidate-results.json');const input=JSON.parse(previous).ingress[0].synthetic_inputs;
await writeFile(root+'/three-pr-input.json',JSON.stringify(input,null,2)+'\n',{flag:'wx'});
const calls=[];const runner={run:async(command,args)=>{calls.push({command,args:[...args]});assert.equal(command,'gh');assert.deepEqual(args,['pr','view',args[2],'--json','number,state,baseRefName,headRefName,mergeable,mergeStateStatus,statusCheckRollup,title,url','--repo','fixture/project']);return JSON.stringify(input[Number(args[2])]);}};
const stack=await mod.ingestStack({prNumbers:[13,11,12],repo:'fixture/project'},runner),drift=mod.detectDrift(stack);
assert.deepEqual(stack.order,[11,12,13]);assert.deepEqual([...stack.edges].sort((a,b)=>a.parent-b.parent),[{parent:11,child:12},{parent:12,child:13}]);assert.deepEqual(stack.nodes.map(n=>n.ciState),['pending','success','failure']);assert.deepEqual(drift.issues.map(x=>[x.number,x.kind]),[[13,'ci_pending'],[12,'ci_failing']]);assert.equal(calls.length,3);
const bindings=[];for(const p of ['packages/github/src/index.ts','packages/github/src/stack.ts','packages/github/src/types.ts','packages/github/src/branch-scanner.ts']){const b=await readFile(w+'/'+p);assert(b.equals(execFileSync('git',['show',head+':'+p],{cwd:w})));bindings.push({path:p,sha256:hash(b)});}
for(const p of ['packages/github/dist/index.js','packages/github/dist/stack.js','packages/github/dist/types.js','packages/github/dist/branch-scanner.js'])bindings.push({path:p,sha256:hash(await readFile(w+'/'+p))});
const result={head,status:rows.every(r=>r.passed)?'passed':'failed',frozen_vectors:57,passed:rows.filter(x=>x.passed).length,failed:rows.filter(x=>!x.passed).map(x=>x.id),rows,undefined_control:{actual:undefinedResult,passed:true,separate_from57:true},public_entry:'packages/github/dist/index.js',input_sha256:hash(raw),original_three_pr_record_sha256:hash(previous),bindings,calls,stack,drift,limits:['Fresh actual public function execution on this build, reusing unchanged frozen vectors and injected three-PR responses.','No baseline RED re-execution, real gh subprocess, network request, CLI/database writes, model calls or full suite.']};
await writeFile(root+'/frozen-vector-results.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({head,status:result.status,passed:result.passed,failed:result.failed,undefined_control:result.undefined_control,ingest_drift_topology:'passed'},null,2));assert(rows.every(x=>x.passed));
