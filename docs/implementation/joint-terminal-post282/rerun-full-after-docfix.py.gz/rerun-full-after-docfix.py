from pathlib import Path
import subprocess,json,datetime,os,hashlib,re
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/terminal-post282');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-terminal-post282-20261027')
record=json.loads((out/'verification.json').read_text());assert record['status']=='failed'
assert record['commands'][-1]['name']=='test-full-isolated' and record['commands'][-1]['exit_code']==1
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert sha==record['code_sha']
(out/'verification-before-document-link-fix.json').write_text(json.dumps(record,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_HOME']=str(out/'home');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack';env.pop('OSSTACK_SOCKET',None)
record['status']='running';record['environment_adjustment']={'reason':'Confirmed inherited OSSTACK_SOCKET fixture mismatch; installer bin and test identical to reviewed base. 12-test isolated rerun passed. One fresh complete full-suite rerun to keep raw 22-package zero-failure acceptance.','OSSTACK_HOME':env['OSSTACK_HOME'],'OSSTACK_SOCKET':'unset; all CLI socket resolution derives from explicit scratch home or test fixture homes','diagnosis':'installer-environment-diagnosis.json'}
record['documentation_adjustment']={'reason':'Concurrent central design edits referenced this not-yet-created archive. Created truthful in-progress README; targeted osstack-config hygiene test passed. Parent froze worktree editing during final full regression.','hygiene_log':'hygiene-prearchive.log','full_rerun_authorized_by_parent':True}
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('test-full-final started',start,flush=True)
with (out/'test-full-final.log').open('w') as f:r=subprocess.run(['pnpm','test'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
record['commands'].append({'name':'test-full-final','command':['pnpm','test'],'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':'test-full-final.log','log_sha256':hashlib.sha256((out/'test-full-final.log').read_bytes()).hexdigest()})
record['status']='failed' if r.returncode else 'running';(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print('test-full-final exit',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
assert sha==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
rows=[]
for line in (out/'test-full-final.log').read_text().splitlines():
 m=re.match(r'(packages/\S+) test:\s+Tests\s+(.+)$',line)
 if m:
  counts={k:int(n) for n,k in re.findall(r'(\d+) (passed|failed|skipped)',m.group(2))};rows.append({'package':m.group(1),'passed':counts.get('passed',0),'failed':counts.get('failed',0),'skipped':counts.get('skipped',0)})
assert len(rows)==22 and len({x['package'] for x in rows})==22 and sum(x['failed'] for x in rows)==0
record['status']='passed';record['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['validation']={'passed':sum(x['passed'] for x in rows),'failed':0,'skipped':sum(x['skipped'] for x in rows),'packages':22};record['validation_source']='test-full-final.log';record['prior_full_run_status']='failed_environment_fixture and early_missing_archive_document; both preserved unchanged'
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');(out/'test-summary.json').write_text(json.dumps({'base_sha':record['base_sha'],'code_sha':sha,**record['validation'],'source':'test-full-final.log','detail':rows},indent=2)+'\n');print(json.dumps(record['validation']),flush=True)
