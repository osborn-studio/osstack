from pathlib import Path
import subprocess,json,datetime,os,hashlib,re
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/terminal-post282')
out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-terminal-post282-20261027')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_HOME']=str(out/'home');env['OSSTACK_SOCKET']=str(out/'daemon.sock');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack'
base='ede5aadced37ac9dc29dd21f0e307ad2c46d2976'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
record={'base_sha':base,'code_sha':sha,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['pnpm','--version'],env=env,text=True).strip(),'commands':[],'status':'running','product_patch_unchanged_on_merge':(out/'product-before.patch').read_bytes()==(out/'product-after.patch').read_bytes()}
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
cmds=[('install',['pnpm','install','--frozen-lockfile','--offline']),('build',['pnpm','build']),('focused',['pnpm','--filter','@osstack/cli','exec','vitest','run','src/session-send-receipt.test.ts','src/session-rpc.test.ts','src/session-wait.test.ts','src/session-command.test.ts','src/daemon-drain-recovery.test.ts','src/adapter-lifecycle.test.ts']),('typecheck',['pnpm','typecheck:check']),('lint',['pnpm','lint']),('inventory',['node','scripts/generate-inventory.mjs','--check']),('changeset',['node','scripts/check-changeset-coverage.mjs','--base',base]),('test-full',['pnpm','test'])]
for label,cmd in cmds:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(label,'started',start,flush=True)
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 record['commands'].append({'name':label,'command':cmd,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':label+'.log','log_sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()})
 record['status']='failed' if r.returncode else 'running';(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(label,'exit',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
assert sha==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
rows=[]
for line in (out/'test-full.log').read_text().splitlines():
 m=re.match(r'(packages/\S+) test:\s+Tests\s+(.+)$',line)
 if m:
  counts={k:int(n) for n,k in re.findall(r'(\d+) (passed|failed|skipped)',m.group(2))};rows.append({'package':m.group(1),'passed':counts.get('passed',0),'failed':counts.get('failed',0),'skipped':counts.get('skipped',0)})
assert len(rows)==22 and len({x['package'] for x in rows})==22 and sum(x['failed'] for x in rows)==0
record['status']='passed';record['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['validation']={'passed':sum(x['passed'] for x in rows),'failed':0,'skipped':sum(x['skipped'] for x in rows),'packages':22}
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');(out/'test-summary.json').write_text(json.dumps({'base_sha':base,'code_sha':sha,**record['validation'],'detail':rows},indent=2)+'\n');print(json.dumps(record['validation']),flush=True)
