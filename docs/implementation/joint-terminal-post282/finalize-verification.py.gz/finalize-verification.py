from pathlib import Path
import json
out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-terminal-post282-20261027')
p=out/'verification.json';v=json.loads(p.read_text());assert v['status']=='passed' and v['validation']['failed']==0
historical=[x for x in v['commands'] if x['exit_code']!=0]
assert len(historical)==2 and historical[0]['name']=='test-full' and historical[1]['name']=='test-full-isolated'
v['historical_runs']=[{'status':'failed_environment_fixture','commands':[historical[0]],'verification':'verification-before-socket-isolation.json','summary':'test-summary-before-socket-isolation.json','diagnosis':'installer-environment-diagnosis.json'},{'status':'failed_missing_in_progress_archive_document','commands':[historical[1]],'verification':'verification-before-document-link-fix.json','repair':'Created truthful in-progress README; hygiene-prearchive.log passed before full rerun'},{'status':'interrupted_by_operator_before_test_coverage_update','verification':'historical-candidate/verification.json','reason':'superseded-run.json'}]
v['commands']=[dict(x,code_sha=v['code_sha']) for x in v['commands'] if x['exit_code']==0]
for x in v['commands']:
 if x['name']=='test-full-final':x['name']='test-full'
assert v['commands'][-1]['log']=='test-full-final.log' and len(v['commands'])==8
p.write_text(json.dumps(v,indent=2)+'\n')
print('normalized final effective commands; both prior runs preserved')
