VERDICT: PASS

This is a static review of the diff and the excerpts provided. I ran nothing, I did not see the full suite, and I could not see the other callers of `executeReservedSessionTurn`.

## Claims checked against the code

- **Start, no terminal event.** `settled` is still false when the loop exhausts, so `daemon.ts:669` throws. The `finally` at `:722` then aborts, calls `confirmAdapterStopped`, and either releases or retains. If the adapter has no `confirmStopped`, `confirmAdapterStopped` returns false and the lease is retained. The "missing_stop_verifier" test covers this.
- **Start, completed then failed or throw.** The failed terminal throws at `:664` and a post-terminal iterator throw is caught at `:710`. Both leave `settled` false, so stop confirmation is requested.
- **Start, completed but no native id.** `settled = true` is set at `:670`, before the native-id check at `:671`. That failed result does not retain an already completed invocation, as the changeset says, and a test covers it.
- **Send.** Moving `settled = true` after the `terminalCompleted` check (`:1043-1049`) closes the old hole where a terminal-free exhaustion released without stop proof. A failed terminal returns before `settled` is set, and a throw lands in the inner catch, so both cases request stop confirmation. DB-commit failure after completion still releases without stop proof, which is consistent with a completed invocation.
- **Built-in Codex.** Every `runSession` path emits a terminal event or throws, and the adapter has no `confirmStopped`. Completed streams therefore release, which the new test shows, and terminal-free streams cannot normally occur.
- **Replay, persistence and cleanup separation.** The diff leaves the receipt paths, `markMessageFailed` and `reportSessionCleanupFailure` untouched. The tests assert that restart replay does not re-invoke the adapter and that persisted state is unchanged.

## Findings

No P0 or P1.

**P2, test blind spots (not blocking):**
1. **Confirmed-stop branch.** No test covers completed-then-failed or completed-then-throw with a confirmed stop, where the lease should release. Only `stopUnconfirmed = true` is tested there. A fix for "retain on any late failure" would pass the suite. Minimal correction: parametrize the late-fault test over `stopUnconfirmed`.
2. **Evidence validation.** `confirmAdapterStopped` rejects empty or whitespace evidence, and it times out after 1s. Neither is tested, though both are inherited behavior.
3. **Drain abort.** Nothing tests an abort after a completed terminal but before release. The `|| controller.signal.aborted` clause at `:722` and `:1097` then forces stop verification even though `settled` is true. This predates the PR.
4. **Events after the completed terminal.** Nothing tests extra events or a second completed terminal after the first. The loop continues and accepts them, which is inherited.

## Inherited, not regressions
- A failed terminal from the built-in Codex adapter, for example `codex_nonzero_exit` after the process has closed, retains the lease permanently because there is no verifier. Start already behaved this way and send did too. DEBT02 owns recovery.
- Replaying a failed Session start returns RPC `ok: true` with `state: failed`. The changeset documents this.
- Trust in "completed terminal plus normal exhaustion" as proof of exit rests on the adapter. This is the stated model.

## Scope
The `settled` move in `executeReservedSessionTurn` also applies to any other route that calls it with `engineeringPermit` or `completed` options. I could not see those callers, so confirm their tests tolerate a retained lease on terminal-free streams.

END_AUDIT