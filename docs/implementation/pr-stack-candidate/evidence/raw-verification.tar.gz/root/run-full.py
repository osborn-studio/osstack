import pathlib,subprocess,hashlib,json,os,datetime
w=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/post307-ci-close');r=pathlib.Path(__file__).parent
def snap():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=w).decode().split('\0');return {n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in names if n and (w/n).is_file()}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();before=snap();dirty=subprocess.check_output(['git','status','--porcelain'],cwd=w).decode();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
(r/'full-before.json').write_text(json.dumps({'head':head,'dirty':dirty,'files':before},indent=2))
with (r/'full.log').open('w') as f: code=subprocess.run(['pnpm','test'],cwd=w,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}).returncode
after=snap();(r/'full-after.json').write_text(json.dumps(after,indent=2));(r/'full-binding.json').write_text(json.dumps({'head':head,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'tracked_files':len(before),'tracked_bytes_unchanged':before==after,'initial_dirty':dirty,'changed':[n for n in set(before)|set(after) if before.get(n)!=after.get(n)]},indent=2));print(code)
