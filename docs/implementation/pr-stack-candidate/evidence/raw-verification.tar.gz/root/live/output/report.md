# PR stack observation

Repository: osborn-studio/osstack. Declared order: 308 → 309.
Observed: 2026-10-30T01:05:49.542Z to 2026-10-30T01:05:56.987Z.
Result: frontier_observed. Frontier: 309.
This is not Ready or merge authorization. Observations are sequential, not atomic.
Target base: main. Branch names are not ancestry proof.

## PR 308 (merged_prefix)
Observation: observed; candidate summary: merged; issue: none.
Relation: not_applicable; expected base: unknown; observed base: main.
Blockers: none observed.
Waiting: none observed.
Unknowns: requirements&#95;unspecified, checks&#95;not&#95;success, mergeability&#95;unknown, merge&#95;state&#95;unknown.
[Snapshot and original policy limits](prs/308/snapshot.json); [query receipts](prs/308/queries.json).

## PR 309 (frontier)
Observation: observed; candidate summary: blocked; issue: none.
Relation: target_matches; expected base: main; observed base: main.
Blockers: forge&#95;blocked.
Waiting: checks&#95;pending, review&#95;required, draft.
Unknowns: requirements&#95;unspecified, checks&#95;not&#95;success.
[Snapshot and original policy limits](prs/309/snapshot.json); [query receipts](prs/309/queries.json).

## Limits
- Caller-declared order; branch-name equality is not ancestry or dependency proof.
- Sequential non-atomic observations; facts can change after each read. No automatic re-read.
- A frontier is not Ready or merge authorization. Original per-PR policy and unknowns remain in snapshots.
- No watcher, retry, retarget, approval, merge, candidate execution or database refresh.
- Collection budgets use wall time. The runner must honor timeoutMs; injected runners are not forcibly cancelled.
