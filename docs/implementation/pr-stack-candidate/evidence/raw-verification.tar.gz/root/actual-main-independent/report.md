# Post309 actual-main candidate equivalence

Actual main `e4643324b9de1d2db51c744e59ccd7c05146b0a6` has exactly the same tree as original base `fc272c631885fe39049c488dbfd60c708d2a6bdb`. Merged candidate `a0b9fd4ef1ed72e2801eef8a5c67f05a7a57d734` has exactly the same tree as pre-merge `f710783105c742167f74d5f755d2949d11181e9d` (`c84b644ae4de302abd887da965c6d1de3fe6d88e`). Both the entire normal diff and full-index binary diff are byte-identical across these base/head pairs. Normal diff SHA `37179b1de81c296aecea5e55ca81f7578f1f1e19d47af6016e9205b2de5db24e`; binary diff SHA `1286392ec95bed6994c396df333439c325ce435cc652d07fadc8d30eba48d637`.

102 changed paths include the bounded stack tool, its direct tests, barrel/CI/package-script wiring, changeset and documentation/control evidence. The five author paths match wired540; later f710 changes only the CLI, CLI tests and README. The library and its test bytes remain exactly the author bytes. All five are unchanged by actual-main merge. The existing single-candidate collector is unchanged.

32 package manifests/lock/workspace metadata paths are byte-identical. Root package.json only adds two scripts; dependencies and all pre-existing scripts are unchanged. CI only adds the ordered-stack offline contract step; no existing steps/matrix are removed. Detailed paths and hashes are in report.json.

No full suite, model, forge mutation, DB or source edit was run. This is Git-byte equivalence evidence only. Root's four fresh generated dist files were not inspected, restored or changed by this task.
