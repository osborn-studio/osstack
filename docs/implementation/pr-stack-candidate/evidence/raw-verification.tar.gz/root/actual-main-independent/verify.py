from pathlib import Path
import subprocess,json,hashlib,datetime
R=Path(__file__).parent;W=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack');h=lambda b:hashlib.sha256(b).hexdigest()
commands=[]
def git(*a):
 p=subprocess.run(['git',*a],cwd=W,capture_output=True);commands.append({'argv':['git',*a],'exit':p.returncode,'stdout_sha256':h(p.stdout),'stderr':p.stderr.decode()});assert p.returncode==0;return p.stdout
a='fc272c631885fe39049c488dbfd60c708d2a6bdb';b='f710783105c742167f74d5f755d2949d11181e9d';c='e4643324b9de1d2db51c744e59ccd7c05146b0a6';d='a0b9fd4ef1ed72e2801eef8a5c67f05a7a57d734';author='ad38b017876a84b6333c67a47acc98ebb8b5b848';wired='540cd7a50fd044aa3c5b39f2f0ea62bfcec6ebe9'
trees={x:git('rev-parse',x+'^{tree}').decode().strip()for x in [a,b,c,d]};assert trees[a]==trees[c] and trees[b]==trees[d]
diffs=[]
for label,left,right in [('original',a,b),('actual-main',c,d)]:
 raw=git('diff',left,right);binary=git('diff','--binary','--full-index',left,right);(R/(label+'.diff')).write_bytes(raw);(R/(label+'.full-binary.diff')).write_bytes(binary);diffs.append({'label':label,'base':left,'head':right,'diff_sha256':h(raw),'full_binary_sha256':h(binary),'bytes':len(raw),'full_binary_bytes':len(binary)})
assert (R/'original.diff').read_bytes()==(R/'actual-main.diff').read_bytes();assert (R/'original.full-binary.diff').read_bytes()==(R/'actual-main.full-binary.diff').read_bytes()
changed=git('diff','--name-only',c,d).decode().splitlines();(R/'changed-paths.txt').write_text('\n'.join(changed)+'\n')
source_manifest=json.loads(Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr-stack-frontier-20261030/author/candidate-source-manifest.json').read_bytes());author_rows=[]
for item in source_manifest['source']:
 p=item['path'];o=git('show',author+':'+p);x=git('show',wired+':'+p);y=git('show',b+':'+p);z=git('show',d+':'+p);assert h(o)==item['sha256'];assert o==x and y==z
 author_rows.append({'path':p,'author_sha256':h(o),'wired540_sha256':h(x),'f710_sha256':h(y),'actual_main_sha256':h(z),'author_equals_wired':True,'changed_by_cli_fix':x!=y,'merge_preserved':True,'bytes':len(z)})
assert {x['path']for x in author_rows if x['changed_by_cli_fix']}=={'scripts/report-pr-stack-candidate.mjs','scripts/report-pr-stack-candidate.test.mjs','docs/implementation/pr-stack-candidate/README.md'}
assert all(not x['changed_by_cli_fix']for x in author_rows if x['path'].startswith('packages/github/'))
files=git('ls-tree','-r','--name-only',c).decode().splitlines();deps=[p for p in files if p.endswith('/package.json') or p in ['pnpm-lock.yaml','pnpm-workspace.yaml'] or p.endswith('/pnpm-lock.yaml')];assert not set(deps)&set(changed)
depbindings=[{'path':p,'blob_before':git('rev-parse',c+':'+p).decode().strip(),'blob_after':git('rev-parse',d+':'+p).decode().strip()}for p in deps];assert all(x['blob_before']==x['blob_after']for x in depbindings)
p0=json.loads(git('show',c+':package.json'));p1=json.loads(git('show',d+':package.json'));scripts0=p0.pop('scripts');scripts1=p1.pop('scripts');assert p0==p1
added={k:v for k,v in scripts1.items()if k not in scripts0};assert set(added)=={'test:pr-stack-candidate','inspect:pr-stack-candidate'};assert all(scripts1[k]==v for k,v in scripts0.items())
collector='packages/github/src/pr-candidate-snapshot.ts';assert git('show',c+':'+collector)==git('show',d+':'+collector)
ci=git('diff',c,d,'--','.github/workflows/ci.yml').decode();assert '-      'not in ci
product=[p for p in changed if not p.startswith('docs/')];package_sources=[p for p in changed if p.startswith('packages/')]
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_before_merge':a,'candidate_before_merge':b,'actual_main':c,'merged_candidate':d,'merged_parents':git('show','-s','--format=%P',d).decode().strip().split(),'trees':trees,'both_baseline_trees_equal':True,'both_candidate_trees_equal':True,'complete_delta_bytes_equal':True,'diffs':diffs,'changed_paths_count':len(changed),'non_docs_paths':product,'package_changed_paths':package_sources,'author_five_paths':author_rows,'dependency_manifests_and_locks':depbindings,'root_package_only_added_scripts':added,'existing_single_collector_unchanged':True,'ci_diff':ci,'limits':['Read-only Git object comparison, not product execution or fresh tests.','No working-tree reads/restoration; root fresh generated dist intentionally untouched.','All complete binary/text deltas compared; this establishes exact candidate equivalence, not deployment/CI or whole-capability qualification.']}
(R/'report.json').write_text(json.dumps(result,indent=2)+'\n');(R/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(R/'report.md').write_text(f'''# Post309 actual-main candidate equivalence

Actual main `{c}` has exactly the same tree as original base `{a}`. Merged candidate `{d}` has exactly the same tree as pre-merge `{b}` (`{trees[d]}`). Both the entire normal diff and full-index binary diff are byte-identical across these base/head pairs. Normal diff SHA `{diffs[0]['diff_sha256']}`; binary diff SHA `{diffs[0]['full_binary_sha256']}`.

{len(changed)} changed paths include the bounded stack tool, its direct tests, barrel/CI/package-script wiring, changeset and documentation/control evidence. The five author paths match wired540; later f710 changes only the CLI, CLI tests and README. The library and its test bytes remain exactly the author bytes. All five are unchanged by actual-main merge. The existing single-candidate collector is unchanged.

{len(deps)} package manifests/lock/workspace metadata paths are byte-identical. Root package.json only adds two scripts; dependencies and all pre-existing scripts are unchanged. CI only adds the ordered-stack offline contract step; no existing steps/matrix are removed. Detailed paths and hashes are in report.json.

No full suite, model, forge mutation, DB or source edit was run. This is Git-byte equivalence evidence only. Root's four fresh generated dist files were not inspected, restored or changed by this task.
''')
fs=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for p in sorted(R.rglob('*'))if p.is_file()and p.name!='manifest.json'];(R/'manifest.json').write_text(json.dumps({'files':fs,'count':len(fs)},indent=2)+'\n');print(json.dumps({'normal_diff_sha256':diffs[0]['diff_sha256'],'binary_diff_sha256':diffs[0]['full_binary_sha256'],'report_sha256':h((R/'report.json').read_bytes()),'manifest_sha256':h((R/'manifest.json').read_bytes()),'changed':len(changed),'dependency_files':len(deps)},indent=2))
