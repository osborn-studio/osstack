# Author evidence — one-shot declared PR stack report

Candidate `ad38b017876a84b6333c67a47acc98ebb8b5b848`, base actual main `a250ad88163132675d33dfe163c2e7e409443846`. Only the five assigned files changed. Worktree is clean; no tracked build artifacts were restored. Build outputs stay available for C's independent review.

Actual final results: library **29**, CLI **16**, whole GitHub package **201** passed; package build passed. Biome exited 0 with one optional-chain warning. Earlier progress text estimated 31 library tests; retained final logs are authoritative and show 29.

Original missing-module/script RED is normal preparation of a new feature, not a previous production bug. The first CLI GREEN attempt had 15 pass/1 fail because the assertion expected an unescaped underscore code in Markdown; the assertion now checks rendered entity text, while the JSON outcome and original safe renderer remain unchanged. The late-budget regression had 1 fail/28 pass: an uncooperative runner's result arriving after the global deadline was not explicitly marked. The fix preserves raw observations but marks the row as budget-exhausted and excludes it from frontier/branch relation qualification. The dispatch-receipt RED then required effective runner timeouts to be retained separately from the unchanged singleton collector's requested timeout.

The intermediate uncommitted source files were not separately frozen before those edits. Their original failure logs are preserved, but this bundle does not invent an exact pre-fix source hash. `candidate-source-manifest.json` binds actual final committed source, tests and current compiled files. `commands.json` records commands and observed exits.

Two actual file-output runs used explicitly injected offline runners: `two-lower-failure/` and `three-merged-prefix/`. Their manifests were independently read back by the author script for all 24 and 34 members, respectively. Original response strings, effective dispatch parameters, plan bytes and hashes remain. These are not live forge reads, authenticated observations, native host use or a formal gate. `offline-example-calls.json` retains complete synthetic runner inputs/outputs.

No whole-repo test, model, live forge, database, watcher, retarget, approval or merge was invoked. Root owns integration, audit, full tests and publication. Source inspiration and Lauren Tan/MIT attribution are in the implementation README.
