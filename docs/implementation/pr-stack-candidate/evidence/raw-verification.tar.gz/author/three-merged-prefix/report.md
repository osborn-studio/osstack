# PR stack observation

Repository: owner/repo. Declared order: 20 → 7 → 9.
Observed: 2026-10-30T00:58:30.714Z to 2026-10-30T00:58:30.714Z.
Result: frontier_observed. Frontier: 7.
This is not Ready or merge authorization. Observations are sequential, not atomic.
Target base: main. Branch names are not ancestry proof.

## PR 20 (merged_prefix)
Observation: observed; candidate summary: merged; issue: none.
Relation: not_applicable; expected base: unknown; observed base: main.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/20/snapshot.json); [query receipts](prs/20/queries.json).

## PR 7 (frontier)
Observation: observed; candidate summary: no_observed_blocker; issue: none.
Relation: retarget_review_needed; expected base: main; observed base: branch-20.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/7/snapshot.json); [query receipts](prs/7/queries.json).

## PR 9 (upstack)
Observation: observed; candidate summary: no_observed_blocker; issue: none.
Relation: parent_matches; expected base: branch-7; observed base: branch-7.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/9/snapshot.json); [query receipts](prs/9/queries.json).

## Limits
- Caller-declared order; branch-name equality is not ancestry or dependency proof.
- Sequential non-atomic observations; facts can change after each read. No automatic re-read.
- A frontier is not Ready or merge authorization. Original per-PR policy and unknowns remain in snapshots.
- No watcher, retry, retarget, approval, merge, candidate execution or database refresh.
- Collection budgets use wall time. The runner must honor timeoutMs; injected runners are not forcibly cancelled.
