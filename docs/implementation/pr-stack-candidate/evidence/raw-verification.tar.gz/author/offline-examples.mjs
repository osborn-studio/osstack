import { writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { runPrStackCandidateReport } from '/Users/osborn/Developer/CodeX/.worktrees/osstack/pr-stack-frontier-author/scripts/report-pr-stack-candidate.mjs';
const root = '/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr-stack-frontier-20261030/author';
const calls = [], H = n => n.toString(16).padStart(40, '0');
for (const [name, numbers, merged] of [['two-lower-failure', [20, 7], false], ['three-merged-prefix', [20, 7, 9], true]]) {
  const plan = { schema_version: 1, repo: 'owner/repo', target_base: 'main', prs: numbers.map(pr => ({ pr, requiredChecks: ['test'] })) };
  const input = join(root, `${name}.plan.json`), output = join(root, name);
  await writeFile(input, `${JSON.stringify(plan, null, 2)}\n`, { flag: 'wx' });
  const runner = { async run(command, args, options) {
    const get = prefix => args.find(v => v.startsWith(prefix))?.slice(prefix.length);
    const n = Number(get('number=') ?? Number.parseInt(get('oid='), 16));
    const q = get('query='), page = nodes => ({ nodes, pageInfo: { hasNextPage: false, endCursor: null } });
    let repository;
    if (q.includes('CandidateFacts')) repository = { nameWithOwner: 'owner/repo', pullRequest: { number: n, url: `https://github.com/owner/repo/pull/${n}`, state: merged && n === 20 ? 'MERGED' : 'OPEN', isDraft: false, headRefOid: H(n), baseRefOid: 'b'.repeat(40), headRefName: `branch-${n}`, baseRefName: n === 20 ? 'main' : n === 7 ? 'branch-20' : 'branch-7', mergeable: 'MERGEABLE', mergeStateStatus: 'CLEAN', reviewDecision: 'APPROVED' } };
    else if (q.includes('CandidateChecks')) repository = { nameWithOwner: 'owner/repo', object: { oid: H(n), statusCheckRollup: { contexts: page([{ __typename: 'CheckRun', id: `check-${n}`, name: 'test', status: 'COMPLETED', conclusion: !merged && n === 20 ? 'FAILURE' : 'SUCCESS', detailsUrl: null }]) } } };
    else repository = { nameWithOwner: 'owner/repo', pullRequest: { number: n, reviewThreads: page([]) } };
    const result = { stdout: JSON.stringify({ data: { repository } }), stderr: '', exitCode: 0 };
    calls.push({ example: name, command, args, options, result }); return result;
  } };
  const result = await runPrStackCandidateReport(['--plan', input, '--output', output], { runner });
  await writeFile(join(root, `${name}.result.json`), `${JSON.stringify(result, null, 2)}\n`, { flag: 'wx' });
  if (result.exitCode !== 0 || result.frontier_pr !== (merged ? 7 : 20)) throw new Error('example_failed');
  const manifest = JSON.parse(await readFile(join(output, 'manifest.json'), 'utf8'));
  for (const f of manifest.files) {
    const b = await readFile(join(output, f.path));
    if (b.length !== f.bytes || createHash('sha256').update(b).digest('hex') !== f.sha256) throw new Error('member_mismatch');
  }
  console.log(JSON.stringify({ name, result, verified_members: manifest.files.length }));
}
await writeFile(join(root, 'offline-example-calls.json'), `${JSON.stringify(calls, null, 2)}\n`, { flag: 'wx' });
