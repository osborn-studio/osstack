# PR stack observation

Repository: owner/repo. Declared order: 20 → 7.
Observed: 2026-10-30T00:58:30.705Z to 2026-10-30T00:58:30.707Z.
Result: frontier_observed. Frontier: 20.
This is not Ready or merge authorization. Observations are sequential, not atomic.
Target base: main. Branch names are not ancestry proof.

## PR 20 (frontier)
Observation: observed; candidate summary: blocked; issue: none.
Relation: target_matches; expected base: main; observed base: main.
Blockers: check&#95;failure.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/20/snapshot.json); [query receipts](prs/20/queries.json).

## PR 7 (upstack)
Observation: observed; candidate summary: no_observed_blocker; issue: none.
Relation: parent_matches; expected base: branch-20; observed base: branch-20.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/7/snapshot.json); [query receipts](prs/7/queries.json).

## Limits
- Caller-declared order; branch-name equality is not ancestry or dependency proof.
- Sequential non-atomic observations; facts can change after each read. No automatic re-read.
- A frontier is not Ready or merge authorization. Original per-PR policy and unknowns remain in snapshots.
- No watcher, retry, retarget, approval, merge, candidate execution or database refresh.
- Collection budgets use wall time. The runner must honor timeoutMs; injected runners are not forcibly cancelled.
