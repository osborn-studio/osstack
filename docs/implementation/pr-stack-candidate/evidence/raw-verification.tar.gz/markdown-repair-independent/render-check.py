from pathlib import Path
import subprocess,json,unicodedata,hashlib,re
from html.parser import HTMLParser
r=Path(__file__).parent
class Inspect(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.links=[];self.text=[]
 def handle_starttag(self,t,a):
  if t=='a':self.links.append(dict(a).get('href'))
 def handle_data(self,s):self.text.append(s)
def render(s,name):
 x=subprocess.run(['/opt/homebrew/bin/pandoc','-f','gfm','-t','html'],input=s.encode(),capture_output=True,check=True)
 (r/(name+'.html')).write_bytes(x.stdout);p=Inspect();p.feed(x.stdout.decode());return p
cal=render('www.example.test/login a@b.example https://example.test/login\n\n&#8238;\n','renderer-control')
assert len(cal.links)==3 and '\u202e' in ''.join(cal.text)
cases=json.loads((r/'criteria.json').read_text())['cases'];rows=[]
for version in ['old','new']:
 for c in cases:
  md=(r/'owned'/f'{version}-{c["id"]}'/'report.md').read_text();p=render(md,version+'/'+c['id']);txt=''.join(p.text)
  unwanted=[x for x in p.links if x not in ['prs/72/snapshot.json','prs/72/queries.json','prs/3/snapshot.json','prs/3/queries.json']]
  ctrl=[f'U+{ord(x):04X}' for x in txt if unicodedata.category(x) in ['Cc','Cf'] and x not in '\n\r\t']
  checks={'no_unexpected_links':not unwanted,'no_decoded_controls_or_format':not ctrl,'four_intended_links_preserved':len(p.links)-len(unwanted)==4}
  if c['id'] in ['MD07','MD08','MD09']:checks['readable_original']=c['value'] in txt
  for ch in c['value']:
   if unicodedata.category(ch) in ['Cc','Cf']:
    # Semantic visible literal escape requirement allows uXXXX, u{XXXX}, UXXXXXXXX.
    code=ord(ch);alts=['\\u'+f'{code:04x}','\\u{'+f'{code:x}'+'}','\\U'+f'{code:08x}'];checks[f'literal_escape_{code:x}']=any(a.lower() in txt.lower() for a in alts)
  rows.append({'version':version,'id':c['id'],'passed':all(checks.values()),'checks':checks,'unexpected_links':unwanted,'decoded_control_points':ctrl,'markdown_sha256':hashlib.sha256(md.encode()).hexdigest(),'html_sha256':hashlib.sha256((r/(version+'/'+c['id']+'.html')).read_bytes()).hexdigest()})
obj={'renderer':subprocess.check_output(['/opt/homebrew/bin/pandoc','--version']).decode().splitlines()[0],'renderer_control':{'raw_links':cal.links,'entity_bidi_remains_control':True},'escape_spelling_note':'Frozen visible literal escape requirement is checked semantically: both \\uXXXX and \\u{HEX} preserve readable codepoint identity. No requirement for one casing/braces spelling.','results':rows,'old_failed':[x['id'] for x in rows if x['version']=='old' and not x['passed']],'new_failed':[x['id'] for x in rows if x['version']=='new' and not x['passed']]}
(r/'render-results.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({k:obj[k] for k in ['old_failed','new_failed']},indent=2))
