# Markdown repair independent supplement

Old `540cd7a5` failed 7 of 10 targeted rendered-output cases. Repair `2348c825` passed all 10; 20 actual CLI seam reports were generated and every emitted manifest member verified. The underlying library is unchanged.

Pandoc GFM rendering confirmed that raw web/email/https strings become links and an entity-encoded bidi character becomes the control character again. Repair output retained only the four intended internal links, displayed control/format characters as visible codepoint escapes, and preserved normal Unicode and literal entity-looking text. JSON branch values remain exact. This is concrete rendered-HTML evidence, not a screenshot or universal renderer claim. Original 42-scenario grading is unchanged.

Separately, the retained root live snapshot manifest and eight fixed GraphQL receipts were verified. Guard precedes calls; 308 was stably MERGED and 309 the OPEN frontier, still blocked with draft/checks-pending/review-required and unknowns. This historical observation grants no Ready/merge authority and was not rerun.
