from pathlib import Path
import subprocess,hashlib,json,stat,os,datetime
r=Path(__file__).parent;repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';wt=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr-stack-frontier-author')
h=lambda b:hashlib.sha256(b).hexdigest();g=lambda rev,p:subprocess.check_output(['git','show',rev+':'+p],cwd=repo)
a='ad38b017876a84b6333c67a47acc98ebb8b5b848';b='2348c82522030c63e4d0c1125dd0c361cda3fca4';p='scripts/report-pr-stack-candidate.mjs'
assert (wt/p).read_bytes()==g(b,p)
assert g(a,'packages/github/src/pr-stack-candidate.ts')==g(b,'packages/github/src/pr-stack-candidate.ts')
(r/'new-source.mjs').write_bytes(g(b,p))
for version in ['old','new']:
 for c in json.loads((r/'criteria.json').read_text())['cases']:
  d=r/'owned'/f'{version}-{c["id"]}';m=json.loads((d/'manifest.json').read_text())
  for e in m['files']:
   f=d/e['path'];assert f.stat().st_size==e['bytes'] and h(f.read_bytes())==e['sha256'] and stat.S_IMODE(f.stat().st_mode)==e['mode']
  plan=json.loads((d/'plan.json').read_text());report=json.loads((d/'report.json').read_text());assert plan['target_base']==report['target_base']==c['value'];assert report['rows'][1]['relation']['expected_base']==c['value']
  for pr in [72,3]:
   for label in ['initial','final']:
    raw=json.loads((d/f'prs/{pr}/raw/{label}.stdout').read_text())['data']['repository']['pullRequest'];assert raw['baseRefName']==c['value']
    if pr==72:assert raw['headRefName']==c['value']
live=r.parent/'root/live';d=live/'output';m=json.loads((d/'manifest.json').read_text());livehash=[]
for e in m['files']:
 f=d/e['path'];assert f.stat().st_size==e['bytes'] and h(f.read_bytes())==e['sha256'] and stat.S_IMODE(f.stat().st_mode)==e['mode'];livehash.append(e)
assert set(x['path'] for x in m['files'])=={str(f.relative_to(d)) for f in d.rglob('*') if f.is_file() and f!=d/'manifest.json'}
guard=json.loads((live/'guard.json').read_text());report=json.loads((d/'report.json').read_text());qs=[]
for pr in [308,309]:
 q=json.loads((d/f'prs/{pr}/queries.json').read_text());qs+=q
 for x in q:
  assert x['command']=='gh' and x['args'][:2]==['api','graphql'] and x['exit_code']==0
  query=[v for v in x['args'] if v.startswith('query=')][0];assert query.startswith(('query=query CandidateFacts','query=query CandidateChecks','query=query CandidateThreads'))
  assert datetime.datetime.fromisoformat(guard['at'])<datetime.datetime.fromisoformat(x['started_at'].replace('Z','+00:00'))
 ini=json.loads((d/f'prs/{pr}/raw/initial.stdout').read_text())['data']['repository']['pullRequest'];fin=json.loads((d/f'prs/{pr}/raw/final.stdout').read_text())['data']['repository']['pullRequest'];assert ini['headRefOid']==fin['headRefOid'] and ini['baseRefOid']==fin['baseRefOid']
 if pr==308:assert ini['state']==fin['state']=='MERGED'
 else:assert ini['state']==fin['state']=='OPEN' and ini['isDraft'] and ini['reviewDecision']=='REVIEW_REQUIRED'
assert len(qs)==report['requests']==8 and report['frontier_pr']==309 and report['rows'][0]['role']=='merged_prefix' and report['merge_authorized']==False
assert {'checks_pending','review_required','draft'}<=set(report['rows'][1]['waiting'])
lr={'source_commit':guard['head'],'manifest_sha256':h((d/'manifest.json').read_bytes()),'members':len(m['files']),'all_member_hash_size_mode_inventory_valid':True,'guard_before_all_queries':True,'requests':len(qs),'frontier':309,'merged_prefix':308,'candidate_summary':report['rows'][1]['candidate_summary'],'waiting':report['rows'][1]['waiting'],'unknowns':report['rows'][1]['unknowns'],'merge_authorized':False,'original_paths':[str(live/x) for x in ['guard.json','result.json','output/manifest.json']],'scope':'Read-only retained evidence verification; no new gh calls. Snapshot is historical at its recorded time, not current readiness. UTF8-decoded responses, not wire authentication.'}
(r/'live-observation-receipt.json').write_text(json.dumps(lr,indent=2)+'\n')
results=json.loads((r/'render-results.json').read_text());assert not results['new_failed']
summary={'frozen_criteria_sha256':h((r/'criteria.json').read_bytes()),'baseline':'540cd7a50fd044aa3c5b39f2f0ea62bfcec6ebe9','repair':b,'baseline_cli_sha256':h(g(a,p)),'repair_cli_sha256':h(g(b,p)),'library_unchanged':True,'cases':10,'actual_cli_seam_outputs':20,'old_failed':results['old_failed'],'new_failed':[],'renderer':results['renderer'],'json_and_raw_branch_values_preserved':True,'all_20_manifests_verified':True,'limits':['Post-audit targeted supplement; old 42-scenario report unchanged.','Real Pandoc GFM HTML parser output checked for anchors and decoded Unicode controls, not a visual browser screenshot or all-renderer guarantee.','Visible escape syntax accepts equivalent codepoint spelling including \\u{HEX}; requirement is visible text and absent decoded control.','No models, full regression, product source changes or new forge reads.','Injected offline CLI runner evidence distinct from root one historical live invocation.'],'live_receipt':'live-observation-receipt.json'}
(r/'report.json').write_text(json.dumps(summary,indent=2)+'\n');(r/'report.md').write_text('''# Markdown repair independent supplement

Old `540cd7a5` failed 7 of 10 targeted rendered-output cases. Repair `2348c825` passed all 10; 20 actual CLI seam reports were generated and every emitted manifest member verified. The underlying library is unchanged.

Pandoc GFM rendering confirmed that raw web/email/https strings become links and an entity-encoded bidi character becomes the control character again. Repair output retained only the four intended internal links, displayed control/format characters as visible codepoint escapes, and preserved normal Unicode and literal entity-looking text. JSON branch values remain exact. This is concrete rendered-HTML evidence, not a screenshot or universal renderer claim. Original 42-scenario grading is unchanged.

Separately, the retained root live snapshot manifest and eight fixed GraphQL receipts were verified. Guard precedes calls; 308 was stably MERGED and 309 the OPEN frontier, still blocked with draft/checks-pending/review-required and unknowns. This historical observation grants no Ready/merge authority and was not rerun.
''')
entries=[]
for p in sorted(r.rglob('*')):
 if p==r/'manifest.json':continue
 s=p.lstat();e={'path':str(p.relative_to(r)),'mode':stat.S_IMODE(s.st_mode)}
 if stat.S_ISLNK(s.st_mode):e.update(type='symlink',target=os.readlink(p))
 elif stat.S_ISREG(s.st_mode):e.update(type='file',bytes=s.st_size,sha256=h(p.read_bytes()))
 elif stat.S_ISDIR(s.st_mode):e.update(type='directory')
 entries.append(e)
(r/'manifest.json').write_text(json.dumps({'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':entries},indent=2)+'\n');print(json.dumps({'report_sha256':h((r/'report.json').read_bytes()),'manifest_sha256':h((r/'manifest.json').read_bytes()),'members':len(entries),'live_members':lr['members']},indent=2))
