import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {fixture,plan,makeRunner} from '../independent/offline-fixtures.mjs';
const root='/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr-stack-frontier-20261030/markdown-repair-independent';
const cases=JSON.parse(await readFile(root+'/criteria.json','utf8')).cases;
process.env.OSSTACK_SCRATCH_ROOT=root+'/owned';await mkdir(process.env.OSSTACK_SCRATCH_ROOT);
const logs=[];
for(const [version,path] of [['old',root+'/old-layout/scripts/report-pr-stack-candidate.mjs'],['new','/Users/osborn/Developer/CodeX/.worktrees/osstack/pr-stack-frontier-author/scripts/report-pr-stack-candidate.mjs']]){
 const cli=await import(pathToFileURL(path));await mkdir(root+'/'+version);
 for(const c of cases){
 const p=plan([72,3]);p.target_base=c.value;const f=[fixture(72,0),fixture(3,1)];
 f[0].initial.baseRefName=f[0].final.baseRefName=c.value;f[0].initial.headRefName=f[0].final.headRefName=c.value;f[1].initial.baseRefName=f[1].final.baseRefName=c.value;
 const input=root+'/'+version+'/'+c.id+'.json';await writeFile(input,JSON.stringify(p));const r=makeRunner(f);
 const got=await cli.runPrStackCandidateReport(['--plan',input,'--output',root+'/owned/'+version+'-'+c.id],{runner:r.runner,clock:()=>0});
 logs.push({version,id:c.id,result:got,calls:r.calls});if(got.exitCode!==0)throw Error(version+c.id+JSON.stringify(got));
 }
}
await writeFile(root+'/execution.json',JSON.stringify(logs,null,2)+'\n');
