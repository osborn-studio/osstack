# PR stack observation

Repository: fixture&#47;project. Declared order: 72 → 3.
Observed: 1970-01-01T00:00:00.000Z to 1970-01-01T00:00:00.000Z.
Result: frontier_observed. Frontier: 72.
This is not Ready or merge authorization. Observations are sequential, not atomic.
Target base: a&#64;b&#46;example. Branch names are not ancestry proof.

## PR 72 (frontier)
Observation: observed; candidate summary: no_observed_blocker; issue: none.
Relation: target_matches; expected base: a&#64;b&#46;example; observed base: a&#64;b&#46;example.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/72/snapshot.json); [query receipts](prs/72/queries.json).

## PR 3 (upstack)
Observation: observed; candidate summary: no_observed_blocker; issue: none.
Relation: parent_matches; expected base: a&#64;b&#46;example; observed base: a&#64;b&#46;example.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/3/snapshot.json); [query receipts](prs/3/queries.json).

## Limits
- Caller-declared order&#59; branch-name equality is not ancestry or dependency proof&#46;
- Sequential non-atomic observations&#59; facts can change after each read&#46; No automatic re-read&#46;
- A frontier is not Ready or merge authorization&#46; Original per-PR policy and unknowns remain in snapshots&#46;
- No watcher&#44; retry&#44; retarget&#44; approval&#44; merge&#44; candidate execution or database refresh&#46;
- Collection budgets use wall time&#46; The runner must honor timeoutMs&#59; injected runners are not forcibly cancelled&#46;
