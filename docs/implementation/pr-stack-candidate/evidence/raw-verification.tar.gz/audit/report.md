# Verdict: PASS (static review only, no blockers)

I traced the library and CLI code against the stated contract and walked every test scenario by hand. I found no defect that breaks the contract, so I would not block on anything below. One low-severity defect (item 1) violates a property the code itself claims, and I recommend fixing it in this PR because the fix is small. If you treat "forge strings cannot add links" as a requirement rather than hardening, that item flips the verdict to REVISE.

Nothing was executed. I did not verify the build output, CI step ordering, `scratch.mjs` behavior, or that `pr-candidate-snapshot.ts` is unchanged. No diff for that file was provided; the shown source is merely consistent with the docs.

## Confirmed blockers

None. These contract points hold:

- **Prefix promotion.** `stableState` requires a stable binding, non-null initial and final, equal states, and no `issue`. The `while` loop in `inspectPrStackCandidate` stops at the first non-stable-MERGED row, so a later stable MERGED row stays `upstack`.
- **Request and time budget.**
  - `boundedRunner` increments `requests` only after the cap and deadline checks, and clamps `timeoutMs` to the remaining time. A zero timeout, which `execFile` would treat as "no timeout", cannot occur because `remaining <= 0` is refused first.
  - `queryIndex` stays aligned with the collector's receipts. Refused attempts consume an index in both places, and collector-side refusals consume neither.
- **Late results.** A PR that finishes after the deadline gets `issue: stack_budget_exhausted`, which makes `stableState` return null. Later PRs are marked `not_observed` without any runner call.
- **Axes stay separate.** `relation` is a separate field, and blockers, waiting and unknowns are passed through untouched.
- **CLI preflight.**
  - `readPlan` uses `O_NOFOLLOW | O_NONBLOCK`, then `isFile`, a size check, and a bounded positional read.
  - `mkdir` without `recursive` gives exclusive creation and also rejects a terminal symlink. Containment is checked against the realpath'd parent.
  - Raw labels are whitelisted, so there is no path traversal. `row.pr` is a validated positive integer.
  - Exit 2 never follows a forge call, and the `mkdir` is the last preflight step.
- **Tests.** Every library scenario and CLI scenario I traced matches the code, including the 24-file manifest count and the call counts.

## Confirmed defect, low severity, recommended fix

**1. `escape()` in `scripts/report-pr-stack-candidate.mjs` does not prevent links or display spoofing from forge branch names.**

- **Mechanism.** The comment says the function must not let forge strings add structure or links. The escape set omits `.`, `/`, `:`, `@` and `~`, and escapes only C0 controls and DEL.
  - Branch names such as `www.example.test/login` or `a@b.example` are legal refs. GFM extended autolinks turn them into clickable links.
  - Unicode bidi or format characters (U+202E, U+2066–2069) and C1 controls pass through, which allows display reordering.
- **Reach.** `expected_base` and `observed_base` print forge-controlled names. A fork PR's `headRefName` becomes the upper PR's `expected_base` whenever both rows are stable OPEN.
- **Reproduction.** Extend the CLI fixture so that `headRefName` for PR 20 is `www.example.test/login`. Make both PRs OPEN, with PR 7's base set to that name. Then assert `report.md` contains no bare `www.` or `@` token and no U+202E. Today the name appears verbatim.
- **Fix.** Entity-encode every code point outside `[A-Za-z0-9 -]`, plus all `\p{Cc}` and `\p{Cf}` characters.

## Optional suggestions

**Tests**

- The "result arriving beyond the stack deadline" test does not discriminate. Lower PR 20 is unknown, so `frontier=20` and the upper row would be `unconfirmed` even without the late-result rule. Use a stable-MERGED lower PR with the late result on the frontier, and assert `frontier_unknown` instead of `frontier_observed`.
- Add three-PR cases:
  - `[MERGED, unknown, MERGED]` should keep the frontier at index 1.
  - `[MERGED, MERGED, OPEN]` should leave the frontier at index 2.
- Add a case with a stable-MERGED upper PR above an OPEN frontier, and a markdown case for the autolink and bidi inputs from item 1.
- Add a CLI test where a write fails midway: no manifest, exit 3.
- `collector_failed` looks effectively unreachable with real runners, because `read` absorbs runner throws as `runner_failed`.

**Semantics**

- A stable-MERGED upper PR above an OPEN frontier is reported only as `upstack` with summary `merged`, with nothing flagging the anomaly.
- A MERGED prefix row is never compared to `target_base`; `observed_base` is printed but not judged.
- Both are consistent with "name equality is not ancestry", but an explicit diagnostic would be cheap.

**Docs**

- State that nothing is written until collection finishes, which can take up to 270s. An interrupt during that window leaves an empty output directory and loses the evidence.
- Note that raw bodies may contain private repository metadata. The single-PR doc says so; this README does not.
- `repo` must match the forge's canonical case, because `nameWithOwner` is compared exactly. This behavior predates the PR.
- `pr-readiness.md` says `ABSOLUTE_PLAN_JSON`, but the CLI also accepts a relative plan path.
- `report.md` source reads `check&#95;failure` when viewed as plain text. It renders correctly, but is awkward in a terminal.

**Resources**

- All raw output is held in memory until the end. The worst case is 24 calls × (16 MiB stdout + 16 MiB stderr), roughly 768 MiB or more, before any file is written. That is the single-PR bound tripled. An OOM would lose everything, so consider documenting the bound.

**Items to confirm outside this review**

- `packages/github/dist/pr-stack-candidate.js` must be emitted per file, and the CI job must build `@osstack/github` before the new step.
- The pinned pstack adaptation in the README should also appear in the method's `sources.md`, which I was not given.
- The new `index.ts` named exports should not shadow anything exported from `stack.js` via `export *`.