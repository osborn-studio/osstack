# Markdown display repair

Base `ad38b017876a84b6333c67a47acc98ebb8b5b848`; repaired candidate `2348c82522030c63e4d0c1125dd0c361cda3fca4`. This is the low-severity issue confirmed in root's actual Sonnet static PASS report; the original report is retained by root without verdict rewriting.

Before editing, the CLI, tests and README were copied with exact hashes. Thirteen new cases cover bare web/email/protocol links, Markdown text, U+202E, U+2066–2069, C1 controls U+0085/U+009B and format characters U+200B/U+FEFF. The unchanged new test bytes yielded 17 pass/12 fail on old production, then 29 pass/0 fail after the two-line semantic change. One new formatting case already passed on old code; no claim of 13 old failures is made.

The renderer now emits visible Unicode escapes for Cc/Cf, and numeric entities for other characters outside ASCII letters/digits/space/hyphen. JSON and raw metadata remain unchanged. Author tests inspect Markdown source and entity-decoded display text; actual GFM rendering is a separate independent verification, not claimed here. README also explains private raw metadata and in-memory collection before first evidence write.

The library and its tests were unchanged. No model, full suite, live forge, database or PR operation occurred. Original author manifest and all 91 members were reverified unchanged. Root owns integration/review/publication; this repair directory is a separate evidence supplement.
