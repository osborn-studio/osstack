// Independent wire fixtures prepared before candidate inspection; no live process calls.
export const repo = 'fixture/project';
export const oid = n => n.toString(16).padStart(40, '0');
export const plan = (prs = [72, 3, 41]) => ({schema_version:1, repo, target_base:'main', prs:prs.map(pr=>({pr,requiredChecks:['test']}))});
export function facts(pr, position = 0) {
  return {number:pr,url:`https://example.invalid/fixture/project/pull/${pr}`,state:'OPEN',isDraft:false,headRefOid:oid(pr),baseRefOid:oid(900+position),headRefName:`branch-${pr}`,baseRefName:position===0?'main':position===1?'branch-72':'branch-3',mergeable:'MERGEABLE',mergeStateStatus:'CLEAN',reviewDecision:'APPROVED'};
}
export function fixture(pr, position=0) {
  return {initial:facts(pr,position),final:facts(pr,position),checks:[{__typename:'CheckRun',id:`check-${pr}`,name:'test',status:'COMPLETED',conclusion:'SUCCESS',detailsUrl:null}],threads:[]};
}
export function makeRunner(fixtures, options={}) {
  const calls=[], factsCounts=new Map();
  const runner={run:async(command,args,settings)=>{
    if(command!=='gh'||args[0]!=='api'||args[1]!=='graphql')throw Error('unexpected command');
    const variables={};for(let i=2;i<args.length;i+=2){if(!['-f','-F'].includes(args[i]))throw Error('unexpected flag');const k=args[i+1].indexOf('=');variables[args[i+1].slice(0,k)]=args[i+1].slice(k+1);}
    const query=variables.query;const kind=query.startsWith('query CandidateFacts')?'facts':query.startsWith('query CandidateChecks')?'checks':query.startsWith('query CandidateThreads')?'threads':null;
    if(!kind||variables.owner!=='fixture'||variables.name!=='project')throw Error('unexpected fixed query');
    const pr=kind==='checks'?fixtures.find(x=>x.initial.headRefOid===variables.oid)?.initial.number:Number(variables.number);
    const f=fixtures.find(x=>x.initial.number===pr);if(!f)throw Error('fixture identity missing');
    calls.push({command,args:[...args],settings:{...settings},kind,pr});
    if(options.beforeCall)options.beforeCall(calls.length,kind,pr);
    if(options.throwAt===calls.length)throw Error('injected transport unavailable');
    let repository={nameWithOwner:repo};
    if(kind==='facts'){
      const count=factsCounts.get(pr)??0;factsCounts.set(pr,count+1);repository.pullRequest=structuredClone(count===0?f.initial:f.final);
    }else{
      const page=variables.after?Number(variables.after.split('-').at(-1)):0;
      const input=kind==='checks'?f.checks:f.threads;
      const pages=kind==='checks'?f.checkPages:f.threadPages;
      const nodes=pages?pages[page]:input; if(!nodes)throw Error('unexpected page');
      const hasNextPage=!!pages&&page<pages.length-1;
      const connection={nodes:structuredClone(nodes),pageInfo:{hasNextPage,endCursor:hasNextPage?`${kind}-${page+1}`:null}};
      if(kind==='checks')repository.object={oid:f.initial.headRefOid,statusCheckRollup:{contexts:connection}};
      else repository.pullRequest={number:pr,reviewThreads:connection};
    }
    const payload=options.graphqlErrorAt===calls.length?{data:{repository},errors:[{message:'injected partial error'}]}:{data:{repository}};
    return {stdout:JSON.stringify(payload),stderr:'',exitCode:0};
  }};
  return {runner,calls};
}
