# Independent stack-frontier acceptance

Candidate `ad38b017876a84b6333c67a47acc98ebb8b5b848`: 58/58 bounded offline assertion groups passed; all 42 frozen scenario IDs covered. One extra late-result subcase is explicitly post-freeze. No confirmed defect found.

The public compiled API preserves supplied order, advances only over stable MERGED prefixes, keeps unknown/closed lower rows, retains constituent uncertainty, and grants no merge authority. Invalid plans make zero queries. Injected budget probes checked 24 requests, 100 ms remaining timeout, exhausted later rows and a late final result. A second-page GraphQL error retained the first 100 checks.

The public CLI injected-runner seam wrote real complete (34 members) and partial (26 members) reports. Every emitted member hash/size/mode, complete inventory, original plan bytes, partial exit 3, preflight exit 2 and no-overwrite/symlink escape were checked. A separate actual Node process ran `--help`; no live `gh` was called. Source and dist binding is in `validation/binding.json`; the existing collector source is byte-identical to baseline. The new compiled module matches independent TS emission except the source-map comment.

Limits: offline engineering verification only, no model/full/DB/forge calls or formal gate. Budget probes do not prove OS/process-tree cancellation. Relations are names, not ancestry or atomicity. Successful file output uses an injected runner; write-failure injection and exhaustive collector pagination/cursor behavior were not rerun. Negative responses remain in the raw records. Root integration wiring/CI and any actual forge use require their own binding.

Root integration `540cd7a50fd044aa3c5b39f2f0ea62bfcec6ebe9`: all five authored files equal the author Git objects and live root bytes. Compiled stack module is byte-identical. An actual Node import of the public compiled index exposed both API functions and validated a legal one-PR input. No repeated vectors, alias execution or CI claim. See `integration.json`.
