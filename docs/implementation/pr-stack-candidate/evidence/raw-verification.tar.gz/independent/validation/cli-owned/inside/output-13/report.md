# PR stack observation

Repository: fixture/project. Declared order: 72 → 3 → 41.
Observed: 1970-01-01T00:00:00.000Z to 1970-01-01T00:00:00.000Z.
Result: frontier_unknown. Frontier: 72.
This is not Ready or merge authorization. Observations are sequential, not atomic.
Target base: main. Branch names are not ancestry proof.

## PR 72 (frontier)
Observation: observed; candidate summary: unknown; issue: none.
Relation: unconfirmed; expected base: unknown; observed base: unknown.
Blockers: none observed.
Waiting: none observed.
Unknowns: initial&#95;identity&#95;unavailable, checks&#95;incomplete, threads&#95;incomplete, required&#95;checks&#95;missing, candidate&#95;state&#95;unconfirmed.
[Snapshot and original policy limits](prs/72/snapshot.json); [query receipts](prs/72/queries.json).

## PR 3 (upstack)
Observation: observed; candidate summary: no_observed_blocker; issue: none.
Relation: unconfirmed; expected base: unknown; observed base: branch-72.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/3/snapshot.json); [query receipts](prs/3/queries.json).

## PR 41 (upstack)
Observation: observed; candidate summary: no_observed_blocker; issue: none.
Relation: parent_matches; expected base: branch-3; observed base: branch-3.
Blockers: none observed.
Waiting: none observed.
Unknowns: none reported.
[Snapshot and original policy limits](prs/41/snapshot.json); [query receipts](prs/41/queries.json).

## Limits
- Caller-declared order; branch-name equality is not ancestry or dependency proof.
- Sequential non-atomic observations; facts can change after each read. No automatic re-read.
- A frontier is not Ready or merge authorization. Original per-PR policy and unknowns remain in snapshots.
- No watcher, retry, retarget, approval, merge, candidate execution or database refresh.
- Collection budgets use wall time. The runner must honor timeoutMs; injected runners are not forcibly cancelled.
