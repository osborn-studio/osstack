# PR stack frontier independent freeze

**SF01** Closed plan schema_version=1, repo, target_base, prs only; each item closed pr/expectedHead/expectedBase/requiredChecks. 1–3 unique valid PRs in supplied order. Validate whole plan before any runner call; invalid CLI also creates no report directory.

**SF02** Reuse existing candidate validation for repository, positive bounded PR number, paired SHA40 and required check names. target_base is a bounded nonempty exact branch-name string without ASCII controls; never interpolated into a shell. Do not sort/normalize PR order.

**SF03** Observe all planned rows once in order with immutable per-PR observation/raw retention; no query retry, watch, DB, card update, approval, Ready, merge or retarget. A lower bad row must remain visible even if later rows are clear.

**SF04** Frontier can advance only across a prefix whose observed binding is stable and initial AND final state are MERGED. This deliberate conservative new-feature policy treats OPEN→MERGED during collection as frontier_unknown, without extra collection/retry. Stop advance at changed/unknown/closed-unmerged lower row.

**SF05** First unmerged stable OPEN row is frontier; its blocked/waiting/unknown/no_observed_blocker candidate summary remains separate. closed-unmerged stops as closed_unmerged; all stably merged yields observed_all_merged. Every result retains merge_authorized:false.

**SF06** First unmerged OPEN baseRefName must match explicit target_base; later OPEN child baseRefName must match preceding OPEN parent headRefName. Mismatch/missing/unstable evidence blocks relation confirmation and must not be called ready or silently repaired. Merged-prefix remainder pointing at merged branch is not already-retargeted evidence. Branch names establish only observed relation, never commit ancestry or whole-stack atomicity.

**SF07** Preserve complete constituent checks/reviews/blockers/waiting/unknowns and caller-required-check basis. Missing/ambiguous check, neutral/skipped, incomplete page, GraphQL partial error, initial/final error, wrong pins never become success by aggregation. Original collector policy remains unchanged.

**SF08** At most24 actual runner requests, 270000ms total collection, per-request timeout no larger than min(existing timeout, remaining). Budget exhaustion retains completed/partial observations and explicit not-observed entries; no extra request after budget. No guarantee that a malicious injected runner obeys cancellation.

**SF09** CLI accepts only --plan/--output or --help; plan parse/schema/output checks before network. Help performs no query. Exclusive new output strictly inside existing scratch with owned parent; reject outside/root/existing/symlink escapes. Preserve original plan bytes/hash.

**SF10** Output retains report JSON/Markdown plus each constituent snapshot/query/raw and manifest hash/size bindings with generated filenames, not forge-controlled paths. Markdown must not omit unknown/bad lower rows. Raw denotes retained UTF8-decoded strings re-encoded by existing runner, not wire-byte authenticity. Injected runner explicitly marked.

**SF11** Exit0 means report written, even blocked/unknown constituent summary; exit2 input/output refusal with zeroqueries. Exit3 any identity unavailable/not-observed or write failure, retaining available evidence. CLI success is never merge authorization. Output failure must not delete prior evidence or overwrite existing output.

**SF12** Source/base and offline vectors bound independently; frozen expectations precede candidate inspection. No model calls/live forge/DB needed for independent acceptance. Sequential observation limitation and omitted policy/approval qualification are explicit; history comparison and DB refresh excluded.

No new candidate inspected. Interface wire assumptions may be adapted with a retained harness revision; semantic expectations will not be changed after outputs to turn failure green.
