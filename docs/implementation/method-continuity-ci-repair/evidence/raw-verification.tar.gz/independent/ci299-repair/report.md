# Independent CI299 repair review

No confirmed coverage loss in 7495b723 versus 88dad065. Only upgrade-native.test.ts changes. Both real fixture/upgrade preparations move to scoped beforeEach(60000); cleanup assertions, actual recovery calls and AbortSignal.timeout(30000) remain exact. Original fixture and global afterEach bytes are unchanged. Setup now closes its port in finally on ordinary thrown/rejected paths.

Total nominal setup-plus-target allowance rises from 30 seconds to 60+30 seconds per case, excluding separately governed teardown. This is budget separation and expansion, not a performance improvement or proof of the CI timeout cause. Hook timeout is not guaranteed cancellation of an underlying promise or process tree. Nested describe prefixes also change fully qualified test titles. No actual tests were executed by this independent reviewer; root supplies execution evidence.
