# PR299 attempt 1 — bounded diagnosis and test-only repair

## Observed failure

Run 40782209081 attempt 1 failed on PR head `38f13cff5c4e161835eaa5c75c3976b5a8e95046`; the check job actually checked out merge `fa12305f03dc8bfc0e0ab47215e5178d6e1cdb1b` onto base `a9e480d39b9fcff206f356cee75a72cc9cc4d9e4`. Original root-provided log is named `ci299/failed.log` (the assignment's rawfailed.log name did not exist). A new read-only download preserves full attempt logs and run/jobs metadata here. No CI rerun or model/test invocation was performed by this worker.

The two failures are Vitest outer `Test timed out in 30000ms` at original declarations lines 155 and 193. Their displayed durations are 30,444 ms and 30,231 ms. There is no per-phase trace, assertion mismatch, child stderr or specific cleanup failure attached to either timeout. The declared line identifies the test, not the operation that stalled. CLI suite: 2 failed, 2,762 passed, 6 skipped; the upgrade file: 23 passed and 2 failed, 333,976 ms total. These are raw per-package/file totals, not repository totals.

The check environment is Ubuntu 24.04.5, runner image `ubuntu-24.04` version `20261025.353.1`, Node `v22.23.4`; CLI config uses forks and `maxWorkers:2`. Another long suite is visibly active concurrently. There is no CPU, memory, I/O, per-hash or per-upgrade-phase telemetry; **pure load is not established**.

## Source and historical comparison

`source-comparison.json` checks exact blobs and SHA256 for 12 files: upgrade test/port/files/backend/coordinator/journal, CLI Vitest config, scratch/hermetic setup, root package, lockfile and CI workflow. All are identical at PR299 head, its actual main base, and prior passing PR298 head `8ba3d98ad27f8febb172bc2392d72fe201ea3e96`. The upgrade test blob is `1ffdf9608797dcb6ec6de400086013e3c294f962`; local full-test candidate `848e4a2e57af0413ffb3e7fa5d7f5661dd2c3a69` has this same blob. PR299 changes methods/export tests/docs, not these runtime files.

Prior passing run 40730300608 attempt 2, check job 122983833700, used the same Ubuntu image version and Node22.23.4. Both affected cases passed at 25,189 and 25,064 ms; full upgrade positive control at 24,229 ms. In failing run the positive control passed at 30,089 ms under its 60-second budget. Three existing setup-split completed-history variants passed with reported total durations 31,296 / 31,146 / 30,050 ms, since setup and target behavior have separate budgets. This is evidence of sensitivity to available whole-test headroom, not proof of the precise slowdown mechanism.

The prior local full run (root-owned, not rerun here) completed exit0; affected cases took 504 and 508 ms. Its exact command/head/build-dirty binding and source-log hash are copied in local-package-full.json, with a limited log excerpt. Different local OS/hardware means these durations cannot establish Linux performance correctness.

## Confirmed test policy issue versus unknown runtime cause

Both failing tests originally put `fixture()` (two real homes/processes), full `coordinateUpgrade` (stop, lock, snapshot, durable publication, switch, restart and verification), journal retrieval and the actual completed-history cleanup action into one 30-second test callback. The fixture plan itself permits 100 seconds total and 20 seconds per step. Target recovery separately creates `AbortSignal.timeout(30000)` only after the full upgrade, so its 30-second clock begins after much of the outer test budget may already be spent.

Same-file commit `4dddf67ab6e293161aab8f59b57392d1c693a298` already separates the prerequisite for three nearby completed-history cases into a 60-second beforeEach with a 30-second behavior body. These two remaining cases were not covered. That inconsistent allocation is a concrete test resource-policy defect; it does not establish that the production cleanup operation is slow, faulty or safe under every timing.

The completed-history branch in upgrade-native-port.ts lines174–188 checks history and target identity, cleans claims and the fence, returns `services_observed:false`, and does not restart consumers. The two tests must continue checking history equality/start counts/permit or operation absence. An unbounded wait elsewhere or late operation after Vitest timeout is not ruled out: the fixture's custom stop awaits process exit, and outer Vitest timeout alone is not cancellation of every underlying asynchronous operation. This repair is not a new cancellation system.

## Authorized narrow repair delivered, not yet executed

Root subsequently authorized editing only `packages/cli/src/upgrade-native.test.ts` in `method-pr-readiness-control`. Original source, candidate and exact diff are preserved here. The two cases now each have their own scoped `describe`, a 60-second `beforeEach` for the real full upgrade plus required status/fault arrangement, and the unchanged target `it` budget30s/AbortSignal30s. Setup port closure now uses try/finally. Global existing afterEach still owns children and scratch cleanup. No production code, concurrency, assertion, skip, target abort or test count changed. Total allowed setup-plus-body time explicitly grows from30 to90 seconds for these cases; this is test orchestration allocation, not a performance improvement.

Static support: 85 expect calls before/after, 12 AbortSignal.timeout(30000) occurrences before/after, all18 30-second test endings retained; two setup60s endings added. Counts are not execution proof. Root owns compilation, affected test execution, real CI and audit. Worker did not commit.

## Optional bounded diagnostic artifact for root

`upgrade-native.instrumented.ts` is a scratch-only copy of the candidate, with four JSON `UPGRADE_PHASE` stderr records in finally blocks: setup/body for terminal-fence and foreign-orphan. It uses performance.now and performs exactly the same upgrade/assertions. It has NOT been installed into the repository or executed. Root may temporarily use it for one targeted run, then restore the exact candidate bytes before final verification/commit. It must not replace candidate source while any other test run is using that tree. Diagnostics can measure new local setup/body cost; they cannot retrospectively locate the old CI timeout. A timeout might log only when the underlying async work eventually settles, another reason not to infer complete cancellation from the log.

Suggested targeted root command after build is ready: `pnpm --filter @osstack/cli exec vitest run src/upgrade-native.test.ts -t 'keeps terminal history intact|removes a foreign orphan permit'`, with the project's explicit scratch/home discipline. Then run the full upgrade file under root's queue. No command was started by this worker. If an actual behavior timeout or invariant failure persists after setup separation, preserve the stage/child logs and diagnose it; do not loop retries or silently increase behavior deadlines.
