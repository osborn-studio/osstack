The stack importer reported completed CheckRuns with ACTION_REQUIRED, STALE or STARTUP_FAILURE as successful, and could also turn unfinished or unknown checks green. Recognize those failure conclusions and require COMPLETED with an explicit SUCCESS, NEUTRAL or SKIPPED conclusion for success. Other incomplete or unknown outcomes remain conservative pending. Existing failure precedence and legacy StatusContext normalization are preserved.

This changes existing stack ingestion metadata and drift classification. Existing cards are still skipped on re-ingestion; ready columns and CI checklists are separate. The bounded PR snapshot has its own policy. No watcher, automatic approval/merge, method or host experiment is added.

Validation:
- Same 56 author tests: old 17 failures/39 passes, new 56 passes; GitHub package 195 passes.
- Independently frozen 57 vectors: old 20 failures, new 57 passes; public ingestion/drift/topology exercised with injected read-only responses. No live forge or database writes.
- Actual Claude CLI Sonnet 5.5 static PASS. Original optional suggestions retained; existing frozen vectors cover the non-completed failure-precedence invariant. Wording correction is documentation only.
- Root full regression and publication checks recorded in the evidence entry below; published-head CI is evaluated separately.

Follows #308 in the delivery queue. Keep Draft on its parent branch until user merges #308, then verify actual main, retarget and rerun applicable checks. Never merge into the feature branch. PS18 contribution, PS17/J07 support; no whole capability or formal gate completion.
