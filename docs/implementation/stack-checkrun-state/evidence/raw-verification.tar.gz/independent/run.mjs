import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
const b='/Volumes/AIMATE_WORK/tmp/osstack/runtime/checkrun-state-20261030/independent';
const out=b+'/validation';
const repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';
const author='/Users/osborn/Developer/CodeX/.worktrees/osstack/checkrun-state-author';
const old='b4a2fc30711d9c3ad5cddbc846839948f1810c56', fixed=process.argv[2]; if(!/^[a-f0-9]{40}$/.test(fixed??''))throw Error('fixed commit required');
const git=(ref,path)=>execFileSync('git',['show',ref+':'+path],{cwd:repo});
const sha=b=>createHash('sha256').update(b).digest('hex');
const require=createRequire(author+'/package.json'), packageRequire=createRequire(author+'/packages/github/package.json');
const ts=require('typescript');
const dependencies=['types','branch-scanner'];
for(const name of dependencies)assert(git(old,`packages/github/src/${name}.ts`).equals(git(fixed,`packages/github/src/${name}.ts`)));
const source=git(old,'packages/github/src/stack.ts');
let emitted=ts.transpileModule(source.toString(),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
for(const name of dependencies)emitted=emitted.replace(`"./${name}.js"`,JSON.stringify(pathToFileURL(`${author}/packages/github/dist/${name}.js`).href));
emitted=emitted.replace('"zod"',JSON.stringify(pathToFileURL(packageRequire.resolve('zod')).href));
await writeFile(out+'/baseline-source.ts',source,{flag:'wx'});await writeFile(out+'/baseline-module.mjs',emitted,{flag:'wx'});
const src=await readFile(author+'/packages/github/src/stack.ts');assert(src.equals(git(fixed,'packages/github/src/stack.ts')));
const candidateBytes=await readFile(author+'/packages/github/dist/stack.js');
const binding={old,fixed,baseline_source_sha256:sha(source),baseline_emitted_sha256:sha(emitted),candidate_source_sha256:sha(src),candidate_compiled_sha256:sha(candidateBytes),typescript_version:ts.version,typescript_compiler_sha256:sha(await readFile(require.resolve('typescript'))),dependency_bindings:await Promise.all(dependencies.map(async name=>({name,source_equal:true,dist_sha256:sha(await readFile(`${author}/packages/github/dist/${name}.js`))}))),note:'Old Git TS independently transpiled in scratch; only import paths rebased to installed zod and same unchanged dependency bytes. New candidate uses observed author built dist; no independent full build attestation. No network/DB. All runner responses synthetic.'};
await writeFile(out+'/binding.json',JSON.stringify(binding,null,2)+'\n',{flag:'wx'});
const baseline=await import(pathToFileURL(out+'/baseline-module.mjs')),candidate=await import(pathToFileURL(author+'/packages/github/dist/stack.js'));
const vectors=JSON.parse(await readFile(b+'/vectors.json','utf8'));
const results=[];
for(const [label,mod]of[['old',baseline],['candidate',candidate]]){
 const rows=[];
 for(const vector of [...vectors,{id:'rollup-undefined',input:undefined,expected:'unknown'}]){
  let actual,error;try{actual=mod.mapRollupToCheckState(vector.input);}catch(e){error={name:e.name,message:e.message};}
  const ok=vector.expected==='throws'?!!error:!error&&(Array.isArray(vector.expected)?vector.expected.includes(actual):actual===vector.expected);
  rows.push({...vector,actual,error,passed:ok});
 }
 const ingress=[]; const calls=[];
 const fixture=(number,rollup)=>({number,state:'OPEN',baseRefName:number===11?'main':number===12?'a':'b',headRefName:number===11?'a':number===12?'b':'c',mergeable:'MERGEABLE',mergeStateStatus:'CLEAN',statusCheckRollup:rollup,title:'untrusted $(echo no-execution)',url:`https://example.invalid/${number}`});
 const data={11:fixture(11,[{__typename:'CheckRun',conclusion:'NEUTRAL',status:'COMPLETED'},{__typename:'StatusContext',state:'SUCCESS'}]),12:fixture(12,[{__typename:'CheckRun',conclusion:'ACTION_REQUIRED',status:'COMPLETED'}]),13:fixture(13,[{__typename:'CheckRun',conclusion:'SUCCESS',status:'REQUESTED'}])};
 const runner={run:async(command,args)=>{calls.push({command,args:[...args]});assert.equal(command,'gh');assert.deepEqual(args,['pr','view',args[2],'--json','number,state,baseRefName,headRefName,mergeable,mergeStateStatus,statusCheckRollup,title,url','--repo','fixture/project']);return JSON.stringify(data[Number(args[2])]);}};
 let stack,drift,error;
 try{stack=await mod.ingestStack({prNumbers:[13,11,12],repo:'fixture/project'},runner);drift=mod.detectDrift(stack);}catch(e){error={name:e.name,message:e.message};}
 const checks={no_error:!error,topology:JSON.stringify(stack?.order)===JSON.stringify([11,12,13])&&JSON.stringify([...stack.edges].sort((a,b)=>a.parent-b.parent))===JSON.stringify([{parent:11,child:12},{parent:12,child:13}]),states:JSON.stringify(stack?.nodes.map(n=>n.ciState))===JSON.stringify(['pending','success','failure']),drift:JSON.stringify(drift?.issues.map(x=>[x.number,x.kind]))===JSON.stringify([[13,'ci_pending'],[12,'ci_failing']]),only_three_read_queries:calls.length===3};
 ingress.push({case:'mixed-three-pr-ingress',synthetic_inputs:data,calls,stack,drift,error,checks,passed:Object.values(checks).every(Boolean)});
 const record={label,rows,ingress,passed:rows.filter(x=>x.passed).length,total:rows.length,failed:rows.filter(x=>!x.passed).map(x=>x.id)};
 await writeFile(out+'/'+label+'-results.json',JSON.stringify(record,null,2)+'\n',{flag:'wx'});results.push({label,passed:record.passed,total:record.total,failed:record.failed,ingress_passed:ingress[0].passed});
}
const summary={results,scope:'57 frozen classification vectors plus separately declared undefined control and public ingestStack/detectDrift/topology scenario. No actual gh, CLI, DB, model or full test.'};await writeFile(out+'/summary.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(summary,null,2));if(results[1].failed.length||!results[1].ingress_passed)process.exitCode=1;
