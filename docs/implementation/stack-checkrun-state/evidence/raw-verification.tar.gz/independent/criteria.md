# CheckRun independent freeze

**CR01** Known non-success conclusions ACTION_REQUIRED/STALE/STARTUP_FAILURE classify failure; preserve prior failing conclusions.

**CR02** COMPLETED with SUCCESS/NEUTRAL/SKIPPED is success; no change to explicit neutral/skipped policy.

**CR03** WAITING/REQUESTED and existing active statuses remain pending even when accompanied by a premature SUCCESS.

**CR04** Unknown/empty/missing conclusion or status must not manufacture success: conservatively pending. Malformed types retain existing parse rejection.

**CR05** Failure dominates pending/success regardless of order, preserving existing failure precedence even on inconsistent nonterminal rows.

**CR06** All existing StatusContext mappings including state-only legacy objects and unknown-state conservative pending remain.

**CR07** Empty/absent/non-array rollups remain unknown; no extra forge or merge semantics.

**CR08** Same frozen inputs run against parent and candidate, preserving actual RED results and source/dist bindings.

**CR09** Public ingestStack with injected read-only runner propagates failure/pending/success to detectDrift; topology and query arguments unchanged.

**CR10** Official enum definitions inform recognized states; aggregation and conservative unknown behavior are local policy, not a claim that GitHub specifies this local aggregator.

Official semantics: https://docs.github.com/en/graphql/reference/checks . Local aggregation and conservative unknown policy are separately stated.

Frozen before inspecting candidate implementation; author has reported tests-only RED and production unchanged. No claim that author tests were not written.
