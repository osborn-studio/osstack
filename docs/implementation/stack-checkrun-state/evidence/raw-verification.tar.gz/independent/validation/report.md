# Independent CheckRun verification

Candidate `7b7916ea` passes all 57 frozen classification vectors; parent `b4a2fc30` has 20 failures on the same inputs. Separately, undefined input passes both. Public ingestStack → detectDrift with a synthetic three-PR chain now reports the expected pending/success/failure states; query arguments and topology are unchanged.

The observed built candidate module exactly matches an independent transpilation of its pinned source after excluding only the source-map comment. No confirmed defect in this bounded scope. Original RED output is retained.

Official state enumeration: https://docs.github.com/en/graphql/reference/checks . Aggregation and conservative unknown handling are local policy. No live forge, DB, model, full regression, merge authorization or formal independent-principal claim.

Git proof: merged main de43 equals published PR307 tree; retarget PR308 has expected parents, unchanged old-308 tree, and byte-identical complete base-relative patch. This is not fresh CI execution evidence.
