**Verdict: PASS** (static review only; I ran nothing).

## Confirmed defects
None found.

## What I checked in the code
- **Failure set:** `ACTION_REQUIRED`, `STALE` and `STARTUP_FAILURE` are added to `FAILING_CONCLUSIONS`. Together with the old members, that covers every `CheckConclusionState` value that isn't success, neutral or skipped. `ERROR` is retained.
- **Failure precedence:** `hasFailure` is unchanged and runs before `hasPending`. It looks only at `conclusion`, so an inconsistent row such as `IN_PROGRESS` with `FAILURE` still yields `failure`.
- **Success rule:** `status === "COMPLETED"` plus a conclusion in `{SUCCESS, NEUTRAL, SKIPPED}` is the only path to success. Missing, empty or unknown values of either field give `pending`. `WAITING`, `REQUESTED`, `QUEUED`, `IN_PROGRESS` and `PENDING` are all covered by `!== "COMPLETED"`, so removing `IN_PROGRESS_STATUSES` loses nothing.
- **Type narrowing:** the `check.conclusion == null ||` clause is needed for TypeScript. `Set<string>.has` would not accept `null | undefined`. It is not dead code.
- **StatusContext path:** unchanged. Normalized rows come out as `COMPLETED` with `SUCCESS`/`FAILURE`, or `PENDING` with `null`, so they flow through the new rule correctly.
- **Unchanged areas:** the empty or non-array `unknown` early return, the Zod schemas, `ingestStack`, topology and `detectDrift` are untouched. That matches the stated scope.

## Tests
- The new block pins every scope item: the three new failures, `WAITING`/`REQUESTED` with a premature `SUCCESS`, unknown or empty status and conclusion, the three success conclusions, the missing-field rows, mixed failure dominance, and end-to-end ingest plus drift for six cases.
- `toMatchObject` with `issues: [{…}]` also fixes the issue count at exactly one, so the drift assertions are tight.
- I hand-counted the parent-versus-candidate result against the author's reported numbers. There are 23 new tests and 33 existing, which gives 56 total and matches GREEN.
  - Against the old logic, 17 new tests should fail: 3 failure, 2 waiting/requested, 3 status, 2 conclusion (`FUTURE_CONCLUSION` and `""`), 1 mixed failure, and 6 ingest.
  - The `null`/`undefined` conclusion cases, the missing-field rows and the success cases already passed on the parent, so they are regression guards rather than RED discriminators.
  - This is a derivation from the source, not an observation of a run. The reported 17/39 and 195 remain author-reported.

## Optional suggestions (non-blocking)
1. **Pin the inconsistent-row precedence.** The scope and CR05 call out that a failing conclusion on a non-`COMPLETED` row still wins, but no test asserts it. The code is correct and unchanged here, but a one-line guard would protect it. For example: `[{ status: "IN_PROGRESS", conclusion: "FAILURE" }]` gives `failure`, and `[checkRun("WAITING", "ACTION_REQUIRED")]` gives `failure`.
2. **Changeset wording.** "Missing, unknown and waiting states *remain* pending" isn't quite accurate. `COMPLETED` with an unknown conclusion, and `WAITING` with `SUCCESS`, were previously success. "…are reported as pending" would be more accurate.
3. **Formatting nit.** The new block uses `x => …` and several `expect` calls on one line. This matches the adjacent StatusContext block but not the older `(check) =>` and one-statement-per-line style. It is cosmetic only.

## Residual risks (not verified here)
- **Other fixtures or consumers.** I can't see other callers of `mapRollupToCheckState`, or fixtures elsewhere in the repo shaped like `{ conclusion: "SUCCESS" }` with no `status`. Those would now read as `pending`. The ongoing full root run and the frozen-vector run are the right places to catch this, and neither is complete.
- **Possible stuck-pending state.** A future GitHub conclusion that really means failure will show as `ci_pending` rather than `ci_failing`, possibly indefinitely. That follows the stated conservative policy. It does mean pending is not strictly "in progress".
- **Known gaps, out of scope.** `status: null` is still rejected by Zod (`z.string().optional()`), and `detectDrift` handling of `unknown` is unchanged. Neither is a regression from this slice.