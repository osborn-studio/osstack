# CheckRun state repair

Candidate `7b7916eac56d654891018204b11f3a00daffdc3f`, parent `6d97897325efdeea47d86f3ae169c72907b74d6e` (the current-main retarget of the prior StatusContext repair). Owned paths: stack.ts, its test, one scoped patch changeset. No unrelated production files changed.

The same test bytes produce a real RED on the old source:17 failures/39 passes. After the minimal classifier change,56 tests pass. The GitHub package's195 tests, tsc build and two-file Biome check pass. The new failure cases include valid completed ACTION_REQUIRED/STALE/STARTUP_FAILURE as well as deliberate incomplete/unknown payload controls. Offline inputs are representative forge shapes, not a claim of a live incident for every artificial contradictory row.

Only explicit COMPLETED plus SUCCESS/NEUTRAL/SKIPPED can be successful. Known failures retain priority. Pending, missing and unknown CheckRun states remain conservative pending. The existing StatusContext normalization is byte-identical; non-array/empty rollups retain their old unknown value. No broader detectDrift behavior is changed or qualified.

handoff.json binds the original production SHA, exact RED test bytes, final production SHA and identical GREEN test bytes. All raw logs and the original pstack watch-pr source/license are retained. The implementation is independently expressed; no upstream source body is copied into the patch. Tests preceded the independent implementation freeze; the freeze occurred before production edits, and this archive does not backdate it.

No live gh/DB operation, host model call or repository-wide suite was run by the author. Root owns actual Sonnet review, single full-test queue and publication. The author worktree is clean and held for review.
