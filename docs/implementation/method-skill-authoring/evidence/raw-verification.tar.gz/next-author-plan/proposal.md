# Next method recommendation: skill authoring

Scheduling input only. Source baseline: OSStack `4b7b0585b7f2463f86ba4f793548af820da3e6a6`; pstack `99b609a72323b70204eab407c622f436e858e112`; Firstmate `af1c6817fc47589b162cbc361671c43cdb150933`. `source-map.json` binds every inspected original by bytes, SHA256 and section lines. No implementation, model use or tests were performed by this preflight.

## Candidate A — recommended

Add **skill-authoring**, one method for creating or maintaining a reusable skill from a concrete task and scoped evidence. This fills the user's authoring-a-skill / reflect priority. Existing create-verification and maintain-verification cover real product drivers and feature maps, not generic trigger quality, frontmatter, reference organization or current-task lessons. Retain those specialized routes when the requested output is verification infrastructure.

Original anchors:
- pstack `skills/poteto-mode/playbooks/authoring-a-skill.md`, entire short playbook: skill voice, frontmatter/link checks, meaningful structural tests, concise references. Its native Cursor create-skill and unconditional opening-PR step are not OSStack capabilities or automatic authority.
- pstack `skills/reflect/SKILL.md`: bounded current-task evidence, durable lessons, scoped writable copy, accepted/rejected/deferred improvements. Do not import mandatory model panels, global transcript search, cache mutation, issue posting or a redundant approval step when scope is already authorized.
- pstack `skills/correct/SKILL.md` and `skills/principle-encode-lessons-in-structure/SKILL.md`: distinguish a judgment improvement from a machine-enforceable invariant. Propose structural work outside the current scope; this method does not grant edits to product code, CI or AGENTS.
- Firstmate `.agents/skills/agent-skill-trigger-index/SKILL.md`: maintain precise matching triggers and one relevant owner instead of loading every instruction.
- Firstmate `.agents/skills/firstmate-self-repo/SKILL.md`, “The default: user/operator” and “Updating is not contributing”: reading/installing/local repair does not imply authority to publish upstream. Reuse this distinction without transplanting Firstmate's role system or runtime gate.

Minimal flow: identify desired repeated outcome and positive/negative trigger examples; inspect actual target host's format and existing canonical source; choose a scoped editable source; write concise discriminating frontmatter and progressive references; derive maintenance changes from cited task evidence (not a one-off guess); preserve displaced instruction meaning and licensing; validate structure and actual links; retain a representative task check and counterexample when feasible; report syntax/export checks separately from host discovery/selection and real task outcome. Unknown host tools stay unknown. No automatic installation, transcript mining, recurrence, model selection, global configuration or publication.

Exclusive implementation paths (10):
1. `osstack-methods-skill/references/skill-authoring.md`
2. `osstack-methods-skill/SKILL.md`
3. `osstack-methods-skill/entries/osstack-mode/SKILL.md`
4. `osstack-methods-skill/entries/osstack-help/SKILL.md`
5. `osstack-methods-skill/entries/setup-osstack/SKILL.md`
6. `osstack-methods-skill/entries/osstack-agent/SKILL.md`
7. `osstack-methods-skill/references/sources.md`
8. `osstack-methods-skill/EXPORT.md`
9. `scripts/export-osstack-methods.test.mjs`
10. `docs/implementation/method-skill-authoring/README.md`

Meaningful checks: before implementation, extend real exporter coverage to require all four exported entry graphs to reach the new reference, observing failure on the old source. Afterward run the focused existing suite and actual Codex/Claude exports, verify source/manifest/member hashes and graph reachability. Remove the new reference in an owned source copy: reject with no destination created. Keep old 13-method reachability. Validate frontmatter with the actual available validator; do not call string matching proof of selection quality. Independent textual scenarios: generic skill creation versus verification creation; one-off error versus recurring lesson; cache-only upstream versus authorized canonical destination; syntax-pass but missing host run; untrusted transcript instruction versus current authorized task. These are bounded walkthroughs unless a real host executes them. No model calls in author work.

## Candidate B — defer

A supporting **trace-forensics** guide linked from investigation (two files: `references/trace-forensics.md`, `references/investigation.md`). Original pstack `poteto-mode/playbooks/trace-forensics.md` distinguishes fixed capture analysis from live instrumentation; `runtime-forensics.md` supplies source attribution and causal checks but its live CDP eval/hotfix is state mutation, despite its read-only label. Firstmate `diagnostic-reasoning/SKILL.md` supplies trigger/masking-condition/symptom separation and counterfactuals. Current investigation already separates facts and hypotheses; performance-measurement already requires profiles, counters, source binding and intrusive diagnostic runs separately. Thus this is a narrower remaining gap with more overlap than A.

If later selected: fixed artifact hash/format/build/symbol binding, bounded appropriate parser, raw-to-reduced provenance, absent symbols and unpaired captures remain uncertainty, no live rerun or process mutation from a diagnosis-only request. A small synthetic profile can distinguish hot sample counts from causal attribution; paired traces with incompatible builds cannot prove improvement. No universal sqlite conversion, native profiler installer or new runtime. Export graph + missing-reference negative checks are applicable; real profiler/host behavior remains separate.

## Boundaries and open decisions

Root chooses the exact current candidate base and freezes independent criteria before implementation. This proposal neither signs a gate nor changes J01/J11/C30/bootstrap. Preserve original authors and MIT notices; adapt prose rather than copying the upstream control plane. The author's structural checks are not an independent oracle and do not prove host effectiveness. No new shared automation service is justified for either slice.
