# Verdict: REVISE

This is a static review of the pasted diff only. I did not see the full `sources.md`, the exporter script, the test fixture, `create-verification.md`/`maintain-verification.md`, or the frontmatter of `osstack-help`. Nothing was run, and no host behavior is claimed.

## Blockers

1. **Source attribution has no test guard, and its back-references are unverified.**
   - The PR-readiness addition has a test asserting that `sources.md` contains the pinned URLs (`scripts/export-osstack-methods.test.mjs:~591`). Skill authoring has no equivalent. Dropping any of the five new links (authoring-a-skill, Reflect, Correct, Firstmate trigger index, Firstmate self-repo) would pass.
   - The new `sources.md` paragraph depends on text I could not see. "The encode-lessons principle linked above" and "Both licenses and authors remain as recorded above" are only true if `sources.md` already records an encode-lessons link and Firstmate's author and license at `af1c6817…`. If either is missing, the attribution claim is false.
   - Fix: add a URL-presence test mirroring the PR-readiness one. Confirm both "above" anchors exist, or inline them.

2. **The new routing test does not establish what its title claims.**
   - The regex `/\|[^\n]+\[([^\]\n]+)\]\(([^)\s]+)\)/g` has a greedy `[^\n]+`. It yields at most one match per line, capturing only the last link. It also matches any line containing a pipe, not just table rows. A row linking two methods would be silently miscounted.
   - It asserts only that each target is the last link on exactly one pipe line in the router and in `osstack-mode`. It does not check that the skill-authoring row differs from the verification rows. It also does not check that `skill-authoring.md` points to both verification methods. `osstack-help` and `osstack-agent` are not covered.
   - The final `.trim()` assertion duplicates the existence test.
   - Fix: parse table rows by cell and assert one row per method, with no cross-links. Assert that `skill-authoring.md` links `create-verification.md` and `maintain-verification.md`. Otherwise rename the test to what it checks (link presence), as its "navigation only" comment already concedes.

## Confirm before PASS (not visible in the diff)

- **D2a for `skill-authoring` may be vacuous.** The visible body does `rm(f.sourceRoot, {recursive:true})`. If the fixture does not copy the real source and link to this reference, the case passes for any failure. Check that the assertion names `skill-authoring.md`.
- **No exporter-script change appears in the diff.** The existing tests imply the exporter copies all `references/*.md` into each entry. If the exporter has a hardcoded method or reference list, this candidate fails to export the new file.
- **Remaining "thirteen" wording.** Only three places were updated. `grep -ri thirteen` across the repo, including `docs/`, `parallel-work.md` and the README, to find the rest. No test guards the count.
- **`osstack-help` frontmatter.** It may list methods, since only the body hunk is shown.
- **Pinned upstream paths.** I did not fetch the pinned upstream paths, and nothing here confirms they exist at `99b609a…` and `af1c681…`.

## What holds up

- **Permissions and intent:**
  - Review-only requests produce findings or a diff.
  - Transcripts and model suggestions are treated as evidence, not as a grant.
  - History reads are bounded.
  - No global destination is the default.
  - Cache and export patching, upstream publication, watchers and trackers are all excluded.
- **Capability honesty:**
  - Validator, export, host selection and task outcome are reported separately.
  - `EXPORT.md` correctly leaves the `ca95aba1` host observations unextended.
  - `sources.md` states there is no installer, daemon or runtime gate.
- **Routing prose:** the verification split is stated in four places (`skill-authoring.md` intro, router table, mode table, help paragraph).
- **Stale wording:** the parallel-work "fourteenth method" text was fixed.

## Optional improvements

- The router description pairs "evidence-based maintenance" with "maintaining project verification instructions". Qualify the first as "reusable agent skill (SKILL.md)" to avoid overlap in selection text. Low impact, because the table disambiguates after the router loads.
- `skill-authoring.md` is dense prose with no concrete artifact. Add a small record template (trigger/non-trigger pair, observed failure, supported/deferred change, checks run vs. not run).
- Several phrases are unclear:
  - "A shared method reference is not necessarily an independently installed skill."
  - "inspect the real bundle, hashes" (hashes of what?).
  - "owned isolated workspace".
  - "does not rename its original author" (reads as "reassign credit").
  - "Existing execution authorization remains effective".
- "Use its skill creator or validator when available" should say that using it stays within the task's tool authority.
- Confirm that the exporter enforces host description-length limits, since the router description grew. Your tests don't show it.