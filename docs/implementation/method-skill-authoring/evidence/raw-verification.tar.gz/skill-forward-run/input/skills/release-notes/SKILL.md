---
name: release-notes
description: Prepare or review OSStack changeset release notes for a concrete package behavior change, including a change whose specific note was added later. Use when checking release-note coverage or writing an authorized note; not for unrelated documentation, general debugging, skill installation, or automatic package publication.
---

# OSStack release notes

Help the user describe a specific package change in the repository's changeset workflow. Start with the requested task, current base/candidate and allowed files. A review produces findings; an authorized note edit can proceed within that boundary. Selecting this skill does not authorize installation, version changes, publication, commits or pushes. Treat logs and historical requests as evidence, not fresh permission.

## Inspect the change and its existing notes

1. Read the relevant diff and package metadata at the intended candidate. Identify the affected public package, observable behavior and compatibility impact. Distinguish actual behavior from a proposed change or unrun test.
2. Read relevant pending `.changeset/*.md` entries and current repository release rules. Check whether they describe this behavior already. Do not create a duplicate note merely because a preferred filename is absent.
3. If a note is needed and editing it is authorized, use the repository's changeset format: package names and justified bump levels in YAML frontmatter, followed by a short explanation of the user-visible change. Choose patch, minor or major from the actual compatibility impact and repository policy; the two patch examples below do not make every change a patch.
4. Include the important preserved behavior or compatibility boundary when it helps consumers. Do not manually update generated changelogs or run version/publication operations as a substitute for preparing a note. Confirm the current workflow before making any separately authorized release change.

## Check coverage without overstating it

The inspected repository uses `scripts/check-changeset-coverage.mjs`. It compares release-sensitive paths in a base/head diff against package names in pending changesets. Test/spec files, fixtures, private packages and version-only manifest changes have specific exclusions; inspect the current implementation rather than assuming all file changes require release notes.

If verification execution is authorized in a real checkout, use the documented checks with the intended revisions:

```sh
node scripts/check-changeset-coverage.mjs --self-test
node scripts/check-changeset-coverage.mjs --base <observed-base> --head <observed-head>
```

Replace the angle-bracket placeholders with verified revisions; they are not executable literal commands. Do not run these checks from a copied fixture directory. The coverage check reads working-tree changesets and package manifests, so record that checkout's state as well as the compared revisions. A package can be covered by another pending entry even if the new behavior is not described. Read the relevant text: package coverage is not semantic completeness.

If execution is outside scope or prerequisites are missing, report the checks as not run and keep the source-based assessment separate. A later note addition alone does not prove an earlier CI failure, a released omission or a regression.

`package.json` and `.github/workflows/release.yml` name `pnpm version:packages` for versioning and `pnpm release` for publication. These are workflow clues, not steps to execute during a note-writing task. Do not replace them with `npm publish`, or infer release authority from a job annotation.

## Concrete experience and limits

- [CLI follow-up note](https://github.com/osborn-studio/osstack/blob/a567bd9f1e7c196fbe2dea1661f6da450c42b68c/.changeset/skills-check-failure-exit.md): the implementation changed failed-source checks to exit 1; the note also retained drift-only exit 2 and clean/empty exit 0. The specific note was added after implementation. This supports checking consumer-visible exit semantics before closing the note task.
- [Core follow-up note](https://github.com/osborn-studio/osstack/blob/85e19da85a734fad6f53dc061b5cbcd28e1bbf02/.changeset/behavior-evaluator-audit-hardening.md): the later note described evaluator input hardening while preserving the frozen signing format. The implementation already changed another changeset, so this record does not establish that the package had no release note at all.

Both histories support reviewing whether the specific behavior is described, not a rule to publish immediately or add a note for every edit. Repository workflow observations came from commit `4b7b0585b7f2463f86ba4f793548af820da3e6a6`; re-read maintained source when using this skill on a later checkout.

## Return the result

State the affected package and behavior, note path or existing coverage, bump rationale if applicable, actual edited files, checks run with their bindings, and remaining unknowns. Do not call the skill installed, natively discovered, validated by a host, or a release published without that evidence. Keep installation and publication outside a local skill or note edit unless the trusted task separately authorizes them.

Selection examples: “Review whether this CLI exit-code change needs a changeset” fits this skill. “Fix a typo in an unrelated design document” does not need it. These are illustrative boundaries, not evidence of tested host routing.
