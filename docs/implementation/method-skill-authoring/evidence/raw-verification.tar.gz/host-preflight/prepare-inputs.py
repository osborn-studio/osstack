#!/usr/bin/env python3
"""Fixed offline input preparation only. Never starts a host or reads auth/environment."""
from pathlib import Path
import argparse, hashlib, json, subprocess
SOURCE = '4b7b0585b7f2463f86ba4f793548af820da3e6a6'
REPO = '/Volumes/AIMATE_WORK/Developer/CodeX/osstack'
HERE = Path(__file__).resolve().parent

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def bundle():
    protocol = json.loads((HERE / 'protocol.json').read_text())
    if protocol['source']['sha'] != SOURCE:
        raise ValueError('source pin changed')
    files = {}
    tree = subprocess.check_output(['git', '-C', REPO, 'ls-tree', '-r', SOURCE, '--', 'osstack-methods-skill/']).decode().splitlines()
    for row in tree:
        meta, path = row.split('\t', 1)
        mode, kind, oid = meta.split()
        if mode != '100644' or kind != 'blob' or '..' in Path(path).parts:
            raise ValueError('non-regular source member')
        files['source/' + path] = subprocess.check_output(['git', '-C', REPO, 'cat-file', 'blob', oid])
    expected = protocol['input']['records']
    if [x['id'] for x in expected] != ['A', 'B', 'C', 'D']:
        raise ValueError('four fixed records required')
    for row in expected:
        if set(row) != {'id','scope','owner','facts'}:
            raise ValueError('unexpected fixture fields')
        files['inputs/lane-' + row['id'] + '.json'] = encoded(row)
    files['inputs/request.txt'] = (protocol['input']['request'] + '\n' + protocol['input']['assigned_candidate'] + '\nAll lane records are synthetic teaching input, not actual test receipts.\n').encode()
    files['prompt.txt'] = (protocol['prompt'] + '\n').encode()
    files['inputs/index.json'] = encoded({'fixture_kind':'synthetic_only','method_source': SOURCE,
        'required_entry':'<exported-osstack-agent>/SKILL.md',
        'required_references':['parallel-work.md','evidence.md','pr-readiness.md'],
        'required_records':['inputs/lane-' + x + '.json' for x in 'ABCD'],
        'path_status':'Logical export slot; root must replace with exact host paths in a new final-context index before freeze. This is not a dispatchable input yet.'})
    return files

def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true')
    group.add_argument('--emit-bundle', type=Path)
    args = parser.parse_args()
    files = bundle()
    manifest = {'source':SOURCE,'host_user_turns':0,'host_workspace_created':False,
        'members':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in sorted(files.items())]}
    if args.emit_bundle:
        target = args.emit_bundle
        # A staging bundle is not a host workspace. It cannot launch anything.
        if not target.is_absolute() or target.parent.resolve() != HERE or target.exists() or target.is_symlink():
            raise ValueError('output must be a new direct child of this owned scratch directory')
        target.mkdir(mode=0o700)
        for path, data in files.items():
            dest = target / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open('xb') as stream:
                stream.write(data)
        (target / 'manifest.json').write_bytes(encoded(manifest))
    print(json.dumps(manifest, indent=2))
if __name__ == '__main__':
    main()
