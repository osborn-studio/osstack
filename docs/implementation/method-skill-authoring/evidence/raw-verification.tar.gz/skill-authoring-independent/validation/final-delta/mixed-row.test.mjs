import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {join} from 'node:path';
test('each authoring and verification method has its own navigation row', async () => {
  const root = "/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-post300-20261029/skill-authoring-independent/validation/final-delta/mixed-row";
  for (const entry of ['SKILL.md', 'entries/osstack-mode/SKILL.md']) {
    const text = await readFile(join(root, entry), 'utf8');
    const targets = ['skill-authoring', 'create-verification', 'maintain-verification']
      .map(method => `${entry === 'SKILL.md' ? 'references' : '../../references'}/${method}.md`);
    const rows = text.split('\n').filter(line => /^\s*\|.*\|\s*$/.test(line))
      .map(line => [...line.matchAll(/\[[^\]\n]+\]\(([^)\s]+)\)/g)].map(([, target]) => target));
    for (const target of targets) {
      const matchingRows = rows.filter(links => links.includes(target));
      assert.equal(matchingRows.length, 1, `${entry}: one navigation row for ${target}`);
      assert.deepEqual(matchingRows[0].filter(link => targets.includes(link)), [target],
        `${entry}: each method must have a separate navigation row`);
    }
  }
});
