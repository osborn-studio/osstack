from pathlib import Path
import json,hashlib,re,subprocess,shutil,datetime
p=Path(__file__).parent;src=p/'snapshot';repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';sha='b8bfc83ceee2065cf8192e9de083c24707c13976';h=lambda b:hashlib.sha256(b).hexdigest();names=['osstack-mode','osstack-help','setup-osstack','osstack-agent'];methods=['feature','refactoring','bug-fix','investigation','create-verification','maintain-verification','code-review','change-impact','performance-measurement','task-framing','architecture-design','session-continuity','pr-readiness','skill-authoring'];out={};common={}
for host in ['codex','claude']:
 root=p/('export-'+host);m=json.loads((root/'manifest.json').read_text());files={x['path']:x for x in m['files']};assert len(files)==88
 assert {str(x.relative_to(root)) for x in root.rglob('*') if x.is_file()}==set(files)|{'manifest.json'}
 for f in m['source_files']:
  b=(src/'osstack-methods-skill'/f['path']).read_bytes();assert len(b)==f['bytes'] and h(b)==f['sha256']
 graph={};edges=0;normalized={}
 for path,f in files.items():
  q=root/path;b=q.read_bytes();assert len(b)==f['bytes'] and h(b)==f['sha256'];original=(src/'osstack-methods-skill'/f['source_path']).read_bytes();assert h(original)==f['source_sha256']
  if f['source_path'].startswith('references/'):assert b==original
  normalized[path[len(m['namespace'])+1:]]=h(b)
  text=b.decode();text=re.sub(r'^```[^\n]*\n.*?^```\s*$', '',text,flags=re.M|re.S);targets=[]
  for target in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)',text):
   if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',target) or target.startswith('#'):continue
   dest=(q.parent/target.split('#')[0]).resolve();assert dest.is_relative_to(root.resolve()) and dest.is_file(),(path,target);targets.append(str(dest.relative_to(root.resolve())));edges+=1
  graph[path]=targets
 reach={}
 for name in names:
  start=m['namespace']+'/'+name+'/SKILL.md';visited=set();stack=[start]
  while stack:
   f=stack.pop()
   if f in visited:continue
   visited.add(f);stack.extend(graph.get(f,[]))
  required=['parallel-work','evidence']+methods
  for ref in required:assert any(x.endswith('/references/'+ref+'.md') for x in visited),(host,name,ref)
  reach[name]={'reachable_files':len(visited),'all_14_methods':True,'supporting_guide':True,'evidence':True}
 out[host]={'files':len(files),'local_links':edges,'manifest_sha256':h((root/'manifest.json').read_bytes()),'reachability':reach};common[host]=normalized
assert common['codex']==common['claude']
before=json.loads((p/'snapshot-binding.json').read_text())
for f in before['files']:assert h((src/f['path']).read_bytes())==f['sha256']
neg=p/'missing-guide-source';shutil.copytree(src,neg);(neg/'osstack-methods-skill/references/skill-authoring.md').unlink();dest=p/'missing-guide-output';argv=['/opt/homebrew/opt/node@22/bin/node',str(neg/'scripts/export-osstack-methods.mjs'),'--host','codex','--output',str(dest)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,capture_output=True,cwd=neg,timeout=30,env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(p/'isolated-home'),'OSSTACK_HOME':str(p/'isolated-home'),'OSSTACK_SCRATCH_ROOT':str(p)});(p/'missing-guide.stdout.txt').write_bytes(r.stdout);(p/'missing-guide.stderr.txt').write_bytes(r.stderr);assert r.returncode==1 and not dest.exists();assert 'skill-authoring.md' in r.stderr.decode();negative={'argv':argv,'started':start,'exit':r.returncode,'output_created':dest.exists(),'stderr_sha256':h(r.stderr)};(p/'missing-guide.command.json').write_text(json.dumps(negative,indent=2)+'\n')
result={'candidate':sha,'exports':out,'cross_host_normalized_bytes_equal':True,'canonical_snapshot_unchanged':True,'negative':negative,'method_count':14,'limits':['Local path graph only; no fragment anchor or remote URL liveness verification.','No native host discovery/model effectiveness or formal gate claim.','No full suite; exporter contract suite not rerun by this reviewer.']};(p/'structural-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
