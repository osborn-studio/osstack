# Current repair independent preflight framework

This is a preparation framework, not a final oracle freeze or dispatch authorization. A current defect and bounded independent holdouts are still pending.

**CR01 — Current defect selection** Pin the chosen current source/base and original trigger. Establish a behavioral failure using an actually executable product entry; missing harness/test/build or historical repaired bug does not qualify. Exclude old1038, old4611 and fixedcleanupidentity. Record main vs provisional branch truthfully.

**CR02 — Frozen oracle and controls** Before any model response, freeze concrete incident bytes, expected observation, legitimate controls and bounded hidden variants. Calibrate against pinned bad behavior and a separately explained correct reference/expectation when available; otherwise mark calibration gap, not presumedPASS. Corrections are newversion beforedispatch, never overwrite priorfailedoracle.

**CR03 — Real host repair sequence** Trace must show permitted baselinebehaviorRED, added regression test, behavioral testRED against original source, repair only allowed source, identical testbytes testGREEN on repaired source and same incidentGREEN. A helpermissing/permissionerror/changedexpected/testdeletion is not behavioralRED.

**CR04 — Control and holdout preservation** Original incident/input/helper bytes remain unchanged. Legal controls continue to pass; additional hidden checks run by independent coordinator are separately attributed, not falsely claimed as hostexecution. Test-specific hardcoding or overbroad rejection is a failure.

**CR05 — Complete material delivery** Freeze required materials and pagination/hash boundary. Count actual returned raw bytes and model-visible segments separately, including final lines; reading a tool name or truncated preview is not full delivery. Full delivery does not prove comprehension or causal benefit.

**CR06 — Permission and bounded execution** Freeze literal approved calls and writepaths, exact helper/source/hash, budgets and once-only dispatch. First actual atomic denial ends that host attempt; no wrapper/fallback/escalation/retry. CLI permission configuration and observedcompliance are not OS I/O containment or full descendant termination.

**CR07 — Evidence and candidate binding** Retain argv/cwd/time/exit/rawstdout/stderr/testbeforeafter/sourcebeforeafter, complete inventory and error paths. Tie every observation to exact candidate and test SHA. Hash match is consistency, not authenticated build/compiler/provider principal.

**CR08 — Attribution and result axes** Separate nativeSkill discovery/use, explicitread, host-issuedcommands, coordinator-mediatedexecution and independentrecheck. Inspect all final/assistantmessages against complete trace. Missing evidence is unknown, mismatch/failure staysfailed; launcherexit0 cannot make repairPASS.

**CR09 — Owned resources and privacy** Use owned scratch/home, no defaultDB, no new provider/network access, no credentials/env inspection. Keep raw minimal product-env records only where task explicitlypermits. Changes outside allowlist or unexpected input mutations fail; cleanup unobserved remainsunknown.

**CR10 — Finite interpretation** This is one concrete task/host configuration, not broad modelrank or methodcausalproof. Keep old failures/LIMITED intact. Criteria finalization, dispatch approval and hostcalls remain root-owned; current document grants no execution permission.
