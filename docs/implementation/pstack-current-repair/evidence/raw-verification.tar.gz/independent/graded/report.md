# Current packet repair — independent result

Codex completed the bounded repair; Claude stopped after a permission denial and did not produce a repair. These are separate outcomes, not a comparative model benchmark.

Codex followed the 14 literal product/test commands. Its unchanged six-case behavioral test failed on both contradictory incidents against the original source (4 controls passed), then passed after the one-line guard. The original source SHA `24c8f656…` became `f2480538…`; test SHA `254cae99…` was identical across RED and GREEN. Independent copies replayed that same test against old/new source (exit 1/0), and all 12 pre-frozen hidden vectors met expectations (8 contradictions rejected, 4 legal packets accepted). Those replays are coordinator executions, separate from the model's own loop.

Both hosts actually received all 19 required files, including all 16 method pages, byte-exact in the returned tool content. This closes the earlier partial-delivery problem for this run only; it does not prove understanding or alter prior LIMITED results. Claude invoked native `osstack-mode`; Codex used explicit `cat`. Codex's claim that no native Skill was available is not independently established, and its resolved model is not attested by this stream.

Claude executed six baseline helpers. Its first compound source read (`cat; ls; grep`, events 61–62) actually executed. Its second (`sed|cut; python`, 65–67) was denied; no further tool call followed. No test, source fix, or GREEN occurred. Thus the configured Bash prefix was not an exclusive execution boundary. The final request for additional permission remains unexecuted. Codex's later `git diff` exited 129 because the workspace was not a repository; this inspection limitation is retained without misclassifying it as a product/test failure.

Only authorized Codex source/test changes and helper-owned `results/**` outputs were observed; original inputs, helper and materials remained unchanged. All 24 Codex and 6 Claude staged CLI source/input/raw-output bindings were checked. The observed hosts used one user turn each, no retry. Required material reads and helper-recorded minimal environment reads were permitted; no live environment or credential inspection was observed.

No model call or product modification was performed by this independent verifier. The task proves a narrowly scoped consistency repair, not source authenticity, formal gate qualification, OS containment, all-descendant termination, or causal benefit from a method. Workspaces remain preserved for owner-controlled archival and cleanup.
