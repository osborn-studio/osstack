import json,hashlib,stat,os
from pathlib import Path
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-current-repair-20261029');H=R/'host'
def sha(b):return hashlib.sha256(b).hexdigest()
results={}
for host in ['codex','claude']:
 ws=H/'runs'/host/'workspace'; index=json.loads((ws/'inputs/material-pages.json').read_text()); out=[]
 for item in index['required']:
  orig=(ws/item['material']).read_bytes(); parts=[];n=1
  assert len(orig)==item['bytes'] and sha(orig)==item['sha256']
  for i,p in enumerate(item['pages']):
   b=(ws/p['file']).read_bytes();v=json.loads(b);assert len(b)==p['bytes'] and sha(b)==p['sha256'] and len(b)<=1500
   assert v['sha256']==sha(orig) and v['start']==n and v['end']-v['start']+1<=20
   assert v['eof']==(i==len(item['pages'])-1) and v['next_start']==(None if v['eof'] else v['end']+1)
   parts.append(v['text'].encode());n=v['end']+1
  assert b''.join(parts)==orig
  out.append({'material':item['material'],'sha256':sha(orig),'bytes':len(orig),'pages':len(parts),'reconstructed_exact':True})
 template=json.loads((R/'discovery/template-freeze.json').read_text())
 for f in template['files']:
  b=(ws/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
 assert not list((ws/'results').iterdir()) and not (ws/'tests/repair.test.mjs').exists()
 results[host]={'materials':out,'template_files_equal':17,'results_empty':True,'regression_test_absent':True,'request_sha256':sha((ws/'inputs/request.txt').read_bytes()),'commands_sha256':sha((ws/'inputs/commands.txt').read_bytes())}
assert results['codex']['request_sha256']==results['claude']['request_sha256']
assert results['codex']['commands_sha256']==results['claude']['commands_sha256']
(H.parent/'independent/prepared-byte-check.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
