import json,hashlib,stat,os,datetime
from pathlib import Path
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-current-repair-20261029');H=R/'host';C=R/'independent'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inv(root):
 out={}
 def visit(p):
  s=p.lstat();v={'length':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISREG(s.st_mode):v.update(type='file',sha256=sha(p))
  elif stat.S_ISDIR(s.st_mode):v['type']='directory'
  else:raise AssertionError('unexpected filesystem type')
  out[str(p.relative_to(root))]=v
  if v['type']=='directory':
   for q in sorted(p.iterdir()):visit(q)
 visit(root);return out
m=json.loads((H/'prepared-manifest.json').read_text());assert sha(H/'prepared-manifest.json')=='1f793eb26d996eaf000128c6bb5d5f6239ad406384600013183b5ca537c5e23c'
for f in m['files']:
 p=H/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],str(p)
hosts={}
for host in ['codex','claude']:
 path=H/f'harness/dispatch-{host}-repair.template.json';t=json.loads(path.read_text());assert t['approved'] is False
 assert not (H/f'harness/dispatch-{host}-repair.json').exists()
 for f in t['frozen_files']:assert sha(Path(f['path']))==f['sha256'],f['path']
 assert inv(H/f'runs/{host}/workspace')==t['workspace_inventory']
 assert t['criteria_sha256']==sha(C/'criteria.json')
 assert sha(H/f'harness/run_{host}.py')==t['runner_sha256'] and sha(H/'harness/prompt.txt')==t['prompt_sha256']
 hosts[host]={'template_sha256':sha(path),'frozen_files':len(t['frozen_files']),'inventory_entries':len(t['workspace_inventory']),'budget':t['budget']}
cat=json.loads((H/'runs/claude/evidence/catalog-final-result.json').read_text());sett=json.loads((H/'runs/claude/state/settings.json').read_text());names=json.loads((H/'harness/claude-builtin-catalog.json').read_text())
assert cat['exit_code']==0 and cat['user_turns']==0 and cat['complete_workspace_inventory_unchanged'] is True
assert sorted(cat['catalog_names'])==sorted(names+['osstack-mode']) and all('Skill('+n+')' in sett['permissions']['deny'] for n in names)
assert len(cat['catalog_names'])==59 and len(names)==58
proto=next(p for p in H.glob('*protocol*.json'));assert sha(proto)=='8a17f5b54bba5b8153650d315c4f2d2d27b749addb4b279f4f4f28c84ee9b338'
v={'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'ready_for_root_dispatch_decision','approved':False,'criteria_sha256':sha(C/'criteria.json'),'prepared_manifest_sha256':sha(H/'prepared-manifest.json'),'manifest_members_verified':len(m['files']),'protocol_path':str(proto),'protocol_sha256':sha(proto),'hosts':hosts,'material_check_sha256':sha(C/'prepared-byte-check.json'),'adapter_review_sha256':sha(C/'adapter-review.json'),'interpretations':['CR07 complete required set is request.txt, commands.txt, reading-list.txt and16 JSON method pages. Source may be read as needed; judge accuracy of observed source fragments, not an invented complete28KB reading requirement.','Claude Read then first Bash incident; Codex literal cat material reads then first product/test execution incident. Material cat is not product verification.','14 literal product/test commands:6 baseline, regressionRED,6 after, unchanged regressionGREEN; expected nonzero is not permission denial.','Model edits only checker/tests/repair.test.mjs/results.md; helper owns results/**.','Packet manifest is self-signed byte consistency, not authentic origin. Zero-byte wrong-digest tightening is not a hidden mandatory extension.'],'limits':['Claude native Read configuration and explicit tool rules do not constrain arbitrary JS/shell OS reads; inherited CLI auth not isolated, harness does not enumerate/copy credentials.','Codex workspace-write confines configured writes, read/network restrictions also task agreements. CLI can use existing auth internally.','Helper10s/outputlimit and host600s/no-retry are bounded configured execution, not all-descendant termination proof.','Native catalog is observed59/target1/deny58 and exact-set checked before userturn, not exhaustive hidden capability proof.','No host calls performed by C; required page delivery is only prepared, actual returned content must still be graded.'],'root_requirements':['Only root creates approved live guards; bind criteria and this supplement bytes before userturn.'],'preflight_error_preserved':{'description':'Initial ad hoc inspection tried nonexistent run-protocol.json; actual protocol.json identified by frozen hash; no product or host execution failure.'}}
(C/'dispatch-supplement.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({'supplement_sha256':sha(C/'dispatch-supplement.json'),'hosts':hosts,'members':len(m['files'])},indent=2))
