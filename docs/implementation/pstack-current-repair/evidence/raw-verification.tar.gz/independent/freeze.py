import json,hashlib,datetime,subprocess,copy,os
from pathlib import Path
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-current-repair-20261029'); D=R/'discovery'; O=R/'independent'; H=O/'holdouts'; H.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def put(p,v):p.write_bytes(raw(v))
rows=[]
def add(name,p,expected,why):
 d=H/name;d.mkdir(); b=raw(p);(d/'packet.json').write_bytes(b);put(d/'manifest.json',{'schema_version':1,'files':[{'path':'packet.json','bytes':len(b),'sha256':sha(b)}]});rows.append({'id':name,'directory':str(d),'expected_exit':expected,'reason':why,'packet_sha256':sha(b)})
for v,prefix in [(1,'v1-'),(2,'')]:
 base=json.loads((D/(prefix+'legitimate-passed')/'packet.json').read_text());add(f'v{v}-passed-control',base,0,'All verified cases have empty stderr.')
 fail=json.loads((D/(prefix+'legitimate-unverified-stderr')/'packet.json').read_text());add(f'v{v}-failed-control',fail,0,'Failed verification with unknown product status retains omitted nonempty stderr.')
 for idx,f in enumerate(base['features']):
  p=copy.deepcopy(base);id=f['case_id']+'.product.stderr'; b=['\n',' \t','诊断','warning\r\n','x'][idx].encode()
  next(x for x in p['references'] if x['id']==id).update(bytes=len(b),sha256=sha(b));next(x for x in p['streams'] if x['id']==id)['omitted_bytes']=len(b)
  add(f'v{v}-nonempty-{f["case_id"]}',p,1,'Verification passed cannot retain any nonempty product stderr, including whitespace.')
 if v==2:
  p=copy.deepcopy(p);p['journey_status']='failed';p['failure_recorded']=True;add('v2-global-failed-passed-row-stderr',p,1,'Rule follows individual verification passed even when journey failed.')
# Do not expand this repair into a general referenced-digest authentication policy.
criteria=[
('CR01','Current behavioral defect','Freeze main493 v1 and provisional856 v1/v2 source bytes. Baseline must accept contradictory passed/nonempty packet while legitimate controls accept; missing files/import failures are not RED.'),
('CR02','Both versions and all passed cases','Post-fix --check rejects nonempty product stderr for every passed feature in schemas1/2, including whitespace and a passed row inside a failed journey. Product exit1/2 does not mean verification failed.'),
('CR03','Legal controls preserved','Normal passed/empty-stderr packets and sealed failed-verification/unknown-product nonempty-stderr packets remain accepted without rewriting their states.'),
('CR04','Host-owned repair loop','Host executes baseline, writes a behavioral regression test, executes assertion RED before modifying checker, repairs checker, executes the SAME test bytes GREEN and unchanged visible controls. Coordinator replays are reported separately.'),
('CR05','Input and test integrity','Original source/fixtures/methods/helper immutable except authorized checker; newly written regression test unchanged across RED/GREEN; final patch binds exact source SHA.'),
('CR06','Write authority','Model Edit/Write only projector, tests/repair.test.mjs, results.md as final request permits. Helper owns results/** receipts. Inventory distinguishes these owners; unexpected writes fail or remain unknown if inventory incomplete.'),
('CR07','Material delivery','Every required page and source read is checked against raw returned bytes; method delivery is distinct from native selection and semantic understanding; preview/truncated/missing pages cannot count complete.'),
('CR08','Execution boundary','One authorized user turn per host, no retry, bounded runner/helper times/output. First native permission denial stops the attempt; no compound-command bypass or expanded permission. Configured limits are not OS containment/all-descendant proof.'),
('CR09','Evidence and attribution','Retain raw tool events, commands, exits, hashes, inventories, errors and all assistant messages. Identify actual host/model attestation, native Skill versus explicit file reads, host execution versus coordinator validation separately.'),
('CR10','Consistency not authentication','Packet self-manifest resealing proves byte consistency only. --check remains original_evidence_revalidated:false/formal_gate_pass:false. No demand for external evidence lookup or new trust infrastructure.'),
('CR11','Bounded scope and failures','Do not repair previous1038/4611/cleanup issues or unrelated product code. Unknown, blocked, failed and partial outputs stay visible; no host/model ranking from different permission surfaces.'),
('CR12','Final input binding','Before dispatch supplement binds exact task inputs, source/helper/runner/settings/catalog, resource limits and root guard chronology. Hidden holdouts never enter model workspace.')]
sources={}
for root in ['source','source-main493']:
 for f in (D/root).rglob('*.mjs'):sources[str(f)]=sha(f.read_bytes())
freeze={'schema_version':1,'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'current passed-product-stderr packet consistency repair','criteria':[{'id':i,'title':t,'expectation':e} for i,t,e in criteria],'source_sha256':sources,'holdouts':rows,'zero_byte_digest_decision':{'required_this_task':False,'reason':'No raw evidence is available in --check. A zero-length reference with a non-empty digest is a possible separate internal-consistency tightening, but current repair acceptance is the established passed/nonempty-stderr contradiction; do not impose an undisclosed new digest policy.'},'calibration_limits':'No known fixed candidate exists for this current bug. Baseline acceptance is calibrated below; expected rejection derives independently from evaluateCase unexpected_stderr and actual producer behavior, not from a fabricated fixed implementation. Future candidate is tested against unchanged inputs.'}
put(O/'criteria.json',freeze)
(O/'criteria.md').write_text('# Current packet repair independent criteria\n\nFrozen before any new host call; independent engineering check, not a formal oracle principal.\n\n'+'\n\n'.join(f'**{i} {t}.** {e}' for i,t,e in criteria)+'\n\nZero-byte digest tightening is not a required hidden criterion; source authenticity is out of scope. No existing fixed implementation is claimed.\n')
print('criteria',sha((O/'criteria.json').read_bytes()),'time',freeze['frozen_at_utc'],'holdouts',len(rows))
# Baseline CLI, bounded, read-only packets. Save every output and invocation.
cal=O/'baseline-calibration';cal.mkdir();results=[]
for root in ['source','source-main493']:
 script=D/root/'scripts/project-method-journey-evidence.mjs'
 for row in rows:
  if root=='source-main493' and not row['id'].startswith('v1-'):continue
  label=root+'-'+row['id'];argv=['/opt/homebrew/opt/node@22/bin/node',str(script),'--check',row['directory']]
  p=subprocess.run(argv,cwd=O,capture_output=True,timeout=10,env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':str(O)})
  (cal/(label+'.stdout')).write_bytes(p.stdout);(cal/(label+'.stderr')).write_bytes(p.stderr)
  rec={'argv':argv,'cwd':str(O),'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'source_sha256':sha(script.read_bytes()),'expected_after_fix':row['expected_exit'],'baseline_defect_reproduced':p.returncode==0 and row['expected_exit']==1}
  put(cal/(label+'.command.json'),rec);results.append({'id':label,**rec})
put(cal/'results.json',results)
print('baseline',len(results),'calls','defectaccepts',sum(x['baseline_defect_reproduced'] for x in results),'legitimate',sum(x['exit_code']==0 and x['expected_after_fix']==0 for x in results))
