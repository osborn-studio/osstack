from pathlib import Path
import json,hashlib,subprocess,shutil,datetime
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-current-repair-20261029');O=R/'independent/replay';O.mkdir(exist_ok=False);W=R/'host/runs/codex/workspace';NODE='/opt/homebrew/opt/node@22/bin/node'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
records=[]
def run(label,args,cwd):
 p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=20,env={'PATH':'/opt/homebrew/opt/node@22/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':str(O),'HOME':str(O/'unused-home'),'OSSTACK_HOME':str(O/'unused-osstack')});(O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr);v={'label':label,'argv':args,'cwd':str(cwd),'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)};write(O/(label+'.command.json'),v);records.append(v);return p
for version in ['old','candidate']:
 d=O/version;shutil.copytree(R/'discovery/template',d);shutil.copyfile(W/'tests/repair.test.mjs',d/'tests/repair.test.mjs')
 if version=='candidate':shutil.copyfile(W/'scripts/project-method-journey-evidence.mjs',d/'scripts/project-method-journey-evidence.mjs')
 p=run(version+'-same-test',['/usr/bin/python3',str(d/'tools/run-node.py'),'test','independent'],d);assert p.returncode==(1 if version=='old' else 0)
 print(version,p.returncode)
criteria=json.loads((R/'independent/criteria.json').read_text());hidden=[]
for row in criteria['holdouts']:
 d=Path(row['directory']);before={p.name:sha(p.read_bytes()) for p in d.iterdir()};p=run('hidden-'+row['id'],[NODE,str(O/'candidate/scripts/project-method-journey-evidence.mjs'),'--check',str(d)],O/'candidate');after={p.name:sha(p.read_bytes())for p in d.iterdir()};assert before==after;hidden.append({'id':row['id'],'expected':row['expected_exit'],'observed':p.returncode,'pass':p.returncode==row['expected_exit'],'unchanged':True})
assert all(x['pass']for x in hidden)
v={'candidate_sha256':sha((W/'scripts/project-method-journey-evidence.mjs').read_bytes()),'test_sha256':sha((W/'tests/repair.test.mjs').read_bytes()),'old_source_sha256':sha((R/'discovery/template/scripts/project-method-journey-evidence.mjs').read_bytes()),'same_test_old_exit':1,'same_test_candidate_exit':0,'hidden':hidden,'commands':records,'actor':'independent coordinator replay, not host-authored execution','limits':'No model calls, no products changed, no formal gate or source authentication. Owned replay stages retained.'};write(O/'results.json',v);print('hidden',len(hidden),'pass',all(x['pass']for x in hidden))
