// Task-local adapter; executes the current product CLI, with no expected-answer oracle.
import { lstatSync, realpathSync, mkdirSync, readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = realpathSync(fileURLToPath(new URL('../', import.meta.url)));
const NODE = '/opt/homebrew/opt/node@22/bin/node';
const SOURCE = ['scripts/project-method-journey-evidence.mjs', 'scripts/lib/skills-check-verification.mjs', 'scripts/lib/scratch.mjs'];
const CASES = ['incident-v1', 'passed-v1', 'failed-v1', 'incident-v2', 'passed-v2', 'failed-v2'];
const hash = b => createHash('sha256').update(b).digest('hex');
const json = x => JSON.stringify(x, null, 2) + '\n';
function dir(p) { const s = lstatSync(p); if (!s.isDirectory() || s.isSymbolicLink() || realpathSync(p) !== p) throw Error('unsafe_directory'); }
function file(p) { const s = lstatSync(p); if (!s.isFile() || s.isSymbolicLink() || s.size > 1048576) throw Error('unsafe_file'); const b = readFileSync(p); if (b.length > 1048576) throw Error('file_limit'); return b; }
function snapshot(id) {
  for (const name of ['scripts', 'scripts/lib', 'tools', 'inputs', 'results', 'inputs/' + id]) dir(join(ROOT, name));
  if (JSON.stringify(readdirSync(join(ROOT, 'inputs', id)).sort()) !== JSON.stringify(['manifest.json', 'packet.json'])) throw Error('input_inventory');
  return { source: SOURCE.map(path => ({ path, bytes: file(join(ROOT, path)) })), input: ['manifest.json', 'packet.json'].map(path => ({ path, bytes: file(join(ROOT, 'inputs', id, path)) })) };
}
const bind = files => files.map(f => ({ path: f.path, bytes: f.bytes.length, sha256: hash(f.bytes) }));
export function checkFixture(id, label) {
  if (!CASES.includes(id) || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$/.test(label)) throw Error('invalid_case_or_label');
  const before = snapshot(id); const run = join(ROOT, 'results', 'check-' + label); mkdirSync(run, { mode: 0o700 });
  const stage = join(run, 'stage'); mkdirSync(stage); const input = join(stage, 'input'); mkdirSync(input);
  for (const [files, base] of [[before.source, stage], [before.input, input]]) for (const f of files) { const p = join(base, f.path); mkdirSync(dirname(p), { recursive: true }); writeFileSync(p, f.bytes, { flag: 'wx', mode: 0o600 }); }
  for (const name of ['home', 'tmp', 'scratch']) mkdirSync(join(run, name));
  const env = { PATH: '/opt/homebrew/opt/node@22/bin:/usr/bin:/bin', HOME: join(run, 'home'), TMPDIR: join(run, 'tmp'), OSSTACK_HOME: join(run, 'unused-osstack'), OSSTACK_SCRATCH_ROOT: join(run, 'scratch'), LANG: 'C', LC_ALL: 'C' };
  const argv = ['scripts/project-method-journey-evidence.mjs', '--check', input];
  const record = { executable: NODE, argv, cwd: stage, environment: env, case_id: id, source: bind(before.source), inputs: bind(before.input), started_at: new Date().toISOString(), timeout_seconds: 10, output_limit_each: 1048576 };
  writeFileSync(join(run, 'command.json'), json(record), { flag: 'wx' });
  const observed = spawnSync(NODE, argv, { cwd: stage, env, timeout: 10000, maxBuffer: 1048576, killSignal: 'SIGKILL' });
  const rawOut = observed.stdout ?? Buffer.alloc(0); const rawErr = observed.stderr ?? Buffer.alloc(0);
  const stdout = rawOut.subarray(0, 1048576); const stderr = rawErr.subarray(0, 1048576);
  writeFileSync(join(run, 'stdout'), stdout, { flag: 'wx' }); writeFileSync(join(run, 'stderr'), stderr, { flag: 'wx' });
  const after = snapshot(id); const stagedInput = before.input.map(f => ({ path: f.path, bytes: file(join(input, f.path)) }));
  const result = { ...record, exit_code: observed.status, signal: observed.signal, error: observed.error?.code ?? null, timed_out: observed.error?.code === 'ETIMEDOUT', output_limit_exceeded: observed.error?.code === 'ENOBUFS' || rawOut.length > 1048576 || rawErr.length > 1048576, stdout: stdout.toString('utf8'), stderr: stderr.toString('utf8'), stdout_sha256: hash(stdout), stderr_sha256: hash(stderr), source_after: bind(after.source), inputs_after: bind(after.input), source_inputs_unchanged: JSON.stringify(bind(before.source)) === JSON.stringify(bind(after.source)) && JSON.stringify(bind(before.input)) === JSON.stringify(bind(after.input)), staged_input_unchanged: JSON.stringify(bind(before.input)) === JSON.stringify(bind(stagedInput)), ended_at: new Date().toISOString(), evidence: 'results/check-' + label, cleanup: 'retained_owned_stage', descendant_termination: 'not_attested' };
  writeFileSync(join(run, 'result.json'), json(result), { flag: 'wx' }); return result;
}
if (process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url))) {
  try { if (process.argv.length !== 4) throw Error('usage: check-case CASE LABEL'); const r = checkFixture(process.argv[2], process.argv[3]); process.stdout.write(json(r)); process.exitCode = r.timed_out ? 124 : r.output_limit_exceeded ? 125 : r.error || !r.source_inputs_unchanged || !r.staged_input_unchanged ? 126 : r.exit_code ?? 126; }
  catch (e) { process.stderr.write(json({ adapter_error: e.code ?? e.message })); process.exitCode = 126; }
}
