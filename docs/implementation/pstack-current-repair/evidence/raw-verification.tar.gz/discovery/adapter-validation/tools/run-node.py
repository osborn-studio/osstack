#!/usr/bin/python3
"""Fixed packet-check task adapter, not an outcome oracle or general command runner."""
import sys,subprocess,json,hashlib,os,signal,time,selectors,re
from pathlib import Path
WS=Path(__file__).resolve().parent.parent
NODE='/opt/homebrew/opt/node@22/bin/node'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bindings():
 paths=['scripts/project-method-journey-evidence.mjs','scripts/lib/skills-check-verification.mjs','scripts/lib/scratch.mjs','tests/repair.test.mjs','tools/check-case.mjs','tools/run-node.py']
 for name in ['scripts','scripts/lib','tools','tests','inputs','results']:
  p=WS/name
  if p.is_symlink() or not p.is_dir() or p.resolve()!=p:raise SystemExit('unsafe directory')
 for c in ['incident-v1','passed-v1','failed-v1','incident-v2','passed-v2','failed-v2']:
  base=WS/'inputs'/c
  if base.is_symlink() or not base.is_dir():raise SystemExit('unsafe input root')
  for p in base.rglob('*'):
   if p.is_symlink():raise SystemExit('input symlink')
   if p.is_file():paths.append(str(p.relative_to(WS)))
 out={}
 for path in sorted(paths):
  p=WS/path
  if p.is_symlink():raise SystemExit('source symlink')
  if p.exists() and (not p.is_file() or p.stat().st_size>1048576):raise SystemExit('unsafe source')
  out[path]=digest(p) if p.is_file() else None
 return out
args=sys.argv[1:]
if len(args)==3 and args[0]=='check' and args[1] in ['incident-v1','passed-v1','failed-v1','incident-v2','passed-v2','failed-v2']:
 label=args[2];command=[NODE,'tools/check-case.mjs',args[1],label]
elif len(args)==2 and args[0]=='test':
 label=args[1];command=[NODE,'--test','tests/repair.test.mjs']
else:raise SystemExit('usage: /usr/bin/python3 tools/run-node.py check incident-v1|passed-v1|failed-v1|incident-v2|passed-v2|failed-v2 UNIQUE_LABEL | test UNIQUE_LABEL')
if not re.fullmatch('[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}',label):raise SystemExit('invalid label')
before=bindings();result=WS/'results'/('invoke-'+label);result.mkdir(mode=0o700)
run_tmp=result/'tmp';run_tmp.mkdir()
env={'PATH':'/opt/homebrew/opt/node@22/bin:/usr/bin:/bin','HOME':str(result/'isolated-home'),'TMPDIR':str(run_tmp),'LANG':'C','LC_ALL':'C','OSSTACK_HOME':str(result/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':str(WS/'results'/'scratch')}
record={'argv':command,'cwd':str(WS),'environment':env,'before':before,'mode':args[0],'test_file_exists':(WS/'tests/repair.test.mjs').is_file(),'timeout_seconds':10,'output_limit_each':1048576,'started_at_epoch':time.time()}
(result/'command.json').write_text(json.dumps(record,indent=2)+'\n')
p=None;timed_out=False;overflow=False;counts={};streams={};start=time.monotonic()
try:
 p=subprocess.Popen(command,cwd=WS,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 sel=selectors.DefaultSelector()
 for name,pipe in [('stdout',p.stdout),('stderr',p.stderr)]:
  streams[name]=(result/name).open('xb');counts[name]=0;sel.register(pipe,selectors.EVENT_READ,name)
 while sel.get_map():
  if time.monotonic()-start>10:timed_out=True;break
  for key,_ in sel.select(.1):
   data=os.read(key.fileobj.fileno(),65536)
   if not data:sel.unregister(key.fileobj);continue
   counts[key.data]+=len(data)
   if counts[key.data]>1048576:overflow=True;break
   streams[key.data].write(data)
  if overflow:break
 if timed_out or overflow:os.killpg(p.pid,signal.SIGKILL)
 p.wait(timeout=2)
finally:
 if p and p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2)
 for stream in streams.values():stream.close()
 record.update(exit_code=None if p is None else p.returncode,timed_out=timed_out,output_limit_exceeded=overflow,output_bytes=counts,elapsed_seconds=time.monotonic()-start,after=bindings(),descendant_termination='not_attested')
 for name in ['stdout','stderr']:
  if(result/name).exists():record[name+'_sha256']=digest(result/name)
 (result/'result.json').write_text(json.dumps(record,indent=2)+'\n')
for name in ['stdout','stderr']:
 if(result/name).exists():(sys.stdout.buffer if name=='stdout' else sys.stderr.buffer).write((result/name).read_bytes())
print('\nEvidence: results/invoke-'+label+'/result.json',file=sys.stderr)
raise SystemExit(124 if timed_out else 125 if overflow else p.returncode if p else 126)
