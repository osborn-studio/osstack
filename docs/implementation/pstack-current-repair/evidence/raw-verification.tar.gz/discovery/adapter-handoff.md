# Neutral repair template handoff

Frozen template: `template/`, 17 regular files plus empty `tests/` and `results/`. Exact source candidate856bec1deaa720425d8b475793f9dd75e1364288, three product/support files. Six minimal canonical packets come from the confirmed discovery; no known fix, regression-test implementation or hidden controls are included.

`template-freeze.json` SHA256: 1c7ecaad675109d003c5b09ab7621e906861987b05c0f1c229e28f6b02973810.

Atomic interfaces:

```text
/usr/bin/python3 tools/run-node.py check CASE UNIQUE_LABEL
/usr/bin/python3 tools/run-node.py test UNIQUE_LABEL
```

CASE is exactly incident-v1, passed-v1, failed-v1, incident-v2, passed-v2 or failed-v2. Labels are fresh ASCII identifiers, at most64 characters. The host must create `tests/repair.test.mjs`; its absence is a harness/setup failure, not behavioral RED. Test code can import `checkFixture` from `../tools/check-case.mjs` and inspect its returned `exit_code`, raw `stdout`/`stderr` and evidence fields. Each call creates its own stage, copies current candidate source plus selected fixture, and runs the actual Node CLI with `--check`; no test parser replaces the product.

Node is pinned to /opt/homebrew/opt/node@22/bin/node. Each Node subprocess has10s/1MiB bounds and is synchronous; the Python invocation has its own10s bounded output loop and kills its own process group on timeout. Both environments use explicit isolated scratch/home values and omit inherited credentials. Evidence stores actual argv, source/input/test hashes, streams, exit/signal/timeout flags and before/after states. Stage inputs are checked after product exit; original inputs and sources are compared by the Node helper. Python records all six inputs and test/source before/after so independent reviewers can assess the broader task boundary.

This is not an OS filesystem/network fence. Test execution is candidate code, so host permissions and full workspace inventory checks remain separate. Direct-child or process-group kill is not proof about escaped descendants. Original result directories are retained and labels cannot overwrite them.

Offline validation copied the template into `adapter-validation/`: six baseline checks exit0 (the incident acceptances are the defect), missing test exits1, and invalid/duplicate labels exit1. Nine commands with raw outputs are in adapter-validation.json. No product repair, model call or full suite ran. The frozen template itself has no generated results/test file. Do not copy discovery reports, original raw-journey derivation or validation workspace as intended model answers.
