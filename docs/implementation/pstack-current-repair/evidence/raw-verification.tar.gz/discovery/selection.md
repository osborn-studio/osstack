# Selected current repair task: contradictory passed product stderr

**Confirmed, currently unfixed.** Candidate `856bec1deaa720425d8b475793f9dd75e1364288` and current main `493caa4e46e616b1d7e9e1c87ed0a5775eae3ad1` are affected. This is a small publication-validator consistency defect, not a newly observed production-user incident. It is not the old1038 not_run bug, old4611 exporter bug, or repaired cleanup identity issue. No fix has been written.

## Reproduction and expected behavior

The existing `evaluateCase` in `scripts/lib/skills-check-verification.mjs` rejects **product** stderr when nonempty (`unexpected_stderr`). `verifyPassed` in the projector uses this predicate and requires its passed result. A packet claiming a passed fixed case while its product.stderr reference declares1 byte is therefore internally inconsistent, without needing to authenticate history or follow a path.

Start from the retained genuine full packet, leave its drift feature `verification: passed`, set only `drift.product.stderr` reference bytes to1 and SHA256 to the digest of `x`, and set that stderr stream's `omitted_bytes` to1. Keep selected_lines empty. Recompute the normal packet manifest. Candidate `--check` returns exit0/status valid instead of rejecting. The analogous healthy row in v1 also passes on both main493 and candidate856.

For a separate causal check, a scratch copy of the actual retained full journey has only `cases/drift/drift.stderr` changed to `x`, corresponding command/detail stderr hashes updated, and case/root manifests correctly resealed. Candidate `--input ... --scope full` rejects this input with `behavior_mismatch`, exit1, no output directory. Git stderr files are untouched. Thus the expectation is already in the producer/retained-source verifier, not an invented rule.

## Actual controls and commands

`probe-results.json` contains three candidate-v2 calls. `extension-results.json` contains six v1 calls across main/candidate plus the actual raw-journey mutation. All10 real invocations used Node22 and finished in about0.05s each. Raw stdout/stderr and full argv are retained.

Minimal fixtures (each contains only canonical packet.json + manifest.json):

- `legitimate-passed`: v2 valid original; expect exit0.
- `passed-nonempty-stderr`: v2 contradiction; expect rejection (currently0).
- `legitimate-unverified-stderr`: v2 globally failed, drift row failed/unknown with retained reported result; nonempty stderr is legal; expect0.
- `v1-legitimate-passed`, `v1-passed-nonempty-stderr`, `v1-legitimate-unverified-stderr`: analogous v1 controls.

Run the unchanged product, for example:

```sh
node source/scripts/project-method-journey-evidence.mjs --check passed-nonempty-stderr
```

Resolve fixture paths against this discovery directory. The exact absolute commands are in the JSON records. `source/` contains exact candidate Git bytes and two unchanged support modules; `source-main493/` binds the old-main comparison. No installation/build/network/DB is needed.

## Minimal repair / two-host task boundary

Limit product changes to `scripts/project-method-journey-evidence.mjs` and its adjacent test. Add a behavioral regression first, run it against the unchanged candidate for RED, make a minimal consistency correction, then use the same test and controls for GREEN. Preserve all legal v1 packet bytes, support both schemas, and retain failed/unknown nonempty-stderr representation. Do not turn structural checks into provenance authentication or add source-file reads to --check. A possible zero-byte/wrong-digest inconsistency was **not tested or selected**; any expansion needs independent criteria.

Each host should get its own copy of candidate source and neutral fixtures. Do not supply an implementation patch, this reasoning report, or hidden holdouts as model answers. A closed atomic helper can expose real `--check` and a new node:test path with fresh result directories; that helper is not implemented by this discovery task. Neither host should edit read-only fixtures or raw original evidence. Root owns execution budgets, independent criteria and publication. No model calls or repository changes happened here.

Reader and journey were inspected at the same SHA; no other reliable new defect was established in this bounded search. This selection closes a real evidence-checking gap while exercising the existing bug-fix/create-verification material, without adding a method or claiming general host effectiveness.
