# Fixed skills-check journey

Journey status: passed. See journey.json for failure details.

| Feature | Product exit | Driver exit | Verification | Cleanup | Evidence |
|---|---|---|---|---|---|
| healthy | 0 | 0 | passed (journey:passed) | passed | cases/healthy/manifest.json |
| missing-ref | 1 | 0 | passed (journey:passed) | passed | cases/missing-ref/manifest.json |
| drift | 2 | 0 | passed (journey:passed) | passed | cases/drift/manifest.json |
| mixed | 1 | 0 | passed (journey:passed) | passed | cases/mixed/manifest.json |
| empty | 0 | 0 | passed (journey:passed) | passed | cases/empty/manifest.json |

Expected missing-ref product exit1 is an unrecovered source failure. Driver exit0 means its fixed negative predicate passed. Native selection/model execution: not observed/not run. Descendant termination: not attested. Full scope covers only these five fixed cases. Expected drift exit2 reports changed source; mixed exit1 preserves failure precedence over drift. Existing two-case projection does not accept this scope.
