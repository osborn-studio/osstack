from pathlib import Path
import re,json,hashlib
r=Path(__file__).parent;rows=[];steps={};checkout=[];steptext={}
for line in (r/'full.log').read_text().splitlines():
 line=re.sub(r'(?:\x1b|\^\[)\[[0-9;]*m','',line);a=line.split('\t',2)
 if len(a)!=3 or a[0]!='check':continue
 step=a[1];txt=re.sub(r'^\ufeff?\d{4}-\S+Z\s?','',a[2]);steptext.setdefault(step,[]).append(txt)
 if step=='Test':
  m=re.search(r'packages/([^ ]+) test:\s+Tests\s+(.*)',txt)
  if m:
   nums={k:int(n) for n,k in re.findall(r'(\d+) (passed|skipped|failed)',m[2])};rows.append({'package':m[1],**{k:nums.get(k,0) for k in ['passed','skipped','failed']}})
 m=re.search(r'^# (tests|pass|fail|skipped) (\d+)',txt)
 if m:steps.setdefault(step,{})[m[1]]=int(m[2])
 if step.startswith('Run actions/checkout') and ('HEAD is now at' in txt or re.fullmatch('[a-f0-9]{40}',txt)):checkout.append(txt)
assert len(rows)==22 and len({x['package']for x in rows})==22
s='\n'.join(steptext['Full method verification journey (five real local cases)']);j=json.JSONDecoder().raw_decode(s[s.index('\n{\n')+1:])[0]
assert j['status']=='passed' and [f['product_exit']for f in j['features']]==[0,1,2,1,0]
p=[json.loads(x) for x in steptext['Project and check full five-case method evidence']if x.startswith('{"status"')];assert [x['status']for x in p]==['projected','valid'] and p[0]['packet_sha256']==p[1]['packet_sha256']
v={'head_sha':'856bec1deaa720425d8b475793f9dd75e1364288','run_id':40839214482,'latest_run':json.loads((r/'run-after-freeze.json').read_text()),'checkout':checkout,'unique_package_count':len(rows),'package_totals':{k:sum(x[k]for x in rows)for k in ['passed','skipped','failed']},'packages':rows,'standalone_steps':steps,'full_journey_features':[{'case_id':f['case_id'],'verification':f['verification'],'product_exit':f['product_exit'],'driver_exit':f['driver_exit'],'cleanup':f['cleanup']}for f in j['features']],'full_projection':p,'raw_log_sha256':hashlib.sha256((r/'full.log').read_bytes()).hexdigest(),'limits':['No CI rerun or product tests run by C.','Uploaded artifact bytes not downloaded/independently verified.','CI success applies to856 and synthetic merge d671, not a future repair candidate.','Current independent passed-stderr counterexamples remain a real uncovered defect despite this CI success.','One initial repository-name typo returned404; preserved separately, not CI failure.']}
(r/'report.json').write_text(json.dumps(v,indent=2)+'\n');(r/'report.md').write_text('# PR305 independent CI observation\n\nRun40839214482 finished SUCCESS at head856bec1d. Five applicable jobs passed; paid job skipped. Actual checkout synthetic merge d67173d21a566af1b17e7ff3fe6168799b94947d (856 into185d).\n\n22 unique package summaries: '+str(v['package_totals'])+'. Export94 total/93pass/1skip; reader14, journey43, projection79. Actual full journey five product exits0/1/2/1/0 and driver0 each; full projection/check returned matching packet hash. Artifact contents not downloaded. This is old856 evidence, not future repair verification.\n');print(v['package_totals']);print('hash',hashlib.sha256((r/'report.json').read_bytes()).hexdigest())
