"""Offline preparation only: exact pinned reader output, bounded complete JSON pages.
Does not run a host, edit a material, or approve a dispatch guard.
"""
from pathlib import Path
import subprocess,hashlib,json,sys
ROOT=Path(__file__).resolve().parent.parent
READER=ROOT/'metadata/read-method-material.mjs'
NODE='/opt/homebrew/opt/node@22/bin/node'
def sha(b):return hashlib.sha256(b).hexdigest()
def prepare(source,output):
 source=Path(source).resolve(strict=True);output=Path(output)
 if not source.is_file() or source.is_symlink():raise ValueError('regular source required')
 if not output.is_absolute() or not output.parent.is_dir():raise ValueError('absolute new output with existing parent required')
 output.mkdir() # exclusive; partial output remains evidence on failure
 original=source.read_bytes();digest=sha(original);start=1;pages=[];joined=b''
 while True:
  selected=None
  for count in range(20,0,-1):
   args=[NODE,str(READER),'--file',str(source),'--start',str(start),'--lines',str(count)]
   if start>1:args+=['--sha256',digest]
   p=subprocess.run(args,capture_output=True,timeout=10)
   if p.returncode:
    error=json.loads(p.stderr).get('error')
    if error=='page_too_large':continue
    raise RuntimeError('reader failed: '+str(error))
   if len(p.stdout)<=1500:selected=(args,p.stdout,json.loads(p.stdout));break
  if selected is None:raise ValueError('single line cannot fit complete1500byte JSON; stop preparation without truncating')
  args,raw,page=selected
  assert page['sha256']==digest and page['start']==start
  name=f'page-{len(pages)+1:03}.json';(output/name).write_bytes(raw)
  pages.append({'file':name,'sha256':sha(raw),'bytes':len(raw),'start':page['start'],'end':page['end'],'eof':page['eof'],'next_start':page['next_start'],'argv':args})
  joined+=page['text'].encode('utf-8')
  if page['eof']:break
  assert page['next_start']>start;start=page['next_start']
 assert joined==original and source.read_bytes()==original
 record={'source':str(source),'source_sha256':digest,'source_bytes':len(original),'reader_sha256':sha(READER.read_bytes()),'page_json_limit':1500,'line_limit':20,'reconstruction_exact':True,'pages':pages,'limit':'Preparation verifies complete page bytes only; actual tool response delivery and understanding need separate observation.'}
 (output/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
 return record
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('SOURCE NEW_ABSOLUTE_OUTPUT_DIRECTORY')
 print(json.dumps(prepare(sys.argv[1],sys.argv[2]),indent=2))
