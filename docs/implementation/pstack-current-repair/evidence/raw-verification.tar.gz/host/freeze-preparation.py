from pathlib import Path
import json,hashlib,sys,datetime
R=Path(__file__).parent;H=R/'harness';sys.path.insert(0,str(H))
from common import inventory
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
model=json.loads((R/'codex-model-metadata/result.json').read_text())['unique_default']['model'];assert model=='gpt-6.1-sol'
cat=json.loads((R/'runs/claude/evidence/catalog-final-result.json').read_text());assert cat['user_turns']==0 and cat['status']=='catalog_gate_observed' and cat['complete_workspace_inventory_unchanged']
protocol={'prepared_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'frozen_pending_C_supplement_and_root_dispatch','source_and_methods_pin':'856bec1deaa720425d8b475793f9dd75e1364288','task':'Repair current packet checker contradiction using neutral v1/v2 incident and legal controls; no fixed source/history supplied','budget':{'hosts':['codex','claude'],'user_turns_each':1,'timeout_seconds_each':600,'retries':0,'product_command_seconds':10,'output_bytes_per_stream':1048576,'report_words_suggested':300,'hard_word_limit':None},'commands_per_host':14,'sequence':'6baseline (incident-v1 first), host writes real behavior test with unchanged source, testRED, minimal fix,6samechecks,same unchanged testGREEN','write_paths':['scripts/project-method-journey-evidence.mjs','tests/repair.test.mjs','results.md'],'helper_owned_paths':['results/**'],'materials':{'required':['osstack-mode entry','bug-fix','evidence'],'pages_each_host':16,'complete_json_max_bytes':1500,'max_lines':20,'other_exported_references':'provided_not_required','delivery':'Each listed page must be returned fully by host tool; native preview and raw bytes alone do not prove model-facing delivery or understanding'},'host_surface':{'claude':'Native Skill(osstack-mode), then explicit Read pages; first Bash literal incident; restricted tool allow and task restrictions, no bypass','codex':'Single literal cat per required input/page; first product/test call literal incident; workspace-write, no approval, ignored rules/config, ephemeral; explicit reading not asserted native'},'permission_denial':'Stop without fallback,reissue,retry. Expected test/product nonzero is not a permission denial. Verify from actual trace rather than assume compliance.','auth':'CLI internally uses existing auth; no credential reading/copying/hashing, no environment enumeration; Claude inherited environment is not isolated','limitations':['No OS read/network isolation claim; tests are executable JS','Requested/CLI-reported identity is not independently attested','No causal method/model comparison claim','Cleanup only after independent archive verification/root approval; no all-descendant guarantee','Prior failed/limited experiments remain unchanged'],'metadata':{'claude_version':'2.1.291','codex_version':'0.160.1','claude_catalog_items':len(cat['catalog_names']),'non_target_denied':58,'codex_requested_model':model,'claude_requested_model':'claude-sonnet-5-5','user_turns_so_far':0},'criteria_binding':{'path':str(R.parent/'independent/criteria.json'),'sha256':'000da1c46bb539a246b1f8ec1f03bfce895987c2b8a178d0c8b5e850d7217845'},'launch_commands':{'codex':'python3 -B harness/run_codex.py repair','claude':'python3 -B harness/run_claude.py run repair'},'launch_cwd':str(R)}
save(R/'protocol.json',protocol)
for host in ['codex','claude']:
 case=R/'runs'/host;ws=case/'workspace';idx=json.loads((ws/'inputs/material-pages.json').read_text())
 for mat in idx['required']:
  joined=b''
  for row in mat['pages']:
   p=ws/row['file'];raw=p.read_bytes();assert sha(p)==row['sha256'] and len(raw)==row['bytes']<=1500
   d=json.loads(raw);assert d['sha256']==mat['sha256'];joined+=d['text'].encode()
  assert joined==(ws/mat['material']).read_bytes() and hashlib.sha256(joined).hexdigest()==mat['sha256']
 frozen=[p for p in H.iterdir() if p.is_file() and not p.name.startswith('dispatch-')]
 frozen += [p for sub in ['workspace','state'] for p in (case/sub).rglob('*') if p.is_file()]
 frozen += [R/'protocol.json',R/'metadata/read-method-material.mjs',R/'metadata/adapter-template-binding.json',R/'metadata/method-source-bindings.json',R/'codex-model-metadata/result.json']
 if host=='claude':frozen += [case/'evidence/catalog-final-result.json']
 frozen=sorted(set(frozen))
 template={'approved':False,'status':'C supplement and explicit root dispatch required','runner_sha256':sha(H/f'run_{host}.py'),'prompt_sha256':sha(H/'prompt.txt'),'frozen_files':[{'path':str(p),'sha256':sha(p)}for p in frozen],'workspace_inventory':inventory(ws),'criteria_sha256':protocol['criteria_binding']['sha256'],'independent_supplement':'pending_root_must_bind','codex_model':model if host=='codex' else None,'budget':protocol['budget']}
 save(H/f'dispatch-{host}-repair.template.json',template)
files=[p for p in R.rglob('*')if p.is_file() and '__pycache__'not in p.parts and p.name!='prepared-manifest.json']
save(R/'prepared-manifest.json',{'prepared_at':protocol['prepared_at'],'status':'frozen_pending_independent_C_and_root','files':[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(files)]})
print(json.dumps({'protocol_sha256':sha(R/'protocol.json'),'manifest_sha256':sha(R/'prepared-manifest.json'),'members':len(files),'guards':{host:sha(H/f'dispatch-{host}-repair.template.json')for host in ['codex','claude']}}))
