import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { checkFixture } from '../tools/check-case.mjs';

for (const version of ['v1', 'v2']) {
  for (const kind of ['incident', 'passed', 'failed']) {
    const id = `${kind}-${version}`;
    test(`${id}: retained stderr agrees with verification claim`, () => {
      const result = checkFixture(id, `repair-${id}-${randomUUID()}`);
      assert.equal(result.error, null);
      assert.equal(result.signal, null);
      assert.equal(result.timed_out, false);
      assert.equal(result.output_limit_exceeded, false);
      assert.equal(result.source_inputs_unchanged, true);
      assert.equal(result.staged_input_unchanged, true);
      if (kind === 'incident') {
        assert.equal(result.exit_code, 1, 'verified-passed evidence with nonempty stderr must be rejected');
        assert.equal(JSON.parse(result.stderr).status, 'rejected');
      } else {
        assert.equal(result.exit_code, 0, `${kind} evidence must remain usable`);
        assert.equal(JSON.parse(result.stdout).status, 'valid');
      }
    });
  }
}
