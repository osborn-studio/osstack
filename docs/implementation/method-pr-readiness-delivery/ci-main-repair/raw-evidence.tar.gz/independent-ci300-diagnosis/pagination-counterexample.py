# Standalone exact-query demonstration, not a production observer/CI reproduction.
import hashlib,json,sqlite3
D=lambda a:hashlib.sha256(json.dumps(a,separators=(',',':')).encode()).hexdigest()
for seed in range(10000):
 home=f'00000000-0000-4000-8000-{seed:012d}'
 scope=D([home,'t','/synthetic/repo',1])
 items=[(D([scope,f's{i:04d}',f'turn{i}','d']),scope,f's{i:04d}') for i in range(101)]
 if items[0][0]==max(x[0] for x in items):break
else:raise AssertionError('No bounded counterexample found')
db=sqlite3.connect(':memory:');db.execute('CREATE TABLE attention_items(item_id TEXT PRIMARY KEY,scope_id TEXT,session_id TEXT)');db.executemany('INSERT INTO attention_items VALUES(?,?,?)',items)
query='SELECT * FROM attention_items WHERE scope_id=? AND item_id>? ORDER BY item_id LIMIT ?'
page1=db.execute(query,(scope,'',100)).fetchall();page2=db.execute(query,(scope,page1[-1][0],100)).fetchall();exact=db.execute('SELECT * FROM attention_items WHERE scope_id=? AND item_id=?',(scope,items[0][0])).fetchone()
assert len(page1)==100 and len(page2)==1 and all(x[2]!='s0000' for x in page1) and page2[0][2]=='s0000' and exact==items[0]
print(json.dumps({'scope':'synthetic exact-query counterexample; no production observer or live CI DB executed','seed':seed,'home_id':home,'repo_path':'/synthetic/repo','scope_id':scope,'released_item_id':items[0][0],'rows_total':101,'first_page_rows':len(page1),'first_page_contains_s0000':False,'second_page':page2,'getItem_result':exact,'demonstrates':'First-page false does not imply record deletion; exact identity lookup retains the item.','limits':'CI did not preserve its random scope_id or DB, so its specific ordering is inferred from source and failure, not observed.'},indent=2))
