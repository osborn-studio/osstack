import { mkdirSync, realpathSync } from 'node:fs';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const repo=process.argv[2], fixture=process.argv[3];
mkdirSync(fixture,{recursive:false});
const root=realpathSync(fixture);
const {openDb}=await import(pathToFileURL(join(repo,'packages/core/dist/state/db.js')));
const {AttentionStore,attentionDigest}=await import(pathToFileURL(join(repo,'packages/core/dist/state/attention-store.js')));
const {AttentionObserver}=await import(pathToFileURL(join(repo,'packages/core/dist/state/attention-observer.js')));
const db=openDb({path:join(root,'db')});
try {
 db.exec("INSERT INTO tasks(task_id,title,status,created_at,updated_at) VALUES('t','task','running',1,1); INSERT INTO runs(run_id,task_id,session_id,agent_id,capability_id,phase,started_at) VALUES('r','t','s','codex-cli','code','execute',1)");
 for(let i=0;i<101;i++){
  const id=`s${String(i).padStart(4,'0')}`;
  db.prepare("INSERT INTO agent_sessions(session_id,task_id,run_id,agent_id,request_sha256,repo_path,state,resume_supported,version,updated_at) VALUES(?,'t','r','codex-cli','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',?,'awaiting_decision',1,1,1)").run(id,root);
  db.prepare("INSERT INTO session_turns(turn_id,session_id,ordinal,state,decision_json,created_at,updated_at) VALUES(?,?,1,'awaiting_decision',?,1,1)").run(`turn${i}`,id,JSON.stringify({decision_id:'d',question:'Choose?',choices:[]}));
 }
 const store=new AttentionStore(db,join(root,'db'));const owner=store.claimOwner('a');const scope=store.registerScope(owner,'t',root);const observer=new AttentionObserver(store,owner);
 const otherIds=Array.from({length:100},(_,j)=>{const i=j+1;return attentionDigest([scope.scope_id,`s${String(i).padStart(4,'0')}`,`turn${i}`,'d']);});
 const maxOther=otherIds.sort().at(-1);let decisionId,itemId,attempts=0;
 for(;attempts<100000;attempts++){decisionId=`fixture-${attempts}`;itemId=attentionDigest([scope.scope_id,'s0000','turn0',decisionId]);if(itemId>maxOther)break;}
 assert.ok(attempts<100000);
 db.prepare("UPDATE session_turns SET decision_json=? WHERE session_id='s0000'").run(JSON.stringify({decision_id:decisionId,question:'Choose?',choices:[]}));
 observer.tick(1000);
 const before=store.listItems(scope.scope_id).find(x=>x.session_id==='s0000');assert.ok(before);assert.equal(before.item_id,itemId);
 assert.equal(db.prepare('SELECT COUNT(*) n FROM attention_items').get().n,100);
 store.release(owner,scope.scope_id,'session','s0000',1);observer.tick(2000);
 const page1=store.listItems(scope.scope_id),page2=store.listItems(scope.scope_id,page1.at(-1).item_id),exact=store.getItem(scope.scope_id,itemId);
 assert.equal(page1.length,100);assert.equal(page1.some(x=>x.session_id==='s0000'),false);assert.equal(page2.length,1);assert.equal(page2[0].session_id,'s0000');assert.deepEqual(exact,before);
 assert.deepEqual(db.prepare("SELECT admitted FROM attention_subjects WHERE subject_id='s0100'").get(),{admitted:1});assert.deepEqual(db.prepare("SELECT admitted FROM attention_subjects WHERE subject_id='s0000'").get(),{admitted:0});assert.equal(observer.inventory(scope.scope_id,2000).coverage,'degraded');assert.equal(db.prepare('SELECT COUNT(*) n FROM attention_items').get().n,101);
 console.log(JSON.stringify({result:'PASS_counterexample_reproduced',scope:'real compiled AttentionObserver/AttentionStore; fixture-only decision_id search, not reconstruction of CI random state',root,scope_id:scope.scope_id,fixture_decision_id:decisionId,search_attempts:attempts+1,item_id:itemId,first_tick_total:100,final_total:101,first_page_count:page1.length,first_page_s0000:false,second_page_session_ids:page2.map(x=>x.session_id),exact_item_equal_before:true,release_admitted:0,new_admitted:1,coverage:'degraded',database_retained_for_audit:true},null,2));
}finally{db.close();}
