from pathlib import Path
import json,hashlib,subprocess,datetime,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'harness'))
from common import inventory
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
minimal={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','HOME':'/Users/osborn','LANG':'en_US.UTF-8'}
binaries=[Path('/opt/homebrew/bin/codex'),Path('/opt/homebrew/lib/node_modules/@openai/codex/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex'),Path('/opt/homebrew/bin/claude'),Path('/opt/homebrew/opt/node@22/bin/node')]
versions={h:subprocess.check_output(['/opt/homebrew/bin/'+h,'--version'],env=minimal,text=True).strip()for h in ['codex','claude']}
save(R/'host-binaries.json',{'versions':versions,'files':[{'path':str(p),'resolved_path':str(p.resolve()),'sha256':sha(p)}for p in binaries]})
counts={}
for h in ['codex','claude']:
 c=R/'runs'/f'{h}-readiness';inv=inventory(c/'workspace');scope=json.loads((c/'state/read-scope.json').read_text())
 assert inv==json.loads((c/'state/workspace-inventory.json').read_text())
 counts[h]={'inventory_entries':len(inv),'regular_files':sum(x['type']=='file'for x in inv.values()),'required_paths':len(scope['required_once']),'provided_optional_references':len(scope['provided_but_not_required'])}
protocol={'status':'prepared_not_dispatched','card':'card_d520a214','source_sha':'04840eda89650f3c41c9605c9b9648bfc482182f','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'bounded single mode entry; four supplied synthetic PR snapshots; classification/planned next action only','budget':{'max_user_turns_per_host':1,'seconds':180,'retries':0,'target_words':[250,350],'hard_max_words':500,'count':'Python len(final.split())'},'input':'same request and four synthetic snapshots, required mode/PR-readiness/evidence once; no oracle/prior answers; no actual forge resources','workspace_counts':counts,'candidate_not_merged_qualification':'pinned author candidate, not a published/current-main claim','metadata':{'claude':'final context env=None/argv/settings/workspace zero-userturn init exit0,56 catalog=1 target+55 denied builtins','codex':'zero-userturn model/list exit0,unique visible default gpt-6.1-sol; not resolved execution identity'},'models':{'codex_recommended':'gpt-6.1-sol; root must select in approved guard','claude_requested':'claude-sonnet-5-5','actual':'record execution-reported identity if exposed; otherwise not_attested'},'current_calls':{'model_user_turns':0,'live_forge_calls_by_model':0,'product_tests':0,'preparation_export_calls':2},'launch_commands':{'codex':['python3',str(R/'harness/run_codex.py'),'readiness'],'claude':['python3',str(R/'harness/run_claude.py'),'run','readiness']},'guard_paths':{h:str(R/'harness'/f'dispatch-{h}-readiness.json')for h in ['codex','claude']},'approval':'root only, after new independent criteria+final supplement are frozen; false templates are not executable approvals','constraints':['No credentials read/copied/hashed; no environment enumeration; CLI authenticates internally','Claude env inherited; no assertion of authentication isolation','Codex read-only is not read containment; prompt+observed trace constrain reads, not OS fence','Explicit cat/read is not native Skill invocation; absent event does not prove unavailable skill','Workspace-only before/after inventory; owned private temp removal; no all-descendant/no-global-side-effects claim','Known original mode sibling ../osstack-agent/SKILL.md absent in bounded subset; references preserved, not full installation','Snapshot repository task may authorize future in-scope corrections; this current experiment authorizes no corrections or external actions','Preserve all final messages/events and judge completeness/ambiguity independently; never trim to pass500','No retries if userturn incomplete/formatfail/modelunavailable; no old failed record overwritten']}
save(R/'run-protocol.json',protocol)
(R/'RUN.md').write_text('''# Prepared PR-readiness probe

This is a new bounded read-only experiment, pinned to author source 04840eda89650f3c41c9605c9b9648bfc482182f. No model user turn has been sent. Both guard templates are approved:false outside their actual harness guard paths. Root must add the new independent criteria and final-context supplement bindings, explicitly choose Codex model, and authorize exact commands in run-protocol.json.

Each host receives the same request/four simulated PR snapshots, one canonical mode entry and intact shared references. Required paths are exact in inputs/index.json. Only PR-readiness/evidence are required methods; all other references are provided but optional. The original absent sibling agent link is declared. This is not full installation/native discovery qualification.

Claude same final authentication/settings context initialized with one mode plus55 builtin catalog entries and zero user turns. Codex metadata reported one visible default; execution identity remains separately observed. No credentials were read/copied/hashed or environment enumerated. Inherited authentication and read-only sandbox do not prove OS read isolation.

The model classifies snapshots and proposes next actions only. In-scope fix authority in a synthetic repository task never authorizes execution in this probe. No actual forge, CI rerun, tests, patch, approval, comment, rebase, merge or watcher. Four rows A–D plus short method/limitations note;250–350 target,500 hard Python split-word limit,180 seconds,one turn per host,zero retries.

Raw streams/results remain outside workspaces. Preserve every assistant message; a last-message convenience extraction cannot prove unique final. Native attribution must come from actual tool events/returned bytes. Preserve incomplete/limited/failure outcomes. Inventory and cleanup claims cover owned workspace/temporary paths only, not global state or all descendants. Old experiment records remain unchanged.
''')
allfiles=[p for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__'not in p.parts and p.name not in ['prepared-manifest.json'] and not p.name.startswith('dispatch-')]
for host in ['codex','claude']:
 c=R/'runs'/f'{host}-readiness'
 files=[p for p in allfiles if '/runs/'not in str(p) or c in p.parents]+binaries
 template={'approved':False,'runner_sha256':sha(R/'harness'/f'run_{host}.py'),'prompt_sha256':sha(R/'harness/readiness-prompt.txt'),'workspace_inventory':inventory(c/'workspace'),'frozen_files':[{'path':str(p),'sha256':sha(p)}for p in files],'required_independent_bindings':['criteria SHA pending C','final-context supplement SHA pending C'],'case':f'{host}-readiness'}
 if host=='codex':template['codex_model']='gpt-6.1-sol'
 save(R/f'dispatch-{host}-readiness.template.json',template)
files=[p for p in sorted(R.rglob('*'))if p.is_file()and '__pycache__'not in p.parts and p.name!='prepared-manifest.json']
save(R/'prepared-manifest.json',{'source':protocol['source_sha'],'status':'prepared_not_dispatched','files':[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]})
print(json.dumps(counts));print('protocol',sha(R/'run-protocol.json'));print('manifest',sha(R/'prepared-manifest.json'))
