from pathlib import Path
import json,hashlib,re,shlex
R=Path(__file__).resolve().parent
O=R
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,x):(O/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
report={'base':'95a33e371464fe48bf063afe17ed650852e925d5','status':'author_observation_draft_pending_independent_grade','event_index_base':0,'hosts':{}}
raw=[]
for host in ['codex','claude']:
 c=R/'runs'/f'{host}-readiness'; w=c/'workspace'; ev=c/'evidence'
 lines=(ev/'run.jsonl').read_bytes().splitlines(keepends=True)
 events=[json.loads(l) for l in lines]
 index=[];tools=[];reads=[]
 for i,(line,e) in enumerate(zip(lines,events)):
  row={'index':i,'line_number':i+1,'bytes':len(line),'sha256':sha(line),'type':e.get('type'),'subtype':e.get('subtype')}
  if host=='codex':
   it=e.get('item',{});row.update(item_id=it.get('id'),item_type=it.get('type'))
   if it.get('type')=='command_execution':row.update(command=it['command'],exit_code=it.get('exit_code'),output_sha256=sha(it.get('aggregated_output','').encode()))
   if e.get('type')=='item.completed' and it.get('type')=='command_execution':
    shell=shlex.split(it['command']);args=shlex.split(shell[-1]);assert args[0]=='cat'
    files=args[1:]; data=b''.join((w/p).read_bytes() for p in files)
    exact=data==it['aggregated_output'].encode()
    tools.append({'event':i,'name':'command_execution','command':it['command'],'exit_code':it['exit_code'],'only_cat_of_provided_files':True,'aggregate_exact_bytes':exact})
    reads.extend({'path':p,'event':i,'sha256':sha((w/p).read_bytes()),'byte_match':exact,'transport':'concatenated_cat'} for p in files)
  else:
   row['content_types']=[b.get('type') for b in e.get('message',{}).get('content',[])]
   for b in e.get('message',{}).get('content',[]):
    if b.get('type')=='tool_use':
     tools.append({'event':i,'id':b['id'],'name':b['name'],'input':b['input']})
     row.setdefault('tool_use',[]).append({'id':b['id'],'name':b['name'],'input':b['input']})
    if b.get('type')=='tool_result':row.setdefault('tool_result',[]).append({'id':b['tool_use_id'],'is_error':b.get('is_error',False),'content_sha256':sha(json.dumps(b.get('content'),ensure_ascii=False).encode())})
   f=e.get('tool_use_result',{}).get('file')
   if f:
    p=Path(f['filePath']);actual=f['content'].encode();expected=p.read_bytes()
    reads.append({'path':str(p.relative_to(w)),'event':i,'sha256':sha(expected),'returned_sha256':sha(actual),'byte_match':actual==expected,'startLine':f.get('startLine'),'numLines':f.get('numLines'),'totalLines':f.get('totalLines'),'transport':'Read_file_content'})
  index.append(row)
 if host=='codex':
  messages=[{'event':i,'text':e['item']['text'],'words':len(e['item']['text'].split())} for i,e in enumerate(events) if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
  final=messages[-1]['text'];actualmodel='not_attested';usage=events[-1].get('usage')
  selection={'reason':'event 2 is future-tense reading progress before tools; event 7 is completed four-case readiness answer immediately before turn.completed; preserve both, channel not exposed by stream','formal_unique_final_attestation':'unavailable','all_agent_message_words':sum(x['words'] for x in messages),'messages':messages}
 else:
  result=[(i,e) for i,e in enumerate(events) if e.get('type')=='result'];assert len(result)==1
  ri,res=result[0];final=res['result'];actualmodel=list(res['modelUsage']);usage=res['usage']
  assistanttext=[(i,b['text']) for i,e in enumerate(events) for b in e.get('message',{}).get('content',[]) if e.get('type')=='assistant' and b.get('type')=='text']
  selection={'result_event':ri,'assistant_text_events':[i for i,t in assistanttext],'result_equals_assistant_text':'\n'.join(t for i,t in assistanttext)==final}
  skilltext='\n'.join(b['text'] for b in events[5]['message']['content'] if b.get('type')=='text')
  skill=(w/'.claude/skills/osstack-mode/SKILL.md').read_text();body=skill.split('---',2)[2].lstrip('\n')
  args=events[3]['message']['content'][0]['input']['args']
  expected=f'Base directory for this skill: {w}/.claude/skills/osstack-mode\n\n'+body+'\n\nARGUMENTS: '+args
  reads.append({'path':'.claude/skills/osstack-mode/SKILL.md','event':5,'transport':'native_Skill_body_without_frontmatter','byte_match':skilltext==expected,'sha256':sha(body.encode()),'scope':'body exact; frontmatter excluded; native base-directory prefix and ARGUMENTS suffix checked explicitly','arguments':args})
 (O/f'{host}-final.txt').write_text(final)
 before=json.loads((ev/'run-before.json').read_text());after=json.loads((ev/'run-after.json').read_text())
 required=json.loads((c/'state/read-scope.json').read_text())['required_once']
 data={'stream_events':len(events),'tools':tools,'reads':reads,'required_paths':required,'missing_required_paths':sorted(set(required)-{x['path'] for x in reads}),'all_returned_bytes_match':all(x['byte_match'] for x in reads),'words':len(final.split()),'hard_word_cap_pass':len(final.split())<=500,'advisory_250_350':250<=len(final.split())<=350,'final_selection':selection,'actual_model':actualmodel,'usage':usage,'inventory_entries':len(before),'inventory_unchanged':before==after,'private_home_absent_at_analysis':not (c/'private-home').exists(),'runner_result':json.loads((ev/'run-result.json').read_text())}
 report['hosts'][host]=data;dump(f'{host}-events.json',index)
 for p in sorted(ev.iterdir()):
  if p.is_file():raw.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
dump('observations.json',report);dump('raw-evidence-manifest.json',{'files':raw})
print(json.dumps({h:{k:d[k] for k in ['stream_events','words','all_returned_bytes_match','missing_required_paths','inventory_unchanged','private_home_absent_at_analysis']} for h,d in report['hosts'].items()},indent=2))
