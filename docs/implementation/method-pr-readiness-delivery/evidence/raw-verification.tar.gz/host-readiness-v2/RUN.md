# Prepared PR-readiness probe

This is a new bounded read-only experiment, pinned to author source 95a33e371464fe48bf063afe17ed650852e925d5. No model user turn has been sent. Both guard templates are approved:false outside their actual harness guard paths. Root must add the new independent criteria and final-context supplement bindings, explicitly choose Codex model, and authorize exact commands in run-protocol.json.

Each host receives the same request/four simulated PR snapshots, one canonical mode entry and intact shared references. Required paths are exact in inputs/index.json. Only PR-readiness/evidence are required methods; all other references are provided but optional. The original absent sibling agent link is declared. This is not full installation/native discovery qualification.

Claude same final authentication/settings context initialized with one mode plus55 builtin catalog entries and zero user turns. Codex metadata reported one visible default; execution identity remains separately observed. No credentials were read/copied/hashed or environment enumerated. Inherited authentication and read-only sandbox do not prove OS read isolation.

The model classifies snapshots and proposes next actions only. In-scope fix authority in a synthetic repository task never authorizes execution in this probe. No actual forge, CI rerun, tests, patch, approval, comment, rebase, merge or watcher. Four rows A–D plus short method/limitations note;250–350 target,500 hard Python split-word limit,180 seconds,one turn per host,zero retries.

Raw streams/results remain outside workspaces. Preserve every assistant message; a last-message convenience extraction cannot prove unique final. Native attribution must come from actual tool events/returned bytes. Preserve incomplete/limited/failure outcomes. Inventory and cleanup claims cover owned workspace/temporary paths only, not global state or all descendants. Old experiment records remain unchanged.
