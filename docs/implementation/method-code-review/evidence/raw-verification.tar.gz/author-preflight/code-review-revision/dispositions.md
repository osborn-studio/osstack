# Sonnet review dispositions

Candidate `ac9d8e60422318fe66c23b08cfd148fe9c2963ff`; original root report remains unchanged.

- **B1 — confirmed_fixed**: README distinguishes author1d00 nine files from root1e ten method-related files, plus other root control records. PR295 provisional is historical; main709 and d63 trees verified equal. No change to root-owned EXPORT.
- **N1 — accepted_fixed**: Untrusted candidate tests/install scripts require owned isolated checkout/export under repo placement rules, no injected credentials and task-permitted network/writes. Unestablished boundary stays source-supported; no blanket new approval rule.
- **N2 — accepted_fixed**: Authorization and secret exposure added to relevant security lenses; omit secret values in findings/shared logs and use safe pointers or redacted excerpts.
- **N3 — accepted_fixed**: Derive intent from task/PR/commits/code; state uncertainty and bounded assumption; ask only if verdict or permitted scope would change.
- **N4 — accepted_fixed**: Existing review-and-fix authorization remains. Static-only correction requires a conclusive path; nearest feasible check is labeled, not misrepresented as reproduction. Push authority explicitly included.
- **N5 — accepted_fixed**: Guard/retry/cast masking an invariant added to root-cause lens; no blanket rewrite instruction.
- **N6 — accepted_fixed**: Footer points to canonical sources. sources.md adds fixed opening-a-PR inspected/not-imported link; no duplicate incomplete source list.
- **N7 — accepted_fixed_with_actual_rerun**: Existing reference existence/nonempty test renamed seven and includes code-review. Actual rerun reports77pass0fail0skip. Navigation link-label test retained and explicitly not semantic model evaluation.
- **N8 — accepted_fixed**: Historical77/56/5 author results explicitly bound to1d00 and immutable148-member bundle hash. Later revisions require separate records; scratch locator not evidence authentication.
- **N9 — checked_no_additional_change**: rg scanned method materials and related implementation docs. Only author-tree EXPORT historical four-method ca95 observation caveat (root already updated later-addition wording) and an old audit six-publication-findings heading remain. Neither is a current six-method capability claim. No immutable old evidence edited.

Actual focused rerun:77 passed,0 failed,0 skipped. No model, driver or full-suite invocation. Original author archive remains immutable.
