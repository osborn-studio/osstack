# Next slice recommendation

Implement one shared **code-review** method, not another general evaluation tool. Current six methods can investigate or modify code but lack a review deliverable with exact candidate scope, concrete execution paths, finding disposition and honest no-finding limits. The pinned upstream interrogate rubric and lead judgment provide that capability.

Read-only review is the default only for review-only requests. Existing review-and-fix authorization continues without redundant approval. The method should trace each finding to a reachable trigger and user impact, separate observed failures from source reasoning, and disposition disagreements by evidence rather than reviewer votes. Optional authorized reviewers remain actual host tools, not a new model panel or principal.

Six core files plus at most three consistency/delivery files are listed in proposal.json. Exporter implementation, runtime, gates, ledger, CI and package scripts remain untouched. A text routing test establishes discoverable instructions; only a future real host run establishes use.

For the next packet experiment, reuse scratch harness and existing projection checkPacket. Copy only its exact two files. Check raw final response length and explicitly frozen format mechanically, while keeping native selection, meaning and identity independently evidence-based. Do not build a second packet schema, generic trace scorer, authentication layer, automatic repair/retry loop or word truncator. The historical Claude 507-word response remains failed under its original 500-word rule.

No candidate implementation, model call, driver invocation, full test or product file edit occurred during this preflight. Source byte hashes are recorded in proposal.json.
