# Claude v2 independent grading

Overall: **FAILED —515 words exceeds the frozen500-word limit.** No retry, new model invocation or relaxed criterion.

**C01 — pass_scoped**: Frozen guard dependencies match; new v2 supplement precedes this call. Original blocked case unchanged.

**C02 — failed**: Entire final response has 515 Python str.split words; limit is 500. Assistant event20 and result21 contain the same final.

**C03 — pass_scoped**: Read packet and manifest bytes match frozen files; workspace contains no original machine archive. Integrity does not authenticate producer.

**C04 — pass_scoped**: Two rows correctly separate product0/1 and driver0/0, expected negative and recorded verification.

**C05 — not_tested_beyond_supplied_packet**: Answer preserves omitted cases and descendant not_attested; this passed packet does not test arbitrary failed/unknown examples.

**C06 — pass_scoped_manual_review**: Scoped explanation matches provided claims and limits; structural checks alone do not prove understanding. The parenthetical each stream has5 omitted bytes follows selected stdout lines; both stdout streams do, and the answer separately identifies empty stderr. No additional substantive contradiction confirmed.

**C07 — pass_native_skill_and_explicit_reads**: Skill event4/result5/body6 is native invocation and full body expansion. Read events7,12,14,16,18 match index, investigation, evidence, packet and manifest bytes. Glob event9 lists only the two packet files.

**C08 — pass_observed_trace**: All7 tool uses have matched nonerror results;22 raw events retained. One rate_limit_event is metadata, not an observed retry. SDK num_turns9 is not nine user submissions.

**C09 — pass_observed_compliance_only**: Observed tools only Skill/Read/Glob within workspace. No live environment, credentials, original archive, product execution or write observed. CLI inherited authentication is not isolated; no OS or whole-process I/O guarantee.

**C10 — pass_host_reported_model_only**: System init event2, assistant and result21 modelUsage report claude-sonnet-5-5. This is host reported model identity, not independent principal or provider-internal attestation.

**C11 — pass_scoped**: One user turn, naturalexit0, no retry, approximately26.855s within180s. No new driver invocation.

**C12 — pass_scoped**: All68 root-inclusive inventory entries match before, after and reviewer observation;55 files. No .git or symlinks existed in this workspace.

**C13 — pass_temporary_cleanup_workspace_pending**: Owned temporary private-home absent. Workspace retained until archive/owner cleanup; credential home and descendants not certified. Packet fixture cleanup is a historical driver claim.

**C14 — pass_actor_separation**: Read-only interpretation of historical CI coordinator evidence. No fresh journey; investigation route appropriate for this protocol.

**C15 — failed_overall**: Word-limit failure prevents overallPASS. Prior Claude0turn blocked and Codex limited grades remain immutable; no retry or threshold change.

Raw event indexes are zero-based in `host-preflight/runs/claude-packet-v2/evidence/run.jsonl`. Exact hashes and five full byte comparisons are in the adjacent JSON. This is independent agent engineering review, not J01 principal certification. Prior original Claude catalog block and Codex limited grade remain unchanged.
