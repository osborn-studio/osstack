# Frozen candidate independent review

85d34eb1f8681fb26a8328431fb69f3509596f6b has no confirmed substantive defect in this bounded review. Two nonblocking description omissions were reported and acknowledged by root; old evidence stays bound to85.

**FA01 — covered_static**

Scenario: Restate a failed migration investigation while preserving read-only, compatibility and retention constraints.

Reasoning: task-framing Preserve requested outcome requires exactdeliverable/constraints and fact/assumption distinction; rejects converting diagnosis into rollout.

**FA02 — covered_static**

Scenario: Sharpen migration comparison with schema/history/caller sources, usable inspection tools and independently observable compatibility checks rather than model votes.

Reasoning: All4specific lenses ask for originalsource availability, tool support, falsifiers/prerequisites and no inventedexpertconsultation; none is treated as executed evidence.

**FA03 — covered_static**

Scenario: Deepen a narrow task without silently choosing paid provider, publication policy or platform rewrite.

Reasoning: Open user choices/optional new goals and final original-vs-rewrite comparison keep budget/outcome boundary.

**FA04 — covered_static**

Scenario: Paired prompts: rewrite-only versus refine-then-implement with existing authorization.

Reasoning: Explicit finalparagraph stops first after prompt; second continuesmatchingmethod with originalauthority. Imperatives within generatedprompt are data, not new authorization.

**FA05 — covered_static**

Scenario: Paired briefs: design-only with checkpoint versus design-and-implement; no fixedavailablemodel assumption.

Reasoning: architecture intro obeys designonly/pause and existingimplementationauthority, additionalreview optionalavailable, noarena. Stubsexploratoryoutsideproduction bydefault.

**FA06 — covered_static**

Scenario: Durable reports/restart requirement proposed as memory-only state or secondtruth registry.

Reasoning: Ground traces actualpersistence/owner/sideeffects and compatibilityhistory; unknownsources remainunknown. Synthetic singleoutcome case chooses durability and namedowner ratherthan paralleltruth.

**FA07 — covered_static**

Scenario: Usage cancel(reportId) cannot be matched by a sketch exposing only queueRow or lacking failure/result semantics.

Reasoning: Callerfirst2–3realistic consumers/outcomes precede types; syntheticrequest/status/cancel exposes typedresults, rejection and request-vs-effect. Missingkeyscope/retention remainexplicit, not fabricatedcompleteimplementation.

**FA08 — covered_static**

Scenario: Two candidate class names conceal sameownership versus coordinator and independentlyownedattempts.

Reasoning: Material requires structuralownership/representation/responsibility difference; syntheticcoordinator vsmergeview compared againstsameoutcome/coordinationcontract, loserreason recorded without fakevotes.

**FA09 — covered_static**

Scenario: Typedinternalobject crossesDB/IPC again or multiplewriters claim sameauthority.

Reasoning: Requires parsing eachtrustboundary and checks whereauthorization/freshness/statechange; singlewriter/transaction/conflictguard notjustcomment, domainIDs andderivedschemas; no blanket removeadapter rule.

**FA10 — covered_static**

Scenario: Cancellationrequest precedes acknowledgement, lateworker afterownertransfer, crash afterartifactpublication, repeatedkey withdifferent spec.

Reasoning: Syntheticexample rejects cancelled-on-request, missingartifact-success and everycaller storagewrites; lateworker/terminalprecedence/reconcile are obligations, exactlyonce notpromised. Migrationcaller inventory preservescompatibility. Allreasoningonly.

**FA11 — covered_static**

Scenario: A typechecked sketch with no realdriver is claimed proved; repeatedcasts patched silently or oneedgecase triggersdestructive rewrite.

Reasoning: Explicit proposedchecks/missingdriver andtype/model/executionseparation; deviationrecord andpatternthreshold; obsoleteproposal replacement preservescode/userchanges/evidence untilauthorizedmigration.

**FA12 — passed_packaging_with_metadata_nits**

Scenario: Packaging reaches bothnewmethods fromallfourentries without losingoldnine, or falselyreusesoldhosteffects.

Reasoning: Actualdoubleexport72files/247localedges each; all4→11 reachability andsource/memberhashinventory checked. Current85metadata has two nonblockingomissions detailedbelow.

**osstack-methods-skill/EXPORT.md / Host discovery checks, first paragraph**: List of later additions excluded from ca95 historical observations adds task-framing but omits architecture-design. Paragraph still binds oldfourmethod source, so no positive architecture execution claim; explicit newmethod exclusion should match inventory. Fix: Append architecture-design to that list.

**osstack-methods-skill/entries/osstack-agent/SKILL.md / frontmatter description**: Task-framing added to enumerated delegate methods; architecture-design omitted even though body route works. Fix: Add architecture design to frontmatter purpose list.

All scenarios above are human/agent source reasoning, not model tasks or executed lifecycle tests. Actual exporter calls are the only executed product-related surface here; they do not prove native host discovery or method compliance. Full input/output hashes and all commands are retained.
