from pathlib import Path
import json,hashlib,re,urllib.parse,collections,datetime
D=Path(__file__).resolve().parent;S=D/'snapshot/osstack-methods-skill';sha=lambda b:hashlib.sha256(b).hexdigest();results={};normalized={}
methods=['task-framing','architecture-design','change-impact','performance-measurement','code-review','feature','refactoring','bug-fix','investigation','create-verification','maintain-verification'];entries=['osstack-mode','osstack-help','setup-osstack','osstack-agent']
for h in ['codex','claude']:
 root=D/('export-'+h);receipt=json.loads((D/(h+'-receipt.json')).read_text());m=json.loads((root/'manifest.json').read_text());assert receipt['manifest_sha256']==sha((root/'manifest.json').read_bytes());assert receipt['file_count']==72 and len(m['files'])==72
 files={p.relative_to(root).as_posix():p for p in root.rglob('*')if p.is_file()};assert set(files)=={'manifest.json'}|{f['path']for f in m['files']}
 for f in m['source_files']:
  b=(S/f['path']).read_bytes();assert sha(b)==f['sha256']and len(b)==f['bytes']
 for f in m['files']:
  b=files[f['path']].read_bytes();assert sha(b)==f['sha256']and len(b)==f['bytes'];assert sha((S/f['source_path']).read_bytes())==f['source_sha256']
 graph={};edges=[]
 for path,p in files.items():
  if p.suffix!='.md':continue
  text=p.read_text();clean=[];fence=None
  for line in text.splitlines():
   if line.lstrip().startswith(('```','~~~')):fence=None if fence else line.lstrip()[:3];continue
   if fence is None:clean.append(line)
  dests=re.findall(r'\[[^\]\n]+\]\(([^)\n]+)\)','\n'.join(clean));targets=[]
  for target in dests:
   if target.startswith(('https:','http:','mailto:','#')):continue
   q=(p.parent/urllib.parse.unquote(target.split('#')[0])).resolve();assert q.is_relative_to(root.resolve()),(path,target);assert q.is_file(),(path,target);rel=q.relative_to(root.resolve()).as_posix();targets.append(rel);edges.append({'from':path,'to':rel,'href':target})
  graph[path]=targets
 paths={}
 for e in entries:
  start=m['namespace']+'/'+e+'/SKILL.md';queue=collections.deque([start]);seen={start:[]}
  while queue:
   current=queue.popleft()
   for n in graph.get(current,[]):
    if n not in seen:seen[n]=seen[current]+[n];queue.append(n)
  paths[e]={}
  for method in methods:
   options=[n for n in seen if n.endswith('/references/'+method+'.md')];assert options,(h,e,method);chosen=min(options,key=lambda n:len(seen[n]));paths[e][method]=[start]+seen[chosen]
 normalized[h]={f['path'].split('/skills/',1)[1]:files[f['path']].read_bytes()for f in m['files']}
 results[h]={'files':72,'local_link_edges':len(edges),'all_four_entries_reach_all_eleven_methods':True,'paths':paths,'edges':edges,'manifest_sha256':sha((root/'manifest.json').read_bytes())}
assert normalized['codex']==normalized['claude']
for n in ['SKILL.md','entries/osstack-mode/SKILL.md','entries/setup-osstack/SKILL.md']:assert 'eleven methods'in(S/n).read_text()or'eleven implemented shared methods'in(S/n).read_text()
(D/'graph-results.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':'85d34eb1f8681fb26a8328431fb69f3509596f6b','results':results,'cross_host_material_bytes_equal':True,'two_reference_changes_reviewed_separately':True,'parser_scope':'Independent inline Markdown links outside fenced examples in these actual canonical files; not a general Markdown validator or fragment qualification. Host execution/discovery untested.'},indent=2)+'\n');print(json.dumps({h:{k:v for k,v in r.items()if k not in ['paths','edges']}for h,r in results.items()}))
