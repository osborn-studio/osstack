from pathlib import Path
import subprocess,json,hashlib,datetime,re
D=Path(__file__).resolve().parent; R=D.parent; repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack'; old='85d34eb1f8681fb26a8328431fb69f3509596f6b'; new='035285cf26c6fe26a751cbbb93020b2f8cd5c1d8'; pin='99b609a72323b70204eab407c622f436e858e112'
sha=lambda b:hashlib.sha256(b).hexdigest(); commands=[]
def run(args,cwd=repo):
 p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=30,env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'}); n=len(commands); (D/f'delta-{n:02}.stdout').write_bytes(p.stdout);(D/f'delta-{n:02}.stderr').write_bytes(p.stderr);commands.append({'argv':args,'cwd':cwd,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)});assert p.returncode==0;return p.stdout
names=run(['/usr/bin/git','diff','--name-only',old,new]).decode().splitlines();diff=run(['/usr/bin/git','diff','--no-ext-diff',old,new]);assert len(names)==7 and all(x.endswith('.md') for x in names)
anchors=json.loads((R.parent/'architecture/source-anchors.json').read_text()); additional=[]
for name in ['make-operations-idempotent','exhaust-the-design-space','encode-lessons-in-structure','redesign-from-first-principles']:
 path=f'pstack/skills/principle-{name}/SKILL.md'; data=run(['/usr/bin/git','show',pin+':'+path],'/Volumes/AIMATE_WORK/Developer/CodeX/cursor-plugins');a=next(x for x in anchors if x['path']==path);assert sha(data)==a['sha256'] and len(data)==a['bytes'];additional.append({'path':path,'sha256':sha(data),'bytes':len(data),'matches_retained_author_anchor':True})
for name in ['in-your-own-words','sharpen','architect']:
 data=run(['/usr/bin/git','show',pin+f':pstack/skills/{name}/SKILL.md'],'/Volumes/AIMATE_WORK/Developer/CodeX/cursor-plugins');assert b'disable-model-invocation: true' in data
scratch=run(['/usr/bin/git','show','711c45e75264000bde859328bd7dc131f68461d1:packages/core/src/scratch.ts']).decode().splitlines();(D/'baseline-scratch-lines40-47.txt').write_text('\n'.join(f'{i+1}: {scratch[i]}' for i in range(39,47))+'\n')
oldrefs=R/'integrated-85d3/snapshot/osstack-methods-skill';newrefs=D/'snapshot/osstack-methods-skill'
assert (oldrefs/'references/task-framing.md').read_bytes()==(newrefs/'references/task-framing.md').read_bytes()
assert (oldrefs/'references/architecture-design.md').read_bytes()!=(newrefs/'references/architecture-design.md').read_bytes()
sourceold=(oldrefs/'references/sources.md').read_text();sourcenew=(newrefs/'references/sources.md').read_text();links=lambda s:re.findall(r'\]\((https://[^)]+)\)',s);added=set(links(sourcenew))-set(links(sourceold));assert len(added)==4
assert all(pin in u for u in added)
for host in ['codex','claude']:
 exported=list((D/f'export-{host}').rglob('sources.md'));assert len(exported)==4
 for f in exported:
  assert all(u in f.read_text() for u in added)
g=json.loads((D/'graph-results.json').read_text());prev=json.loads((R/'integrated-85d3/graph-results.json').read_text());
for host in ['codex','claude']:
 assert g['results'][host]['files']==72 and g['results'][host]['local_link_edges']==247
 assert g['results'][host]['all_four_entries_reach_all_eleven_methods']
 assert prev['results'][host]['local_link_edges']==247
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':new,'compared_to':old,'criteria_sha256':sha((R/'criteria.json').read_bytes()),'result':'no_confirmed_defect_in_reviewed_delta','changed_paths':names,'commands':commands,'additional_pinned_sources':additional,'new_external_urls':sorted(added),'per_host_new_external_link_occurrences':16,'local_graph_edges_unchanged':247,'exports':{h:{k:g['results'][h][k] for k in ['files','local_link_edges','all_four_entries_reach_all_eleven_methods','manifest_sha256']} for h in ['codex','claude']},'manual_dispositions':{'B1':'Four missing attribution URLs now point to exact retained upstream objects; all four exported copies contain each URL.','B2':'Prior optional-direct-navigation disposition unchanged; actual complete local graph still reaches all eleven methods. No new direct-label test requirement inferred.','B3':'Earlier ca95 host observations explicitly exclude architecture-design as well as other later methods.','B4':'Delegated entry description now covers architecture design.','authorization':'Mode explicitly stops design-only at design/verification plan and preserves existing implementation authorization; selection is not execution authority. Upstream invocation-setting adaptation is accurately disclosed.','synthetic_lifecycle':'Pending cancellation marker and unknown identifier are stated as sketch requirements; request/effect distinction remains and no API implementation is claimed.','author_scope':'19 sources remain 14 upstream plus 5 repository; two additional manual invariants supplement the cancellation lifecycle example. Baseline allocator lines40-47 support typed allocation/later cleanup observation.','relocation':'Help architecture paragraph is relocated nearer routing without semantic expansion.'},'unchanged_task_framing_body':True,'architecture_body_changed_intentionally':True,'scope_limits':['New actual exporter executions and independent byte/inventory/link checks only.','Manual semantic delta review is not model behavior, native discovery, runtime implementation, formal oracle or J01 gate qualification.','No full package tests, product driver, models, DB or management access.','Earlier 85d3 execution/report remains bound to its original candidate; historical semantic checks were not rerun or relabeled.']}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(D/'report.md').write_text('''# Final independent delta and export check

Candidate `035285cf26c6fe26a751cbbb93020b2f8cd5c1d8`; comparison `85d34eb1f8681fb26a8328431fb69f3509596f6b`. No confirmed defect in the seven-document delta.

B1/B3/B4 are closed: four pinned attribution sources match retained original bytes, the earlier host experiment expressly excludes architecture design, and the delegated entry description includes it. B2 remains optional test strengthening rather than a broken reachability contract. The mode preserves both design-only and existing implementation authority. The new cancellation marker/unknown identifier are explicitly synthetic sketch requirements, not implemented APIs. Author scope accurately separates 14 upstream and 5 repository files and the two additional manual invariant examples.

Fresh real exports at the new SHA pass complete member hash/byte/inventory and local-link checks: **72 files and 247 local link edges per host**, four entries reaching all eleven methods; cross-host material bytes match. Local edges did **not** increase: the four added external provenance URLs add 16 external-link occurrences in each host's four source-index copies. No external network resolution was claimed; targets were checked against exact Git objects.

`execution.json` records actual exporter commands; `graph-results.json` records all edges/paths; `report.json` records delta commands, provenance hashes and dispositions. Previous candidate evidence remains unchanged. These are packaging execution and manual static review, not native host comprehension or runtime/formal gate evidence. No product tests/models were run.
''')
print(json.dumps({'report_sha256':sha((D/'report.json').read_bytes()),'delta_commands':len(commands),'new_external_links':len(added)}))
