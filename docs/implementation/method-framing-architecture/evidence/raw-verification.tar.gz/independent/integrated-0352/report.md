# Final independent delta and export check

Candidate `035285cf26c6fe26a751cbbb93020b2f8cd5c1d8`; comparison `85d34eb1f8681fb26a8328431fb69f3509596f6b`. No confirmed defect in the seven-document delta.

B1/B3/B4 are closed: four pinned attribution sources match retained original bytes, the earlier host experiment expressly excludes architecture design, and the delegated entry description includes it. B2 remains optional test strengthening rather than a broken reachability contract. The mode preserves both design-only and existing implementation authority. The new cancellation marker/unknown identifier are explicitly synthetic sketch requirements, not implemented APIs. Author scope accurately separates 14 upstream and 5 repository files and the two additional manual invariant examples.

Fresh real exports at the new SHA pass complete member hash/byte/inventory and local-link checks: **72 files and 247 local link edges per host**, four entries reaching all eleven methods; cross-host material bytes match. Local edges did **not** increase: the four added external provenance URLs add 16 external-link occurrences in each host's four source-index copies. No external network resolution was claimed; targets were checked against exact Git objects.

`execution.json` records actual exporter commands; `graph-results.json` records all edges/paths; `report.json` records delta commands, provenance hashes and dispositions. Previous candidate evidence remains unchanged. These are packaging execution and manual static review, not native host comprehension or runtime/formal gate evidence. No product tests/models were run.
