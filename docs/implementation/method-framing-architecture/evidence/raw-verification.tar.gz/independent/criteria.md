# Frozen framing and architecture acceptance

Prospective independent engineering material acceptance, before author candidates. No model/full/product/benchmark execution. No formal independent-principal or runtime gate claim.

## FA01 — Restate goal and uncertainty accurately

Restate intended outcome/problem, present scope/constraints and what success means in own words. Separate facts from assumptions and unresolved questions; use available context first. Ask only consequential missing choices while continuing independent work.

Counterexample: User wants read-only failure diagnosis; restatement silently becomes rewrite/production rollout, or paraphrases symptoms while dropping data-retention constraint.

Source: in-your-own-words; user priority list; baseline scope.

## FA02 — Deepen through four concrete lenses

Sharpen adds relevant expert omissions, raw primary material, specific suitable methods/tools, and independent observable correctness evidence. Tie each to original outcome rather than generic namedropping; distinguish source availability and intended vs executed checks.

Counterexample: User asks migration analysis; answer lists expert personas and model agreement but no original migration/schema/caller source or checkable compatibility counterexample.

Source: sharpen four questions; user original top-expert/raw-source/tools/external-proof request.

## FA03 — Keep user choices open and avoid scope inflation

Rewritten prompt preserves budget/time/resources, constraints and choices belonging to user. Expose meaningful alternatives without silently choosing deployment/provider/business policy or turning small problem into platform project. End with a usable rewritten prompt when requested.

Counterexample: Rewrite chooses paid provider, enables monitoring or demands building universal agent platform merely to deepen a narrow task.

Source: sharpen deeper-not-bigger/leave choices open.

## FA04 — Prompt-only means no underlying execution

A request only to restate/sharpen/rewrite returns that artifact; proposal text does not become permission to run implementation, models, benchmarks, installs or publish. If original task explicitly says sharpen then execute, preserve that existing authority and continue within it, rather than treating all framing as mandatory stop.

Counterexample: Rewrite-only request produces prompt then executes it; converse authorized improve-and-implement task is blocked for fresh blanket approval after rewriting.

Source: user priority list sharpen itself not execute; baseline authority.

## FA05 — Honor design-only and existing implementation authority

Architecture request honors explicit design-only/checkpoint, producing reviewable design without product implementation. Existing design-and-implement authorization is not revoked by a generic agree phase; no universal approval gate. Additional models/delegates require real host support and existing authority; no fixed model/mandatoryarena or fabricated identity.

Counterexample: Upstream default implementation overrides stop-before-code; or already-authorized implementation is forced to await new human sign-off; unsupported arena claimed executed.

Source: architect Agree opt-in; baseline authority; deliberate host adaptation.

## FA06 — Ground real requirements and integration boundaries

Inspect relevant actual system types/callers/dataflow/history when ownership changes; identify real constraints/invariants and uncertainty. Greenfield skips irrelevant historical grounding only. Name evidence behind design rather than only filename lists.

Counterexample: Design assumes memory state with a durable restart requirement, or proposes replacing authoritative DB with parallel registry without examining existing owner.

Source: architect Ground; main evidence/feature.

## FA07 — Caller-first coherent sketch

Write realistic usage/call sites before deriving public signatures/domain types/module map. Inputs, returns/errors and intended effects agree across usage and sketch; dominant access patterns have an actual data structure and invariants, not promises to add indexes later. Mark pseudocode/unimplemented artifacts honestly.

Counterexample: Public cancel(jobId) appears in usage but sketch exposes only internalcancel(queueRow), omits return/error, or has no caller; working-looking stub silently treated as implementation.

Source: architect outputs/runner/rationale; foundational.

## FA08 — Compare structurally different choices

Consider at least two meaningful architectural shapes before selecting; compare ownership, complexity hidden/exposed, tradeoffs and requirements. Record why base chosen, adaptations/rejections, and constraints if only one shape viable. Naming variations are not independent alternatives; models need not be multiple.

Counterexample: Two diagrams differ only class names; more votes select design without requirements or tradeoff evidence; forcedsecondarchitecture adds gratuitous infrastructure.

Source: architect design-twice/redflags/rationale.

## FA09 — Ownership, interfaces and boundary discipline

Give each invariant/state an authority; derive rather than hand-sync shapes, parse external untyped input into domain model at actual boundaries, encode relevant impossible states/semantic IDs. Keep transport/storage details private where they are implementation detail. Check shallow/pass-through/temporal layers/importableinternals against real costs, not dogmatic no-adapter rule.

Counterexample: Two writers mutate same queue without coordination; UserId/OrderId mixed; public wire object leaks representation; blanket trust-types drops validation at new external boundary.

Source: redflags; type-system/boundary/foundational.

## FA10 — Lifecycle and concurrency obligations

Where relevant show ownership/lifetime, creation/use/teardown, failures, cancellation/retry/replay/crash effects and concurrent actors. Prefer justified isolation/merge over reflex locks; include existing compatibility and migration consumers before deleting old route. Do not import upstream unconditional remove-legacy as extra destructive authority.

Counterexample: Retry duplicates side effect, callback outlives disposedowner, or schema migration deletes old API while unchanged consumer still needs it.

Source: runner sharedstate/idempotency; redflags splitownership; baseline refactoring scope.

## FA11 — Falsifiable validation and revision triggers

Bind acceptance examples/negative controls to caller behavior and key invariants. Distinguish proposed checks, static/compiler checks, real execution and formal claims. Record deviations on new candidate and re-ground repeated friction rather than patching indefinitely; preserve old evidence and bounded next implementation slice.

Counterexample: Architecture called correct from prose/types only; tests assert internally manufactured state; implementation violates sketch silently; repeatedcasts/workarounds ignored or oneedgecase forces entire rewrite.

Source: architect Implement/Scrap; main evidence; behavior verification priority.

## FA12 — Actual packaging and honest capability coverage

New methods remain reachable through intended routes and real Codex/Claude four-entry exports, preserve existing nine methods, consistent finalmethod counts and fixed upstream attribution. Relative links/source hashes checked on exact candidate; root integration may provide shared wiring. Text/link tests establish packaging, not actual host obedience/native discovery/effectiveness/runtime MethodBinding or formal gate.

Counterexample: Newmethod text exists but help/delegate points elsewhere, onehost missingref, stale counts, or prior host experiments relabeled evidence for new methods.

Source: baseline actual export tests/source/EXPORT; user mapping ≠ fullproduct feature list.

Validation uses concrete semantic walkthroughs and real exporter graphs, not keyword tests as evidence of model behavior. User priority summary is input context; raw upstreamGit supplies original implementation meaning.
