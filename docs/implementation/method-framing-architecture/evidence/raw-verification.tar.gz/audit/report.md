# OSStack audit at 85d34eb1f8681fb26a8328431fb69f3509596f6b

**Verdict: REVISE.** There are four small blocking findings and no design-level defect. This was a static read of the supplied text only: nothing was executed, and I did not check any hash. Files that were not supplied were not reviewed: `feature.md`, `host-usage.md`, the other method references, and the exporter library.

## What holds up

- **Method count.** "Eleven" is consistent across `SKILL.md`, `osstack-mode`, `osstack-help` and `setup-osstack`. The `osstack-agent` list has 11 links, and the exporter test's reference list has 11 names.
- **Authority.** Design-only stays design-only, and existing implementation authority has no new gate (`architecture-design.md` ¶2, `osstack-help`, `osstack-agent`). Prompt-only versus refine-then-execute is handled consistently (`task-framing.md`, mode, help, agent). Redesign does not authorize deleting working code or compatibility paths.
- **Upstream defaults.** Fixed models, the arena, the file-count limit, automatic implementation and unconditional legacy removal are all explicitly not imported.
- **Synthetic material.** The report-service example is labelled invented. The README disclaims eleven-method navigation, host use and design quality.
- **Portability.** There are no host-specific tool names, the entry front matter is only name and description, and I saw no Markdown constructs the exporter's subset would refuse in the two new references.

## Blocking findings

**B1. Source attribution is incomplete for architecture-design.**
- **File:** `osstack-methods-skill/references/sources.md`, architecture list.
- **Problem:** The list ends at `[Migrate callers](…principle-migrate-callers-then-delete-legacy-apis/SKILL.md)`. The README says `principle-make-operations-idempotent`, `principle-exhaust-the-design-space`, `principle-encode-lessons-in-structure` and `principle-redesign-from-first-principles` were also read, and the method visibly uses them. Examples are the retry and crash reasoning, the two-candidate rule, and the re-ground and replace step.
- **Reachable problem:** A bundle carries only `sources.md`. A reader cannot trace that guidance upstream, and the README and `sources.md` disagree.
- **Smallest fix:** Add the four links at the same pin, using the existing `pstack/skills/<name>/SKILL.md` pattern. Confirm the names against the retained anchors.

**B2. Nothing tests the architecture-design routes or attribution directly.**
- **File:** `scripts/export-osstack-methods.test.mjs`.
- **Problem:** Code review, change impact and task framing each get a label-based test asserting one correct link from `SKILL.md`, mode, help and agent, plus a source-link test. Architecture design has neither test. The router test covers only feature and refactoring.
- **Cause:** The D2a graph check passes through `osstack-mode`, as its own comment admits: `// Every entry copies the method; graph reachability may go through mode in this four-entry bundle.` Its `endsWith` match can also be satisfied by a sibling entry's copy.
- **Reachable problem:** Dropping the Architecture link from `osstack-help`, `osstack-agent` or `SKILL.md` keeps the suite green. The same regression for the other three methods fails.
- **Smallest fix:**
  - Add a navigation test mirroring the code-review one. The label is `architecture design`, with targets `references/architecture-design.md` and `../../references/architecture-design.md`.
  - Add a `sources.md` test requiring the four architect URLs, plus the principle URLs once B1 is fixed, at the pinned commit.
  - Assert that `architecture-design.md` links `sources.md`.
  - Each entry currently has exactly one such link, so no prose change is needed.

**B3. `EXPORT.md` omits architecture-design from its list of unvalidated additions.**
- **Quote:** "they do not validate later feature/refactoring/code-review/change-impact/performance-measurement/task-framing additions."
- **Reachable problem:** The `ca95aba1` discovery observations could be read as covering the newest method.
- **Smallest fix:** Add `architecture-design` to that list.

**B4. The `osstack-agent` description omits architecture design.**
- **Quote:** "Use for a delegate's task framing, performance measurement review, change impact analysis, code review, feature, refactoring, investigation, bug fix, or verification-material task".
- **Reachable problem:** The description is the host's selection text. A delegated design-only brief is not named there, although every other entry description includes it.
- **Smallest fix:** Add "caller-first architecture design" to the description.

## Optional improvements

1. **Example does not model its own pending cancel.** In the `architecture-design.md` synthetic example, `ReportState` has no way to show a recorded but not yet applied cancellation. The example itself says that "A cancellation request alone does not make the report cancelled." It also has no unknown-id result. One clause fixes this, for example a `cancelRequested` marker on the running state.
2. **README counts to reconcile.** The architecture README says "two additional invariant violations", but the reference lists three. It also says "nineteen retained source hashes", while the README itself names 14 sources (4 architect files and 10 principles). That count may include the license or other files, so I am not asserting an error. The `scratch.ts` observation cannot be checked from the supplied material and the method does not use it, so either cite `file:line` or drop it.
3. **Upstream invocation mode.** The upstream `in-your-own-words`, `sharpen` and `architect` skills carry `disable-model-invocation: true`. OSStack makes these paths selectable through mode. `task-framing.md` limits its use to when the user asks, which is adequate, but the deviation is worth one line in `sources.md`.
4. **Design-only line in mode.** `osstack-mode` states prompt-only and review-only limits but has no design-only sentence. Help and agent do.
5. **Help placement.** The architecture paragraph in `osstack-help` is appended after the closing source-credit paragraph. Folding it into the routing paragraphs would read better.
6. **Tighter reachability assertion.** Scope the D2a `seen` assertion to the entry's own `references/` tree, so a sibling's copy cannot satisfy it.

## Limits of this review

- **Pending items.** Full-package regression and final independent exports are pending. Until they exist, no claim about "11 methods" in a real export, 68-file counts or manifest hashes is supported at this candidate.
- **Native discovery.** The tests cover export and navigation only. They do not show native host discovery or that a model follows the method, and none is claimed.
- **Status.** Not approved and not merged.