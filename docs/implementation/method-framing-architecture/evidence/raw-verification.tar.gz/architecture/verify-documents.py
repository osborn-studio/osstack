from pathlib import Path
import json,re,hashlib,subprocess
R=Path(__file__).parent
W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-architecture-design')
paths=['osstack-methods-skill/references/architecture-design.md','docs/implementation/method-architecture-design/README.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
links=[]
for name in paths:
 p=W/name;t=p.read_text();assert t.endswith('\n') and all(line.rstrip()==line for line in t.splitlines())
 for href in re.findall(r'\[[^\]]+\]\(([^)]+)\)',t):
  if '://'in href:continue
  assert (p.parent/href.split('#')[0]).resolve().is_file();links.append({'from':name,'href':href})
anchors=json.loads((R/'source-anchors.json').read_text())
for a in anchors:assert sha(R/('sources'if a['repository']=='cursor/plugins'else'baseline')/a['path'])==a['sha256']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''
print(json.dumps({'candidate':head,'links':links,'source_hashes_verified':len(anchors),'owned_files':[{'path':n,'sha256':sha(W/n)}for n in paths],'model_calls':0,'product_runs':0,'scope':'link/hash/whitespace verification only; manual synthetic analysis is not an executed behavioral test'},indent=2))
