from pathlib import Path
import subprocess,json,hashlib,re,datetime
D=Path(__file__).resolve().parent;repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';sha=lambda b:hashlib.sha256(b).hexdigest();commands=[]
def git(*args):
 p=subprocess.run(['/usr/bin/git',*args],cwd=repo,capture_output=True,timeout=30);n=len(commands);(D/f'{n:02}.stdout').write_bytes(p.stdout);(D/f'{n:02}.stderr').write_bytes(p.stderr);commands.append({'argv':['/usr/bin/git',*args],'cwd':repo,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)});assert p.returncode==0;return p.stdout
head=git('rev-parse','8ba3d98a').decode().strip();base=git('rev-parse','711c45e7').decode().strip();same={}
for path in ['packages','.github','pnpm-lock.yaml','package.json','pnpm-workspace.yaml','scripts/vitest-setup-scratch.ts']:
 a=git('rev-parse',head+':'+path).decode().strip();b=git('rev-parse',base+':'+path).decode().strip();assert a==b;same[path]=a
scriptdiff=git('diff','--name-only',base,head,'--','scripts').decode().splitlines();assert scriptdiff==['scripts/export-osstack-methods.test.mjs']
for path in ['packages/core/src/state/engineering-store.test.ts','packages/core/src/state/db.ts','packages/core/vitest.config.ts','.github/workflows/ci.yml']:
 data=git('show',head+':'+path);(D/(path.replace('/','__'))).write_bytes(data)
logs={'297':Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-impact-performance-20261028/ci297.log'),'298':D.parent/'full-attempt1.log','298-failed':D.parent/'failed.log'};inputs=[];excerpts={}
for label,path in logs.items():
 data=path.read_bytes();inputs.append({'path':str(path),'bytes':len(data),'sha256':sha(data)});out=[]
 for n,line in enumerate(data.decode().splitlines(),1):
  if not line.startswith('check\t'):continue
  if any(s in line for s in ['Current runner version','Version: 2026','Image: ubuntu','node: v','npm:','src/state/engineering-store.test.ts','upgrades canonical schema46','1300','1301']) and 'Lint' not in line and 'NPM install' not in line:
   out.append({'line':n,'raw':line})
 excerpts[label]=out
(D/'log-excerpts.json').write_text(json.dumps(excerpts,indent=2)+'\n')
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':head,'comparison_main':base,'identical_git_objects':same,'only_changed_script':scriptdiff,'inputs':inputs,'commands':commands,'observations':{'297':{'case_status':'passed','case_ms':1094,'file_ms':7429,'node':'22.23.4','runner_image':'ubuntu-24.04 20261025.353.1','runner_version':'2.338.0'},'298_attempt1':{'case_status':'timeout','case_ms_reported':5638,'timeout_ms':5000,'file_ms':17183,'core_passed':1300,'core_failed':1,'node':'22.23.3','runner_image':'ubuntu-24.04 20261012.334.1','runner_version':'2.338.0'}},'source_assessment':'Synchronous test at line162 creates owned file DB, executes all migration SQL<=46 and user_version pragmas without explicit encompassing transaction, closes it, opens via openDb, asserts version47 and receipt preservation/no legacy dispatch, finally closes. Default test budget is 5000ms; file config supplies scratch setup only. Timing includes fixture construction and upgrade/assertions, with no phase telemetry. openDb busy_timeout=5000 is distinct from Vitest timeout and is not proof that a lock wait occurred.','causality_limits':['No SQL/assertion failure in this case is logged; observed failure is timeout.','Logs do not locate time among migration fixture creation, upgrade, assertions, hooks/scheduling or storage.','Node and runner image differ: previous success is not a same-environment control.','No CPU/disk/lock trace proves load, Node regression or any specific cause.','Identical package/workflow/lock objects rule out direct PR changes to the failed test/production dependencies; this does not prove absence of latent defects.','Changed export test is a later CI step (131-132), after package Test (128-129); it did not execute before this failure.'],'recommendation':'One same-head rerun of only the failed check is reasonable controlled re-observation: retain attempt1 and exact environment, do not change code/timeouts/skip/selection. A pass does not establish cause. A repeated failure requires phase-level investigation, not unlimited retries. Parent has already requested this single rerun; this agent did not trigger CI.','scope':'Read-only Git/log inspection; no tests, models, product/DB/management calls or repository changes.'}
(D.parent/'independent-diagnosis.json').write_text(json.dumps(report,indent=2)+'\n')
(D.parent/'independent-diagnosis.md').write_text('''# PR298 CI timeout diagnosis

The failed test and production package tree are byte-identical to main711c45e7; workflows, lockfile, package configuration and scratch setup are also unchanged. The only changed script is the method exporter test, scheduled after the package Test step.

PR297 passed the same schema46 migration case in **1094ms** (file7429ms). PR298 attempt1 reports **5638ms against5000ms** (file17183ms), with core1300passed/1failed. The environments differ: PR297 Node22.23.4 / Ubuntu image20261025.353.1; PR298 Node22.23.3 / image20261012.334.1. Both runner versions are2.338.0.

The case includes real file-backed schema46 fixture construction, upgrade and assertions in one synchronous test. There is no phase telemetry to identify the slow segment. The logs show a test timeout, not an assertion/SQL error. Neither runner load nor Node behavior is a proven cause; SQLite busy_timeout=5000 is a separate setting and does not establish a lock wait.

One rerun of only the failed check at the same SHA is justified as a controlled re-observation, preserving this failure and environment metadata. Do not raise timeouts, skip assertions or infer root cause from a subsequent pass. If it fails again, investigate phase timings rather than retry indefinitely. Root requested the rerun; this agent performed read-only diagnosis only.

Exact object IDs, original log hashes, line-numbered excerpts and command outputs are retained in independent-diagnosis.json and independent/. No tests or models were run.
''')
print(json.dumps({'report_sha256':sha((D.parent/'independent-diagnosis.json').read_bytes()),'candidate':head,'commands':len(commands)}))
