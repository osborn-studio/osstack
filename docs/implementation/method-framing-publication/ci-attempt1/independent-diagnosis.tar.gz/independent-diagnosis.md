# PR298 CI timeout diagnosis

The failed test and production package tree are byte-identical to main711c45e7; workflows, lockfile, package configuration and scratch setup are also unchanged. The only changed script is the method exporter test, scheduled after the package Test step.

PR297 passed the same schema46 migration case in **1094ms** (file7429ms). PR298 attempt1 reports **5638ms against5000ms** (file17183ms), with core1300passed/1failed. The environments differ: PR297 Node22.23.4 / Ubuntu image20261025.353.1; PR298 Node22.23.3 / image20261012.334.1. Both runner versions are2.338.0.

The case includes real file-backed schema46 fixture construction, upgrade and assertions in one synchronous test. There is no phase telemetry to identify the slow segment. The logs show a test timeout, not an assertion/SQL error. Neither runner load nor Node behavior is a proven cause; SQLite busy_timeout=5000 is a separate setting and does not establish a lock wait.

One rerun of only the failed check at the same SHA is justified as a controlled re-observation, preserving this failure and environment metadata. Do not raise timeouts, skip assertions or infer root cause from a subsequent pass. If it fails again, investigate phase timings rather than retry indefinitely. Root requested the rerun; this agent performed read-only diagnosis only.

Exact object IDs, original log hashes, line-numbered excerpts and command outputs are retained in independent-diagnosis.json and independent/. No tests or models were run.
