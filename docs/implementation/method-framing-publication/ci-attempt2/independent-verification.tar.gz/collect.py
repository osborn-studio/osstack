from pathlib import Path
import subprocess,json,hashlib,datetime
D=Path(__file__).resolve().parent; commands=[]
def run(name,args):
 p=subprocess.run(args,capture_output=True,timeout=90);(D/(name+'.stdout')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr);commands.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':args,'exit_code':p.returncode,'stdout':name+'.stdout','stderr':name+'.stderr','stdout_sha256':hashlib.sha256(p.stdout).hexdigest()});(D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert p.returncode==0;return p.stdout
run('pr',['/opt/homebrew/bin/gh','pr','view','298','-R','osborn-studio/osstack','--json','headRefOid,baseRefOid,isDraft,state,statusCheckRollup,url'])
run('attempt2',['/opt/homebrew/bin/gh','api','repos/osborn-studio/osstack/actions/runs/40730300608/attempts/2'])
run('attempt2-jobs',['/opt/homebrew/bin/gh','api','repos/osborn-studio/osstack/actions/runs/40730300608/attempts/2/jobs','--paginate'])
run('attempt2-log',['/opt/homebrew/bin/gh','run','view','40730300608','-R','osborn-studio/osstack','--attempt','2','--log'])
print('read-only collection complete')
