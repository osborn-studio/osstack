from pathlib import Path
import re,json,subprocess,hashlib,datetime
D=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();commands=json.loads((D/'commands.json').read_text())
def run(name,argv):
 p=subprocess.run(argv,capture_output=True,timeout=30);(D/(name+'.stdout')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr);commands.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'exit_code':p.returncode,'stdout':name+'.stdout','stderr':name+'.stderr','stdout_sha256':sha(p.stdout)});(D/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert p.returncode==0;return p.stdout
pr=json.loads(run('pr-final',['/opt/homebrew/bin/gh','pr','view','298','-R','osborn-studio/osstack','--json','headRefOid,baseRefOid,isDraft,state,statusCheckRollup,url']))
head='8ba3d98ad27f8febb172bc2392d72fe201ea3e96';assert pr['headRefOid']==head
attempt=json.loads((D/'attempt2.stdout').read_text());assert attempt['head_sha']==head and attempt['run_attempt']==2 and attempt['conclusion']=='success'
logs=(D/'attempt2-log.stdout').read_text().splitlines();rows={};cases=[];clean=lambda s:re.sub(r'(?:\x1b|\^\[)\[[0-9;]*m','',s)
for n,l in enumerate(logs,1):
 if not l.startswith('check\tTest\t'):continue
 line=clean(l)
 m=re.search(r'(packages/\S+) test:\s+Tests\s+(.+)',line)
 if m:
  name=m[1];assert name not in rows,('duplicate',name)
  counts={s:int((re.search(r'(\d+) '+s,m[2]) or [None,'0'])[1]) for s in ['passed','skipped','failed']};total=int(re.search(r'\((\d+)\)',m[2])[1]);assert sum(counts.values())==total
  rows[name]={'line':n,'raw':l,**counts,'total':total}
 if 'upgrades canonical schema46' in line:cases.append({'line':n,'raw':l,'clean':line})
assert len(rows)==22 and len(cases)==1 and '1590ms' in cases[0]['clean'] and '✓' in cases[0]['clean']
totals={s:sum(x[s] for x in rows.values()) for s in ['passed','skipped','failed']};assert totals=={'passed':7142,'skipped':7,'failed':0}
source=run('test-source',['/usr/bin/git','-C','/Volumes/AIMATE_WORK/Developer/CodeX/osstack','show',head+':packages/core/src/state/engineering-store.test.ts']);assert source==(D.parent/'independent/packages__core__src__state__engineering-store.test.ts').read_bytes()
workflow=run('workflow-source',['/usr/bin/git','-C','/Volumes/AIMATE_WORK/Developer/CodeX/osstack','show',head+':.github/workflows/ci.yml']);assert workflow==(D.parent/'independent/.github__workflows__ci.yml').read_bytes();assert b'run: pnpm -r test' in workflow
checks=[{'name':x.get('name',x.get('context')),'status':x.get('status'),'conclusion':x.get('conclusion',x.get('state')),'url':x.get('detailsUrl',x.get('targetUrl'))} for x in pr['statusCheckRollup']]
applicable=[x for x in checks if x['conclusion']!='SKIPPED'];assert len(applicable)==5 and all(x['conclusion']=='SUCCESS' for x in applicable)
report={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':298,'head_sha':head,'run_id':40730300608,'run_attempt':2,'conclusion':'success','pr_is_draft':pr['isDraft'],'checks':checks,'package_totals':totals,'package_summary_count':len(rows),'counting_rule':'Only exact check/Test step package Tests summary lines; one per package, assert unique and totals sum. Excludes test-file summaries, matrix runs, repeated smoke suites and later contract steps.','package_summaries':rows,'original_timeout_case':cases[0],'source_unchanged_from_attempt1_diagnosis':{'test_source_sha256':sha(source),'workflow_sha256':sha(workflow),'same_head':True,'test_budget_ms':5000,'selection':'pnpm -r test unchanged'},'environment':{'attempt1':{'node':'22.23.3','image':'20261012.334.1'},'attempt2':{'node':'22.23.4','image':'20261025.353.1'}},'limits':['Successful rerun does not prove original timeout cause.','No timeout increase, test skip or selection change was introduced; source and workflow bytes match original diagnosis.','This agent performed read-only GitHub/Git/log inspection, not test execution or CI retry.','Five current applicable checks succeeded; paid semantic smoke skipped is a job outcome, separate from seven package-test skips.']}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(D/'report.md').write_text('''# PR298 independent Ready verification

GitHub attempt2 of run40730300608 is completed/SUCCESS at unchanged head `8ba3d98ad27f8febb172bc2392d72fe201ea3e96`. Latest PR observation is Ready with five applicable checks successful; the paid semantic job is skipped.

The original schema46 migration case passes in **1590ms**. Its source and workflow match the attempt1 diagnosis byte-for-byte; the5000ms budget and `pnpm -r test` selection were not changed. Exactly22 unique package `Tests` summaries in the check job's Test step sum to **7142passed,7skipped,0failed**. File summaries, matrix tests and later smoke/contract executions are not added to this total.

Attempt2 used Node22.23.4/image20261025.353.1; attempt1 used Node22.23.3/image20261012.334.1. The passing rerun does not establish the earlier timeout's cause. Original failure evidence remains intact. This reviewer only read GitHub/Git/log data and did not execute tests, retry CI or mutate the PR.

Raw API responses, complete attempt2 log, source copies and command records accompany report.json. Its package rows retain exact original log lines for recounting.
''')
files=[]
for p in sorted(D.rglob('*')):
 if p.is_file():b=p.read_bytes();files.append({'path':p.relative_to(D).as_posix(),'bytes':len(b),'sha256':sha(b)})
(D/'manifest.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files},indent=2)+'\n');print(json.dumps({'totals':totals,'report_sha256':sha((D/'report.json').read_bytes()),'manifest_sha256':sha((D/'manifest.json').read_bytes()),'members':len(files)}))
