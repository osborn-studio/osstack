from pathlib import Path
import json,re,hashlib,subprocess,datetime
root=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-method-bridge-20261030');s=root/'full-final';o=root/'full-final-independent'
r=json.loads((s/'result.json').read_text());before=json.loads((s/'before.json').read_text());after=json.loads((s/'after.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
assert r['head']=='ac9e67c6b2d5c2063bc525b5265ea432234d3a56' and r['exit_code']==0
assert len(before)==len(after)==r['tracked_files']==9106 and before==after and r['changed']==[]
text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',(s/'stdout.log').read_text());packages=[]
for line_no,line in enumerate(text.splitlines(),1):
 m=re.fullmatch(r'packages/(\S+) test:\s+Tests\s+(.*?)\s+\((\d+)\)\s*',line)
 if m:
  c={kind:int(count) for count,kind in re.findall(r'(\d+)\s+(passed|failed|skipped)',m[2])};assert sum(c.values())==int(m[3]);packages.append({'package':m[1],'passed':c.get('passed',0),'skipped':c.get('skipped',0),'failed':c.get('failed',0),'line':line_no})
assert len(packages)==len({p['package'] for p in packages})==22
totals={k:sum(p[k] for p in packages) for k in ['passed','skipped','failed']};assert totals=={'passed':7420,'skipped':5,'failed':0}
paths=['packages/cli/src/'+n for n in ['execution-context.ts','execution-context.test.ts','execution-context-host.ts','execution-context-host.test.ts','method-context.ts','method-context.test.ts']]+['packages/skill-registry/src/bug-fix-compiler.ts','packages/skill-registry/src/bug-fix-compiler.test.ts','scripts/prepare-bug-fix-method.mjs','scripts/prepare-bug-fix-method.test.mjs']
bindings=[]
for p in paths:
 b=subprocess.check_output(['git','show',r['head']+':'+p],cwd='/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-method-bridge');h=sha(b);assert before[p]==after[p]==h;bindings.append({'path':p,'git_blob_sha256':h,'bytes':len(b),'matches_before_after':True})
report={'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':r['head'],'command':['pnpm','test'],'runtime_recorded':r['node'],'exit_code':r['exit_code'],'started_at':r['started_at'],'ended_at':r['ended_at'],'initial_dirty':r['initial_dirty'],'tracked_file_count':len(before),'tracked_before_after_equal':before==after,'packages':packages,'totals':totals,'git_source_binding':bindings,'inputs':[{'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(s.iterdir()) if p.is_file()],'limits':['Read-only parsing and fixed Git-object comparisons; no test rerun.','Four generated knowledge dist files were already dirty at start; therefore this is the recorded build state, not a pristine checkout claim.','Untracked tutorial absent from tracked snapshots; no assertion of its byte stability.','Subsequent two-path guard repair and reported76 focused tests are not part of this full run.','No assertion of unchanged untracked files, ignored build outputs, process-level state, runtime host use or formal authorization.']}
(o/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'head':r['head'],'totals':totals,'packages':len(packages),'tracked_files':len(before),'git_source_bindings':len(bindings)},indent=2))
