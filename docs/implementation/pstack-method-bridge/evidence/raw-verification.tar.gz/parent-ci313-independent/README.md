# PR313 parent-base CI 独立日志复核

结论：保存的 run41036945434 为 SUCCESS；5 项适用检查 SUCCESS，Paid DeepSeek semantic smoke 为 SKIPPED。未抓取新状态、下载 artifact、重跑测试或改 PR。

- PR head：f6d7c09a487249a9973783912adb117e1df4333c。
- 目标分支：codex/pstack-maintenance-health-delivery（PR312），不是 actual main。
- check 日志显示 synthetic checkout 9c04d35686e22c344fe6492d3c84823eb1863001：将上述 head 合入 418ffe02929845e73ef56372c8920b51a64b772d。不可将结果直接改绑当前 main 或当前 P4/P5 修订。
- 解压原日志 2,277,626 bytes，SHA256 41c6ad86e298bf54d649d8117b5f4a7f388100e854b1ae4a1be18a7fbc9ed670，与 binding.json 相符。

独立按 check/Test 与各 package 最终 Tests 行取唯一值，22 包共 **7,337 passed / 7 skipped / 0 failed**。保留 ANSI 清除前的原日志；root 最初0条的摘要属于解析错误，不是未运行。原错摘要与修正摘要未改。

源相关日志：skill-registry 121 passed，包含 manifest46、watcher6、source-adoption35、source-snapshot34。方法导出114 passed/1 skipped（115总）；feature map40、health45、reader14、journey43、map25、projection89 均通过。其余逐步结论与全部22包数字见 report.json。

日志中的实际本地回执：session decision passed；skills-check 五例 passed；默认旅程两例 passed；full 旅程五例 passed（产品退出0/1/2/1/0，driver均0）；map维护 consistent/0；两例与五例投影各 projected→valid，前后packet hash相同。CLI startup日志为 version median23ms（250ms限）及 help median119ms（900ms限）。原回执完整抽取在 logged-smoke-receipts.json，不作为重新核验远端原证据成员。

这些是日志观察，不是远端artifact内容重hash、真实模型/宿主使用证明、独立身份资格或merge许可。缺省负产品退出不代表驱动失败。记录保持PR Draft；待312人工合并后root负责新基线核对。
