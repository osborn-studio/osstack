from pathlib import Path
import json,gzip,re,hashlib,datetime
src=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-method-bridge-20261030/parent-ci313')
out=src.parent/'parent-ci313-independent'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=gzip.decompress((src/'full.log.gz').read_bytes()); binding=json.loads((src/'binding.json').read_text())
assert len(raw)==binding['log_bytes'] and sha(raw)==binding['log_sha256']
text=re.sub(r'(?:\x1b|\^\[)\[[0-?]*[ -/]*[@-~]','',raw.decode())
run=json.loads((src/'run.json').read_text());pr=json.loads((src/'pr.json').read_text())
assert run['headSha']==pr['headRefOid']=='f6d7c09a487249a9973783912adb117e1df4333c'
assert run['conclusion']=='success' and len(run['jobs'])==6
assert sum(j['conclusion']=='success' for j in run['jobs'])==5
assert [(j['name'],j['conclusion']) for j in run['jobs'] if j['conclusion']!='success']==[('Paid DeepSeek semantic smoke','skipped')]
assert pr['baseRefName']=='codex/pstack-maintenance-health-delivery' and pr['isDraft']
packages=[];taps={};steps={};checkout=[]
for lineno,line in enumerate(text.splitlines(),1):
 a=line.split('\t',2)
 if len(a)!=3 or a[0]!='check':continue
 step=a[1];body=re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+\s','',a[2]);steps.setdefault(step,[]).append((lineno,body))
 if step=='Test':
  m=re.search(r'packages/(\S+) test:\s+Tests\s+(.*?)\s+\((\d+)\)\s*$',body)
  if m:
   counts={k:int(n) for n,k in re.findall(r'(\d+)\s+(passed|skipped|failed)',m[2])};assert sum(counts.values())==int(m[3]);packages.append({'package':m[1],'passed':counts.get('passed',0),'skipped':counts.get('skipped',0),'failed':counts.get('failed',0),'log_line':lineno})
 m=re.search(r'^# (tests|pass|fail|skipped) (\d+)$',body)
 if m:taps.setdefault(step,{})[m[1]]=int(m[2])
 if step=='Run actions/checkout@v7' and ('HEAD is now' in body or re.fullmatch(r'[a-f0-9]{40}',body)):checkout.append({'log_line':lineno,'text':body})
assert len(packages)==len({p['package'] for p in packages})==22
totals={k:sum(x[k] for x in packages) for k in ['passed','skipped','failed']};assert totals=={'passed':7337,'skipped':7,'failed':0}
assert any('Merge f6d7c09a487249a9973783912adb117e1df4333c into 418ffe02929845e73ef56372c8920b51a64b772d' in x['text'] for x in checkout)
assert any(x['text']=='9c04d35686e22c344fe6492d3c84823eb1863001' for x in checkout)
smoke_names=['Session adoption decision smoke (local fixture)','Skills check verification (local Git fixtures)','Method verification journey (two real local cases)','Full method verification journey (five real local cases)','Maintain fixed skills map (five real local cases)','Project and check actual method evidence','Project and check full five-case method evidence']
smokes={}; decoder=json.JSONDecoder()
for name in smoke_names:
 lines=steps[name]; joined='\n'.join(s for _,s in lines); objects=[]
 for match in re.finditer(r'(?m)^\{',joined):
  try:obj,end=decoder.raw_decode(joined[match.start():]);objects.append(obj)
  except json.JSONDecodeError:pass
 assert objects,name
 smokes[name]={'first_log_line':lines[0][0],'last_log_line':lines[-1][0],'logged_json_objects':objects}
(out/'logged-smoke-receipts.json').write_text(json.dumps(smokes,indent=2)+'\n')
checksteps=[{'name':s['name'],'conclusion':s['conclusion']} for j in run['jobs'] if j['name']=='check' for s in j['steps']]
inputs=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(src.iterdir()) if p.is_file()]
report={'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'Offline independent parser of saved full.log.gz and run/pr JSON; no fetch, rerun, or remote artifact download','run_id':41036945434,'head':run['headSha'],'base_branch':pr['baseRefName'],'base_sha_from_checkout':'418ffe02929845e73ef56372c8920b51a64b772d','synthetic_checkout':'9c04d35686e22c344fe6492d3c84823eb1863001','checkout_lines':checkout,'jobs':[{'name':j['name'],'conclusion':j['conclusion']} for j in run['jobs']],'package_totals':totals,'packages':packages,'script_tap_totals':taps,'check_steps':checksteps,'log_binding':{'uncompressed_bytes':len(raw),'sha256':sha(raw),'matches_saved_binding':True},'inputs':inputs,'limits':['Parent PR312 feature-base CI, not actual-main revalidation or final P4/P5 binding source validation.','Log-reported smoke results only; artifacts, source/build bindings and cleanup were not independently fetched or rehashed.','No host-model execution, provider qualification, approval or merge authority inferred.','Paid DeepSeek semantic smoke skipped. PR saved as Draft; review does not change status.'],'root_parser_history':'Original root-summary-unparsed zero count is a parser failure, not zero executed tests. Independent ANSI-aware parser confirms corrected 7337/7/0 across22 packages.'}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'totals':totals,'packages':len(packages),'tap':taps,'smokes':[(k,[o.get('status',o.get('verification')) for o in v['logged_json_objects']]) for k,v in smokes.items()]},indent=2))
