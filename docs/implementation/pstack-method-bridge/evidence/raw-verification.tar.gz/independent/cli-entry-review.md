# 既有 CLI 承载位置（只读，未执行）

`deliver --execution-context` 已由 deliver-command.ts 接受；bin.ts 的 createDeliveryExecutionContext 动态加载 execution-context-host.ts，后者返回包装后的 adapters。guarded-local 使用这些 adapters，候选receipt引用 context receipt。P5可以沿此入口实现，无需新scheduler。当前 config 严格仅 local/packs，方法配置必须明确新增；不能把已有BM25 snippet当完整方法。

最短调用形状：

```sh
OSSTACK_HOME="$OWNED_HOME" OSSTACK_SCRATCH_ROOT="$OWNED_SCRATCH" node packages/cli/dist/bin.js deliver "$GOAL" --workspace "$TARGET_REPO" --autonomy guarded-local --contract "$V2_CONTRACT" --profile "$PROFILE" --execution-context "$CONTEXT_FILE" --capability code.write --json
```

所有变量需来自当前授权任务。home必须显式自有非默认；材料和config在目标仓库允许范围；V2 task/goal/base/policy/budget、profile角色和registered checks须已匹配。默认capability本来就是code.write，示例显式写出便于与methods.roles.capability_id核对。此处不是完整可直接执行任务，也未证明当前配置可执行。

root需要确保：strict ConfigSchema接受methods，host factory创建并传递method loader/fence；wrapper在optional assembly前预留完整escaped块预算，并在持久prepared receipt后同步复验；receipt反映最终prompt hash/bytes及角色材料。原validateContext/validateContextSync和host safety/contract保留。编译器proposal仍executable:false，独立digest不会为guarded-local合同授权或自动转换trial/qualified。

当前deliver在config加载前enqueueTask，因此验收保证是invoke0，不伪称失败时没有任何本地任务记录。adapter_observed只是AgentTask输入边界，不是provider wire或模型理解。P6真实缺陷/卡回写仍需之后独立执行。
