独立方法完整内容🧭
FIRST
"quoted" & <data>
LAST-REQUIRED-LINE
