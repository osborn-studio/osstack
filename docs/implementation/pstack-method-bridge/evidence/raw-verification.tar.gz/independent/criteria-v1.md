# P4/P5 独立有限验收预冻

- **MB01 纯bug_fix编译**：符合真实MethodRecipe/MethodProposal/SourceSnapshot/CheckRegistry合同；同输入确定同输出且输入不变，proposal executable:false；不执行命令/注册/授予权限。
- **MB02 来源类别分离**：只接受合同要求的SourceSnapshot；source_inspection/declared_adoption_candidate不得伪装。摘要一致仅内容自洽，不认证来源、版本、资格或trial。
- **MB03 跨对象摘要绑定**：recipe source/version/角色材料、intent/revision/task、method input、artifact/check binding之间要求的关联不一致须拒绝，不单独parse后盲拼。
- **MB04 注册检查与required闭包**：reproduce/regression/acceptance按明确映射，primary必须required acceptance；未知registry ref、缺required feature/角色、重复歧义拒绝；不从用户卡文本生成可执行命令。
- **MB05 实际材料送达**：受控真实public wrapper调用的adapter输入含完整必需材料原文（含Unicode/末行），明确数据边界；不依赖BM25命中或optional裁剪。receipt绑定实际prompt/source bytes与适用角色。
- **MB06 调用前失败关闭**：缺材料、错误hash、错误repo/tenant/角色或格式、超文件/聚合/总prompt预算皆invoke0；不得以空材料/可选结果降级继续。
- **MB07 异步间隙复核**：load后/receipt持久化间隙改变材料，dispatch同步fence拒绝invoke0；abort before invoke同样0。不声称能阻止检查后的OS并发写者。
- **MB08 有限路径与字节**：仓库内显式相对材料，越界/外部symlink/非regular/无效UTF8拒绝；按实际bytes而非字符数执行32KiB/file和64KiB/raw聚合（以最终契约补充确切shape）。
- **MB09 权限和指令边界**：恶意方法正文仍是untrusted reference；不能改host safety/contract/task权限或外部执行。proposal、method hash和caller声明均不产生授权；只在受控adapter边界断言不冒充LLM防注入效果。
- **MB10 兼容与证据界限**：未配置methods路径保持现有prompt/行为；配置失败不调用adapter；prepared不能叫adapter_observed/provider wire或理解，后调用receipt失败不得抹去已调用事实。
- **MB11 真实入口接线**：现deliver --execution-context在local模式可承载新配置，公共host factory实际连通；CLI既有strict/guarded-local合同/策略保持，资料送达不能替代候选核验和发布审批。
- **MB12 验收范围**：P4纯函数+P5受控adapter送达，不是P6真实当前bug修复、不关闭原48A/C0/C1C2、不启动Firstmate；所有原失败/fixture修订单独保留。

20个初始语义场景与来源hash见JSON。接口未定部分只追加wire补充，不改原期望翻绿。
