# P4/P5 独立有限验收

本轮接口验证完成，未发现尚未关闭的确认缺陷。这里的通过只指纯编译与受控 adapter 的真实材料交付，不表示原生模型理解、P6、C0 或正式授权/资格。

| 证据层 | 实际结果 | 边界 |
|---|---:|---|
| P4 独立协议输入、摘要公式及负例 | 27/27 | 原夹具阈值估算错误的 26/27 保留，不记产品缺陷 |
| 初版 P5 public host factory/wrapper | 28/28 | 初版 caller-declared 合同；不重标最终新 schema |
| 新 compiled 绑定 | 19/19 | 旧兼容 wire 的 14 个未拒记录保留，非相同 wire RED |
| CLI canonical/file alias/directory alias | 3/3 | 修前 1/3；首次 8 项空 exit0 原件保留 |
| 最终 preparer | 8/8 | 真实文件输出、拒绝不覆盖、三角色受控交付 |
| 真实来源材料原型 | 3 次 adapter / 6 回执 | 三角色文本逐字相等，prompt/材料哈希与字节核验；本次不重读 Git |
| compact compiled 边界 | 524274 bytes，接受 | 同对象旧 pretty 为 526458，超过 512 KiB；同步再验通过 |

已关闭三点：独立发现的 alias main guard 无操作；root 发现的 compiled/P5 缺少实际绑定；新增编译结果美化字节超限。新 artifact 完整重编并与保留对象 canonical 比较，校验 task/repository/proposal 及所有配置角色的材料哈希，prepared 回执后更换 artifact 会阻止 invoke。自洽重编 caller facts 仍可接受，不能据此推导来源认证或执行许可。

原始语义准则先于 C 检视实现冻结；P4 具体 wire 脚本在合同与源码阅读后完成。所有新增门槛与纠错均独立成文件，不改旧结果。最终修订当时为 a9a45116 上的未提交字节，按 JSON 中精确 source/dist SHA 绑定，不能把修订冒称该旧 commit 的全仓结果。

没有新增模型、DB、full suite、默认 home 或真实 deliver 任务。真实 CLI 执行的是 preparer；deliver --execution-context 接线路径仅静态核对。repo_path 与 execution_repo_path 的既有区别保留，不能把 loop worktree 差异自动当错 scope。

详细 CU/MB 映射、原失败、所有文件路径和限制见 final-report.json；完整目录清单见 manifest.json。
