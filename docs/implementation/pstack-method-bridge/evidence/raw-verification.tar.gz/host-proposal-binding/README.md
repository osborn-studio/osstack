# P5 compiled-artifact binding increment

This supplement preserves the earlier P5 evidence unchanged. Source is the six CLI files in final-source.json; five changed relative to the shared HEAD, while execution-context-host.ts remains unchanged. No author commit or full-suite run was performed.

The unpublished methods configuration now requires an exact compiled artifact path/hash. The loader strictly reads at most 512 KiB, reconstructs compileBugFix inputs and requires canonical equality with the complete output, binds task/proposal/workspace and every configured role, and requires exactly one material per configured role. The selected material and compiled bytes are checked again immediately before invoke. A task execution subworktree remains supported; the compiled target binds the host workspace. Receipts record exact compiled bytes/hash and recompiled_caller_facts, not authenticated provenance or authorization.

## Observed validation

- red: 26 failed / 40 passed against the prior implementation using the new tests; original stdout/stderr retained.
- green-1: 66 passed after implementation.
- green-final: 73 passed after artifact and receipt-gap cases.
- green-final-lazy: 74 passed (28 loader, 17 host, 29 wrapper), exit 0. Its command receipt binds all three final test hashes.
- typecheck: exit 0 at 10:28:17 UTC, before the final lazy-loading test was added. Root owns final combined typecheck/build/startup verification.
- The lazy test uses a compiler-module factory sentinel: a no-methods configuration does not load the compiler, while configured methods do. This is source-module loading evidence, not a CLI startup timing measurement.

All commands are targeted local tests, with no host model invocation, provider-wire assertion, authority grant, or full regression. Historical full-suite success at a9a4511 is not rebound to this revision. Exact unchanged artifact bytes are checked at preinvoke; this is not an OS writer fence. Coherently recompiled caller facts remain caller facts.

Root owns the preparer/compact artifact output, build entries, audits, integration, and publication. The compiler and preparer are dependencies outside these six author-owned files.
