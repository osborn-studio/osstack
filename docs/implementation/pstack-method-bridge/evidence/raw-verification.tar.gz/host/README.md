# P5 mandatory method host bridge — author evidence

Candidate: six files listed in candidate-binding.json; shared worktree, no author commit. The original methods proposal and root-approved frozen task-bound contract are both retained.

Behavior RED: host-red-2 ran the same new host cases against the old implementation: 1 old case passed, 6 new cases rejected invalid_execution_context_config. This is a new feature RED, not an old defect. Final GREEN: 57 tests (7 host factory, 22 method loader, 28 execution wrapper), CLI typecheck exit0. The added edge cases are additional regression coverage, not falsely labeled individually pre-implementation RED. First typecheck found missing explicit return in catch; retained before repair.

Author harness mistake: first append omitted cwd and created a new test fragment file in primary, while test execution correctly used the worktree and ran just the old one test. Exact fragment and correction receipt retained. The newly-created file alone was removed and moved to owned worktree. host-red logs are not behavior RED; host-red-2 is the actual failing run.

The loader selects one configured role by exact capability and task ID. Required proposal digest/package version remain caller declarations, not authenticated provenance or proof of proposal validation. Method text is a separate escaped JSON untrusted-reference block. Complete framing reserves final prompt bytes before optional knowledge selection. Missing, changed, symlink, malformed, wrong-role/task and over-budget material fail before invocation; a synchronous re-read follows receipt persistence and existing source validators. Receipt records actual delivered text bytes/hash/scope at adapter input boundary, not model comprehension/provider wire/OS fencing. Existing unconfigured local behavior and off behavior remain supported.

No external model, actual delivery, full suite, DB, automatic activation or formal MethodBinding/TrialPermit was invoked. Root owns integration, real-task prototype, audit and full queue. C independent results are separate and are not copied into author claims.
