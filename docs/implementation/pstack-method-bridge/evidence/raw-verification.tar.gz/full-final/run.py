import subprocess,pathlib,json,hashlib,datetime,os
w=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-method-bridge');r=pathlib.Path(__file__).parent
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
def snapshot():
 out={}
 for raw in git('ls-files','-z').split(b'\0'):
  if not raw:continue
  s=raw.decode();p=w/s
  out[s]=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 return out
before=snapshot();(r/'before.json').write_text(json.dumps(before,sort_keys=True))
record={'head':git('rev-parse','HEAD').decode().strip(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initial_dirty':git('status','--short').decode(),'tracked_files':len(before),'node':'v22.22.1'}
with (r/'stdout.log').open('w') as o,(r/'stderr.log').open('w') as e:
 try:code=subprocess.run(['pnpm','test'],cwd=w,stdout=o,stderr=e,env={**os.environ,'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'},timeout=1800).returncode
 except subprocess.TimeoutExpired:code=124
after=snapshot();(r/'after.json').write_text(json.dumps(after,sort_keys=True));record.update({'exit_code':code,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changed':[s for s in set(before)|set(after) if before.get(s)!=after.get(s)]});(r/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
