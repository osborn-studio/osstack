import fs from 'node:fs';
import assert from 'node:assert/strict';
import { compileBugFix } from 'file:///Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/pstack-method-bridge/packages/skill-registry/dist/bug-fix-compiler.js';
import { CheckRegistry, ArtifactRequirements } from 'file:///Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/pstack-method-bridge/packages/protocol/dist/joint.js';
const base=JSON.parse(fs.readFileSync(new URL('./inputs/scripts/fixtures/synthetic-bug-fix-compilation.json',import.meta.url),'utf8'));
const cases=[];
function run(name,mutate,expected,code,issue) {
 const value=structuredClone(base);mutate(value);
 const registry=CheckRegistry.safeParse(value.check_registry);
 const artifacts=ArtifactRequirements.safeParse(value.required_artifacts);
 const row={name,input:value,registry:{accepted:registry.success,issues:registry.success?[]:registry.error.issues},artifacts:{accepted:artifacts.success,issues:artifacts.success?[]:artifacts.error.issues}};
 try {const result=compileBugFix(value);row.compiler={accepted:true,executable:result.executable,result};}
 catch(e){row.compiler={accepted:false,name:e.name,code:e.code,message:e.message};}
 cases.push(row);
 assert.equal(row.compiler.accepted,expected,name);
 if(code) assert.equal(row.compiler.code,code,name);
 if(issue) assert.ok([...row.registry.issues,...row.artifacts.issues].some(i=>i.message===issue),name);
}
run('valid baseline [0]',()=>{},true);
for(const codes of [[0,3],[3,0],[0,0]])run('pass_codes '+JSON.stringify(codes),v=>{v.check_registry.entries[0].pass_codes=codes},false,'INVALID_INPUT','INVALID_CHECK_IDENTITY_OR_PASS_CODES');
for(const required of [false,true])run('duplicate reproduction builder required='+required,v=>{
 const copy=structuredClone(v.required_artifacts.requirements.find(r=>r.artifact_ref_kind==='reproduction'));
 copy.required=required;copy.body_schema_digest='e'.repeat(64);
 v.required_artifacts.requirements.push(copy);
},false,'INVALID_INPUT','DUPLICATE_ARTIFACT_REQUIREMENT');
run('single optional reproduction is not mandatory',v=>{v.required_artifacts.requirements.find(r=>r.artifact_ref_kind==='reproduction').required=false},false,'MISSING_OBLIGATION');
console.log(JSON.stringify({scope:'Synthetic pure compilation only; no host, checks, admission, installation, or execution',cases},null,2));
