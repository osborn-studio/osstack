# Bounded static closure: PASS_WITH_CONCERNS

This closure is limited to the supplied text. I ran nothing, recomputed no hashes, and make no claim about native model use, `local_verified`, P6, provider behavior or an installed release.

## Disposition

| # | Original concern | Closure | Status |
|---|---|---|---|
| F1 | `pass_codes` not canonicalized or checked for uniqueness | `[0,3]`, `[3,0]` and `[0,0]` are rejected by the protocol schema (`INVALID_CHECK_IDENTITY_OR_PASS_CODES`; `[0,0]` also `OVERLAPPING_EXIT_CODES`) and by the compiler (`INVALID_INPUT`). The legal `[0]` baseline is accepted with `executable:false`. | **Not a defect on this candidate.** My conditional concern is withdrawn. |
| F2 | `.some(...)` mandatory-obligation check | Both duplicate `reproduction/builder` vectors, with `required` false or true and a different digest, give `DUPLICATE_ARTIFACT_REQUIREMENT` and then `INVALID_INPUT`. A single optional `reproduction` gives `MISSING_OBLIGATION`. | **Not a defect on this candidate.** Withdrawn. |
| F3 | `mode: "off"`/undefined silently drops `methodContext` | The guard `methodContext !== undefined && mode !== "local"` now sits before the early-return in `execution-context.ts`. The red log shows the two off/undefined tests failing (2 failed, 29 passed of 31). The green log shows 76 passed across three files (17+28+31). The README and tutorial now state the rejection. | **Confirmed issue, resolved at unit level.** |
| F4 | "PR313-era `methods` configs" compatibility claim | The PR313 head is `f6d7c09a…`. Its `execution-context.ts` has no methods config; the only `methods` there is the proxy `Map`. `ls-tree` for `method-context.ts` and `bug-fix-compiler.ts` is empty with exit 0. The diff shows `method-context.ts` as new. File history starts at `a9a45116`, then `ac9e67c6`. | **My attribution was wrong and is corrected.** The real distinction is draft configs inside this batch, where `compiled` is now required. |
| F5 | Binding scope narrower than digest names suggest | The README and tutorial say `proposal_digest` is not the whole-file digest and that `compiled.sha256` binds the file separately. They also say the live prompt is not tied to `intent`, only `task_id` is compared, and the capability/role mapping and registry are caller-declared. | **Documented. The limits remain.** |
| F6 | Packaging unverifiable | The supplied `packages/cli/package.json` declares both `@osstack/protocol` and `@osstack/skill-registry` as `workspace:*` dependencies. The `./joint` and `./bug-fix-compiler` subpaths exist in the respective exports maps. | **Declared-dependency uncertainty resolved.** Nothing is claimed about bundling, packing or install. |
| F7 | Minor items | The `invalid_utf8` branch and the collapse to `compiled_invalid` are visibly unchanged in the `ac9e67c6` diff. The README keeps the sync-I/O limit. | **Retained, not fixed.** |

## Evidence caveats

- **F1/F2:** The seven vectors are retained probe output, which I read but did not re-run. I did not see `probe.mjs`, the protocol source, or the compiler source. The disposition says the dist modules and their source were retained, but I cannot confirm they correspond. For these specific vectors the observed outcomes are enough to discharge my conditional concerns.
- **F3 is bound to an uncommitted revision.** The follow-up report cites source `f4057427…` and build `8b83ca7e…`, but I saw only truncated hashes and cannot tie the `execution-context.ts` I was shown to them.
  - The guard is visible in the source text.
  - The red and green logs do not record a source hash, so that binding rests on the follow-up report.
  - The green log shows only counts, so "same tests" is inferred from the same 31-test file plus the named red failures.
  - The README correctly says the earlier full-suite runs were not re-labelled as covering this revision.
- **F3 edge:** The guard only throws when `methodContext !== undefined`. A JS caller passing `null` with `mode: "local"` would silently get no method. That is a type violation, not a regression.
- **F4:** An empty `ls-tree` alone could mean a bad pathspec. Here the diff shows `method-context.ts` as a new file, which settles it.
- **F5:** The docs state the caller-declared nature in general terms. They do not itemize that `available_feature_ids` and the assurance/limitations fields sit outside `proposal_digest`, or that `context.json` itself is not hash-pinned.
- **F6:** I did not see `tsup.config.ts`. tsup normally externalizes declared dependencies, but that is unconfirmed here. `workspace:*` rewriting at pack time is also unverified.

## Limits that remain

- **Matching build:** the whole-artifact recompile includes `limitations` and derived fields, so artifacts from a different build fail as `compiled_mismatch`. This is documented in the README and tutorial.
- **Caller-declared facts:** source facts, registry, feature availability and capability/role mapping are not authenticated.
- **F7 diagnostics:** the diagnostic loss and the unreachable branch are unchanged.
- **Out of scope:** nothing here shows the live prompt matches the intent, how native or provider consumption behaves, or that an installed package works.

Verdict: the one confirmed code defect (F3) and my incorrect F4 attribution are resolved, and F1, F2 and the F6 uncertainty are discharged. F5 and F7 limits and the matching-build constraint stay open as stated, so the verdict is **PASS_WITH_CONCERNS**.