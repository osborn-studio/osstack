审计 #3 有限复验闭合：同一探针修前 3 通过 / 2 失败，修后 5/5 通过。

- `off` 或省略 mode 且提供 methods：明确拒绝，adapter invoke0。
- 不带 methods 的 `off`/省略 mode：仍返回原 adapter，受控调用各一次。
- `local`：材料加载、同步校验和受控调用各一次，完整材料仍在 prompt。

源码 `f4057427…`、构建模块 `8b83ca7e…` 精确绑定；不能将未提交 guard 修订冒称此前 full commit 已测。原始失败不改。没有模型、DB、全仓或产品写入。
