**Verdict: PASS_WITH_CONCERNS**

This is static review only. I ran nothing and make no model, runtime or provider claims. I found no confirmed failure that lets a missing, oversize or tampered artifact reach `adapter.invoke`, or lets compiler output claim authorization. The concerns below are determinism or fail-open gaps, and several depend on protocol schemas I wasn't shown.

**Findings**

1. **`pass_codes` is not canonicalized or checked for uniqueness (`bug-fix-compiler.ts`, registry loop).**
   - `fail_codes` gets a uniqueness check and a numeric sort, but `pass_codes` gets neither.
   - Two registries with the same pass set, `[0,3]` and `[3,0]`, produce different `check_registry_digest` and `proposal_digest` values, which contradicts the claim of set-order-independent deterministic output. `[0,0]` is accepted unless the protocol schema rejects it.
   - The "canonicalizes set-like input order" test never reverses `pass_codes`.
   - Binding is not weakened, because host recompile preserves whatever order is in the pinned file. Apply the same unique-and-sort treatment to `pass_codes` and add a test.

2. **The mandatory-obligation check uses `.some(...)` (`bug-fix-compiler.ts`).**
   - Input with two `reproduction/builder` entries, one `required:true` and one `required:false` with a different schema digest, passes, and both are carried into the digest.
   - A downstream consumer that keys by kind and picks the other entry would treat the obligation as optional.
   - This is a bug if `ArtifactRequirements` doesn't enforce uniqueness per (kind, role), which I couldn't see. Require exactly one entry per mandatory kind, or confirm the schema does.

3. **`mode: "off"` silently drops a configured mandatory method (`execution-context.ts`, top of `createExecutionContextAdapters`).**
   - The early `return { adapters: options.adapters }` runs before any option validation. `{ mode: "off", methodContext }` therefore returns the raw adapters and delivers no method material, with no error.
   - The host always passes `"local"`, so the product path isn't affected. At the API level it fails open for something documented as mandatory. Throw when `methodContext` is supplied without `mode: "local"`.

4. **The `methods` schema changed, so PR313-era `methods` configs now fail closed (`execution-context.ts`, `loadExecutionContextConfig`).**
   - The required `compiled` field is new, and a legacy `methods` block without it is rejected at load. That matches the "requires a compiled binding" test.
   - The no-methods path is compatible: the import is lazy, the receipt omits the key, and the budget math is unchanged. I confirmed this from the code.
   - Make sure the breaking change for configs that already have `methods` is called out as intended.
   - `readCompiled` also compares the full artifact by canonical equality, including the `limitations` strings. Any later compiler wording or semantic change invalidates every previously prepared artifact as `compiled_mismatch`. That is consistent with the docs' "matching build" requirement, but it is worth stating.

5. **Binding scope in the receipt is honest but narrower than the digest names suggest.**
   - `proposal_digest` covers neither `available_feature_ids` nor the assurance and limitations fields. Only `compiled.sha256` and the whole-artifact recompile cover them.
   - The capability-to-role mapping lives in `context.json`, which is not hash-pinned, so it stays caller-declared. The receipt labels it that way.
   - The live `task.prompt` is not tied to `intent`; only `task_id` is compared.
   - None of this is a truthfulness bug, because the receipt records both the proposal digest and the compiled hash. Don't describe `proposal_digest` as covering the whole artifact.

6. **Packaging is unverifiable from what was provided.**
   - `tsup.config.ts` externalizes `@osstack/skill-registry` but not `@osstack/protocol`, and `method-context.ts` imports `@osstack/protocol/joint`.
   - `packages/cli/package.json` wasn't included. Confirm it declares both dependencies. Otherwise tsup may bundle a second protocol copy or leave an unresolved import in the published CLI.
   - `prepare-bug-fix-method.mjs` loads two `dist` paths and requires both packages to be built from the same batch. The docs say so.

7. **Minor items (`method-context.ts`).**
   - The `invalid_utf8` branch in `load` is effectively unreachable. A file whose bytes hash to a compiled material is already valid UTF-8, because the compiler round-trips the text.
   - Any `BugFixCompileError` raised inside `readCompiled` is collapsed to `compiled_invalid`, which loses the cause. That is acceptable for fail-closed behavior but weakens diagnostics.
   - `load` and `validateSync` each parse and read up to 512 KiB synchronously. This is bounded and only a latency note.

**Checked and found consistent**
- **Invoke ordering:** the sequence is task, capability and compiled recompile, then the per-role bindings, then the budget, then the prepared receipt. After that come `validateContext`, the expiry check, `validateContextSync`, `methodContext.validateSync` and finally `invoke`. Missing, oversize, symlink, changed and invalid-JSON compiled artifacts all throw before any receipt or adapter call.
- **Resealed or contradictory artifacts:** resealed artifacts are caught by recompile and canonical equality. An unselected role with a mismatching hash is caught by the loop over all config roles.
- **Budget:** `maxPromptBytes - methodBytes` plus the appended method text never exceeds the cap. Equal-or-greater framing fails closed. `<` and `>` escaping is charged before optional selection and prevents sentinel forgery.
- **Compact versus canonical size:** `JSON.stringify` and canonical JSON have the same minimal string escaping for the values involved, so the compact file plus the 524288-byte bound is consistent between the compiler, the script and the host reader.
- **Output bytes:** the script's hashes match the written bytes, since it hashes the same UTF-8 strings it writes. Output happens after all validation, and the `mkdir` plus `wx` writes fail closed on existing output. The partial-write limitation is acknowledged.