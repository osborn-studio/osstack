确认审计发现 #3：public wrapper 在 off 或省略 mode 且提供 methodContext 时返回原 adapter；实际受控调用各 invoke1，材料 load/validate 均0。两项拒绝要求失败，三项正常对照通过。无 methods 的旧 off/省略路径按原对象返回且可调用；local 模式加载材料并同步校验后调用。

这是新增审计向量，不改原成绩。host factory 一直使用 local，未受该绕过路径影响。等待修订后用同一 probe 复验；本次没有模型、DB、全仓或源码写入。
