# Targeted audit disposition at ac9e67c6

This was a read-only, context-aware audit disposition, not fresh-cold acceptance. Seven pure compileBugFix vectors actually ran against the retained current built compiler and protocol modules on Node 22. No checks from the synthetic registry were executed. No product files were edited; no build, full suite, admission, provider, DB, native host, installation or card operation ran here.

## Findings 1 and 2: proposed counterexamples rejected

| Vector | Schema outcome | Compiler outcome |
| --- | --- | --- |
| Legal original fixture, pass_codes [0] | Accept | Accept, executable:false |
| pass_codes [0,3] | INVALID_CHECK_IDENTITY_OR_PASS_CODES | INVALID_INPUT |
| pass_codes [3,0] | INVALID_CHECK_IDENTITY_OR_PASS_CODES | INVALID_INPUT |
| pass_codes [0,0] | INVALID_CHECK_IDENTITY_OR_PASS_CODES and OVERLAPPING_EXIT_CODES | INVALID_INPUT |
| Duplicate reproduction/builder, second required:false, different body_schema_digest | DUPLICATE_ARTIFACT_REQUIREMENT | INVALID_INPUT |
| Duplicate reproduction/builder, second required:true, different body_schema_digest | DUPLICATE_ARTIFACT_REQUIREMENT | INVALID_INPUT |
| Single reproduction/builder changed to required:false | Schema accepts | MISSING_OBLIGATION |

The claimed pass-code order/duplicate ambiguity is unreachable for legal input: joint-evidence.ts CheckRegistry requires exactly [0], and also checks duplicate/overlapping exit codes. Compiler Input embeds that refined CheckRegistry before normalization. ArtifactRequirements in method-binding.ts rejects duplicate artifact_ref_kind:producer_role keys regardless of required flag or body digest, and compiler Input embeds this refinement. Therefore the specific finding 1 and finding 2 examples are not defects in this candidate. The optional-only control independently confirms that successful schema parsing does not bypass mandatory obligations. This is not exhaustive testing of all compiler invariants.

## Finding 6: missing review input, not missing declared dependencies

The retained complete packages/cli/package.json declares both @osstack/protocol and @osstack/skill-registry as workspace:* production dependencies. Its tsup config explicitly externalizes skill-registry; protocol is not in that explicit list. Absence from an explicit external list is not absence from package dependencies. Both dependency manifests and the compiler/protocol code graph are retained. This resolves the narrow uncertainty about omitted manifest evidence. This task did not npm pack, publish, install a tarball, or execute an installed CLI, so it does not establish package publication or installation success.

## Finding 4: historical attribution corrected; build matching still matters

The retained PR313 publication record identifies head f6d7c09a487249a9973783912adb117e1df4333c. Git show of that exact head's execution-context.ts has no methods config field; git ls-tree for method-context.ts and bug-fix-compiler.ts is empty (successful exit 0). Its incidental local variable named methods is a proxy cache, not a methods configuration block.

The retained f6d7c09a→ac9e67c6 diff shows methods config and method-context.ts added. File history starts at a9a45116, followed by ac9e67c6, in this current implementation batch. Thus “PR313-era methods configs” is not an accurate compatibility claim. Draft methods configurations earlier in this batch are a separate, real distinction: current input requires compiled {path,sha256}; a draft without it rejects. No migration claim is made here.

The tutorial honestly requires the matching compiler build: whole compiled-output recompilation/canonical comparison includes current limitations and derived fields, so an artifact emitted by a differing build can reject. The publication-era correction does not remove this current operational constraint. Regenerate artifacts with the matching checkout/build; do not bypass checks or relabel an old artifact.

## Evidence and bounds

- probe.mjs is the complete actual harness; probe.stdout holds every full vector, actual schema issue, and full successful compiler output; probe.stderr is retained (empty), exit 0 in commands.json.
- commands.json records argv, cwd, explicit PATH, start/end UTC and exit for the probe and each Git evidence command.
- inputs/ contains complete relevant code/schema/build blobs, manifests, synthetic fixture, tutorial, and PR313 publication records. inputs-manifest.json gives each byte count and SHA-256.
- The module graph executed was the existing packages/skill-registry/dist/bug-fix-compiler.js plus existing protocol dist graph, not a newly rebuilt or silently rewritten copy. Their corresponding source files are also preserved.
- inputs-after-check.json proves all 32 retained input files had identical before/after hashes. No claim is made that this proves whole-repository immutability; parent owns the concurrent full-suite tracked-byte audit.
- audit-report-original.md retains the reviewed report unchanged. Git stdout/stderr files retain exact historical evidence, including the empty tree result.
- This targeted disposition does not close findings 3, 5 or 7, establish P6/native/provider consumption, authenticate caller source/check facts, or grant execution permission.

Operation rationale: snapshot exact relevant inputs first, run only requested synthetic pure-function counterexamples and legal controls, inspect exact retained PR head rather than relying on historical wording, then compare input hashes and freeze this report. No attempted upstream fetch or old experiment rerun.
