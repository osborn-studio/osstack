import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const root = '/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-method-bridge';
const scratch = '/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-method-bridge-20261030/compiler';
const require = createRequire(root + '/packages/skill-registry/package.json');
const ts = require('typescript');
const sourcePath = root + '/packages/skill-registry/src/bug-fix-compiler.ts';
const source = await readFile(sourcePath, 'utf8');
let js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText;
js = js.replace("'zod'", JSON.stringify(pathToFileURL(require.resolve('zod')).href))
  .replace("'@osstack/protocol/joint'", JSON.stringify(pathToFileURL(root + '/packages/protocol/dist/joint.js').href));
await writeFile(scratch + '/compiler-transpiled.mjs', js);
const { compileBugFix } = await import(pathToFileURL(scratch + '/compiler-transpiled.mjs').href);
const input = JSON.parse(await readFile(scratch + '/synthetic-input.json', 'utf8'));
const output = compileBugFix(input);
await writeFile(scratch + '/synthetic-compiled.json', JSON.stringify(output, null, 2) + '\n');
await writeFile(scratch + '/synthetic-binding.json', JSON.stringify({
  kind: 'synthetic_compiler_example', live_observation: false, actual_host_invoked: false,
  input_sha256: createHash('sha256').update(await readFile(scratch + '/synthetic-input.json')).digest('hex'),
  source_sha256: createHash('sha256').update(source).digest('hex'),
  execution_method: 'TypeScript transpileModule to owned scratch; zod and protocol imports resolved to built workspace dependencies',
  proposal_digest: output.proposal_digest, recipe_digest: output.recipe_digest,
  source_snapshot_digest: output.source_snapshot_digest, executable: output.executable,
}, null, 2) + '\n');
console.log(JSON.stringify({ kind: output.kind, executable: output.executable,
  proposal_digest: output.proposal_digest, material_roles: output.materials.map(m => m.role) }));
