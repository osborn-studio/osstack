/** RED stub only: no compilation behavior implemented. */
export function compileBugFix(_input: unknown): never {
  throw new Error('BUG_FIX_COMPILER_NOT_IMPLEMENTED');
}
