from pathlib import Path
import json, subprocess, hashlib, gzip, re
r=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-evidence-links')
out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-loader-cleanup-20261027/heartbeat-20261027T121316Z')
plan=json.loads((out/'restore-plan.json').read_text())
if plan['different_existing']: raise RuntimeError('Existing immutable evidence differs')
created=0;identical=0;absent_at_base=0
for item in plan['files']:
 data=subprocess.check_output(['git','show',plan['source_commit']+':'+item['source_path']],cwd=r)
 if hashlib.sha256(data).hexdigest()!=item['sha256']:raise RuntimeError('Source bytes differ')
 target=r/item['path']
 if target.exists() and target.read_bytes()!=data:raise RuntimeError('Would overwrite evidence')
 baseline=subprocess.run(['git','cat-file','-e','6929cb4d8c1e6d7dd95827531faa79547f2f9820:'+item['path']],cwd=r,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 absent_at_base+=baseline.returncode!=0
 if target.exists():identical+=1
 else:
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);created+=1
verified=[]
folders=list((r/'docs/design/2026-10-27-joint-engineering/evidence/joint-execution/loader-cleanup-retarget').glob('*/terminal'))
if len(folders)!=4:raise RuntimeError('Expected exactly four historical bundles')
for folder in folders:
 manifest=json.loads((folder/'archive-manifest.json').read_text())
 for entry in manifest['files']:
  data=(folder/entry['path']).read_bytes()
  if hashlib.sha256(data).hexdigest()!=entry['sha256']:raise RuntimeError('Archive hash differs')
  raw=gzip.decompress(data) if entry['path'].endswith('.gz') else data
  if hashlib.sha256(raw).hexdigest()!=entry['raw_sha256'] or len(raw)!=entry['raw_bytes']:raise RuntimeError('Raw evidence differs')
 names={p.name for p in folder.iterdir() if p.is_file()}
 expected={item['path'] for item in manifest['files']}|{'README.md','archive-manifest.json'}
 if len(expected)!=37 or names!=expected|{'code-to-observed-head.diff'}:raise RuntimeError('Bundle file closure differs')
 readme=(folder/'README.md').read_text()
 for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',readme):
  if not (folder/target).is_file():raise RuntimeError('README relative target missing: '+target)
 summary=json.loads((folder/'test-summary.json').read_text());verification=json.loads((folder/'verification.json').read_text())
 if (summary['passed'],summary['skipped'],summary['failed'])!=(6276,5,0) or summary['code_sha'] not in readme or '6,276 passed / 5 skipped / 0 failed' not in readme or not any(c.get('passed')==90 for c in verification['commands']):raise RuntimeError('Report/count/code differs')
 old_paths=subprocess.check_output(['git','ls-tree','-r','--name-only','6929cb4d8c1e6d7dd95827531faa79547f2f9820','--',str(folder.relative_to(r))],cwd=r,text=True).splitlines()
 for old in old_paths:
  if (r/old).read_bytes()!=subprocess.check_output(['git','show','6929cb4d8c1e6d7dd95827531faa79547f2f9820:'+old],cwd=r):raise RuntimeError('Existing baseline evidence changed')
 verified.append({'path':str(folder.relative_to(r)),'artifacts':len(manifest['files']),'files':len(names),'relative_links_resolve':True,'baseline_existing_files_verified':len(old_paths)})
(out/'restore-verification.json').write_text(json.dumps({'source_commit':plan['source_commit'],'planned_files':len(plan['files']),'absent_at_base_commit':absent_at_base,'created_this_invocation':created,'identical_skipped':identical,'bundles':verified,'baseline_byte_equality_check':'passed for every enumerated pre-existing file'},indent=2)+'\n')
print('Restored',len(plan['files']),'files; verified',len(verified),'complete bundles')
