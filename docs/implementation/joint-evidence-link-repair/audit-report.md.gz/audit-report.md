**Verdict: PASS**

I could not run anything, so this rests on the supplied material only. I did not re-hash any files or check the commit contents.

**What checks out**
- **Counts reconcile.** The plan lists 35 files in each of the first three snapshots (archive-manifest.json plus 34 artifacts) and 34 in the fourth, which already has its archive-manifest.json. That totals 139. Each bundle is 35 manifest entries + archive-manifest.json + README = 37, so the existing files are 2, 2, 2 and 3 (README, audit-code-binding.json, and archive-manifest.json in the fourth), 9 in total. 148 − 9 = 139.
- **No overwrite path.** The script aborts if `different_existing` is non-empty, if the source bytes don't match the planned sha256, or if an existing target differs. It never needs to change existing files.
- **Verification is two-level.** It checks compressed sha256, then the gunzipped sha256 and byte length, for all 35 entries in each of the four bundles.
- **There is a non-circular anchor.** In snapshots 1–3 the manifest was itself restored, so a manifest-to-artifact match alone only shows the source commit is self-consistent. However, the pre-existing `audit-code-binding.json` is a manifest entry and was hash-checked. The fourth snapshot's manifest was pre-existing. That ties the restored bytes to the original reports.
- **Scope is clean.** The only repo change shown is the one operating-prose line in project-operations.md. It matches the root cause: reports were copied without their attachment archives, and checks ran on pre-copy state. Requiring staged-final hygiene and ledger tests, and forbidding stale results, addresses that.

**P0**
- None.

**P1**
- None. The staged-candidate hygiene and checkpoint run is not in the supplied evidence. That is an open pre-merge step rather than a false claim, but PR282 must not report "fixed" until a clean run on the final staged tree is recorded.

**P2**
- `restore-verification.json` hardcodes `existing_evidence_modified: false`. It also sets `restored_files` to `len(plan['files'])`, not to the files actually created, because the script accepts a target that already exists with identical bytes and rewrites it. The "139 absent" claim therefore depends on the plan generator, which is not shown. Compute both values: count newly created paths, and skip the write when the bytes are identical.
- The script verifies manifest entries only. It does not check that each snapshot holds exactly 37 files, that archive-manifest.json is in each, or that every relative link in each README resolves, which is the check that actually failed. Add a link-resolution pass or cite the hygiene output.
- Nothing cross-checks the restored `test-summary.json` against the README's stated numbers (6,276 passed, 90 focused tests, candidate c60850c4). A one-line comparison would close that.
- The prose mentions hashing but not the README-link check. Naming "relative link targets resolve" as the gate would match the actual failure mode.
- Restoring the same source directory into four snapshots gives byte-identical artifacts across them. That is fine if the four reports are copies of one report, as stated. Say so in the PR body so reviewers don't read it as four independent runs.

END_AUDIT