# Verdict: REVISE

The core scoped claims hold up against the supplied raw records. The REVISE items are claim-vs-evidence mismatches and dangling references in the published text, not problems with the observations. All are cheap to fix.

## Issues to fix before publishing

1. **The test SHA does not cover the candidate.**
   - `pnpm test` ran at `4d6bb58…`, and "product source same as main" is asserted without a tree comparison in the supplied content.
   - The candidate `7f3d7a0…` changes at least `EXPORT.md`. The extended "Host discovery checks" section is far larger than the 2559-byte `EXPORT.md` retained in `harness/source`.
   - Doc or export tests may inspect that file, and nothing shows they ran against the candidate.
   - **Fix:** state `tree(4d6bb58)` against `tree(ca95aba1)` (`9efad98…`), or drop "same source". Add a statement of the candidate's own test status: run the export and doc tests at `7f3d7a0`, or say the regression excludes the candidate's doc edits. Show the `ca95aba1..7f3d7a0` diff scope, and confirm the exported-entry hashes are unchanged (they should still be 40 files, `44b169e2…` for help).

2. **"`--safe-mode` also disables skills" has no support in the supplied evidence.** Nothing was observed or source-excerpted for it. **Fix:** cite an artifact and label it help-text-derived, or delete it. Likewise "restricted mode ignores project settings" is help-text and source-derived. `catalog-semantics.md` calls it a plausible explanation, not a proven root cause, but `EXPORT.md` states it as fact.

3. **The Codex sentence in `EXPORT.md` overstates the result and drops its caveats.**
   - "Explicitly requested `osstack-help` invocation" is loose. In the Codex stream the read was a shell `cat` of the exact path. There is no native skill-invocation event, and the host-injected catalog that told the model the path is not in the stream.
   - The graded Codex outcome was `inconclusive_observability` (inventory gap, resolved model not attested). Only the Claude paragraph carries the limits and the link to the experiment README.
   - **Fix:** say "read via shell `cat` of the exported path", add the same limits, and link the README.

4. **The archive references evidence it does not contain.**
   - Missing from the manifest but referenced from archived text: `claude-v2-permission-source.json`, `claude-v2-permission-followup.json`, `catalog-semantics.json`, and `settings-before-builtin-deny.json`. The last is cited in `claude-v2-proposal.md` as "preserved".
   - `claude-v2-prepared.json` binds settings hashes `2a2815a3…` and `77297e96…`, which differ from the final `state/settings.json` hashes `84314f44…` and `9c492842…`. The earlier settings were changed after prepare and are not retained.
   - The vendor excerpts are disclosed as excluded, but the other files are not. `v2-check-prefreeze.py` cannot be re-run from the archive.
   - **Fix:** add an "excluded or superseded" list with sha256s (the dispatch file already holds `225f68a8…` and `d3c233ad…`). Include `settings-before-builtin-deny.json` or state that it is gone. Note that the prepared hashes are superseded by the final settings.

5. **The README says "原始模型及工具事件" are retained, but the initialize line is not raw.** In `run.jsonl`, the `control_response` (line 2) is re-serialized with `account` redacted (the v1 `catalog-control.jsonl` is likewise a re-serialization). This is disclosed in the harness docs and the grade, but not in the README. **Fix:** add one sentence.

6. **Possible dead links.**
   - The README links `v1-graded-results.md` and `v2-graded-results.md`, but the archive's v1 file is `independent/graded-results.md`.
   - **Fix:** confirm the targets exist in the candidate. State their sha256s, which should match the archive (`1fc19e5a…` for v1 and `62c47cdb…` for v2) or be declared copies.

## Lower severity

- **Inconsistent redaction.** The test log had its HOME prefix replaced, but `/Users/osborn` remains in `preflight.py` and `run_codex.py`, and `osborn staff` is in `codex-absent/response.jsonl`. `rate_limit_event` also exposes account quota state (0.89 weekly) in `run.jsonl`. These are not credentials. Either scrub them or record that they are intentionally public.
- **The secret scan is narrow.**
  - It checked 5 exact known values over 703 files at 11:17:40, before the archive was built at 11:22:52. It is not a generic token scan, and it does not cover files created after it ran (`v2-graded-*`, the cleanup supplement).
  - `acceptance-review/archive-safety.json` may cover this, but I cannot see it. Confirm it scans the extracted members, ideally with token-shape patterns as well.
  - Never print that your own wording "no credentials archived" is stronger than this evidence.
- **"Isolated authentication" means an isolated config dir only.** Claude used the operator's real keychain OAuth token in the child environment. Codex used a copy of the live `auth.json`. The default-file hash was unchanged, but whether the copy rotated any refresh token is not examined. This is an unknown, not a defect.
- **The README lacks Codex's overall label** (`inconclusive_observability`) and the H2 gap (no catalog PID or timing, launcher fingerprint rather than the vendor binary).
- **`manifest.json` is not self-bound.** It is pinned only by the commit, which is probably acceptable.
- **Confirm the acceptance review matches the final text.** Check that `acceptance-review/source-binding.json` binds the same `ca95aba1`, `4d6bb58` and tree, and that it reviewed the final README, not an earlier draft.

## Checked and supported

- **Test totals.** The package counts sum to 7144 passed and 5 skipped, with exit 0 and a fresh install and build.
- **Call budget.** Four model calls with no retries (Codex 2, Claude 2). The restricted and unrestricted initialize diagnostics had zero user turns.
- **Claude diagnostic and v2 catalogs.**
  - The diagnostic gave 53 commands and 0 targets when restricted, and 57 commands and 4 targets otherwise.
  - The v2 `system/init.skills` has 0 targets for the absent case and all 4 for the present case, in the same process.
- **v2 present case.**
  - `Skill(osstack-help)` succeeded and its body was expanded.
  - Two complete `Read` calls returned `evidence.md` and `maintain-verification.md`.
  - The `Glob` of `osstack-mode` is correctly not counted as a read.
  - The answer discloses that the `osstack-mode` `SKILL.md` was not read.
- **v2 absent case.** The model made two `Glob` calls, selected no skill, and said so.
- **Model and process.** `claude-sonnet-5-5` appears in init, in the assistant messages and in `modelUsage`. Both processes exited 0 with unchanged inventories that include `.git`.
- **Word counts.** 329 and 345 are under 350 by the frozen `\S+` rule. The margin is thin for the present case, so the counting rule should stay quoted.
- **Freeze ordering.** Criteria were frozen at 10:49, before Codex dispatch at 10:53. The v2 prefreeze was at 11:15:09 and dispatch approval at 11:15:32, before the 11:15:57 run. Runner and prompt SHAs match the manifest.
- **Permission-boundary text.** It matches the settings: the native read fence, a workspace-only allow, explicit deny roots, and 53 Skill denies. The README correctly does not claim an OS sandbox.
- **Retained failures.** v1 failures are labelled as retained outcomes, and the v1 grade is not rewritten.

## Unknowns I am leaving open

- The `7f3d7a0` diff, and whether it touches anything other than docs.
- The tree of `4d6bb58`.
- The contents of `archive-safety.json`, `acceptance-review/*`, `merge-observation.json`, and the `v1/v2-graded-results.md` copies in the docs directory.
- The `host_discovery_verified: false` field in the exporter.
- The unchanged authorship, licence and history claim.

I have not assessed runtime or J01 qualification.