# Native discovery 本轮范围与未来验收例复核

只读基线：`8930f0fb910eb48e8a2e0033aee721fff04b956d`，为当前 main `ca95aba1` 加管理文档交接。源文件读取哈希及与该 Git 对象逐字相等检查见 source-binding.json。本报告未运行模型、产品测试或宿主认证/schema 探测；未评分任何尚未发生的响应，未修改仓库。

## 结论

当前材料没有“导出即原生注册”的已确认产品缺陷。`EXPORT.md:14` 要求实际宿主目录观察；`entries/osstack-help/SKILL.md:19` 分开声明 discovery、explicit read、registration、execution；实际 exporter `scripts/lib/osstack-method-export.mjs:244,248` 固定输出 `installed:false/global_registration:false/host_discovery_verified:false`。这不是等待实验后改成 true 的默认字段：导出器自身没有加载宿主，成功实验应另写带宿主版本/候选/路径的观测回执，不能给以后每次 export 全局签 discovery。

四个入口均有明确 name/description，正确保持 scope：mode 路由四类材料；help 解答当前路径并在已授权行动时继续；setup 提议或在已确定授权和宿主支持下应用设置；agent 仅包装实际委派。不创建 CLI 子命令/原生 agent 类型。只实验 help 不足以实际验收另外三个入口的行为。

## 本轮四次调用可支持的有限结论

| 可记录的证据 | 合理结论 | 不能顺带声明 |
|---|---|---|
| 有包组真实 catalog 列出四个目标 name，并绑定本次项目路径；无包组不含 | 这两个具体 CLI/版本/隔离环境支持本次包的项目发现 | 任意版本/桌面UI/全局安装；其余入口已被使用 |
| help 的实际原生选择或展开，连同绑定正文的读取记录 | 被用户明确点名的 help 可选用、读取 | 隐式自动触发率、无需提示即可自主选中、全部宿主等价 |
| 实际读取 maintain/evidence 等选定链接 | 这些具体引用在本次消费链可达 | 所有链接/全部 reference 都读过；仅正确答案并不足以证明读取 |
| 同一题的实际解释、且保留提议与观测区别 | 本次真实宿主进行了只读方法解释 | 已维护验证驱动、执行产品用例、实现修复或完成D2a旅程 |
| 无包组未虚构加载、未另找副本，仍能普通回答 | 本次对照未观察到目标包污染/伪称使用 | 方法改善质量/因果收益；单组对照不是统计比较 |

这些是未来验收例的建议范围，不是当前执行结论。保持目录发现、选择、正文读取、引用读取、回答内容五项分别记录；不要用一个 native=true 掩盖局部可观察性。尤其 Codex catalog 与 exec 是两个进程，目录看到与模型读取之间只能报告有记录的关联，不能伪称同一进程的加载事件。严格限定 help 的消费证据；即使流程中读到 mode 的文字，也不等于另一次原生 mode 调用。

## D2a 与历史欠覆盖

当前机器执行门槛 `execution-gates.json` 中没有 D2a 同名 gate。`execution.md:136` 将 D2a 明确当作工程工具增量，不产生 J01/J11/J03/J09 资格。`verification-kit/README.md` 仍要求后续真实宿主旅程及既有授权入口；本轮只补项目发现/选择/读取这一小格，不把材料可用替代 MethodBinding、principal 身份、正式方法授权或产品激活。

上轮 `osstack-method-entrypoints/host-use.md` 的两次调用是嵌入同一导出材料、模拟六个请求、零工具事件。它明确未建立 native discovery；预冻结条件也非全满足：expected-negative exit1 与 verifier success 的区别、具体宿主调用、权限交接不全；委派、清理及输入保持未执行；Claude还提出过过宽的逐次合并确认。本轮 stale-driver help 题能补 native 加载事实，但不能补上述全部执行欠覆盖，不能把过去部分通过改写为全通过。历史固定 SHA 输入保持原属。

## 真失败时允许考虑的最小修订

| 实际观察 | 最小修订位置/措施 | 不应采取的替代 |
|---|---|---|
| 正确目录但宿主拒绝本次 frontmatter/name/description，且原始解析错误指向材料 | 精确失败的 entry SKILL.md 元数据；若 exporter 发出错误格式才改 export helper 及一条对应反例 | 重写全部入口、注册额外全局目录、假造宿主 schema |
| 宿主真实加载后相邻 entry 或 reference 路径错误 | 先分辨源链接错误或导出重写错误；仅改相应链接/重写及对应定向检查 | 把全部正文塞进 prompt 并把 explicit reading 算 native |
| 宿主权限/信任/隔离配置拒绝读取或技能选择 | 先记录 blocked/limited 与原始错误；允许的实验配置由其负责人复核；必要只在 EXPORT/host-usage 加该版本限制说明 | 撤掉隔离、扩大Bash/写/联网权限、绕过管理策略或静默退回默认home |
| 目录中有技能但原生展开无法在记录中证实 | 报 catalog_only/inconclusive；若交付需要，补明确“当前CLI记录不可观察”的说明 | 仅凭模型说已加载即签正文读取 |
| 指名 help 能读，却只重复建议或未读 relevant references | 保留行为缺口；只有可归因的材料歧义才小改 help 对相关引用的指引 | 无限重试直到正确、为新指令倒改原判据 |
| 实验参数本身不支持、输入/身份绑定错误 | 修本轮 harness/说明，保留原失败与新版本关系 | 认定 exporter 产品错误或通过变更 runtime gate 解围 |

代码修订不是本只读任务的授权。任何后续实际补丁应保留原先失败，绑定新文件哈希，按已授权预算决定再验证；本轮四调用不含自动追加第五次。当前未发现必须先改产品才能实验的材料缺陷。host-usage/EXPORT 已充分保留“正常原生选择可用，explicit reading 只是另一条路径”，无需把本轮失败变成全局 explicit-only 政策。
