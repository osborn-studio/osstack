from pathlib import Path
import subprocess,json,hashlib,shutil,datetime
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-native-discovery');r=Path(__file__).parent.parent
base='ca95aba1c186d9c3a9e70a45143b7a277db84404';test='4d6bb58d446da32a3044d5375baa7f2f935eddf2';candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True).strip()
proof={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_base':base,'full_regression_head':test,'reviewed_candidate':candidate,'trees':{x:git('rev-parse',x+'^{tree}') for x in [base,test,candidate]},'changed_files_base_to_test':git('diff','--name-only',base,test).splitlines(),'changed_files_base_to_candidate':git('diff','--name-only',base,candidate).splitlines(),'current_uncommitted_files':git('diff','--name-only').splitlines(),'rule':'Full pnpm test binds 4d6bb58d and excludes later documentation edits. Product-source equality uses complete diff scope, not equal whole trees. Final docs/export checks and publication CI separately required.'}
for field in ['changed_files_base_to_test','changed_files_base_to_candidate','current_uncommitted_files']:
 assert all(n.startswith('docs/') or n=='osstack-methods-skill/EXPORT.md' for n in proof[field]),proof[field]
proof['runtime_product_diff_empty']=True
proof['exports']=[]
for host in ['codex','claude']:
 dest=r/'control'/('candidate-export-'+host);assert not dest.exists()
 p=subprocess.run(['/opt/homebrew/opt/node@22/bin/node','scripts/export-osstack-methods.mjs','--host',host,'--output',str(dest)],cwd=w,capture_output=True,text=True)
 (r/'control'/('candidate-export-'+host+'.stdout')).write_text(p.stdout);(r/'control'/('candidate-export-'+host+'.stderr')).write_text(p.stderr);assert p.returncode==0,p.stderr
 old=json.loads((r/'runs'/('codex-present' if host=='codex' else 'claude-v2-present')/'evidence/export-manifest.json').read_text());new=json.loads((dest/'manifest.json').read_text());assert new['files']==old['files'];assert new['host_discovery_verified'] is False
 for row in new['files']:
  b=(dest/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 proof['exports'].append({'host':host,'exit_code':p.returncode,'files_checked':len(new['files']),'same_file_hashes_as_frozen_experiment':True,'source_digest':new['source_digest'],'host_discovery_verified':False});shutil.rmtree(dest)
proof['grade_copies']=[]
for src,dst in [('graded-results.md','v1-graded-results.md'),('v2-graded-results.md','v2-graded-results.md')]:
 a=r/'independent'/src;b=w/'docs/implementation/method-native-discovery'/dst;assert a.read_bytes()==b.read_bytes();proof['grade_copies'].append({'repo_path':str(b.relative_to(w)),'archive_path':'independent/'+src,'sha256':hashlib.sha256(a.read_bytes()).hexdigest()})
(r/'control/candidate-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'product_diff_empty':True,'exports':proof['exports'],'grade_copies':proof['grade_copies']},indent=2))
