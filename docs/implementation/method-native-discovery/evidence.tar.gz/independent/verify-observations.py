from pathlib import Path
import json,hashlib,re,shlex,subprocess,datetime,shutil
root=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-native-discovery-20261028');out=root/'independent';sha=lambda b:hashlib.sha256(b).hexdigest();results={};names={'osstack-help','osstack-mode','setup-osstack','osstack-agent'}
prepared=json.loads((root/'harness/prepare.json').read_text());sourcechecks=[]
for f in prepared['source_files']:
 data=(root/'harness/source'/f['path']).read_bytes();git=subprocess.run(['git','show',prepared['candidate']+':'+f['path']],cwd='/Volumes/AIMATE_WORK/Developer/CodeX/osstack',capture_output=True,check=True).stdout
 sourcechecks.append({'path':f['path'],'matches_recorded_hash':sha(data)==f['sha256'],'matches_candidate_git_bytes':data==git})
for case in ['codex-absent','codex-present']:
 e=root/'runs'/case/'evidence';ws=e.parent/'workspace';inv=json.loads((e/'invocation.json').read_text());events=[json.loads(x) for x in (e/'response.jsonl').read_text().splitlines()];copy=out/'observed-inputs'/case;copy.mkdir(parents=True,exist_ok=True)
 for p in e.iterdir():
  if p.is_file():shutil.copyfile(p,copy/p.name)
 hashes=[{'path':f,'matches':sha((e/f).read_bytes())==h} for f,h in inv['file_hashes'].items()]
 catraw=[json.loads(x) for x in (e/'catalog.jsonl').read_text().splitlines()];catentry=next((i,v['result']) for i,v in enumerate(catraw,1) if v.get('id')==1);catalog=json.loads((e/'catalog.json').read_text());assert catentry[1]==catalog
 target=[{'name':x['name'],'path':x['path'],'enabled':x['enabled']} for row in catalog['data'] for x in row['skills'] if x['name'] in names]
 before=json.loads((e/'workspace-before.json').read_text());after=json.loads((e/'workspace-after.json').read_text());fresh={str(p.relative_to(ws)):sha(p.read_bytes()) for p in ws.rglob('*') if p.is_file() and '.git' not in p.relative_to(ws).parts}
 rawreads=[];messages=[];tooltrace=[]
 for line,v in enumerate(events,1):
  item=v.get('item',{})
  if v['type']=='item.completed' and item.get('type')=='agent_message':messages.append({'line':line,'id':item['id'],'text':item['text']})
  if v['type']!='item.completed' or item.get('type')!='command_execution':continue
  tooltrace.append({'line':line,'id':item['id'],'command':item['command'],'exit_code':item['exit_code'],'status':item['status']})
  argv=shlex.split(item['command']);nested=shlex.split(argv[2])
  if nested[0]=='cat':
   payload=b'';inputs=[]
   for rel in nested[1:]:
    p=ws/rel;assert p.resolve().is_relative_to(ws.resolve());data=p.read_bytes();payload+=data
    q=out/'material-read-inputs'/case/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
    inputs.append({'path':rel,'bytes':len(data),'sha256':sha(data),'matches_before_inventory':before[rel]==sha(data)})
   rawreads.append({'event_line':line,'id':item['id'],'inputs':inputs,'output_matches_exact_concatenated_file_bytes':payload==item['aggregated_output'].encode(),'output_sha256':sha(item['aggregated_output'].encode()),'exit_code':item['exit_code']})
 final=messages[-1];words=len(re.findall(r'\S+',final['text']));(out/(case+'-final-answer.txt')).write_text(final['text']);manifestchecks=[]
 if case.endswith('present'):
  mf=json.loads((e/'export-manifest.json').read_text())
  for f in mf['files']:
   data=(ws/f['path']).read_bytes();manifestchecks.append({'path':f['path'],'bytes_match':len(data)==f['bytes'],'hash_matches':sha(data)==f['sha256']})
 # This is explicitly after-the-fact evidence. It cannot fill missing before snapshots.
 posthoc=[]
 for p in sorted(ws.rglob('*')):
  rel=str(p.relative_to(ws));stat=p.lstat()
  if p.is_symlink():posthoc.append({'path':rel,'type':'symlink','target':str(p.readlink())})
  elif p.is_file():posthoc.append({'path':rel,'type':'file','bytes':stat.st_size,'sha256':sha(p.read_bytes())})
  elif p.is_dir():posthoc.append({'path':rel,'type':'directory'})
 (out/(case+'-posthoc-full-inventory.json')).write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'post hoc only; no before counterpart exists for .git/types/lengths','entries':posthoc},indent=2)+'\n')
 results[case]={'file_bindings':hashes,'catalog_raw_line':catentry[0],'catalog_projection_equals_raw':True,'target_catalog':target,'material_inventory_before_equals_after':before==after,'current_material_hashes_equal_recorded_after':fresh==after,'inventory_excludes_git':not any(p.startswith('.git/') for p in before),'original_inventory_value_shape':'path -> sha256; no type or byte length','reads':rawreads,'tool_trace':tooltrace,'final_answer':{'raw_line':final['line'],'item_id':final['id'],'sha256':sha(final['text'].encode()),'whitespace_words':words,'under350':words<350},'other_visible_messages':[{'raw_line':m['line'],'whitespace_words':len(re.findall(r'\S+',m['text']))} for m in messages[:-1]],'export_files_verified':manifestchecks,'usage_event':events[-1],'private_home_absent_now':not (e.parent/'private-home').exists()}
assert all(x['matches_recorded_hash'] and x['matches_candidate_git_bytes'] for x in sourcechecks)
for r in results.values():
 assert all(x['matches'] for x in r['file_bindings'])
 assert all(x['output_matches_exact_concatenated_file_bytes'] for x in r['reads'])
 assert all(x['bytes_match'] and x['hash_matches'] for x in r['export_files_verified'])
(out/'observations-verified.json').write_text(json.dumps({'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_git_checks':sourcechecks,'cases':results},indent=2)+'\n')
print(json.dumps({c:{'catalog_targets':len(v['target_catalog']),'read_events':len(v['reads']),'words':v['final_answer']['whitespace_words'],'material_unchanged':v['material_inventory_before_equals_after'],'export_files':len(v['export_files_verified'])} for c,v in results.items()},indent=2))
