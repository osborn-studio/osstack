from pathlib import Path
import json, hashlib, os, stat, subprocess, datetime
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-native-discovery-20261028'); H=R/'harness'; O=R/'independent'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
J=lambda p:json.loads(p.read_text())
T={'osstack-help','osstack-mode','setup-osstack','osstack-agent'}
fixed=[]
def bind(p):
 assert p.is_file() and not p.is_symlink(),p
 fixed.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
def inv(ws):
 paths=[ws]
 for parent,dirs,files in os.walk(ws,followlinks=False):
  paths.extend(Path(parent)/n for n in dirs+files)
 result={}
 for p in paths:
  s=p.lstat();k=str(p.relative_to(ws));d={'length':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISREG(s.st_mode):d.update(type='file',sha256=sha(p))
  elif stat.S_ISDIR(s.st_mode):d['type']='directory'
  elif stat.S_ISLNK(s.st_mode):d.update(type='symlink',target=os.readlink(p))
  else:raise AssertionError(k)
  result[k]=d
 return result
criteria=O/'criteria-prefreeze.json'; supplement=O/'prompt-prefreeze-supplement.json'
assert sha(criteria)=='6ba7fd3cd626d3b96ab6a4a4c451e9d607abb216b4c3092490b49c5e1cc730fa'
assert sha(supplement)=='79e83b5d4df35e447e5e39ceb1fcbacff565c74218cacd928720f5dd27de0842'
assert sha(H/'prompt.txt')=='36a20a486e7e4e3f0aa72e95a42d4d108c8b09c7021848271e227c4f348d8c9c'
for p in [criteria,supplement,H/'prompt.txt',H/'preflight.py',H/'claude_v2.py',H/'claude-v2-builtin-catalog.json',H/'claude-v2-proposal.md',H/'prepare.json']:
 bind(p)
builtin=J(H/'claude-v2-builtin-catalog.json');assert len(builtin)==len(set(builtin))==53 and not T.intersection(builtin)
permission=[]
for fn in ['claude-v2-permission-source.json','claude-v2-permission-followup.json']:
 p=H/fn;x=J(p);b=Path(x['binary']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['sha256']
 for e in x['excerpts']:
  t=e['text'].encode();assert b[e['offset']:e['offset']+len(t)]==t
 permission.append({'path':str(p),'excerpt_count':len(x['excerpts']),'binary_sha256':x['sha256'],'byte_offsets_verified':True});bind(p)
exe=Path(J(H/'claude-v2-permission-source.json')['binary']);assert Path('/opt/homebrew/bin/claude').resolve()==exe;bind(exe)
prep=J(H/'prepare.json');source=[]
for f in prep['source_files']:
 b=subprocess.check_output(['git','show',prep['candidate']+':'+f['path']],cwd='/Volumes/AIMATE_WORK/Developer/CodeX/osstack')
 assert hashlib.sha256(b).hexdigest()==f['sha256'];source.append(f)
casechecks=[]
for mode in ('absent','present'):
 case=R/'runs'/('claude-v2-'+mode);ws=case/'workspace';ev=case/'evidence';settings=J(case/'state/settings.json');p=settings['permissions']
 assert settings['disableAllHooks'] is True and p['blockReadsOutsideWorkingDirectories'] is True and p['additionalDirectories']==[]
 expected_allow={'Skill('+n+')' for n in T}|{tool+'(/'+str(ws)+'/**)' for tool in ('Read','Glob','Grep')}
 assert set(p['allow'])==expected_allow
 assert {'Skill('+n+')' for n in builtin}.issubset(p['deny'])
 assert {'Bash','Edit','Write','NotebookEdit','Agent','Task','WebFetch','WebSearch'}.issubset(p['deny'])
 for tool in ('Read','Glob','Grep'):
  for path in [str(case/'private-home'),str(case/'state'),str(ev),'/Users','/opt','/private','/tmp','/$bunfs']:
   assert tool+'(/'+path+'/**)' in p['deny']
 assert J(case/'state/empty-mcp.json')=={'mcpServers':{}}
 result=J(ev/'catalog-final-result.json');assert result['exit_code']==0 and result['user_turns']==0 and result['status']=='catalog_gate_observed' and result['private_home_removed']
 argv=result['argv'];assert argv[argv.index('--tools')+1]=='Skill,Read,Glob,Grep' and argv[argv.index('--permission-mode')+1]=='dontAsk' and argv[argv.index('--setting-sources')+1]=='project,local' and '--restricted' not in argv
 assert {'--strict-mcp-config','--no-session-persistence','--no-chrome'}.issubset(argv)
 records=[json.loads(x) for x in (ev/'catalog-final.jsonl').read_text().splitlines()]
 replies=[x for x in records if x.get('type')=='control_response' and x.get('response',{}).get('request_id')=='native-v2-initialize'];assert len(replies)==1
 names=[x['name'] for x in replies[0]['response']['response']['commands']];expected=set(builtin)|(T if mode=='present' else set());assert set(names)==expected and len(names)==len(expected)
 before=J(ev/'catalog-final-before.json');after=J(ev/'catalog-final-after.json');actual=inv(ws);assert before==after==actual
 assert '.git' in actual and not any(v['type']=='symlink' for v in actual.values())
 assert not (case/'private-home').exists()
 for f in ('run-before.json','run.jsonl','user-input.json'):assert not (ev/f).exists()
 ancestor_checks=[]
 for parent in [ws,*ws.parents]:
  for name in ('.claude/settings.json','.claude/settings.local.json','.mcp.json','CLAUDE.md'):
   path=parent/name;assert not path.exists(),str(path);ancestor_checks.append(str(path))
 count=0
 if mode=='present':
  manifest=J(ev/'export-manifest.json');assert len(manifest['files'])==40
  for f in manifest['files']:
   fp=ws/f['path'];assert fp.stat().st_size==f['bytes'] and sha(fp)==f['sha256'];count+=1
  bind(ev/'export-manifest.json')
 for fp in sorted(ws.rglob('*')):
  if fp.is_file():bind(fp)
 for fp in [case/'state/settings.json',case/'state/empty-mcp.json',ev/'catalog-final-result.json',ev/'catalog-final-before.json',ev/'catalog-final-after.json',ev/'catalog-final.jsonl']:
  bind(fp)
 casechecks.append({'case':case.name,'workspace':str(ws),'preflight_targets':sorted(T) if mode=='present' else [],'catalog_names':names,'catalog_pid':result['pid'],'catalog_start':result['at'],'catalog_end':result['finished'],'catalog_exit':0,'complete_inventory_entries':len(actual),'inventory_includes_git':True,'no_symlinks':True,'export_files_verified':count,'no_ancestor_config_found':True,'ancestor_paths_checked':ancestor_checks,'no_run_artifacts':True,'model_user_turns':0,'argv':argv})
assert 'if all_names!=expected_names:raise RuntimeError' in (H/'claude_v2.py').read_text()
assert "for entry in approval['frozen_files']" in (H/'claude_v2.py').read_text()
bind(Path(__file__))
report={'schema_version':2,'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/cleanup_regression independent engineering reviewer within same authorized task; not formal trusted principal','decision':'eligible_for_root_dispatch_with_explicit_native_configuration_limits','root_dispatch_authorization':False,'v1_unchanged':True,'criteria_sha256':sha(criteria),'prompt_supplement_sha256':sha(supplement),'prompt_sha256':sha(H/'prompt.txt'),'runner_sha256':sha(H/'claude_v2.py'),'candidate':prep['candidate'],'tree':prep['tree'],'budget':{'claude_user_turns_max':2,'case_order':['claude-v2-absent','claude-v2-present'],'per_call_seconds':180,'retries':0,'total_with_codex_v1_max':4},'required_dispatch':{'approved':True,'runner_sha256':sha(H/'claude_v2.py'),'prompt_sha256':sha(H/'prompt.txt'),'frozen_files':fixed},'cases':casechecks,'permission_evidence':permission,'source_git_files_verified':source,'unchanged_scoring':['Original criteria and prompt supplement apply in full; no post-response weakening.','Preflight SDK commands projection is not retroactively renamed system/init. Preserve runtime system/init/catalog and actual Skill/body/ref results; missing required observation remains limited or inconclusive.','Same-process full observed catalog must exactly match frozen53 plus expected targets before a user turn; permissions expand requests denied.','Actual Skill selection and help/maintain/evidence bodies must be observed, not inferred from descriptions or names.','Requested model is claude-sonnet-5-5; actual response/modelUsage must be retained. No fallback.','Any prohibited action/non-target material behavior fails or limits BOUNDARIES per original criteria, even if host autoallowed it.','Complete run-before/after workspace inventories including .git/type/length/mode/hash/link needed, not substituted by these preflight records.','Private home removal and later owned-workspace cleanup are separate axes; pending retention cannot become overall PASS.'],'limits':['Native permission configuration and actual tool traces, not OS process sandbox or whole-process I/O proof.','Read deny precedes native outside-working-dir fence; explicit deny covers observed internal exception roots. This is not a universal claim about all possible host internal paths.','53 observed non-target Skill names denied and four exports allowed. Hidden/non-userInvocable native skills not fully enumerated; this is not a universal Skill whitelist.','Native autoallow metadata set includes context/agent/background fields; do not simplify its predicate to only static instruction text.','CLI control account fields redacted; tool/model raw lines otherwise preserved by runner.','No model response for these new cases has appeared at this freeze; engineering eligibility is not behavior PASS or J01 qualification.']}
with (O/'v2-prefreeze.json').open('x') as f:json.dump(report,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps({'decision':report['decision'],'sha256':sha(O/'v2-prefreeze.json'),'runner_sha256':report['runner_sha256'],'frozen_files':len(fixed),'source_git_files':len(source),'cases':[{'case':c['case'],'catalog_names':len(c['catalog_names']),'inventory_entries':c['complete_inventory_entries'],'exports':c['export_files_verified']}for c in casechecks]},indent=2))
