from pathlib import Path
import json,hashlib,os,stat,re,shutil,datetime
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-native-discovery-20261028');O=R/'independent';J=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=J(O/'v2-prefreeze.json')
assert sha(O/'v2-prefreeze.json')=='f456d86c05cde248b9be463162ab2b400ed0bdef211411956f906e27f80b0e62'
for f in freeze['required_dispatch']['frozen_files']:assert sha(Path(f['path']))==f['sha256'],f['path']
guard=J(R/'harness/claude-v2-dispatch.json');assert guard['approved'] and guard['runner_sha256']==freeze['runner_sha256']
for f in guard['frozen_files']:assert sha(Path(f['path']))==f['sha256']
def inv(ws):
 paths=[ws]
 for d,dirs,files in os.walk(ws,followlinks=False):paths.extend(Path(d)/x for x in dirs+files)
 out={}
 for p in paths:
  s=p.lstat();v={'length':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISREG(s.st_mode):v.update(type='file',sha256=sha(p))
  elif stat.S_ISDIR(s.st_mode):v['type']='directory'
  elif stat.S_ISLNK(s.st_mode):v.update(type='symlink',target=os.readlink(p))
  else:raise AssertionError(str(p))
  out[str(p.relative_to(ws))]=v
 return out
obs={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prefreeze_sha256':sha(O/'v2-prefreeze.json'),'dispatch_sha256':sha(R/'harness/claude-v2-dispatch.json'),'frozen_files_still_exact':True,'cases':{}}
for mode in ('absent','present'):
 name='claude-v2-'+mode;case=R/'runs'/name;ev=case/'evidence';ws=case/'workspace';dst=O/'v2-observed-inputs'/name;dst.mkdir(parents=True,exist_ok=False)
 for p in sorted(ev.iterdir()):
  if p.is_file():shutil.copyfile(p,dst/p.name)
 raw=(ev/'run.jsonl').read_bytes();events=[(n,json.loads(l))for n,l in enumerate(raw.decode().splitlines(),1)]
 record=J(ev/'run-result.json');assert record['user_turns']==1 and record['exit_code']==0 and record['result_received'] and record['initialized']
 before=J(ev/'run-before.json');after=J(ev/'run-after.json');actual=inv(ws);assert before==after==actual;assert '.git' in before
 assert not(case/'private-home').exists();assert J(ev/'user-input.json')['message']['content']==(R/'harness/prompt.txt').read_text()
 initline,init=next((n,x)for n,x in events if x.get('type')=='system'and x.get('subtype')=='init')
 assert set(init['tools'])=={'Glob','Grep','Read','Skill'} and init['mcp_servers']==[] and init['permissionMode']=='dontAsk' and init['model']=='claude-sonnet-5-5'
 targets=set(freeze['cases'][1]['preflight_targets']);found=set(init['skills'])&targets;slash=set(init['slash_commands'])&targets
 assert found==slash==(targets if mode=='present'else set())
 assert len(init['skills'])==len(set(init['skills'])) and len(init['slash_commands'])==len(set(init['slash_commands']))
 final_line,final=next((n,x)for n,x in events if x.get('type')=='result')
 assert final['subtype']=='success' and not final['is_error'] and final['permission_denials']==[] and set(final['modelUsage'])=={'claude-sonnet-5-5'}
 assert final['subagent_stats']['spawned']==0 and final['usage']['server_tool_use']=={'web_search_requests':0,'web_fetch_requests':0}
 msgs=[(n,b['text'])for n,x in events if x.get('type')=='assistant'for b in x.get('message',{}).get('content',[])if b.get('type')=='text']
 assert msgs[-1][1]==final['result'];answer=final['result'];words=len(re.findall(r'\S+',answer));assert words<350
 (O/(name+'-final-answer.txt')).write_text(answer)
 calls=[];results={};reads=[];models=set()
 for n,x in events:
  if x.get('type')=='assistant':
   models.add(x['message']['model'])
   for b in x['message'].get('content',[]):
    if b.get('type')=='tool_use':calls.append({'line':n,'id':b['id'],'name':b['name'],'input':b['input']})
  if x.get('type')=='user':
   for b in x.get('message',{}).get('content',[]):
    if b.get('type')=='tool_result':results[b['tool_use_id']]={'line':n,'block':b,'structured':x.get('tool_use_result')}
 assert models=={'claude-sonnet-5-5'}
 for c in calls:
  assert c['name'] in ('Skill','Read','Glob','Grep') and c['id'] in results
  res=results[c['id']];assert not res['block'].get('is_error',False);c['result_line']=res['line']
  if c['name']=='Skill':assert c['input']['skill']=='osstack-help' and res['structured']=={'success':True,'commandName':'osstack-help'}
  if c['name']=='Read':
   fp=Path(c['input']['file_path']);rel=fp.relative_to(ws);assert not fp.is_symlink();sf=res['structured']['file']
   assert sf['content'].encode()==fp.read_bytes();assert sf['startLine']==1 and sf['numLines']==sf['totalLines']
   reads.append({'path':str(rel),'call_line':c['line'],'result_line':res['line'],'bytes':fp.stat().st_size,'sha256':sha(fp),'complete':True,'comparison':'structured raw tool content equals complete exported file bytes'})
  if c['name']=='Glob':
   assert not Path(c['input']['pattern']).is_absolute() and '..'not in Path(c['input']['pattern']).parts
   assert 'path'not in c['input'] or Path(c['input']['path']).resolve().is_relative_to(ws)
   assert res['structured']['truncated'] is False
 expansion=None
 if mode=='present':
  fp=ws/'.claude/skills/osstack-help/SKILL.md';text=fp.read_text();assert text.startswith('---\n');body=text.split('---\n',2)[2].lstrip('\n')
  expansions=[(n,b['text'])for n,x in events if x.get('type')=='user'and x.get('isSynthetic')is True for b in x['message'].get('content',[])if b.get('type')=='text']
  assert len(expansions)==1;n,expanded=expansions[0];prefix='Base directory for this skill: '+str(fp.parent)+'\n\n';assert expanded==prefix+body
  expansion={'line':n,'source':str(fp.relative_to(ws)),'export_file_sha256':sha(fp),'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'body_bytes':len(body.encode()),'complete':True,'normalization':'Only host base-directory prefix added and YAML frontmatter removed; body byte-exact'}
  assert len(reads)==2 and len(calls)==4 and calls[0]['name']=='Skill'
  for f in [fp,*[ws/x['path']for x in reads]]:
   dest=O/'v2-material-read-inputs'/f.relative_to(ws);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
  manifest=J(ev/'export-manifest.json')
  for f in manifest['files']:assert sha(ws/f['path'])==f['sha256'] and (ws/f['path']).stat().st_size==f['bytes']
 else:assert len(calls)==2 and all(c['name']=='Glob'for c in calls)and not reads
 socket=Path(init['messaging_socket_path']);assert not socket.exists()
 obs['cases'][name]={'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'raw_events':len(events),'runtime_system_init_line':initline,'runtime_catalog_target_names':sorted(found),'runtime_tools':init['tools'],'builtin_plugins_reported':init.get('plugins',[]),'model_requested':'claude-sonnet-5-5','actual_init_model':init['model'],'actual_assistant_models':sorted(models),'actual_modelUsage':final['modelUsage'],'pid':record['pid'],'started_at':record['at'],'ended_at':record['finished'],'exit_code':record['exit_code'],'input_user_turns':1,'sdk_internal_num_turns':final['num_turns'],'complete_inventory_entries':len(before),'complete_inventory_equal_before_after_current':True,'private_home_absent':True,'reported_socket_absent':str(socket),'tool_calls':calls,'reads':reads,'skill_expansion':expansion,'answer_line':msgs[-1][0],'result_line':final_line,'final_words':words,'final_sha256':hashlib.sha256(answer.encode()).hexdigest(),'other_assistant_visible_text_messages':msgs[:-1],'permission_denials':[],'owned_workspace_retained_for_review':True}
p=O/'v2-observations-verified.json'
with p.open('x')as f:json.dump(obs,f,indent=2);f.write('\n')
print(json.dumps({'observations_sha256':sha(p),'cases':{k:{'words':v['final_words'],'tool_calls':len(v['tool_calls']),'target_count':len(v['runtime_catalog_target_names']),'inventory_entries':v['complete_inventory_entries']}for k,v in obs['cases'].items()}},indent=2))
