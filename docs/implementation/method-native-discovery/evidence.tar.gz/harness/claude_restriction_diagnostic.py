from preflight import ROOT,H,env,save,now
from pathlib import Path
import subprocess,selectors,json,os,signal,time,shutil,hashlib
TARGETS=['osstack-help','osstack-mode','setup-osstack','osstack-agent']
def main():
 records=[]
 for restricted in (True,False):
  case=ROOT/'runs'/('claude-init-diagnostic-'+('restricted' if restricted else 'project-settings'))
  case.mkdir()
  for d in ('state','private-home','evidence'): (case/d).mkdir()
  shutil.copytree(ROOT/'runs/claude-present/workspace',case/'workspace')
  save(case/'state/empty-mcp.json',{'mcpServers':{}})
  save(case/'state/settings.json',{'disableAllHooks':True,'permissions':{'deny':['Bash','Edit','Write','NotebookEdit','Agent','Task','WebFetch','WebSearch']}})
  argv=['/opt/homebrew/bin/claude','-p','--model','claude-sonnet-5-5','--input-format','stream-json','--output-format','stream-json','--verbose']+(['--restricted'] if restricted else [])+['--tools','','--strict-mcp-config','--mcp-config',str(case/'state/empty-mcp.json'),'--no-session-persistence','--permission-mode','dontAsk','--permission-prompts','none','--setting-sources','project,local','--settings',str(case/'state/settings.json'),'--no-chrome']
  record={'at':now(),'case':case.name,'argv':argv,'user_messages_sent':0,'model_turns_started':0,'controlled_factor':'restricted flag; roots differ only for isolation','tools':[]};p=None
  try:
   with (case/'evidence/control.stderr').open('xb') as err,(case/'evidence/control.jsonl').open('x') as out:
    p=subprocess.Popen(argv,cwd=case/'workspace',env=env(case,'claude',True),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,start_new_session=True)
    record['pid']=p.pid
    selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ)
    request={'type':'control_request','request_id':'restricted-diagnostic','request':{'subtype':'initialize','title':'OSStack catalog only','promptSuggestions':False,'agentProgressSummaries':False}}
    p.stdin.write(json.dumps(request)+'\n');p.stdin.flush();save(case/'evidence/input.json',request)
    deadline=time.monotonic()+25;reply=None
    while time.monotonic()<deadline:
     if not selector.select(max(0,deadline-time.monotonic())):break
     line=p.stdout.readline()
     if not line:break
     x=json.loads(line);payload=x.get('response',{}).get('response',{})
     if isinstance(payload,dict) and 'account' in payload:payload['account']={'redacted':'identity fields not required by discovery probe'}
     out.write(json.dumps(x)+'\n');out.flush()
     if x.get('type')=='control_response' and x.get('response',{}).get('request_id')=='restricted-diagnostic':reply=x;break
    if reply is None:raise RuntimeError('no initialize control response')
    response=reply.get('response',{})
    if response.get('subtype')!='success':raise RuntimeError('initialize failed')
    commands=response['response'].get('commands',[])
    record.update(status='observed',target_commands=[x for x in commands if x.get('name')in TARGETS],command_count=len(commands),catalog_is_behavior_pass=False)
  except Exception as ex:record.update(status='blocked',error=str(ex))
  finally:
   if p:
    p.stdin.close()
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:
     os.killpg(p.pid,signal.SIGTERM)
     try:p.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
    record['exit_code']=p.returncode
   shutil.rmtree(case/'private-home')
   record.update(finished=now(),private_home_removed=not(case/'private-home').exists())
   save(case/'evidence/result.json',record);records.append(record)
 save(H/'claude-restriction-diagnostic.json',records)
 print(json.dumps(records,indent=2))
if __name__=='__main__':main()
