from preflight import ROOT,H,env,save,now,USER
from pathlib import Path
import os,subprocess,json,hashlib,signal,shutil,time

def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(ws):
 return {str(p.relative_to(ws)):sha(p.read_bytes()) for p in sorted(ws.rglob('*')) if p.is_file() and '.git' not in p.relative_to(ws).parts}
def main():
 prep=json.loads((H/'preflight.json').read_text());assert prep['codex_model']=='gpt-6.1-sol'
 independent=ROOT/'independent';criteria=independent/'criteria-prefreeze.json';supplement=independent/'prompt-prefreeze-supplement.json'
 assert sha(criteria.read_bytes())=='6ba7fd3cd626d3b96ab6a4a4c451e9d607abb216b4c3092490b49c5e1cc730fa'
 assert sha(supplement.read_bytes())=='79e83b5d4df35e447e5e39ceb1fcbacff565c74218cacd928720f5dd27de0842'
 prompt=(H/'prompt.txt').read_bytes();assert sha(prompt)=='36a20a486e7e4e3f0aa72e95a42d4d108c8b09c7021848271e227c4f348d8c9c'
 freeze={'at':now(),'candidate':'ca95aba1c186d9c3a9e70a45143b7a277db84404','criteria_sha256':sha(criteria.read_bytes()),'supplement_sha256':sha(supplement.read_bytes()),'prompt_sha256':sha(prompt),'runner_sha256':sha(Path(__file__).read_bytes()),'model':'gpt-6.1-sol','calls':2,'claude_calls':0,'limit_seconds':180,'retries':0}
 with (H/'dispatch-freeze.json').open('x') as f:json.dump(freeze,f,indent=2)
 default_auth_before=sha((USER/'.codex/auth.json').read_bytes())
 for mode in ('absent','present'):
  case=ROOT/'runs'/('codex-'+mode);ev=case/'evidence';ws=case/'workspace';before=inventory(ws);save(ev/'workspace-before.json',before)
  args=['/opt/homebrew/bin/codex','-a','never','exec','--ignore-user-config','--ignore-rules','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--color','never','--json','-m','gpt-6.1-sol','-C',str(ws),'-']
  e=env(case,'codex',True);record={'case':case.name,'started_at':now(),'argv':args,'cwd':str(ws),'environment_keys':sorted(e),'model_requested':'gpt-6.1-sol','prompt_sha256':sha(prompt),'timeout_seconds':180,'retries':0,'candidate':freeze['candidate'],'model_call_started':False,'scope':'actual native skill reading; hypothetical verification advice, no driver execution'}
  with (ev/'started.json').open('x') as f:json.dump(record,f,indent=2)
  p=None
  try:
   with (ev/'response.jsonl').open('xb') as out,(ev/'stderr.txt').open('xb') as err:
    p=subprocess.Popen(args,cwd=ws,env=e,stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True)
    record.update(model_call_started=True,owned_pid=p.pid);save(ev/'invocation.json',record)
    try:p.communicate(prompt,timeout=180);record['timed_out']=False
    except subprocess.TimeoutExpired:
     record['timed_out']=True;os.killpg(p.pid,signal.SIGTERM)
     try:p.communicate(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.communicate(timeout=5)
   record['exit_code']=p.returncode
   messages=[];tools={};final=None;errors=[]
   for n,l in enumerate((ev/'response.jsonl').read_text().splitlines(),1):
    try:x=json.loads(l)
    except Exception as ex:errors.append({'line':n,'error':str(ex)});continue
    item=x.get('item',{})
    if x.get('type')=='item.completed' and item.get('type')=='agent_message':messages.append({'line':n,'text':item.get('text','')})
    if item and item.get('type') not in ('agent_message','reasoning'):tools[item.get('id',str(n))]={'line':n,'item':item}
    if x.get('type')=='turn.completed':final=x
   finaltext=messages[-1]['text'] if messages else ''
   (ev/'final-response.txt').write_text(finaltext)
   save(ev/'parse.json',{'agent_messages':messages,'tools':list(tools.values()),'final_event':final,'stream_errors':errors,'actual_model':'not_attested_unless_raw_stream_says_otherwise'})
   record.update(final_event_present=final is not None,tool_event_count=len(tools),final_whitespace_words=len(finaltext.split()),stream_errors=errors,status='completed_pending_independent_evaluation' if final and not errors and p.returncode==0 and not record['timed_out'] else 'blocked_no_retry')
  except Exception as ex:record.update(status='blocked_no_retry',error=str(ex))
  finally:
   after=inventory(ws);save(ev/'workspace-after.json',after);record.update(workspace_unchanged=before==after,ended_at=now(),default_auth_unchanged=sha((USER/'.codex/auth.json').read_bytes())==default_auth_before)
   private=case/'private-home';credential=private/'.codex/auth.json';credential_existed=credential.exists()
   if credential_existed:credential.unlink()
   shutil.rmtree(private)
   save(ev/'cleanup.json',{'private_home_removed':not private.exists(),'credential_copy_existed_and_removed':credential_existed and not credential.exists(),'workspace_retained_for_independent_evaluation':True,'process_exit_confirmed':p is not None and p.returncode is not None,'scope':'only this case private home deleted; source/export/workspace retained for review, not a whole-process audit'})
   record['file_hashes']={p.name:sha(p.read_bytes()) for p in ev.iterdir() if p.is_file() and p.name!='invocation.json'};save(ev/'invocation.json',record)
   print(json.dumps({k:record.get(k) for k in ['case','status','exit_code','timed_out','final_whitespace_words','workspace_unchanged','default_auth_unchanged']}),flush=True)
 # Claude never received user turn; remove its private state after preserving only nonsecret diagnostics.
 for mode in ('absent','present'):
  case=ROOT/'runs'/('claude-'+mode);private=case/'private-home';shutil.rmtree(private)
  save(case/'evidence/cleanup.json',{'private_home_removed':not private.exists(),'credential_file_created':False,'token_passed_only_in_memory_to_catalog_and_auth_children':True,'model_calls':0,'workspace_retained_for_independent_evaluation':True})
if __name__=='__main__':main()
