# Native skill discovery experiment handoff

Source main: ca95aba1c186d9c3a9e70a45143b7a277db84404; tree 9efad98d9560076ec33611ae75841c7ac85e0fc2. Four exported entry materials; task selection/read-only investigation only. No product changes, verification execution, host equivalence, causal improvement, MethodBinding or formal gate qualification.

## Actual model calls

Exactly four process invocations carrying one user message each: Codex absent/present, Claude v2 absent/present. No retries. Model-free version/auth/schema/catalog/diagnostic processes are separately recorded. SDK `num_turns` includes internal assistant/tool rounds and does not represent additional dispatched user tasks.

- Codex CLI 0.160.1: both natural exit 0. Isolated authenticated model/list default gpt-6.1-sol explicitly requested; exec stream does not attest resolved model. Separate app-server catalog processes observed 0/4 target skills. Positive actual exec made four shell-read calls consuming help/mode/evidence/maintain material; absent made two inventory commands. Final whitespace words 193/286. Independent v1 grading is limited/inconclusive: material bytes unchanged, but original before/after inventory omitted .git and file types/lengths. This gap is not repaired retroactively and Codex was not rerun.
- Claude Code 2.1.291 v1: blocked at positive catalog, zero user messages. Independent research and a tools-empty/no-user initialize comparison showed `--restricted` suppresses project setting sources: 53 commands/0 targets with restricted; 57/all 4 targets without. The catalog observation does not constitute behavior success.
- Claude v2: fresh independently frozen cases, native outside-workspace read fence plus precise permissions instead of restricted. Both natural exit 0, result success, complete before/after inventories (including .git/types/lengths/symlinks) unchanged. Both modelUsage records attest claude-sonnet-5-5. Absent: two Glob calls, no skill invoked; 329 final whitespace words. Present: Skill(osstack-help), Read evidence.md, Glob osstack-mode, Read maintain-verification.md; 345 words. Actual cost fields $0.0307086/$0.0541752. Independent v2 grading is separate from v1; use its final report for scored outcomes.

## Main evidence pointers

- harness/prepare.json — source and prompt hashes.
- independent/criteria-prefreeze.json and prompt-prefreeze-supplement.json — v1 criteria/prompt freeze.
- independent/graded-results.md and grading-manifest.json — immutable v1 independent grade.
- harness/v1-final-disposition.json — explicit v1 limitations.
- harness/catalog-semantics.{json,md}, claude-restriction-diagnostic.json, runs/claude-init-diagnostic-*/evidence — preserved local-source research and no-model controlled diagnostic.
- harness/claude-v2-proposal.md, claude-v2-permission-source.json, claude-v2-permission-followup.json, claude_v2.py — v2 configuration reasoning and actual runner.
- independent/v2-prefreeze.json — independent v2 freeze; runner SHA 47adbb88d4258c671a946bc736aad8d69c681ff51d5bfc0f64ba24bb00744e2a.
- harness/claude-v2-dispatch.json — root authorization and rechecked frozen files.
- runs/claude-v2-*/evidence/run.jsonl — model/tool raw lines unchanged; initialize-control account identity alone redacted as disclosed.
- runs/claude-v2-*/evidence/run-result.json, run-before.json, run-after.json, user-input.json, final-response.txt, observations.json — commands/time/PID/exit, complete inventories, exact user message, projections.
- harness/claude-v2-observations.json — observation projection, not substitute for raw stream or independent grade.

## Boundaries and cleanup

Private HOME/host config only, existing authentication via selected source, no credentials archived; Claude token stays in child environment memory. Strict empty MCP, no hooks, no session persistence, no model web/agent/write/shell tools. V2 native Skill rule is a bounded observed-surface rule (53 builtin catalog names denied, unexpected catalog aborts), not a universal whitelist for unenumerated hidden native commands. Observed tool boundary remains an independent criterion. Native host permission settings are not an OS-wide process I/O audit.

All private homes removed in finally. Completed v1/diagnostic workspaces removed with separate harness/workspace-cleanup.json receipt; original invocation/cleanup records remain untouched. Exact secret-free material export copies (80 files) retained under harness/retained-exports. Independent v2 byte verification completed (v2-observations-verified.json); both v2 workspaces were then removed. harness/v2-workspace-cleanup.json separately binds the original run-result hashes and verified retained export copies. No owned private homes or experiment workspaces remain. Current exact-value credential scan: five known values over 703 files, zero matches, no private homes; not a general secret-detection proof.
