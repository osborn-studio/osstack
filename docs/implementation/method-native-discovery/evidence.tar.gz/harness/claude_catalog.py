from preflight import ROOT,H,env,save,now
import subprocess,selectors,json,os,signal,time

def argv(case):
 return ['/opt/homebrew/bin/claude','-p','--model','claude-sonnet-5-5','--input-format','stream-json','--output-format','stream-json','--verbose','--restricted','--tools','Skill,Read,Glob,Grep','--allowedTools','Skill(osstack-help),Skill(osstack-mode),Skill(setup-osstack),Skill(osstack-agent),Read,Glob,Grep','--strict-mcp-config','--mcp-config',str(case/'state/empty-mcp.json'),'--no-session-persistence','--permission-mode','dontAsk','--permission-prompts','none','--setting-sources','project,local','--settings',str(case/'state/settings.json'),'--no-chrome']
def main():
 all_results=[]
 for mode in ['absent','present']:
  case=ROOT/'runs'/('claude-'+mode);record={'at':now(),'case':case.name,'argv':argv(case),'user_messages_sent':0,'model_turns_started':0};p=None
  try:
   with (case/'evidence/catalog-control.stderr').open('xb') as err,(case/'evidence/catalog-control.jsonl').open('x') as out:
    p=subprocess.Popen(argv(case),cwd=case/'workspace',env=env(case,'claude',True),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,start_new_session=True)
    selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ)
    request={'type':'control_request','request_id':'native-catalog-only','request':{'subtype':'initialize','title':'OSStack catalog only','promptSuggestions':False,'agentProgressSummaries':False}}
    p.stdin.write(json.dumps(request)+'\n');p.stdin.flush();save(case/'evidence/catalog-control-input.json',request)
    deadline=time.monotonic()+20;reply=None
    while time.monotonic()<deadline:
     if not selector.select(max(0,deadline-time.monotonic())):break
     line=p.stdout.readline()
     if not line:break
     x=json.loads(line)
     # Exclude account identity only; no credentials are requested or captured.
     payload=x.get('response',{}).get('response',{})
     if isinstance(payload,dict) and 'account' in payload:payload['account']={'redacted':'identity fields not required by discovery probe'}
     out.write(json.dumps(x)+'\n');out.flush()
     if x.get('type')=='control_response' and x.get('response',{}).get('request_id')=='native-catalog-only':reply=x;break
    if reply is None:raise RuntimeError('no initialize control response')
    response=reply.get('response',{})
    if response.get('subtype')!='success':raise RuntimeError('initialize failed')
    data=response['response'];commands=data.get('commands',[]);target=[x for x in commands if x.get('name') in ['osstack-help','osstack-mode','setup-osstack','osstack-agent']]
    if mode=='present' and len(target)!=4:raise RuntimeError('positive target skills missing from restricted catalog')
    if mode=='absent' and target:raise RuntimeError('negative catalog contaminated')
    record.update(status='pass',target_commands=target,command_count=len(commands))
  except Exception as ex:record.update(status='blocked',error=str(ex))
  finally:
   if p:
    p.stdin.close()
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:
     os.killpg(p.pid,signal.SIGTERM)
     try:p.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
    record['process_exit_code']=p.returncode
   save(case/'evidence/catalog-control-result.json',record);all_results.append(record)
 save(H/'claude-catalog-preflight.json',all_results);print(json.dumps(all_results,indent=2))
if __name__=='__main__':main()
