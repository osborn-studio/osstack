from pathlib import Path
import os,json,hashlib,subprocess,datetime,selectors,time,signal,shutil
ROOT=Path(__file__).resolve().parent.parent
H=ROOT/'harness';USER=Path('/Users/osborn')
PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def env(case,host,auth=False):
 home=case/'private-home';tmp=home/'tmp';tmp.mkdir(exist_ok=True)
 result={'PATH':PATH,'HOME':str(home),'TMPDIR':str(tmp),'LANG':'en_US.UTF-8','OSSTACK_HOME':str(home/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}
 if host=='codex':
  private=home/'.codex';private.mkdir(exist_ok=True);result['CODEX_HOME']=str(private)
  if auth:
   destination=private/'auth.json'
   if not destination.exists():
    with destination.open('xb') as f:f.write((USER/'.codex/auth.json').read_bytes())
    destination.chmod(0o600)
 else:
  private=home/'.claude';private.mkdir(exist_ok=True);result['CLAUDE_CONFIG_DIR']=str(private)
  if auth:
   key=subprocess.run(['/usr/bin/security','find-generic-password','-s','Claude Code-credentials','-w'],capture_output=True,timeout=10)
   if key.returncode:raise RuntimeError('existing Claude credential unavailable; raw credential output suppressed')
   credential=json.loads(key.stdout).get('claudeAiOauth',{});token=credential.get('accessToken')
   if not token:raise RuntimeError('existing Claude access token absent')
   if credential.get('expiresAt',0)<=time.time()*1000:raise RuntimeError('existing Claude access token expired; do not refresh default credentials')
   result['CLAUDE_CODE_OAUTH_TOKEN']=token
 return result

def rpc(case):
 out=case/'evidence/catalog.jsonl';err=case/'evidence/catalog.stderr';e=env(case,'codex',True)
 with out.open('x') as stream,err.open('xb') as errors:
  p=subprocess.Popen(['/opt/homebrew/bin/codex','app-server','--listen','stdio://'],cwd=case/'workspace',env=e,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors,start_new_session=True,text=True,bufsize=1)
  selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ)
  def send(x):p.stdin.write(json.dumps(x)+'\n');p.stdin.flush()
  def receive(id):
   deadline=time.monotonic()+30
   while time.monotonic()<deadline:
    if not selector.select(max(0,deadline-time.monotonic())):break
    line=p.stdout.readline()
    if not line:raise RuntimeError('appserver exited before response')
    stream.write(line);stream.flush();x=json.loads(line)
    if x.get('id')==id:
     if 'error'in x:raise RuntimeError('RPC error '+json.dumps(x['error']))
     return x['result']
   raise TimeoutError('catalog deadline')
  try:
   send({'id':0,'method':'initialize','params':{'clientInfo':{'name':'osstack_native_discovery_probe','title':'OSStack local discovery experiment','version':'1'}}});receive(0)
   send({'method':'initialized','params':{}})
   send({'id':1,'method':'skills/list','params':{'cwds':[str(case/'workspace')],'forceReload':True}});catalog=receive(1)
   send({'id':2,'method':'model/list','params':{}});models=receive(2)
   return catalog,models
  finally:
   p.stdin.close()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   save(case/'evidence/catalog-process.json',{'argv':['/opt/homebrew/bin/codex','app-server','--listen','stdio://'],'cwd':str(case/'workspace'),'exit_code':p.returncode,'model_turns_started':0})

def main():
 record={'at':now(),'model_calls':0,'checks':[]}
 try:
  schema_case=ROOT/'runs/codex-absent';e=env(schema_case,'codex')
  p=subprocess.run(['/opt/homebrew/bin/codex','app-server','generate-json-schema','--out',str(H/'schema')],env=e,cwd=schema_case/'workspace',capture_output=True,timeout=20)
  (H/'schema.stdout').write_bytes(p.stdout);(H/'schema.stderr').write_bytes(p.stderr)
  record['checks'].append({'name':'local_schema','exit':p.returncode})
  if p.returncode:raise RuntimeError('schema generation failed')
  for host in ('codex','claude'):
   for mode in ('absent','present'):
    case=ROOT/'runs'/f'{host}-{mode}';e=env(case,host,True)
    binary='/opt/homebrew/bin/'+host
    v=subprocess.run([binary,'--version'],env=e,cwd=case/'workspace',capture_output=True,timeout=10)
    (case/'evidence/version.stdout').write_bytes(v.stdout);(case/'evidence/version.stderr').write_bytes(v.stderr)
    argv=[binary,'login','status'] if host=='codex' else [binary,'auth','status','--json']
    p=subprocess.run(argv,env=e,cwd=case/'workspace',capture_output=True,timeout=20)
    if host=='claude':
     data=json.loads(p.stdout or '{}');auth={'loggedIn':data.get('loggedIn'),'authMethod':data.get('authMethod'),'apiProvider':data.get('apiProvider')};ok=p.returncode==0 and data.get('loggedIn') is True
    else:
     # Never persist credential command raw output; only known status predicate.
     ok=p.returncode==0 and b'Logged in' in (p.stdout+p.stderr);auth={'loggedIn':ok}
    save(case/'evidence/auth-precheck.json',{'argv':argv,'exit_code':p.returncode,'status_fields':auth,'raw_credential_or_identity_output_retained':False,'default_home_used':False})
    if not ok:raise RuntimeError(host+' isolated auth not established')
    check={'case':case.name,'auth_pass':True,'version':v.stdout.decode().strip()}
    if host=='codex':
     catalog,models=rpc(case);save(case/'evidence/catalog.json',catalog);save(case/'evidence/models.json',models)
     data=catalog.get('data',[]);skills=[s for entry in data for s in entry.get('skills',[])];target=[s for s in skills if s.get('name') in ['osstack-mode','osstack-help','setup-osstack','osstack-agent']]
     if mode=='present':
      if len(target)!=4 or any(not str(s.get('path','')).startswith(str(case/'workspace/.agents/skills')+'/') for s in target):raise RuntimeError('Codex positive catalog missing/overridden')
     elif target:raise RuntimeError('Codex negative catalog contaminated')
     model=[x for x in models.get('data',[]) if x.get('isDefault') is True]
     if len(model)!=1:raise RuntimeError('Codex default model not uniquely resolved')
     check.update(target_skills=[{'name':s['name'],'path':s['path']} for s in target],catalog_count=len(skills),default_model=model[0].get('model',model[0].get('id')))
    record['checks'].append(check)
  defaults=[x['default_model'] for x in record['checks'] if 'default_model'in x]
  if len(set(defaults))!=1:raise RuntimeError('Codex case model defaults differ')
  record.update(status='preflight_auth_codex_catalog_pass_claude_catalog_pending_init',codex_model=defaults[0],claude_model='claude-sonnet-5-5')
 except Exception as ex:record.update(status='blocked',error=str(ex))
 save(H/'preflight.json',record);print(json.dumps(record,indent=2));return record['status']=='blocked'
if __name__=='__main__':raise SystemExit(main())
