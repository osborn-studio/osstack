"""Fresh Claude cases. prepare/catalog never sends a user turn; run requires external freeze."""
from preflight import ROOT,H,env,save,now
from pathlib import Path
import subprocess,queue,threading,json,os,signal,time,shutil,hashlib,stat,sys
TARGETS=['osstack-help','osstack-mode','setup-osstack','osstack-agent']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(root):
 out={}
 def visit(p):
  st=p.lstat();rel=str(p.relative_to(root));record={'type':None,'length':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
  if stat.S_ISREG(st.st_mode):record.update(type='file',sha256=sha(p))
  elif stat.S_ISDIR(st.st_mode):record['type']='directory'
  elif stat.S_ISLNK(st.st_mode):record.update(type='symlink',target=os.readlink(p))
  else:raise RuntimeError('unsupported filesystem type at '+rel)
  out[rel]=record
  if record['type']=='directory':
   for child in sorted(p.iterdir()):visit(child)
 visit(root)
 return out
def case_for(mode):return ROOT/'runs'/('claude-v2-'+mode)
def settings(case):
 # Exact workspace allowlist; deny retained native-fence exceptions as well.
 root=str(case/'workspace');private=str(case/'private-home')
 deny_tools=['Bash','Edit','Write','NotebookEdit','Agent','Task','WebFetch','WebSearch']
 denied_skills=['Skill('+n+')' for n in json.loads((H/'claude-v2-builtin-catalog.json').read_text())]
 denied_roots=[private,str(case/'state'),str(case/'evidence'),'/Users','/opt','/private','/tmp','/$bunfs']
 return {'disableAllHooks':True,'permissions':{'blockReadsOutsideWorkingDirectories':True,'additionalDirectories':[],
  'allow':['Skill('+n+')' for n in TARGETS]+[tool+'(/'+root+'/**)' for tool in ['Read','Glob','Grep']],
  'deny':deny_tools+denied_skills+[tool+'(/'+path+'/**)' for tool in ['Read','Glob','Grep'] for path in denied_roots]}}
def argv(case):
 return ['/opt/homebrew/bin/claude','-p','--model','claude-sonnet-5-5','--input-format','stream-json','--output-format','stream-json','--verbose','--tools','Skill,Read,Glob,Grep','--strict-mcp-config','--mcp-config',str(case/'state/empty-mcp.json'),'--no-session-persistence','--permission-mode','dontAsk','--permission-prompts','none','--setting-sources','project,local','--settings',str(case/'state/settings.json'),'--no-chrome']
def prepare():
 result=[]
 for mode in ['absent','present']:
  case=case_for(mode);case.mkdir()
  for d in ['workspace','state','evidence']:(case/d).mkdir()
  if mode=='present':
   shutil.copytree(ROOT/'runs/claude-present/workspace/.claude',case/'workspace/.claude')
   shutil.copyfile(ROOT/'runs/claude-present/evidence/export-manifest.json',case/'evidence/export-manifest.json')
  subprocess.run(['/usr/bin/git','-c','init.templateDir=','init','--quiet',str(case/'workspace')],check=True,env={'PATH':'/usr/bin:/bin','HOME':str(case/'unused-home')})
  save(case/'state/settings.json',settings(case));save(case/'state/empty-mcp.json',{'mcpServers':{}})
  inv=inventory(case/'workspace')
  if any(x['type']=='symlink' for x in inv.values()):raise RuntimeError('fresh case contains symlink')
  save(case/'evidence/prepared-inventory.json',inv)
  result.append({'case':case.name,'argv':argv(case),'workspace_inventory_sha256':sha(case/'evidence/prepared-inventory.json'),'settings_sha256':sha(case/'state/settings.json')})
 save(H/'claude-v2-prepared.json',{'at':now(),'cases':result,'prompt_sha256':sha(H/'prompt.txt'),'model_turns':0})
def control_or_run(mode,run=False,catalog_label='catalog-final'):
 case=case_for(mode);label='run' if run else catalog_label;record={'at':now(),'case':case.name,'argv':argv(case),'user_turns':0,'timeout_seconds':180 if run else 25,'automatic_retry':False};p=None
 if run:
  approval=json.loads((H/'claude-v2-dispatch.json').read_text())
  if approval.get('approved') is not True or approval['runner_sha256']!=sha(Path(__file__)):raise RuntimeError('missing/mismatched external runner freeze')
  if approval['prompt_sha256']!=sha(H/'prompt.txt'):raise RuntimeError('prompt freeze mismatch')
  for entry in approval['frozen_files']:
   if sha(Path(entry['path']))!=entry['sha256']:raise RuntimeError('external freeze file mismatch')
 # Exclusive before artifact is also a no-retry marker.
 save_new=case/'evidence'/(label+'-before.json')
 with save_new.open('x') as f:json.dump(inventory(case/'workspace'),f,indent=2)
 (case/'private-home').mkdir()
 try:
  with (case/'evidence'/(label+'.stderr')).open('xb') as err,(case/'evidence'/(label+'.jsonl')).open('x') as out:
   p=subprocess.Popen(argv(case),cwd=case/'workspace',env=env(case,'claude',True),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,start_new_session=True)
   record['pid']=p.pid
   lines=queue.Queue()
   def read_lines():
    try:
     for line in p.stdout:lines.put(line)
    finally:lines.put(None)
   reader=threading.Thread(target=read_lines,daemon=True);reader.start()
   request={'type':'control_request','request_id':'native-v2-initialize','request':{'subtype':'initialize','title':'OSStack native discovery v2','promptSuggestions':False,'agentProgressSummaries':False}}
   p.stdin.write(json.dumps(request)+'\n');p.stdin.flush();save(case/'evidence'/(label+'-initialize-input.json'),request)
   deadline=time.monotonic()+(180 if run else 25);initialized=False;result_received=False
   while time.monotonic()<deadline:
    try:line=lines.get(timeout=max(0,deadline-time.monotonic()))
    except queue.Empty:break
    if line is None:break
    x=json.loads(line)
    # Only control account identity is redacted. Model/tool stream stays byte-original.
    if x.get('type')=='control_response':
     payload=x.get('response',{}).get('response',{})
     if isinstance(payload,dict) and 'account'in payload:payload['account']={'redacted':'account identity outside experiment scope'}
     out.write(json.dumps(x)+'\n')
    else:out.write(line)
    out.flush()
    if x.get('type')=='control_request':
     # Never approve runtime permission expansion or tool requests from this channel.
     response={'type':'control_response','response':{'subtype':'success','request_id':x['request_id'],'response':{'behavior':'deny','message':'Experiment refuses permission expansion'}}}
     p.stdin.write(json.dumps(response)+'\n');p.stdin.flush()
    if x.get('type')=='control_response' and x.get('response',{}).get('request_id')=='native-v2-initialize':
     r=x['response']
     if r.get('subtype')!='success':raise RuntimeError('initialize failure')
     all_names=sorted(c['name'] for c in r['response'].get('commands',[]))
     expected_names=sorted(json.loads((H/'claude-v2-builtin-catalog.json').read_text())+(TARGETS if mode=='present' else []))
     if all_names!=expected_names:raise RuntimeError('native catalog changed from frozen observed surface')
     found=sorted(n for n in all_names if n in TARGETS)
     if found!=(sorted(TARGETS) if mode=='present' else []):raise RuntimeError('unexpected native catalog')
     initialized=True;record['catalog_targets']=found
     if not run:break
     user={'type':'user','message':{'role':'user','content':(H/'prompt.txt').read_text()}}
     save(case/'evidence/user-input.json',user);p.stdin.write(json.dumps(user)+'\n');p.stdin.flush();record['user_turns']=1
    if x.get('type')=='result':result_received=True;record['result_subtype']=x.get('subtype');break
   record.update(initialized=initialized,result_received=result_received)
   if not initialized or (run and not result_received):raise TimeoutError('bounded run did not complete')
   record['status']='observed_pending_independent_grading' if run else 'catalog_gate_observed'
 except Exception as ex:record.update(status='blocked_or_incomplete',error=str(ex))
 finally:
  if p:
   p.stdin.close()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    record['termination_sent']=True;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   record['exit_code']=p.returncode
  try:
   after=inventory(case/'workspace');save(case/'evidence'/(label+'-after.json'),after)
   record['complete_workspace_inventory_unchanged']=json.loads(save_new.read_text())==after
  except Exception as ex:record['inventory_error']=str(ex);record['complete_workspace_inventory_unchanged']=None
  if(case/'private-home').exists():shutil.rmtree(case/'private-home')
  record.update(finished=now(),private_home_removed=not(case/'private-home').exists())
  save(case/'evidence'/(label+'-result.json'),record)
 print(json.dumps(record,indent=2))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]in ['catalog','run']:control_or_run(sys.argv[2],sys.argv[1]=='run')
 else:raise SystemExit('prepare | catalog absent/present | run absent/present')
