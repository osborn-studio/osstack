# Native discovery experiment handoff

Candidate ca95aba1c186d9c3a9e70a45143b7a277db84404; card_6198adaf. Independent criteria and prompt supplement froze before any model output. Prompt SHA25636a20a486e7e4e3f0aa72e95a42d4d108c8b09c7021848271e227c4f348d8c9c remained unchanged.

## Executed

Exactly2 model invocations, both Codex0.160.1, isolated authenticated default model/list selection gpt-6.1-sol requested explicitly. Actual exec stream does not attest resolved model. No retries,180s limits, neither timeout. Absent193words/2shellread calls; present286words/4shellread calls. Both exit0 and retained workspace files unchanged. Model task is simulated verification advice; actual actions only inspect/read local skill files.

Codex host-native app-server catalog separately lists absent0/present4 target skills with owned export paths. The exec process then reads exact help, evidence, mode and maintain-verification material. Raw response.jsonl + tool results are preserved unchanged for independent evaluation. A separatecatalog process is not represented as exec-internal catalogtelemetry.

## Blocked

Claude2.1.291 isolated existingOAuth auth succeeds, but restricted configuration's native SDK initialize catalog lists53built-in commands and0target skills in BOTHconditions. No user message was sent to either control session and no Claude model turn started. Thus0 of the2allowed Claude modelcalls used. Do not score authsuccess or absentcatalog alone as completednegativecontrol. Do not change permissions or injectbody to turn this intoPASS.

The control protocol is supported by the locallyinstalled SDK type definitions (initialize request/commandsresponse); no userturn is required. Catalogoutput retains all relevant commandmetadata, but accountidentity was redacted and JSONreserialized before saving. It is not claimed as originalbyteidenticaloutput. It contains no skillbody injection.

## Boundaries and cleanup

Eachcondition had newexport/emptyGitworkspace and newprivatehome; no gitworktree. Authonly copied into privateCodexhome; Claude existingkeychain accessToken only in childenvironment. Tokenvalues never printed or archived; allprivatehomes and copiedcredentials removed afterprocess exit. Exactcurrentcredential scanner found0matches across558ownedfiles; this is not generalsecretproof. DefaultCodexauthfilehash remained unchanged; no wholedefault-home/keychainwriteaudit is claimed.

Positiveworkspace and sourcecopies remain for independentfullread/hash assessment. Root or thisagent will remove exactownedworkspaces only afterreview, retaining exportedfiles/evidencecopies. No product/defaultconfiguration/PR/ledgerwrites or verificationdriverexecution occurred.

See execution-summary.json, dispatch-freeze.json, binary-identities.json and each runs/*/evidence. Independent evaluator owns pass/fail scores. If desired later, Claude restricted-vs-discovery incompatibility needs an explicit revised experiment, not a silent retry in this batch.
