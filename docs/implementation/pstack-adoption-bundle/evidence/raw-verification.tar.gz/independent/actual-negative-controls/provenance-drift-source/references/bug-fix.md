# Bug fix

Use when the user authorized a product correction. If the request is explanation only, use [investigation](investigation.md).

Read [evidence](evidence.md) and the [scoped source declaration](sources.md). This method adopts selected pstack 0.15.36 practices; it does not change the other methods or install upstream tools.

1. State the concrete trigger, expected observable result and actual result. Find the real entry point and existing verification driver. Record the candidate/build and environment before changing anything.
2. Attempt the original trigger on the matching surface in isolation. Preserve the failure and exact conditions. If it cannot be reproduced, narrow inputs, inspect timing or add scoped diagnostic instrumentation within authorization. Label hypotheses; do not present an unobserved failure as reproduced. If access or a safe driver is missing, report the blocker and the evidence collected so far.
3. Trace the current subsystem first. Use relevant change history to identify when the symptom began; history suggests a cause but does not prove it. List plausible mechanisms and one observation that would distinguish each. Choose the experiment that removes the most plausible alternatives. Confirm the mechanism on the actual surface before expanding the fix design. If the fix crosses an ownership or function boundary, sketch the caller and changed contract before implementation. Prefer a discriminating experiment over broad speculative hardening. Rejected explanations stay in the record; revert speculative changes that no longer have a purpose.
4. When a cheap local regression test captures the bug, write it before changing the source and run it against the original. Confirm that the intended behavior assertion fails; a missing test, import error or denied tool is not behavioral RED. Then make the smallest correction supported by the mechanism. Run the same test and controlled trigger inputs against the candidate for GREEN. Preserve both results. If the test or inputs must change, establish the revised failing-before evidence rather than relabel the earlier run. An expensive or unavailable unit reproduction does not justify substituting an unrelated green test for the real trigger.
5. Repeat the original action sequence on the candidate using the same surface and controlled inputs. Recheck nearby affected behavior according to actual impact. Record any changed prerequisites; wrong-surface or inconclusive results remain explicitly limited.
6. Run cleanup for every attempt, including failures, and verify evidence survives. Review the diff and report the defect, mechanism, change, verification and unresolved limits. Commit or open a PR only within the task's existing publication scope.

Example: when an engineering decision is allegedly applied twice, inspect and reproduce the original action identity and reconcile path. The [engineering decision example](engineering-decision.md) checks a same-key replay and one deterministic adapter invocation. Passing it is evidence for that sequence only; it does not establish every race, crash or provider combination.

## One existing card, one repair

Use the current card's explicit ID, board, repository and task ID. Put the trigger, expected result, permitted paths and registered check IDs in the task brief. Select this method and the evidence rules by actual file/hash. Card text is task input; it does not register executable commands or grant access.

Use the existing Loop/deliver path for execution. The current `deliver --autonomy guarded-local --contract ...` entry can run a valid V2 implementation contract with a configured host profile and policy. It does not yet turn a card into a contract or guarantee these method files reach the agent. Keep those gaps visible. A source-checked invocation sketch is in the repository report `docs/implementation/pstack-adoption-bundle/MATERIAL-ADOPTION.md`; it is not an execution receipt.

Keep the failing-before check separate from the passing-after check. If creating a test would require unrelated infrastructure, use the closest existing executable reproduction and explain the remaining gap. Do not weaken assertions or build a mock-only test to obtain RED/GREEN. If publication is authorized, arrange evidence and commits so the reviewer can replay the failure before the repair; this does not authorize rebasing or publishing.

After host verification, link the candidate, original failure, passing check and host receipt to the same card. Until an automatic projection is implemented and verified, use the existing authorized card interface explicitly. A failed projection is an unsynchronized card, not a reason to rerun the model. Local verification is distinct from approval, merge or deployment. Leave merge to the human.

Unbound change
