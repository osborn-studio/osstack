import pathlib,subprocess,json,hashlib,re,posixpath,datetime
r=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-adoption-bundle-20261030/independent');w=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-adoption-bundle');out=r/'actual-exports';out.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();reports=[]
for host in ['codex','claude']:
 dest=out/host;args=['/opt/homebrew/opt/node@22/bin/node',str(w/'scripts/export-osstack-methods.mjs'),'--host',host,'--output',str(dest)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,capture_output=True);(out/(host+'.stdout')).write_bytes(p.stdout);(out/(host+'.stderr')).write_bytes(p.stderr);(out/(host+'.command.json')).write_text(json.dumps({'argv':args,'start':start,'exit':p.returncode},indent=2));assert p.returncode==0
 receipt=json.loads(p.stdout);mb=(dest/'manifest.json').read_bytes();assert sha(mb)==receipt['manifest_sha256'];m=json.loads(mb);assert not m['installed'] and not m['host_discovery_verified'];files={x['path']:x for x in m['files']};actual={x.relative_to(dest).as_posix() for x in dest.rglob('*') if x.is_file()};assert actual==set(files)|{'manifest.json'}
 graph={};links=0
 for name,f in files.items():
  b=(dest/name).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'];src=(w/'osstack-methods-skill'/f['source_path']).read_bytes();assert sha(src)==f['source_sha256'];graph[name]=[]
  if name.endswith('.md'):
   text=b.decode();text=re.sub(r'```.*?```','',text,flags=re.S)
   for target in re.findall(r'\[[^\]\n]+\]\(([^\s)]+)\)',text):
    if target.startswith(('https:','http:','mailto:','#')):continue
    local=posixpath.normpath(posixpath.join(posixpath.dirname(name),target.split('#')[0]));assert local in files,(name,target,local);graph[name].append(local);links+=1
   if f['source_path'].startswith('references/'):assert b==src
 p=m['provenance'];assert len(p['bound_materials'])==5;assert not p['authenticated'] and not p['upstream_content_verified'] and not p['host_delivery_verified']
 reach={}
 for entry in ['osstack-mode','osstack-help','setup-osstack','osstack-agent']:
  start=m['namespace']+'/'+entry+'/SKILL.md';seen=set();pending=[start]
  while pending:
   n=pending.pop()
   if n in seen:continue
   seen.add(n);pending.extend(graph.get(n,[]))
  for ref in ['bug-fix.md','investigation.md','code-review.md','evidence.md','sources.md']:assert m['namespace']+'/'+entry+'/references/'+ref in seen,(entry,ref)
  reach[entry]=len(seen)
 retry=subprocess.run(args,capture_output=True);(out/(host+'-existing.stdout')).write_bytes(retry.stdout);(out/(host+'-existing.stderr')).write_bytes(retry.stderr);assert retry.returncode==1 and b'output_exists' in retry.stderr
 reports.append({'host':host,'payload_files':len(files),'manifest_sha256':sha(mb),'local_inline_edges':links,'reachable':reach,'provenance':p,'all_hash_size_and_source_bindings_match':True,'existing_output_rejected':True,'limits':'Independent simple inline Markdown graph; anchors not evaluated. Actual export is not native host discovery/consumption.'})
(out/'summary.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps([{k:v for k,v in x.items() if k!='provenance'}for x in reports],indent=2))
