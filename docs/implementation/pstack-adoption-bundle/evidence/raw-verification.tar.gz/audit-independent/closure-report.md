# 后审计有限闭环

冻结六向量旧版4通过/2失败，新版6通过。D1现在按同一路径矛盾hash报 `provenance_source_conflict`；相同hash正控通过。R1现在按超出canonical预算报 `SourceAdoptionError/RESOURCE_LIMIT`；小nested正控通过。R3跨组件大小写碰撞仍报 `FILE_CONFLICT`，合法共享路径通过。R1/R3输入完全一致，D1仅按预先记录的wire修订补必填role。

新版源码绑定548af5a3；保留inspections重组的candidate与root完全一致，digest699ffdbb。原51文件/174474bytes不变，新增caller-asserted版本字段与明确限制。五材料来源role/hash均核对，arena为context_only，plugin/LICENSE为identity_license。

双host全新项目局部导出各89payload、333本地inline边；所有成员和source/output哈希一致，四入口可达五材料，已有output仍拒绝。无实际宿主送达/理解/安装或资格宣称。

另保留一次核验脚本错误：初始旧新candidate对照漏计新增明确版本限制，原失败输出保存；新脚本只针对该确切限制修正，并未改变六向量或产品。原independent及455-file manifest未改。未重跑full/build/Git检查/模型/DB。
