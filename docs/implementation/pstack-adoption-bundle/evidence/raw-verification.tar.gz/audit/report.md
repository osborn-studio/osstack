# Verdict: PASS_WITH_CONCERNS

I found no defect that breaks the declared scope: no unsafe write, no legacy-export regression, and no claim of installation or authentication. Several items should be fixed before the candidate digest is frozen, because `fcdbd613…` is already embedded in `provenance.json`. Review was by reading only. Nothing was executed, and my hash comparisons were done by eye.

## Confirmed defects (visible in the supplied source)

**D1. Contradictory source hashes are accepted (`method-provenance.mjs`).**
- The `seen` set is per binding, so nothing relates one binding's `source_refs` to another's.
- Trigger: binding A lists `pstack/skills/tdd/SKILL.md` with sha `c…`, and binding B lists the same path with `d…`.
- Export succeeds with `declared_material_hashes_checked`, although one of the two hashes must be false.
- Fix: keep one `Map<path, sha>` across all bindings and fail on a mismatch.

**D2. `source_refs` carry no role, and the shipped file contradicts `sources.md`.**
- `references/code-review.md` binds `pstack/skills/arena/SKILL.md`, but `sources.md` says arena "was read… **not** adopted".
- `sources.md` is bound only to `plugin.json` and `LICENSE`, which are identity material and not derivation sources. It cites 15 other c742 paths.
- MATERIAL-ADOPTION itself distinguishes `adopted_guidance`, `context_only` and `identity_license`. The flat list reads as "derived from" for all of them.
- Fix: add a closed `role` enum per ref, or drop arena and rename the field to say "consulted". Neither option changes the candidate digest.

**D3. The shipped binding set is not enforced by anything.**
- Trigger: delete `osstack-methods-skill/provenance.json`, or trim it to one binding.
- All 16 new tests use fixtures. The canonical-tree export tests check only manifest self-consistency, so they would still pass.
- The export would silently emit no `provenance` key, while EXPORT.md says the canonical package includes it and binds five materials.
- Fix: add one canonical-tree test asserting that `bound_materials` equals the five names and that `adoption_candidate_digest` equals the pinned value.

**D4. The candidate leaves `package_version` unlabeled as caller-asserted.**
- `repository_identity` is flagged `caller_asserted`, but `package_version` is not, and the `limitations` text omits it.
- `plugin.json` is in no component, so `declared_closure: 'verified'` sits next to an unchecked version.
- Provenance and the manifest then echo that version.
- Trigger: the same commit with `package_version: "9.9.9"` yields an identical `verified` candidate.
- Fixing this changes `candidate_digest`, so it must be done before freezing. A docs-only fix is the alternative.

**D5. Provenance errors have weak diagnostics and a brittle limit label.**
- `fail('material_drift')` names no path. Changing one byte of one of five bindings gives no hint which.
- `maxBytes === 65536 ? 'provenance_limit' : …` identifies the file by a magic number. A file that grows between `lstat` and read reports `source_limit: bytes` instead.

**D6. Real-export and dry-run receipts differ.** Dry-run returns `provenance`. Real export returns only `file_count`, so the receipt does not reveal provenance status without reading `manifest.json`.

**D7. Duplicate-key behavior is documented only in a JSDoc comment.**
- The exact bytes are copied into the bundle but validated with last-wins `JSON.parse`.
- Neither the manifest `limitation` nor EXPORT.md mentions it.
- Trigger: `"sha256":"<stale>","sha256":"<current>"` passes export, and a first-wins consumer reads the stale value.
- Cheapest fix: add one sentence to the manifest `limitation`, which no digest covers.

## Untested risks (plausible, not demonstrated)

**R1. Candidate output size is not bounded by the file and byte limits.**
- Those limits count unique files only. Each file carries `component_ids` and `roles` for every component containing it.
- Nested subdirs are allowed. Genuine inspections of 32 nested subdirs over a ~500-file leaf give each file 32 roles, producing a candidate on the order of 1 MB or more.
- The final `canonicalJointJson(result)` is unguarded. If it has a size or depth cap, a non-`SourceAdoptionError` escapes. I can't see the cap.

**R2. Overlapping or nested component subdirs are accepted and untested.**

**R3. The aggregate `SourceSnapshot` guard (`FILE_CONFLICT`) has no direct test.**
- Existing tests cover only per-path fact conflicts.
- A real trigger: A's license is `docs/LICENSE` and B's is `docs/license`, from one commit, so each inspection passes alone.

**R4. Legacy edges.**
- An unrelated `provenance.json` in a legacy source tree now hard-fails export.
- The bundle root gains a file, which would break any consumer that assumes the root holds only `manifest.json` and the namespace directory.

**R5. Input leniency.**
- The candidate's `Repository` accepts `https://h/p?token=abc` and `git@host:org/repo`. Provenance is stricter. Candidate JSON is likely to be retained as evidence.
- `text()` and `Declaration` accept bidi and format characters in `package_version` and `repository`, and the dry-run output echoes them.

**R6. Large input arrays.** Zod parses array elements before enforcing `.max`. This matters only for in-process callers.

**R7. Cross-check of provenance against the candidate is manual.**
- By eye, 17 of the 18 `source_refs` match candidate file hashes. `plugin.json` is outside the candidate by design.
- Nothing asserts this. A pure script or test would make it repeatable.

**Nits:**
- `UNDECLARED_COMPONENT` is reused for an unused external requirement.
- The 51-file candidate covers 34 files never consumed, so the candidate digest is much wider than the adoption actually used.

## Checked and sound

- The bytes hashed for binding are the same buffers written to output, so there is no TOCTOU between check and write.
- Provenance failures occur in `plan()`, before the `mkdir` reservation.
- With no `provenance.json`, the manifest key order, the dry-run shape and `files` are unchanged.
- A source link to `provenance.json` is still rejected by the second, export-side link check.
- Dependency order and the candidate digest are deterministic, and inputs are not mutated.
- Provenance read budgets and loops are bounded.

## Recommended before freezing

Fix D4 first, since it re-mints the digest. Then fix D1, D2 and D3 and add the D7 sentence. R1 needs only a try/catch mapped to `RESOURCE_LIMIT`, plus one nested-subdir test.