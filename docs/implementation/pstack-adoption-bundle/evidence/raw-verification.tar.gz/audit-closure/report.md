# Limited closure verdict: PASS

This is a static read of the supplied final source against my prior report. I found no concrete remaining blocker for D1-D7 or R1-R3/R7. I did not execute anything, and I compared hashes by eye.

## Item-by-item

| Item | Result | Basis in final source |
| --- | --- | --- |
| D1 | Closed | `sourceHashes` is a `Map` shared across bindings, and a differing hash fails with `source_conflict: <path>`. The new test reuses the same path with `d…` in a second binding. |
| D2 | Closed | `source_refs` now require exactly `path`, `sha256` and `role`, and the role is a closed three-value enum. Arena is `context_only` and `plugin.json`/`LICENSE` are `identity_license` in `provenance.json`. Missing or unknown roles are tested. The manifest limitation and EXPORT.md both explain the roles. |
| D3 | Closed | The canonical-tree test pins the five `bound_materials` in sorted order, the commit, the version and `699ffdbb…`. That digest matches both `provenance.json` and `adoption-candidate-final.json`. |
| D4 | Closed | The candidate emits `package_version_identity: 'caller_asserted'` and a matching limitation line. The test shows a version change at the same commit changes the digest while the label stays. The old digest `fcdbd613…` was replaced consistently everywhere I can see. |
| D5 | Closed | `material_missing` and `material_drift` carry the path. `boundedRead` takes an explicit `limitLabel`, used on both the pre-read and post-read checks, so the magic number is gone. |
| D6 | Closed | The real-export return spreads `result`, which includes `provenance`. The test asserts `deepEqual` with the saved manifest. |
| D7 | Closed as disclosure | Last-wins `JSON.parse` is unchanged, as the disposition says. It is now stated in the manifest `limitation`, in EXPORT.md and in the test regex. Nothing claims duplicate keys are rejected. |
| R1 | Closed | The `canonicalJointJson(result)` call is wrapped and mapped to `RESOURCE_LIMIT`. Statically, the 32×500 fixture is legal everywhere else, so only the final serialization can fail. That covers the 64-character ids, the 501 unique files ≤ 512 and the 33-segment paths. |
| R2 | Closed | The nested 3×4 test expects 5 files, 11 bytes and 3 roles per file. This matches the code path: license 7 + 4×1 = 11, with `component_ids` and `roles` of length 3. |
| R3 | Closed | The `docs/LICENSE` vs `docs/license` fixture passes each inspection alone and reaches the aggregate `SourceSnapshot` check. The `docs/NOTICE` control expects 4 files. |
| R7 | Closed for this scope | I compared the proof file's refs to `provenance.json` by eye. All 18 paths, hashes and roles agree. 17 hashes match candidate file hashes, and `plugin.json` is marked `separate_identity_read`. |

## Non-blocking notes

- **R1 depends on a module I can't see.** The test assumes `canonicalJointJson` throws above about 1 MiB. I can't confirm the cap from this source. The disposition says the old code failed 2 of 35 tests and the new code passes. I take that as retained evidence, not as something I verified.
- **R7 is a retained artifact, not a repo test.** The script that produced `final-provenance-proof.json` is not in the supplied files, so I can't judge whether it can be re-run. This only matters if you want the cross-check to be part of the suite.
- **`plugin.json` rests on a separate read.** Its hash, `ebc3ee08…`, is outside the candidate by design. Nothing supplied lets me verify it.
- **Manifest wording is slightly asymmetric.** The manifest `limitation` covers unauthenticated upstream references, but only EXPORT.md says the version label is caller-asserted. This is wording only and changes no digest.

## Not claimed

I did not verify the reported test counts (export 115, source 35, old 16 pass/1 fail). I also did not verify the Node 22/26 notes, any host behavior, provenance authenticity, or the content of `sources.md`. This verdict covers only whether the described repairs are present and coherent in the supplied source.