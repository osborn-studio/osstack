# Retained product deviation classification priority

Only classifyFailure and new retained-fixture tests changed. Ordinary outer drive exit1 is deferred until the sealed product observation is examined; concrete timeout/signal/output-limit/process errors and doctor errors retain tool failure priority. A genuine raw product mismatch can then be classified observed_product_deviation, with cause unknown. No schema, CLI guard, limitation, projector or runtime change.

Four identical targeted tests: old source 3 pass/1 behavioral failure (tool_failure instead of observed_product_deviation), fixed source 4 pass. Complete health focused suite: 45 pass, including root-owned symlink CLI regression. All evidence is synthetic retained data through the existing readonly verifier, no full5 drive. The first test-preparation run failed because the fixture attempted to seal an existing manifest; this harness failure is preserved separately as red.*, not called the behavioral RED. Corrected fixture old/new runs are red-behavior and green-behavior.

No product execution, whole-repository tests, model invocation, commit, PR or central ledger writes. Root-owned CLI guard and limitations were left untouched. Source snapshots include those preexisting root changes; the two patch files show only this author's delta.
