import subprocess,os,pathlib,json,hashlib,datetime
r=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-maintenance-health');o=pathlib.Path(__file__).parent
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin';env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap():
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().split('\0');return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths if p and (r/p).is_file()}
commands=[['pnpm','build'],['pnpm','typecheck:check'],['pnpm','lint'],['node','scripts/generate-inventory.mjs','--check'],['node','--test','scripts/method-control-health.test.mjs','scripts/maintain-skills-check-map.test.mjs','scripts/project-method-journey-evidence.test.mjs','scripts/method-feature-map.test.mjs'],['pnpm','test']]
results=[]
for i,cmd in enumerate(commands):
 before=snap();(o/f'{i}.before.json').write_text(json.dumps(before));start=now()
 with (o/f'{i}.stdout').open('w') as out,(o/f'{i}.stderr').open('w') as err:p=subprocess.run(cmd,cwd=r,env=env,stdout=out,stderr=err)
 after=snap();(o/f'{i}.after.json').write_text(json.dumps(after));v={'argv':cmd,'start':start,'end':now(),'exit_code':p.returncode,'tracked_before':len(before),'tracked_changed':[x for x in sorted(set(before)|set(after)) if before.get(x)!=after.get(x)],'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()};results.append(v);(o/'receipt.json').write_text(json.dumps(results,indent=2));print(json.dumps(v),flush=True)
 if p.returncode:break
