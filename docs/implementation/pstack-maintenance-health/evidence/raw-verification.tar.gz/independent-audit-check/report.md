审计逐项处置（不修改旧独立成绩）

确认 CLI 入口缺陷：Node22 --preserve-symlinks-main 下符号链接 --help 自然 exit0、两流为空。建议两侧 realpath。

产品偏差分类的静态限制比审计推测更具体：不是 failed packet 归零本身阻断 raw，而是当前 smoke 将行为偏差转 driver_exit1，health 先按外层非零归 tool_failure，未进入 raw evaluateCase。因此普通当前 producer 路径不会得到 observed_product_deviation；本轮没有执行新的产品偏差实验。

- concern1 [accurate_with_scope_correction] versions.driver compares the single wrapper file hash to caller configuration; it is not a transitive executable identity or live checkout freshness. Other journey/source binding records exist, so do not say imports are unbound everywhere. 建议：Clarify single-file and configured-only semantics in JSON limitations.

- concern2 [accurate_contract_limit] Only caller-declared attempts are queried. Omitted attempts cannot be discovered; bounded_consistent covers that declared set. 建议：Expose caller-declared attempt-set limitation, no implicit scan.

- concern3 [accurate_bounded_untrusted_data] Preserved diagnostics are bounded but arbitrary retained strings. H11 requires retaining primary and secondary diagnoses; replacing them with generic codes loses evidence. 建议：Label untrusted retained text, never interpret as instructions; no requirement to strip originals.

- concern4 [accurate_contract_limit] required_feature_ids is reverse impact selection, not health inheritance. A dependent own record may be consistent independently of dependency status. 建议：Explicitly say selection-only; no new policy.

- concern5 [safe_limit_with_precision] Missing/null journey cannot complete original verifier and becomes unknown, not healthy. First supported failure classification is returned; other raw diagnostics remain preserved after C H11 repair. Earlier unclassifiable failure can be absent from the one classification, so it is not exhaustive causal attribution. 建议：Document partial classification; do not call it full diagnosis.

- concern6 [confirmed_runtime_entry_defect] One authorized Node22 --preserve-symlinks-main symlink --help probe on source772f exited0 with empty stdout/stderr. 建议：Realpath both entry paths, retain import-not-run behavior and add exact regression.

- coverage-product-deviation [confirmed_static_normal_producer_path_gap] Failed packet normalization itself does not eliminate raw files. smoke evaluateCase failure sets driver_exit1; journey records failed and leaves product_exit null; health sees nonzero drive command at line95 and returns tool_failure before raw evaluateCase at111. Thus the ordinary producer behavior-deviation path is intercepted. The raw branch can be reached by a retained drive0/verifier-failed special shape, not demonstrated as a current ordinary producer output. 建议：Do not claim product-deviation classification exercised or generally usable. For that promise, prefer complete raw behavior evidence before generic nonzero driver fallback. No additional product experiment performed.

- coverage-other-branches [partially_missing_reviewer_context] Injected execution was independently exercised (initial19 plus correction3); malformed arguments3 and file refusals4 also actually executed. map_changed/toolchanged/nulltoolafter and drive-phaseflag variants not all independently exercised. --changed-path only API exercised; no >2 real-record ordering. 建议：Preserve exact tested scopes rather than saying all CLI argument paths are untested.

- weak-negative-assertions [optional_strengthening] Some original tests assert unknown without exact reason; independent raw outputs retain issues for inspection. This does not invalidate actual positive controls and identity/tamper rejection, but no blanket exact-cause coverage claim. 建议：Targeted exact reason assertions are useful future regressions, not a new acceptance gate.

- provenance-H11 [supplied_context_omission] report-initial has C1/C2 because H11 was found later. remaining-retained-run/01-raw.json and closure/retained-fixed-run/03-raw.json preserve its RED/GREEN; frozen report was not rewritten. 建议：Include both in audit evidence list.

- provenance-health-query [phase_binding_not_contradiction] docs/actual-summary health_query_executed:false refers root drive/repair stage. Independent actual-cli has four subsequent readonly queries. good uses copied attempt02 with receipt878fe3; tool-fault uses copied attempt01 receipt91125e. Final closure good/fault is API on772f; earlier four CLI calls are source6fda. 建议：Do not relabel earlier CLI as final-source execution.

- provenance-repaired-tool [omitted_input_now_bound] repair.json and clean/faulty snapshots prove same owned entry restored to clean bridged copy8088, not checkout wrapperf8836. Independent retained-input-check includes exact repair diff and validates receipt/raw hashes. 建议：Keep bridge-source distinction; no same-binary claim for checkout wrapper.

- full-suite [not_reverified_in_this_audit_check] Root reports full d12ed16b exit0 and8980tracked unchanged. This task did not parse/verify full output or rerun it. 建议：Keep separate root binding and subsequent source/doc changes.

