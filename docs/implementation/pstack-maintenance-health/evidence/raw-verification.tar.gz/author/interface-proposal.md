# W19 health 最小实际接口（待 root 冻结，尚未编码）

基线 `5569e8fe8bae5129d69689937aff5802de658931`。原 W19 位于 integration-spec:555–561；A45 位于 acceptance-cases:614–622。实际来源：maintain-skills-check-map.mjs 的 runMaintenance / maintenance.json；method-verification-journey.mjs:195–268 的 journey.json/manifest；project-method-journey-evidence.mjs:153–198 的 retained 原件验证。

## 公开入口

`node scripts/method-control-health.mjs --config ABS_CONFIG --as-of ISO_UTC [--changed-path REL_PATH ...]`

`inspectMethodControlHealth({config, asOf, changedPaths})`，无副作用。stdout JSON。exit0仅报告生成（可含unknown/degraded），exit2为配置/参数错误。未知、失败不能作为该工具exit0的健康依据。缺省不运行任何进程、网络、schedule或通知；不自动修复、重驱、遍历仓库或全scratch找“最近”。

配置闭合对象示意：

```json
{"schema_version":1,"project":"osstack","max_age_seconds":86400,"features":[{"feature_id":"maintenance","owner_ref":null,"source_digest":null,"build_digest":null,"driver_sha256":null,"changed_paths":["scripts/maintain-skills-check-map.mjs","scripts/method-verification-journey.mjs","scripts/lib/skills-check-verification.mjs","packages/cli/src/skills-command.ts"],"required_feature_ids":[],"attempts":[{"kind":"maintenance","path":"records/attempt-1","receipt_sha256":"..."}]}]}
```

字段可由root进一步收窄。owner只来自这份显式项目配置，输出config hash/feature key；null为unassigned，无worker/作者fallback，不授予新权限。source/build为当前比较基准的调用者配置摘要，driver为对应wrapper声明基准；null保留freshness unknown，不偷偷hash整仓推断构建。所有记录相对配置目录，逐级拒symlink/escape。最多8feature、每feature8attempt，输入文件/成员/总字节均有界。配置changed_paths为精确规范化仓库相对文件路径（不glob），required依赖闭包传播影响；无changed flag检查全部配置features，有flag只读受影响feature记录，未映射path单列unknown，不能默认为无影响。

## 原件核验及复用选择

**推荐最小额外root改动：** 在 projector 暴露 `inspectRetainedJourney({input,scope})` 只读封装现私有buildProjection，复用既有所有manifest/hash/raw/固定五例/cleanup一致性检查，返回现有packet对象供内存消费。不创建packet文件，不改既有project/check语义；root独占此现有文件和针对readonly的定向测试。作者仍只新增health与其test两文件。

不建议复制约200行retained parser到health；也不能调用会创建输出的projectJourney冒充只读。公开verifyCaseEvidence有live路径/fixture要求，不适合本查询历史归档。若不允许该只读export，本片只能称record摘要核对、healthy始终unknown，不能满足“已核原件”的实用范围。

health对每记录：

1. 读取并绑定maintenance.json（或直接journey.json）到配置receipt_sha256。拒错误JSON/超限/非regular。receipt与目录均明确来自配置，不认证生产者。
2. maintenance：读取map-before，核其sha/bytes和固定五例闭合schema；若map_after存在，核after及unchanged；核expected/actual/matches是由map+已核journey重新比较所得，不信自报status。保留execution_path，injected_journey/injected_driver不升级真实驱动。
3. 只读完整核验journey和全部已留case manifests，使用现有验证器。验证失败/缺失不healthy。原件未提供不是“无失败”。hash只证明留存字节一致，不证明认证、编译或当前运行。
4. full passed应有healthy/missing-ref/drift/mixed/empty固定顺序、预期产品0/1/2/1/0；不因产品非零报告回归。只认可对应driver验证成功，不拿单行结果代表五例。
5. 完整maintenance应该绑定journey receipt/manifest的hash和复制features。合法partial（receipt_sha256=null等）保留，不补写或把后来可读的原件当成包装器当时成功。

## 结果与分类（分轴，不强行推根因）

每feature返回owner、配置版本/hash、recent_attempt、last_success、freshness、evidence_integrity、health、分类及引用hash/不足。`last_success`明确historical，不能覆盖较新失败。

- 每次attempt的时间来自已hash绑定receipt的started_at/ended_at；必须合法、start≤end≤asOf。按ended_at排序，不用文件mtime/配置顺序。时间冲突或未能读取某条导致无法确定最新时，recent_attempt=unknown，旧成功可以保留为historical但当前health unknown。
- 版本比对使用实际case binding source/build摘要及wrapper记录（若当前maintenance记录没有wrapper摘要则driver freshness unknown，不发明字段）；缺配置值unknown，明确不一致stale；超max_age过期。只有已核、未过期、版本可比且一致的最近完整记录可称bounded_consistent；其余保留unknown/blocked/degraded。不称整个项目healthy。
- map_before/after真实不一致→map_changed；合法地图与已核实际行不一致→expectation_mismatch（根因unknown），不自动称地图漂移或产品bug。
- doctor原始记录含具体缺前提（ready=false/check失败）→environment_blocked；无法读doctor原件或只有字符串→unknown。
- 包装器已有passed完整journey但maintenance blocked、其receipt读取/核验字段未完成→tool_evidence_failure，保留明确阶段/首错/后续错。不因下层full5成功抹掉上层失败。
- 驱动超时、输出截断、执行失败等只有在绑定的command/raw对应失败阶段时标tool_failure。产品行为偏离只能报告observed_product_deviation，非自证产品根因。证据损坏/矛盾/未支持失败形状统一unknown，不按错误文字猜分类。
- packet 场景在首片不强行归入maintenance健康；配置可没有attempt，保持unknown。无任意外部record认证。

## root选定真实工具修复闭环如何读取

root独占实际注入：maintenance副本仅将读取journey.json改为journey-receipt.json；真实full5 passed后wrapper blocked/2/ENOENT。恢复该行后fresh output同入口consistent0，map不变。health第一次应并列：journey retained verification=passed、wrapper=blocked、tool_evidence_failure/读取阶段未完成。第二次recent_attempt=新consistent，last_success=该新记录；旧失败仍列历史，不能删除。若记录没有wrapper源码版本绑定，必须保留driver freshness unknown；可查询修复差异，但不能凭这个记录签完整A45。

## 必需测试与实施边界

- 配置缺/冲突owner、未知changed路径、精确匹配与required反向传播、无关record不可读但未访问。
- 最近失败+较早success、时间重复/未来/非法、未读记录、过期、source/build不符、driver缺绑定，均不upgrade。
- 真实留存full5正控制；expected非零不误报产品失败；地图mismatch重算；篡改receipt、manifest/member、跨case、partial wrapper读取失败与完整journey并存。
- 同注入工具问题修复前/后health读取（实际重驱由root唯一队列负责）；保留旧失败，不新增方法数。
- CLI只读资源检查，模块导入无启动，原件字节未改。所有fixture测试标明模拟/注入，不认证独立principal。此方案不是完整W19/A45已经完成。
