# W19 limited post-inspection repair

This revision changes only the health reader and its focused test file. No full-five product drive, whole-repository suite, model invocation, or commit was run by the author.

- Strict string SHA-256 validation replaces implicit RegExp coercion in config/attempt/tool fields. Existing nullable positions remain nullable.
- If retained map-after.json exists, its bytes/hash and equality with map-before must match the receipt. Ordinary unchanged records without an after file remain valid. Symlinks are rejected by the same bounded reader.
- After retained evidence validation, record_details.failure and subsequent_failures preserve the existing diagnostics without changing classification. Each diagnostic is bounded to 4096 UTF-8 bytes and subsequent diagnostics to 32; oversized records remain unknown.

The identical 40-test source ran against original 6fda implementation (28 pass, 12 fail) and revised implementation (40 pass, 0 fail). Existing 27 tests still pass. Additional cases cover digest arrays, map-after conflict/symlink and unchanged controls, preserved two-stage failures, and diagnostic bounds. These are synthetic retained-evidence regressions using the real readonly verifier, not real product executions or formal qualification.

The original author/manifest.json and all its members remain untouched. Revision records are separate. C owns independent old/new closure; root owns integration and auditing.
