# W19 author evidence

- `contract.json` and `contract-output.json` bind the agreed local query interface. `interface-proposal.md` remains the earlier proposal.
- RED is a new missing module, not an old product regression. First GREEN has 18 tests; final GREEN has 27. The fixtures construct retained evidence and use the actual readonly verifier; they do not drive products.
- `actual-adverse-query` invokes the real health CLI on copies of root's previously executed environment and map-expectation controls. The original records were not changed. It creates no new journey/product run.
- `source/` holds final two author scripts. `final-binding.json` binds dependencies and code SHA256, without committing the shared tree.
- All later independent/Sonnet/full-suite results belong to root/C, not this author report.

The two large copied input directories under actual-adverse-query are excluded from this author manifest to avoid duplicate payload. Their complete file lists, hashes, sizes and equal original locations are preserved in retained-input-bindings.json; root retains the original actual records. No failure/log or authored output is excluded.
