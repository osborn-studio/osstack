import pathlib,json,hashlib,difflib
S=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-maintenance-health-20261030'); O=S/'independent'; P=S/'docs/actual-tool-repair'
sha=lambda b:hashlib.sha256(b).hexdigest()
result={'scope':'Readonly retained-byte/claim check, no product execution, hashes not producer authentication','records':[]}
for d in [P/'attempt-01',P/'attempt-02',S/'root/adverse-controls/environment',S/'root/adverse-controls/expectation-mismatch']:
 r=json.loads((d/'maintenance.json').read_bytes()); checks=[]
 for m in sorted(d.rglob('*manifest.json')):
  obj=json.loads(m.read_bytes())
  for f in obj.get('files',[]):
   p=m.parent/f['path']; b=p.read_bytes(); assert len(b)==f['bytes'] and sha(b)==f['sha256'],str(p)
  checks.append({'path':str(m.relative_to(d)),'sha256':sha(m.read_bytes()),'members':len(obj.get('files',[]))})
 rows=r['journey']['features'] if r.get('journey') else []
 item={'path':str(d),'receipt_sha256':sha((d/'maintenance.json').read_bytes()),'status':r['status'],'exit_code':r['exit_code'],'failure':r['failure'],'map':r['map'],'tool':r.get('tool'),'rows':[{'case_id':x['case_id'],'product_exit':x['product_exit'],'driver_exit':x['driver_exit'],'verification':x['verification'],'fixture_absent':not pathlib.Path(x['cleanup']['fixture_path']).exists() if x['cleanup'].get('fixture_path') else None} for x in rows],'manifests':checks}
 result['records'].append(item)
for phase in ['fault','redrive']:
 c=json.loads((P/f'records/{phase}.command.json').read_bytes())
 for stream in ['stdout','stderr']: assert sha((P/f'records/{phase}.{stream}').read_bytes())==c[f'{stream}_sha256']
a=json.loads((P/'records/fault.command.json').read_bytes());b=json.loads((P/'records/redrive.command.json').read_bytes());assert a['argv'][:-1]==b['argv'][:-1]; assert a['exit_code']==2 and b['exit_code']==0
assert (P/'map.json').read_bytes()==(P/'map-original.json').read_bytes()
old=(P/'snapshots/faulty-bridged.mjs').read_text();new=(P/'snapshots/clean-bridged.mjs').read_text()
result['repair_diff']=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='faulty',tofile='clean'))
result['source_input_inventory']=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for d in [P/'attempt-01',P/'attempt-02',S/'root/adverse-controls/environment',S/'root/adverse-controls/expectation-mismatch'] for p in sorted(d.rglob('*')) if p.is_file()]
(O/'retained-input-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'records':len(result['records']),'manifest_members':sum(m['members'] for r in result['records'] for m in r['manifests']),'file_count':len(result['source_input_inventory']),'status':'byte_checks_passed'}))
