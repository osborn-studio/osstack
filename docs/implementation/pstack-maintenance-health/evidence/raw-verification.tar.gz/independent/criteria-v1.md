# W19 只读健康查询：独立预冻 v1

时间：2026-10-30T07:47:09.813178+00:00；基线 `5569e8fe8bae5129d69689937aff5802de658931`。未读新实现、未运行产品。本轮20个向量均未执行；API明确后只补wire/边界，不覆盖原期望。

- **MH01 Owner provenance**：Only project-explicit owner declaration with config identity and feature scope; missing owner stays unassigned. No inference from worker/Git author/fixture ownership; no permission or principal authentication follows.
- **MH02 Separate latest attempt and last success**：Never substitute older success for newer failed/blocked/incomplete/unknown attempt. Keep both identities/times/versions and selection reason. Invalid/equal/contradictory ordering evidence must remain explicit; do not silently fall back to green.
- **MH03 Evidence integrity before health**：Missing/malformed/hash-mismatched/mixed-run or internally contradictory claimed-success receipts cannot report verified healthy. Manifest resealing is not authenticity. Complete self-consistent fabricated provenance cannot be detected by hashes alone; report retained evidence verification scope, not authenticated execution.
- **MH04 Versions and freshness**：Display source, driver/map identities and explicit comparison basis. Missing current comparison unknown; mismatch stale/drift, not current healthy. Prior historical success preserved bound to its version.
- **MH05 Expected product negatives**：Five verified product exits0/1/2/1/0 and statuseshealthy/failed/drift/failed/empty with successful driver are expected controls, not regressions. Empty has zero sources, not observed healthy sources.
- **MH06 Fault categories follow evidence**：Environment requires specific prerequisite evidence; harness/tool failures require named stage/raw support; mismatch alone is discrepancy/cause unknown, not automatically map drift. Product result is an observed predicate deviation, not proof of regression cause. Preserve multiple/secondary failures and uncertainty.
- **MH07 Changed paths and dependency direction**：Only declared related features affected; include reverse required dependency closure. Unknown/unmapped changes remain visible, never imply everything fresh. Unknown dependency/cycle/invalid path cannot yield a complete healthy plan. No implicit network/watchers or whole repository scans.
- **MH08 Partial and missing evidence**：not_run, unknown cleanup, absent artifacts and failed verification do not become pass. A partial failed journey may retain trustworthy prior observations, but its global health cannot be upgraded. Readable receipt alone is insufficient.
- **MH09 Readonly and bounded**：No doctor/drive/subprocess/DB/network/repair/scheduler/notification by default. Imports/query only inspect explicitly scoped files. Exact file/row/bytes/time limits, paths/symlink policy bound to forthcoming API; refusal must not hide required data via truncation.
- **MH10 Input distrust**：Closed validated config/reference structures; malicious fields, paths and text remain data not instructions. Duplicate identities, unsupported types, escape/symlink, huge data have bounded rejection per contract; no outside-scope file reads.
- **MH11 Actual interface and reproducibility**：Independently use real CLI and API read seam on controlled copies and an actual retained bundle when supported. Record argv/code/source hashes, reads, before/after input hashes and raw outputs; no product rerun implied by receipt inspection.
- **MH12 Limited delivery**：This is W19 read-only health/ownership/change-impact query only. It does not complete A45 real tool repair/re-drive, W11 activation, fullC0 or Firstmate runtime. Default periodic work disabled/not_configured, not asserted monitored-good.

## 最小可实现分类规则建议

| 已核证据 | 可报告 | 不能直接报告 |
|---|---|---|
| 项目配置的owner声明+配置摘要+适用feature | configured declaration / unassigned | 身份认证、修改或通知授权 |
| 回执/manifest/必要原始文件与语义一致的固定五例 | retained verification success，保留product负例状态 | 所有产品健康、真实来源被修复 |
| 明确doctor检查失败/前提缺失，且阶段和输出吻合 | environment/precondition blocked | 产品回归 |
| 具体工具/证据处理错误，首因及后续错误保留 | harness/evidence failure；不足则unknown | 功能产品失败或成功 |
| map期望与已核观察不同 | mismatch / cause unknown | 自动认定map drift或product regression |
| 原始观察违反固定产品谓词且执行/输入身份一致 | observed product deviation | 原因已证明、一定是新版本回归 |
| 缺件、篡改、混run、无版本比较或未观察前提 | invalid evidence / unknown / stale，分轴保留 | 用旧成功遮新失败、当前healthy |

`map drift` 若只指版本不一致，可明确叫地图版本漂移，不能混同“地图期望错误”的根因诊断。若报告消费外部诊断，请标为reported claim并绑定来源；本切片无需建立通用诊断或签名平台。自签manifest只能检一致性；完全自洽的伪造不能凭哈希识破，不设无法兑现的认证门槛，也不能过称真实性。

维护结果本身保留status/exit/时间/map哈希/rows/journey/首错与后续错误，适合作为入口，但不能仅凭status consistent或exit0判健康。上层maintenance没有自动提供独立认证；需声明本适配器究竟核了哪些原件。不能直接对归档迁移路径无条件调用具有原路径和livefixture前提的verifyCaseEvidence。

最新尝试与最后成功分开，历史成功绑定历史source/driver/map；查询当前健康需显式比较基准。owner缺失可以不阻止读取证据，但不应让报告显示维护责任完整。输入changed paths是一轮查询数据，不是后台订阅；未知映射应保留缺口。默认周期未配置不需要先建调度器。

完整A45仍包括分别出现故障、修复真实工具问题并实际重驱。本批只读查询不代做该动作，不重跑旧C0，也不进入Firstmate深运行。
