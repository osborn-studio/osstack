W19 有界独立验证：初候选仍需两处小修。

35 项 wire 检查通过；22 项留存检查原记录为 19 通过、3 个 harness 断言失败。时间包络修正和两个状态轴断言修正分别追加，3 项均通过，原失败保留。四次实际 health CLI 查询 exit0，分别报告 bounded_consistent、tool_evidence_failure、environment_blocked、expectation_mismatch；exit0 不表示健康。

后续只读代码检查引出的 4 次针对性探针确认：SHA 字段数组被接受；矛盾的现有 map-after 文件被忽略且报告健康。均已交作者/root，未改产品。

核验四组既有原件的 536 个 manifest 成员；这是对 root 已执行工具故障/修复和两个控制的留存复核，不是独立重跑产品。原件绑定 563 文件。真实两次 full5 的预期非零 product 结果不能称 regression；mismatch 原因仍 unknown。所有证据不构成生产者身份、现场版本或完整 W19/A45/C0 资格。
