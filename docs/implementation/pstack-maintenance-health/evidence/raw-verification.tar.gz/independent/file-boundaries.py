import pathlib,subprocess,json,hashlib,os
p=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-maintenance-health-20261030/independent');out=p/'file-boundaries';out.mkdir();src='/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-maintenance-health/scripts/method-control-health.mjs';base=(p/'wire-run-v1/01/config.json').read_bytes();(out/'valid.json').write_bytes(base);(out/'invalid-utf8.json').write_bytes(b'\xff');(out/'directory.json').mkdir();os.mkfifo(out/'fifo.json');(out/'link.json').symlink_to(out/'valid.json');rs=[]
for name in ['invalid-utf8.json','directory.json','fifo.json','link.json']:
 args=['/opt/homebrew/opt/node@22/bin/node',src,'--config',str(out/name),'--as-of','2026-10-30T09:00:00Z'];r=subprocess.run(args,timeout=5,capture_output=True,env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin'});rs.append({'name':name,'argv':args,'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode(),'passed':r.returncode==2 and not r.stdout})
(out/'fifo.json').unlink();(out/'results.json').write_text(json.dumps({'source_sha256':hashlib.sha256(pathlib.Path(src).read_bytes()).hexdigest(),'results':rs,'fifo_removed':True},indent=2)+'\n');print(json.dumps({'passed':sum(x['passed'] for x in rs),'total':len(rs)}))
# Verify original 563 retained inputs remain unchanged after all read-only queries and mutation-of-copy probes.
a=json.loads((p/'retained-input-check.json').read_text());bad=[]
for x in a['source_input_inventory']:
 b=pathlib.Path(x['path']).read_bytes()
 if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256']:bad.append(x['path'])
(p/'original-inputs-after.json').write_text(json.dumps({'files':len(a['source_input_inventory']),'changed':bad},indent=2)+'\n')
