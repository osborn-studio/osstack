#!/usr/bin/env python3
"""Reviewable scenario driver. No action occurs until explicitly invoked.
prepare is file-only; fault/redrive each launch exactly one actual full5 wrapper.
Do not invoke execution phases before root's explicit execution window.
"""
import argparse,datetime,difflib,hashlib,json,os,pathlib,subprocess,sys
WORKER=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-maintenance-health-20261030/docs')
CHECKOUT=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-maintenance-health').resolve()
NODE='/opt/homebrew/opt/node@22/bin/node'
PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin'
IMPORTS={'./method-verification-journey.mjs':'scripts/method-verification-journey.mjs','./lib/scratch.mjs':'scripts/lib/scratch.mjs','./lib/skills-check-verification.mjs':'scripts/lib/skills-check-verification.mjs'}
BIND_PATHS=['scripts/maintain-skills-check-map.mjs',*IMPORTS.values(),'scripts/smoke-skills-check.mjs','packages/cli/src/skills-command.ts','packages/skill-registry/src/watcher.ts','packages/skill-registry/src/manifest.ts','packages/cli/dist/bin.js','packages/core/dist/index.js','packages/skill-registry/dist/index.js']
GOOD="const raw = await readFile(join(output, 'journey', 'journey.json'));"
BAD="const raw = await readFile(join(output, 'journey', 'journey-receipt.json'));"
POLICY={'healthy':(0,'healthy'),'missing-ref':(1,'failed'),'drift':(2,'drift'),'mixed':(1,'failed'),'empty':(0,'empty')}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b):return hashlib.sha256(b).hexdigest()
def dump(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def bindings():return {p:digest((CHECKOUT/p).read_bytes()) for p in BIND_PATHS}
def check_pins(scene):
    saved=json.loads((scene/'preparation.json').read_text());assert bindings()==saved['source_bindings'],'checkout_binding_changed'
    b=(scene/'map.json').read_bytes();assert b==(scene/'map-original.json').read_bytes();assert digest(b)==saved['map_sha256'],'map_changed'
    return saved

def prepare(scene):
    # This phase only copies bytes and runs read-only git identity/status commands.
    scene.mkdir(mode=0o700);(scene/'tool').mkdir(mode=0o700);(scene/'snapshots').mkdir(mode=0o700);(scene/'home').mkdir(mode=0o700);(scene/'records').mkdir(mode=0o700)
    raw=(CHECKOUT/'scripts/maintain-skills-check-map.mjs').read_bytes();clean=raw.decode();mapping=[]
    for old,relative in IMPORTS.items():
        token="from '"+old+"'";replacement="from '"+(CHECKOUT/relative).as_uri()+"'";assert clean.count(token)==1
        clean=clean.replace(token,replacement);mapping.append({'original':old,'resolved':(CHECKOUT/relative).as_uri(),'sha256':digest((CHECKOUT/relative).read_bytes())})
    assert clean.count(GOOD)==1 and BAD not in clean
    bad=clean.replace(GOOD,BAD)
    for name,b in [('upstream.mjs',raw),('clean-bridged.mjs',clean.encode()),('faulty-bridged.mjs',bad.encode())]:(scene/'snapshots'/name).write_bytes(b)
    (scene/'tool/maintain-skills-check-map.mjs').write_text(bad)
    (scene/'snapshots/import-map.patch').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True),clean.splitlines(True),fromfile='upstream.mjs',tofile='clean-bridged.mjs')))
    (scene/'snapshots/fault.patch').write_text(''.join(difflib.unified_diff(clean.splitlines(True),bad.splitlines(True),fromfile='clean-bridged.mjs',tofile='faulty-bridged.mjs')))
    m=(CHECKOUT/'docs/implementation/skills-check-map-maintenance/map.json').read_bytes()
    for name in ['map.json','map-original.json']:(scene/name).write_bytes(m)
    dump(scene/'preparation.json',{'prepared_at':now(),'checkout':str(CHECKOUT),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=CHECKOUT,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=CHECKOUT,text=True),'source_bindings':bindings(),'map_sha256':digest(m),'imports':mapping,'upstream_sha256':digest(raw),'clean_sha256':digest(clean.encode()),'faulty_sha256':digest(bad.encode()),'fault':'deliberately injected retained-receipt pathname error; not spontaneous product regression','driver_sha256':digest(pathlib.Path(__file__).read_bytes()),'product_executed':False})

def verify_attempt(scene,phase,code):
    output=scene/('attempt-01' if phase=='fault' else 'attempt-02');m=json.loads((output/'maintenance.json').read_text());j=json.loads((output/'journey/journey.json').read_text())
    assert m['execution_path']=='runJourney' and m['map']['unchanged'] is True
    active_digest=digest((scene/'tool/maintain-skills-check-map.mjs').read_bytes())
    assert m['tool']['unchanged'] is True and m['tool']['before_sha256']==active_digest and m['tool']['after_sha256']==active_digest,'maintenance_tool_binding_mismatch'
    assert j['status']=='passed' and m['journey']['status']=='passed'
    assert [f['case_id'] for f in j['features']]==list(POLICY)
    members=[];cleanup=[]
    for f in j['features']:
        id=f['case_id'];assert f['verification']=='passed' and f['driver_exit']==0 and (f['product_exit'],f['product_status'])==POLICY[id]
        case=output/'journey/cases'/id;mb=(case/'manifest.json').read_bytes();assert digest(mb)==f['manifest_sha256']
        for row in json.loads(mb)['files']:
            p=case/row['path'];assert p.resolve().is_relative_to(case.resolve());b=p.read_bytes();assert len(b)==row['bytes'] and digest(b)==row['sha256'];members.append(str(p.relative_to(output)))
        c=json.loads((case/'cleanup.json').read_text());assert c['status']=='passed' and c['fixture_removed'] is True
        fixture=pathlib.Path(c['fixture_path']);assert fixture.is_relative_to(output) and not os.path.lexists(fixture)
        cleanup.append(c)
    jm=output/'journey/journey-manifest.json'
    for row in json.loads(jm.read_text())['files']:
        p=jm.parent/row['path'];assert p.resolve().is_relative_to(jm.parent.resolve());b=p.read_bytes();assert len(b)==row['bytes'] and digest(b)==row['sha256'];members.append(str(p.relative_to(output)))
    if phase=='fault':
        assert code==2 and m['status']=='blocked' and m['failure']=='ENOENT' and m['rows']==[]
        assert m['journey']['receipt_sha256'] is None and m['journey']['receipt_matches_returned'] is None
        assert not os.path.lexists(output/'journey/journey-receipt.json')
    else:
        assert code==0 and m['status']=='consistent' and m['failure'] is None and len(m['rows'])==5 and all(r['matches'] for r in m['rows'])
    check_pins(scene)
    return {'phase':phase,'checked_at':now(),'status':'passed','maintenance_status':m['status'],'wrapper_exit':code,'journey_status':j['status'],'features':[{'case_id':f['case_id'],'product_exit':f['product_exit'],'product_status':f['product_status'],'driver_exit':f['driver_exit']} for f in j['features']],'verified_member_count':len(members),'cleanup':cleanup,'map_unchanged':True,'copied_tool_sha256':digest((scene/'tool/maintain-skills-check-map.mjs').read_bytes()),'limits':['Deliberate tool fault, not spontaneous bug.','Product expected negatives remain negatives.','Fixture absence does not attest every descendant.']}

def drive(scene,phase):
    saved=check_pins(scene);rec=scene/'records';label='fault' if phase=='fault' else 'redrive';output=scene/('attempt-01' if phase=='fault' else 'attempt-02')
    assert not output.exists() and not (rec/(label+'.command.json')).exists(),'attempt_already_started'
    expected=saved['faulty_sha256'] if phase=='fault' else saved['clean_sha256'];assert digest((scene/'tool/maintain-skills-check-map.mjs').read_bytes())==expected
    if phase=='redrive':assert json.loads((rec/'repair.json').read_text())['status']=='repaired'
    argv=[NODE,str(scene/'tool/maintain-skills-check-map.mjs'),'--map',str(scene/'map.json'),'--output',str(output)]
    env={'PATH':PATH,'HOME':str(scene/'home'),'OSSTACK_HOME':str(scene/'home/unused-osstack'),'OSSTACK_SCRATCH_ROOT':str(scene),'LANG':'C','LC_ALL':'C'}
    record={'phase':phase,'argv':argv,'cwd':str(CHECKOUT),'environment':env,'started_at':now(),'copied_tool_sha256':expected,'timeout_seconds':180,'exit_code':None,'timed_out':False,'reason':'Explicit root-authorized bounded tool fault/repair experiment; this wrapper launches real full5.','stderr_policy':'Preserve all bytes; empty stderr is not a success predicate.'}
    dump(rec/(label+'.command.json'),record)
    with (rec/(label+'.stdout')).open('wb') as stdout,(rec/(label+'.stderr')).open('wb') as stderr:
        p=subprocess.Popen(argv,cwd=CHECKOUT,env=env,stdout=stdout,stderr=stderr)
        try:code=p.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['timed_out']=True;p.terminate()
            try:code=p.wait(timeout=15)
            except subprocess.TimeoutExpired:p.kill();code=p.wait(timeout=5)
    record.update({'finished_at':now(),'exit_code':code,'stdout_sha256':digest((rec/(label+'.stdout')).read_bytes()),'stderr_sha256':digest((rec/(label+'.stderr')).read_bytes()),'descendant_termination':'not_attested'})
    dump(rec/(label+'.command.json'),record);(rec/(label+'.exit')).write_text(str(code)+'\n')
    assert not record['timed_out'],'timeout_stop_preserve_unknown_cleanup'
    dump(rec/(label+'.verification.json'),verify_attempt(scene,phase,code))

def repair(scene):
    saved=check_pins(scene);rec=scene/'records';assert not (rec/'repair.json').exists()
    assert json.loads((rec/'fault.verification.json').read_text())['status']=='passed'
    active=scene/'tool/maintain-skills-check-map.mjs';before=digest(active.read_bytes());assert before==saved['faulty_sha256']
    clean=(scene/'snapshots/clean-bridged.mjs').read_bytes();assert digest(clean)==saved['clean_sha256']
    active.write_bytes(clean)
    dump(rec/'repair.json',{'status':'repaired','at':now(),'same_entry':str(active),'before_sha256':before,'after_sha256':digest(active.read_bytes()),'map_sha256':saved['map_sha256'],'reason':'Restore the original receipt filename in the owned copied tool. Keep import bridge and every product/map predicate unchanged.'})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['prepare','fault','repair','redrive']);parser.add_argument('--scenario',required=True);args=parser.parse_args();os.umask(0o077)
    scene=pathlib.Path(args.scenario);assert scene.is_absolute() and scene.parent.resolve()==WORKER.resolve(),'scenario_must_be_direct_child_of_owned_worker_root'
    try:
        if args.phase=='prepare':prepare(scene)
        elif args.phase=='repair':repair(scene)
        else:drive(scene,args.phase)
        print(json.dumps({'phase':args.phase,'status':'completed','scenario':str(scene)}))
    except Exception as error:
        failure={'phase':args.phase,'at':now(),'status':'stopped','error':type(error).__name__+': '+str(error),'rule':'Preserve all evidence. No automatic rerun or cleanup expansion.'}
        if (scene/'records').is_dir():dump(scene/'records'/(args.phase+'.failure.json'),failure)
        print(json.dumps(failure),file=sys.stderr);sys.exit(1)
