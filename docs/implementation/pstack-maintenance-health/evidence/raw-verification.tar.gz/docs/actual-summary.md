# Actual bounded tool repair

Two real full-five journeys completed, once per attempt. The first owned wrapper intentionally used an incorrect receipt filename and exited **2 / blocked / ENOENT** after its underlying journey passed. Restoring that one line at the same copied-tool path and using a new output produced **0 / consistent**. Neither map bytes nor product predicates were edited.

Both journeys retained product exits **0/1/2/1/0**, driver exits all 0 and the distinct healthy/failed/drift/failed/empty meanings. Per attempt, 177 case/top-level manifest members were read and hash/size checked; five owned fixtures were absent after passed cleanup. Source/build bindings matched between attempts. Each maintenance receipt's tool-before/tool-after hashes matched the corresponding faulty or repaired copy and tool.unchanged was true.

The fault is a deliberate tool-copy injection, not a spontaneous bug or product regression. Original wrapper, import bridge, faulty/repaired snapshots, patches, commands, timing, stdout/stderr/exits and repair reason are retained in actual-tool-repair/ and actual-phase-logs/. Empty stderr was not a required predicate.

Machine details and exact receipt hashes: actual-summary.json. Health queries remain pending the frozen health API; no real project owner has been inferred. This does not close the separate A45 map/product fault arms, full W19/W18/C0, host/model/Firstmate or all-descendant termination obligations. Product execution is now stopped after the authorized two runs.
