node scripts/method-control-health.mjs --help
health_as_of="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf '%s\n' "$health_as_of" > "$health_root/health-01.as-of"
node scripts/method-control-health.mjs   --config "$health_root/health-config-01.json"   --as-of "$health_as_of"   > "$health_root/health-01.stdout" 2> "$health_root/health-01.stderr"
health_exit=$?
printf '%s\n' "$health_exit" > "$health_root/health-01.exit"
