import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { isAbsolute, join } from 'node:path';
const root = process.argv[2];
if (!root || !isAbsolute(root)) throw Error('absolute owned health_root required');
const paths = ['attempt-01'];
const attempts = await Promise.all(paths.map(async (path, i) => ({
  attempt_id: `attempt-${i + 1}`, kind: 'maintenance', path,
  receipt_sha256: createHash('sha256')
    .update(await readFile(join(root, path, 'maintenance.json'))).digest('hex'),
})));
const config = {
  schema_version: 1, project: 'osstack', max_age_seconds: 86400,
  features: [{
    feature_id: 'maintenance', owner_ref: null,
    source_digest: null, build_digest: null, driver_sha256: null,
    changed_paths: ['scripts/maintain-skills-check-map.mjs'],
    required_feature_ids: [], attempts,
  }],
};
await writeFile(join(root, 'health-config-01.json'),
  JSON.stringify(config, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
