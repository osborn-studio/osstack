# Frozen proposal: owned maintenance-tool receipt-path fault

Status: amended for root tool-self-binding change; execution phases **not executed**. Preparation is now authorized. Product execution remains prohibited until root supplies the frozen health API and an execution window. Baseline checkout: `/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-maintenance-health`, HEAD observed `5569e8fe8bae5129d69689937aff5802de658931`. This is a context-familiar analysis, not fresh cold acceptance.

## Deliberate fault and repair

Use one task-owned copy of `scripts/maintain-skills-check-map.mjs`. Rewrite its three local imports to absolute file URLs for the **same unchanged checkout modules**. This is a no-new-install setup, not a dependency-free/fully isolated checkout: the copied wrapper still uses the checkout's built product and dependencies through the original journey. No symlink, repository clone, package install, source patch or primary modification is needed.

The copy's normal receipt read is uniquely:

```js
const raw = await readFile(join(output, 'journey', 'journey.json'));
```

Deliberately change that one line in the copy to:

```js
const raw = await readFile(join(output, 'journey', 'journey-receipt.json'));
```

The erroneous pathname is a simulated tool defect, **not a spontaneously discovered product bug**. The real `runJourney` runs full5 before that line is reached. Its existing `journey.json` remains valid; the wrapper then attempts an incorrect filename and must report blocked. Repair restores the correct filename exactly. Neither expected map bytes nor product predicates change.

## Execution sequence to authorize later

1. `prepare`: create one previously nonexistent scenario directory under this worker's `docs/`. Save the upstream wrapper, rewritten clean copy, faulty copy, exact import-map and unique-line unified diffs, input map/original, source hashes and baseline Git HEAD. Active `tool/maintain-skills-check-map.mjs` initially contains faulty bytes. This step itself does not execute/import any Node module.
2. `fault`: use the active copied entry with `--map ABS_SCENARIO/map.json --output ABS_SCENARIO/attempt-01`. Expected wrapper exit 2; `maintenance.json.status=blocked`, `failure=ENOENT`, map unchanged, and returned `journey.status=passed`. Real full5 evidence must exist and pass all existing verifier/cleanup assertions. Missing erroneous filename and existing valid receipt, together with the recorded one-line patch, support the **tool-fault** classification. Do not require wrapper stderr to be empty. If any expected condition fails, retain all observations and stop; do not reinterpret it as successful tool-fault proof.
3. `repair`: only after the expected fault is checked, replace the active copy with the saved clean rewritten bytes. Preserve both snapshots, import-map and patch. Same absolute tool path, same map, same original imports, same root Node/PATH/cwd. Record before/after tool hashes and the restoration reason. This is a code repair to an owned tool copy, not a map correction or relaxed check.
4. `redrive`: run the **same active copied entry** with the same map and a new `attempt-02` output. Expected wrapper exit 0, status consistent, execution_path runJourney, unchanged map and five matches. Fresh full5 must again be observed. Do not reuse or modify the earlier attempt; do not compare only wrapper exits.
5. Preserve both full journeys, all raw command files, manifests, cleanup, stdout/stderr, actual argv/cwd/environment/times/exits and copied-tool/source bindings. Verify original map unchanged and imported/underlying checkout file hashes unchanged before/after. Root's generated dist files stay in place through all validation.
6. Once API is frozen, query health separately against these retained records. The first query should expose the latest tool fault and no usable successful maintenance conclusion, despite passed underlying product predicates. The second may expose a repaired latest attempt with fresh five-case evidence while keeping the first failure. Precise query argv, schema and assertions are **pending API freeze**; the health query must not re-drive either attempt or silently create a schedule.

Only **two actual full5** executions are planned. No baseline third drive, old C0 replay, packet projection, model/host task, full suite or Firstmate runtime. A phase refuses an already recorded invocation/output. Any environment, build, evidence or timeout anomaly stops the sequence for reporting rather than spawning another experiment.

## Frozen observations

| Observation | Fault attempt | Repaired attempt |
| --- | --- | --- |
| Wrapper | exit 2, blocked, ENOENT; no rows populated after receipt read failure | exit 0, consistent, five rows match |
| Underlying journey | passed, full five rows, each verification passed/driver 0 | fresh passed, full five rows, each verification passed/driver 0 |
| Product cases | healthy 0/healthy; missing-ref 1/failed; drift 2/drift; mixed 1/failed; empty 0/empty | same expected distinctions, not repaired sources |
| Map | original bytes, unchanged during run | exact same bytes, unchanged during run |
| Copied tool | faulty path hash; real CLI with original runJourney, no injected seams | clean bridged hash restored at same pathname |
| Evidence | actual good receipt exists; wrong name absent; original failure retained | new output directory; prior failure retained |
| Cleanup | five recorded owned fixture paths absent and evidence still readable | same checks for five new fixtures |

`execution_path=runJourney` describes dispatch, **not proof that the wrapper equals upstream source**. The experiment's separate copied-tool hashes/diffs disclose the injected fault and import bridge. The journey's source/build binding does not automatically include this copied outer wrapper. The amended maintenance receipt now separately records tool.before_sha256/tool.after_sha256/tool.unchanged from its own import.meta.url; both attempts must match their respective active copied-tool bytes and remain unchanged during that attempt. Fixture absence/direct-child exit do not prove all descendants terminated; retain `not_attested`.

## Why this is the smallest useful copy

The maintenance wrapper imports only Node builtins plus three relative modules. Resolving those three imports to known file URLs lets one copied wrapper use the existing supported execution environment. Copying `node_modules`, an entire worktree or compiled packages would enlarge the experiment and introduce dependency/link drift. Copying the journey would change its repository-root inference, so this proposal deliberately keeps the original journey module in place.

Risk: the bridge still trusts live checkout module/build bytes; it is not a hostile-writer sandbox. Root must provide a stable execution window, and before/after bindings must match. A mismatch or changed map blocks the experiment. The driver itself creates local file:// fixtures and isolated homes. Wrapper timeout handling can stop only the direct launched process; unknown descendant cleanup remains unknown, never forced clean.

## Ownership, health and acceptance limits

Actual owner must come from the future frozen project configuration. This worker and upstream Lauren Tan/poteto are not implicitly maintenance owners; absent configuration remains unassigned. A deliberately named fixture owner, if needed for schema tests, must be labeled a fixture declaration rather than a real project assignment.

This experiment can establish one bounded tool-fault→actual repair→fresh full5 re-drive and retained evidence path. It alone does not demonstrate the separate map-drift and product-regression arms of A45, arbitrary maintenance lifecycle, scheduled behavior, full W19/W18/C0 or producer authenticity. Existing product negative fixtures are expected failures, **not product regressions**. No schedule is configured or created; health reads should remain side-effect-free. User tutorial command examples wait for the frozen health interface rather than inventing flags.

## Amendment after root tool binding

Root added maintenance tool.before_sha256/after_sha256/unchanged capture plus tool_changed failure. The prepared copy must be regenerated from these current bytes, never the earlier wrapper snapshot. verify_attempt now requires receipt tool hashes to match the actual active copy and unchanged=true. v1 proposal/script/freeze are retained separately; only amended files govern execution. The source field still records baseline HEAD plus dirty working-byte hashes, not a claim that the modification is committed.
