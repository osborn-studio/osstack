import { execFileSync } from "node:child_process";
import { mkdirSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import { connect } from "node:net";
import { join } from "node:path";
import { CodexCliAdapter, type AgentSessionEvent, type AgentSessionInput, type SessionCapableAdapter } from "@osstack/agents";
import * as autonomy from "@osstack/autonomy";
import { createScratchDir, insertRun, insertTask, openDb, SessionRepository } from "@osstack/core";
import { encodeFrame, FrameDecoder, type HermesEvent } from "@osstack/hermes-adapter";
import { afterEach, expect, it, vi } from "vitest";
import { startDaemon, type DaemonHandles } from '/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/terminal-post282/packages/cli/src/daemon.ts';
import { healthyAutonomyHealth } from '/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/terminal-post282/packages/cli/src/test-healthy-autonomy.ts';

class ReceiptAdapter implements SessionCapableAdapter {
  readonly id = "receipt-fixture";
  readonly display_name = "In-process receipt fixture";
  readonly cost_tier = "low" as const;
  readonly resumed: AgentSessionInput[] = [];
  readonly started: string[] = [];
  readonly stopChecks: string[] = [];
  omitTerminal = false;
  afterTerminal: "throw" | "failed" | undefined;
  failStart = false;
  failResume = false;
  failStop = false;
  stopUnconfirmed = false;
  capabilities() { return []; }
  async isAvailable() { return { available: true, status: "available" as const, last_checked_at: Date.now() / 1000 }; }
  async *invoke(): AsyncIterable<HermesEvent> { yield* []; }
  sessionCapabilities() { return { resume: true, snapshot: true }; }
  async *startSession(task: { prompt: string }): AsyncIterable<AgentSessionEvent> {
    this.started.push(task.prompt);
    yield { type: "native_session.started", native_session_id: "private-started-native" };
    if (this.failStart) throw new Error("injected lost start response");
    yield { type: "assistant.message", message_id: "start-reply", text: "Session started" };
    if (!this.omitTerminal) yield { type: "session.terminal", state: "completed" };
    if (this.afterTerminal === "throw") throw new Error("injected post-terminal fault");
    if (this.afterTerminal === "failed") yield { type: "session.terminal", state: "failed", error_code: "late_failure" };
  }
  async confirmStopped(runId: string) {
    this.stopChecks.push(runId);
    if (this.failStop) throw new Error("injected stop verifier failure");
    if (this.stopUnconfirmed) return { stopped: false as const };
    return { stopped: true as const, evidence: "fixture has no external producer" };
  }
  async *resumeSession(input: AgentSessionInput): AsyncIterable<AgentSessionEvent> {
    this.resumed.push(input);
    yield { type: "native_session.started", native_session_id: input.native_session_id };
    if (this.failResume) throw new Error("injected lost execution response");
    yield { type: "assistant.message", message_id: "reply", text: "Instruction complete" };
    if (!this.omitTerminal) yield { type: "session.terminal", state: "completed" };
    if (this.afterTerminal === "throw") throw new Error("injected post-terminal fault");
    if (this.afterTerminal === "failed") yield { type: "session.terminal", state: "failed", error_code: "late_failure" };
  }
}

type Response = { ok: boolean; result?: Record<string, unknown>; error?: { code: string } };
let root: string | undefined;
let socket: string;
let daemon: DaemonHandles | undefined;
let adapter: ReceiptAdapter;
const releaseFixtures: Array<() => Promise<void>> = [];
let admissionBlocked: (() => Promise<void>) | undefined;
let unblockAdmission: (() => void) | undefined;
let cleanupAttempts = 0;
const request = {
  session_id: "session", runtime_id: "receipt-fixture", turn_id: "turn",
  message_id: "instruction", expected_version: 1, text: "Continue the task", requested_by: "owner",
};

function rpc(method: string, params: unknown = {}): Promise<Response> {
  return new Promise((resolve, reject) => {
    const sock = connect(socket);
    const decoder = new FrameDecoder();
    const timer = setTimeout(() => { sock.destroy(); reject(new Error("RPC timeout")); }, 5_000);
    sock.on("connect", () => sock.write(encodeFrame({ id: 1, method, params })));
    sock.on("error", error => { clearTimeout(timer); reject(error); });
    sock.on("data", chunk => {
      const frames = decoder.push(chunk);
      if (frames.length === 0) return;
      clearTimeout(timer); sock.end(); resolve(frames[0] as Response);
    });
  });
}

async function boot(registeredAdapter: SessionCapableAdapter = adapter) {
  daemon = await startDaemon({ socketPath: socket, adapters: [registeredAdapter], autonomyHealth: async () => {
    await admissionBlocked?.();
    return healthyAutonomyHealth();
  } });
}

async function fixture({ failCleanup = true, builtInCodex = false } = {}) {
  root = await createScratchDir("tests", "send-receipt");
  socket = join(root, "d.sock");
  const repo = join(realpathSync(root), "repo");
  mkdirSync(repo);
  execFileSync("git", ["init", "--quiet", repo]);
  vi.stubEnv("OSSTACK_HOME", root);
  vi.stubEnv("OSSTACK_SOCKET", socket);
  vi.stubEnv("OSSTACK_UPDATE_CHECK", "0");
  vi.stubEnv("OSSTACK_DASHBOARD_PORT", "0");
  vi.stubEnv("OSSTACK_ATTENTION", "1");
  vi.stubEnv("OSSTACK_ENGINEERING", "0");
  adapter = new ReceiptAdapter();
  let registeredAdapter: SessionCapableAdapter = adapter;
  if (builtInCodex) {
    const bin = join(root, "codex-fixture");
    writeFileSync(bin, `#!${process.execPath}
if (process.argv.includes("--help")) process.exit(0);
for (const event of [
  {type:"thread.started",thread_id:"private-native"},
  {type:"item.completed",item:{id:"reply",type:"agent_message",text:"Normal completion"}},
  {type:"turn.completed"}
]) console.log(JSON.stringify(event));
`, { mode: 0o700 });
    registeredAdapter = new CodexCliAdapter({ bin, cwd: repo, strictCompletion: true,
      env: { CODEX_HOME: root } });
  }
  cleanupAttempts = 0;
  await boot(registeredAdapter);
  const db = openDb({ path: daemon!.dbPath });
  try {
    insertTask(db, daemon!.dbPath, { task_id: "task", title: "Receipt fixture", created_at: 1 });
    insertRun(db, daemon!.dbPath, { run_id: "run", task_id: "task", session_id: "session", agent_id: registeredAdapter.id,
      capability_id: "code", phase: "execute", started_at: 1 });
    const sessions = new SessionRepository(db, daemon!.dbPath);
    sessions.createSession({ session_id: "session", task_id: "task", run_id: "run", agent_id: registeredAdapter.id,
      request_sha256: "a".repeat(64), native_session_id: "private-native", repo_path: repo, state: "idle",
      resume_supported: true, version: 1, updated_at: 1 });
    sessions.appendTurn({ turn_id: "turn", session_id: "session", ordinal: 1, state: "idle", assistant_text: "Ready",
      decision: null, created_at: 1, updated_at: 1 });
  } finally { db.close(); }
  // Inject cleanup failure only when requested. Admission, SQLite transactions,
  // framing and replay use the real implementations and the real writer lock.
  const acquire = autonomy.acquireRepoWriteLock;
  vi.spyOn(autonomy, "acquireRepoWriteLock").mockImplementation(async (...args) => {
    const lock = await acquire(...args);
    releaseFixtures.push(() => lock.release());
    return { ...lock, release: async () => {
      cleanupAttempts++;
      if (failCleanup) throw new Error("injected physical cleanup failure");
      await lock.release();
    } };
  });
  return registeredAdapter;
}

function persisted() {
  const db = openDb({ path: daemon!.dbPath });
  try {
    const sessions = new SessionRepository(db, daemon!.dbPath);
    return {
      message: sessions.getMessage(request.message_id),
      snapshot: sessions.latestSnapshot(request.session_id),
      turns: (db.prepare("SELECT count(*) AS count FROM session_turns").get() as { count: number }).count,
    };
  } finally { db.close(); }
}

afterEach(async () => {
  unblockAdmission?.(); unblockAdmission = undefined; admissionBlocked = undefined;
  await daemon?.close(); daemon = undefined;
  // Test-owned lock cleanup only. This does not claim a product recovery route.
  for (const release of releaseFixtures.splice(0)) await release();
  vi.restoreAllMocks(); vi.unstubAllEnvs();
  if (root) rmSync(root, { recursive: true, force: true });
  root = undefined;
});


import {SupervisionService} from '/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/terminal-post282/packages/cli/src/supervision-service.ts';

it.each(["start","send"] as const)("terminal-free %s stop timeout preserves fail-closed state despite observer rejection",async route=>{
 await fixture({failCleanup:false}); adapter.omitTerminal=true;
 const stop=vi.spyOn(adapter,"confirmStopped").mockImplementation(()=>new Promise(()=>{}));
 const original=SupervisionService.prototype.requestScan;
 const scan=vi.spyOn(SupervisionService.prototype,"requestScan").mockImplementation(function(reason){
  if(reason===`session.${route}.settled`)return Promise.reject(new Error("injected settled scan failure"));
  return original.call(this,reason);
 });
 const params={request_id:"timeout-terminal",agent_id:adapter.id,repo_path:join(realpathSync(root!),"repo"),title:"Terminal timeout",prompt:"Private timeout prompt"};
 expect(await rpc(`session.${route}`,route==="start"?params:request)).toMatchObject({ok:false,error:{code:"agent_failed"}});
 expect(stop).toHaveBeenCalledTimes(1);expect(cleanupAttempts).toBe(0);
 expect(scan.mock.calls.filter(([reason])=>reason===`session.${route}.settled`)).toHaveLength(1);
 expect(await rpc("health")).toMatchObject({ok:true,result:{active_runs:0,execution_lease_holds:1}});
 if(route==="start"){
  expect(await rpc("session.start",params)).toMatchObject({ok:true,result:{state:"failed"}});
  expect(await rpc("session.start",{...params,request_id:"fresh-after-timeout"})).toMatchObject({ok:false,error:{code:"agent_failed"}});
  expect(adapter.started).toHaveLength(1);
 }else{
  const before=persisted();expect(before.message).toMatchObject({state:"failed",applied_at:null});expect(before.turns).toBe(1);
  expect(await rpc("session.send",request)).toMatchObject({ok:false,error:{code:"delivery_uncertain"}});
  expect(persisted()).toEqual(before);expect(adapter.resumed).toHaveLength(1);
 }
 expect(stop).toHaveBeenCalledTimes(1);
});
