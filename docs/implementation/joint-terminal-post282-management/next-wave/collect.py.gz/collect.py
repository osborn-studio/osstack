from pathlib import Path
import subprocess,json,hashlib,datetime
out=Path(__file__).parent
b='ede5aadced37ac9dc29dd21f0e307ad2c46d2976';prior='28d116f3f8c15f64bebb314308adf320d8380b2b';merge='ce543535be9b1ef96a8c4fb14d13ea8483444051';r='docs/design/2026-10-27-joint-engineering/'
def git(*args):return subprocess.check_output(['git',*args],cwd='/Volumes/AIMATE_WORK/Developer/CodeX/osstack')
def blob(path,sha=b):return git('show',sha+':'+path)
def obj(path):return json.loads(blob(path))
sha=lambda data:hashlib.sha256(data).hexdigest()
base=obj(r+'baseline.json');inputs=[]
for i in base['inputs']:
 if i['repository']!='osstack':continue
 snap=r+i['snapshot'];live=blob(i['path']);archived=blob(snap)
 inputs.append({'path':i['path'],'snapshot':snap,'snapshot_sha256':sha(archived),'main_sha256':sha(live),'byte_equal':live==archived})
files=git('diff','--name-only',merge+'^1',merge).decode().splitlines()
contract_paths=['packages/protocol','packages/core/fixtures/operator-recovery','packages/core/src/state/operator-recovery-spec.test.ts','docs/design/operator-recovery-schema.md']+[r+x for x in ['work-packages.json','execution-gates.json','acceptance-cases.json','unknowns.json']]
g=obj(r+'execution-gates.json');orig={x['id']:x['requires'][:] for x in g['gates']};proposal={k:v[:] for k,v in orig.items()}
changed=['J02.scoped','J03.scoped','J04.scoped','J11.scoped']
for k in changed:proposal[k]=['J01.contracts' if x=='J01.scoped' else x for x in proposal[k]]
proposal['J01.contracts']=[];proposal['J08.admission_boundary']=['J01.contracts'];proposal['J01.scoped']=['J01.contracts','J08.admission_boundary'];proposal['J08.scoped'].append('J01.scoped')
def closure(graph,k,stack=()):
 if k in stack:raise ValueError('cycle '+str(stack+(k,)))
 result=set()
 for dep in graph[k]:result.add(dep);result.update(closure(graph,dep,stack+(k,)))
 return result
for k in proposal:closure(proposal,k)
release=['J27.scoped','J27.default_enable','J27.full_original_completion'];reach={k:{'old_requires_J01_scoped':'J01.scoped' in closure(orig,k),'proposed_requires_J01_scoped':'J01.scoped' in closure(proposal,k)} for k in release}
paths=git('ls-tree','-r','--name-only',b,'--','packages','docs').decode().splitlines()
result={'kind':'read_only_n0_decision_evidence','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_sha':b,'prior_main_sha':prior,'pr271_merge_sha':merge,'pr271_paths':files,'pr271_product_paths':[x for x in files if not(x.startswith('docs/') or x in ['README.md','README.zh.md'])],'firstmate_input_comparison':inputs,'relevant_contract_diff':git('diff','--name-only',prior,b,'--',*contract_paths).decode().splitlines(),'proposed_graph':{'status':'proposal_not_applied_not_gate_evidence','node_count':len(proposal),'acyclic':True,'changed_requires':{k:{'before':orig.get(k),'proposed':proposal[k]} for k in ['J01.contracts','J08.admission_boundary','J01.scoped','J08.scoped',*changed]},'release_reachability':reach},'broker_paths_present':[x for x in paths if ('broker' in x.lower() and any(y in x.lower() for y in ['sql','schema','fixture'])) or 'resource-leases' in x],'runtime_qualification':False,'files_modified_outside_scratch':False}
(out/'n0-machine-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'input_comparisons':len(inputs),'all_equal':all(x['byte_equal'] for x in inputs),'contract_diff':result['relevant_contract_diff'],'pr271_product_paths':result['pr271_product_paths'],'proposed_graph':result['proposed_graph']},ensure_ascii=False,indent=2))
