# N0 决策草案：分开组件开工与真实主机验收

固定基线：`ede5aadced37ac9dc29dd21f0e307ad2c46d2976`（#282 merge）。本次只读 Git 对象；未启动 OSStack/Claude/测试套件，未改冻结规范、产品或中央账本。以下是待主入口裁定和独立审计的设计修订建议，不是已签发 gate。

## 一、O06 可以形成一份精确基线收口记录

实际 #271 merge 为 `ce543535be9b1ef96a8c4fb14d13ea8483444051`。比较该 merge 与第一父提交：43 个变更全部是 README 或 docs，产品接口路径变更为零。冻结 baseline 曾引用其 head `4199d9aadf776042d924a0a307c62aef1a729088`，并没有遗漏一个更新的 Firstmate 设计 head。

进一步对固定 main 逐字节核对了 baseline 引用的8份 Firstmate 输入：capabilities、work-packages、base-work-items、delivery-gates、sources、source-additions、audit-followups、pilot-scenarios。**实际路径与联合设计归档 snapshot 全部相同。** 因而 #271 合并本身没有改变被联合设计消费的接口/原验收语义；不需要把原 Firstmate gate 重映射为一套新定义。

与上轮基线 `28d116f3f8c15f64bebb314308adf320d8380b2b` 相比，protocol 全目录、恢复 fixture/spec/test、work-packages/execution-gates/acceptance-cases/unknowns 均未变化。变化集中于 R02 审计修复及执行文档/证据。当前新 baseline 不会自动认证这些历史证据，但不存在本次比较发现的共享契约漂移。

**建议的 O06 记录内容：** main SHA、#271 merge/head、8项输入摘要、实际产品 diff 为空、当前将派发的切片及其读取/写入接口、主入口判断和失效条件。写在新 checkpoint，不覆写历史 `baseline.json`。O06 为每批 `implementation_start` 核对，不是永久对未来 main 免检；main 或消费接口再次变化即复核。此报告提供事实，尚未把 O06 标 resolved。

机器证据：`n0-machine-evidence.json`；生成程序 `collect.py` 仅执行 git show/diff/ls-tree。

## 二、J01 分层需要设计修订，不能只换账本名称

现状原始约束：

- `work-packages.json` 的 J01 输出是严格协议、identity、codec、digest、recovery/oracle/gate形状。
- `acceptance-cases.json` 的 JA01 是“请求 task local_verified”的真实 Session/task 完成层级隔离；JA02 是真实 admission 对 repo/scope 不匹配拒绝且 executor调用为零；JA59是独立TS/Python规范字节互操作。
- `execution-gates.json` 的 J02/J03/J04/J11 等直接要求 `J01.scoped`。
- `contracts.md` §对应末段明确未通过冻结协议门槛的接线PR不能合入。
- 产品调用检索未发现新 Joint helper 在真实method admission主机入口的消费者，已有 `joint-admission.test.ts` 是结构/helper测试。

把 #273 合并直接称作 `J01.scoped` PASS 会偷换 JA01/JA02；让所有组件一直等待完整 runtime 验收，又会使实现顺序依赖尚未实施的 admission 接线。主入口若希望现在并行交付组件，应先审核一份**明确分层的小型设计PR**。

### 推荐最小 patch（仅建议）

1. 新增拟议 `J01.contracts`：只证明组件身份/版本、strict parse、所有材料 schema、digest域/独立互操作与binding结构约束。消费原 JA59，并新增一个明确 contract-layer case（建议未占用的 JA70）覆盖闭合schema、缺字段/未知字段/错kind和身份投影正负例。JA70 不声称主机授权或完成判定。
2. 保留现 `J01.scoped` 及 JA01、JA02、JA59 原 given/when/then/bad_variant/oracle，不改成纯结构测试。该 gate 仍表示真实集成义务全部满足。
3. 仅将 `J02.scoped`、`J03.scoped`、`J04.scoped`、`J11.scoped` 的直接 `J01.scoped` 前置替换为 `J01.contracts`。J04 的 J02 前置保留。其他消费者保持原边，不一次放宽全图。
4. 从 J08 拆出拟议 `J08.admission_boundary`，依赖 `J01.contracts`：在实际受信host入口运行严格解析、repository/scope/current authorization边界；不发permit、不建run、不启动executor。J01.scoped依赖此边界；JA02仍由独立case执行而非相信该阶段名称。
5. 给 `J08.scoped` 增加 `J01.scoped` 前置，保留原J03/J07/J12/J08.recovery前置。这样真实 trial 不能先于 JA01/JA02 证明执行。**不采用 J01.scoped→J08.scoped 的简化方案**，它会把首次完整trial排在JA02边界证明之前。
6. `J01.legacy_full`、J23/J26及release相关消费边保持；不删除/放宽原legacy gate。修改后的126节点草图已经做纯数据DAG检查，无环；J27.scoped、default_enable、full_original_completion仍传递要求J01.scoped。这是图形建议的检查，不是设计/运行资格PASS。

### patch 涉及的精确文件与校验规则

- `execution-gates.json`：上述两个新节点与精确边；新节点保持 `specified_not_run`。
- `work-packages.json`：J01列组件与host验收两个slice；J08列最小admission-boundary子slice及独占写路径；J02/J03/J04/J11 增加显式 dependency gate override，保留其 work-package J01依赖，不删依赖来绕过验证器。
- `acceptance-cases.json`：只追加JA70；原JA01/JA02的全部语义字段保持byte-for-byte；oracle初始unassigned，不能虚填当前调查为预冻结。
- `validate-design.py` + 邻接测试：现有代码约207行硬要求所有 package deps 直接映射 `.scoped`，必须支持**仅注册/白名单的override**并验证同owner组件生产者；未知override、无组件case、release丢失J01.scoped、J08 trial缺J01.scoped、JA01/JA02语义变更都应失败。
- 注意现 `case_requirements` 专用于 legacy case IDs（约238行检查），不能塞JA59/JA70。新增区分明确的 `joint_case_requirements`，验证所有ID存在、case完整执行和新gate覆盖；原legacy校验不变。runtime GateEvidence消费方将来同样必须区分命名空间。
- 同步 `verification-spec.md`、`work-package-index.md`、`audit-specifications.md` 的分层解释及计数，不修改原Firstmate输入归档。
- integration-owner单独维护这份设计PR和checkpoint；功能worker不修改中央计划。

### J08.admission_boundary 不能成为新的假主机验收

不能仅新增一个返回拒绝的pure helper、fake host或mock-success来过JA02。独立oracle必须从真实受信入口发入有效proposalA/授权B，看到真实adapter spy计数零、明确scope错误，并使用同repo/scope正控制确认不是无条件拒绝。移除repo/scope检查的mutation必须被该case杀死。完整trial接线后来还要证明沿用同一受检入口，不能另开绕行函数。JA01独立读取实际Session/task记录，保留没有checks/review时拒绝local_verified的要求。注册独立作者/实现者/保管人/安全复核人，先冻结oracle再创建验收候选；“多agent”本身不是身份独立性的证明。

## 三、J11 / JA20 的真实 broker DDL 缺口

`acceptance-cases.json#JA20` 明确给定“home目标DDL、旧attention hold、未来broker DDL”，oracle是目标schema fixture与依赖图，**不是运行资格**。目前真实文件只有：

- `packages/core/fixtures/operator-recovery/bootstrap.sql` 与 `source-hold.sql`：home bootstrap 47→候选48与旧attention记录。
- `future-storage.sql`：method binding/object、active、trial消费及engineering goal形状，不包含broker ledger/lease DDL。
- `manifest.json`：home精确tuple与future模板独立摘要；没有broker tuple。
- `operator-recovery-schema.md` 明确local-home ledger拒绝broker subject，broker由J17生产。

固定main的路径枚举未发现broker schema/SQL/fixture或`packages/core/src/state/resource-leases.ts`。机器图定义了生产者 `J17.schema_spec`，它要求J11.scoped；J17工作包已经计划 `JP-17a broker schema spec`、17b recovery、17c storage/routing。**因此仅对124节点作拓扑排序不能满足JA20给定的真实broker DDL输入。** 当前应报告输入未生产，不能把home DDL复制改名当broker实物。

### 下一最小切片：JP-17a 的“规格输入准备”，不是broker运行实现

建议由 controller-owner 负责broker结构、state-owner审核持久层，先交独立候选规格材料：

- 明确存储部署：broker ledger在独立broker DB还是共享control-plane schema。原设计要求broker自己的identity/schema/owner-generation，但当前尚无实际SQL可证明部署选择；不能从逻辑身份推断物理数据库。
- 确定最小lease/held-orphan/recovery-decision及owner-generation持久约束、subject唯一性、不可变历史、同request异input冲突、旧owner不能释放。
- 提供真实可解析broker DDL bytes、最小held-orphan fixture、预期完整catalog、独立身份/错误generation反例；无daemon注册、无迁移执行、无global schema抢号。
- 建议候选新路径 `packages/core/fixtures/broker-recovery/{schema.sql,held-orphan.sql,manifest.json}` 和 `docs/design/broker-recovery-schema.md`；这些路径目前是提案，需在JP-17a实际path manifest声明。
- 在JA20契约调查中只消费这些候选**实物的摘要与生产者关系**，不得消费尚未PASS的J17.schema_spec作为资格证书。文件存在不是J17 gate PASS。
- 只有明确真实部署后，才在state-owner队列针对对应实际base分配精确schema tuple并重新冻结。若初稿仍使用无编号模板，必须标记template-only；JA20的完整精确目标要求未满足，继续not_run/blocked，不拿模板当MigrationSpec。

这样不需要把现 `J11.scoped → J17.schema_spec → J11.scoped` 加成循环：先生产可审查的规格输入，J11验证依赖组织和receipt字段，J17再按其原阶段进行正式spec/recovery资格。`audit-specifications.md` §阶段门槛明确unknown仅阻对应阶段、O03不禁止J11做规格，支持这种“先做候选材料、后签发gate”的顺序。若独立审计认为JA20必须消费一个已资格broker schema而非候选实物，必须另提J11.home_spec分层，不允许静默缩减JA20。

J11本轮最小并行任务是JA47字段删除oracle和JA20输入manifest；J12 file-backed crash/fence预检可准备，但产品迁移merge仍受O03、精确tuple和原J11/J12 gates约束。broker完整恢复仍由J17.recovery/J12.full_recovery承担。

## 四、立即派发的独立写边界

| worker | 可以先完成 | 独占输出/禁止边界 | 主入口接收条件 |
|---|---|---|---|
| N0 integration/contract | O06事实checkpoint草案、上述gate/case/validator修订草案 | 独立设计候选；中央ledger由根写；不改产品 | 独立审计确认JA01/JA02不变、首次trial仍受真实边界证明约束、DAG/release继承不丢 |
| J01 independent verification | JA59与拟议JA70预冻结向量；JA01/JA02实际host观测计划 | 专属oracle/evidence目录，不碰protocol产品实现 | 身份/冻结时间/候选/预期观测完整，组件结果不称主机资格 |
| JP-17a spec owner | broker部署选择、真实DDL/held-orphan fixture候选 | 专属broker规格文件；不改db.ts/migrations.ts/schema.ts，不注册runtime | 与state-owner一致的存储身份及实际字节，明确未分配/已分配tuple状态 |
| J11 independent verification | JA47逐字段删除矩阵、JA20真实输入清单 | 专属验证脚本/证据目录；不同时改home spec | 对缺broker输入明确阻断；未来候选证明与home证明分开 |
| source/driver worker（空槽时） | J02b闭包或JP-03a动作registry离线候选 | source新纯模块或scripts目录，不碰daemon/中央计划/schema | O06当前slice确认；新组件门槛审计后才接线/Ready；不挤占#279终态写者 |

当前4槽意味着主入口加最多3个并行worker。优先用槽完成N0门槛修订、JP-17a真实规格输入和独立oracle；共享schema与中央文档单写。以明确可验收的小产物补当前瓶颈，不把多个等待同一main/gate的PR同时堆进合并队列。
