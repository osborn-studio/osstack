from pathlib import Path
import ast, json, subprocess, hashlib, gzip, re, copy
OUT=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-terminal-post282-20261027')
R=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/terminal-post282')
script=OUT/'refresh-checkpoint.py'; tree=ast.parse(script.read_text())
ns={'Path':Path,'json':json,'subprocess':subprocess,'hashlib':hashlib,'gzip':gzip,'re':re,'R':R,'OUT':OUT/'independent','D':R/'docs/design/2026-10-27-joint-engineering'}
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in ['digest','run','check_archive','materialize_archive','readiness']:
  exec(compile(ast.Module(body=[node],type_ignores=[]),str(script),'exec'),ns)
required=['check','graph-macos-fixtures (22)','graph-macos-fixtures (24)','graph-runtime-matrix (20.6.0)','graph-runtime-matrix (22.23.1)'];ns['required']=required
head=ns['run']('git','rev-parse','3202b790');src=OUT/'independent'/('published-archive-'+head);ns['check_archive'](src)
code='cb76b6432d597d1c057d241f17e652308286b8ee';base='ede5aadced37ac9dc29dd21f0e307ad2c46d2976'
# Execute exactly the owner's verification statements from binding read through reviewed-file hash checks;
# exclude copying, ledger updates, network, socket and Git mutations.
loop=next(n for n in tree.body if isinstance(n,ast.For) and ast.unparse(n.target)=='part')
branch=next(n for n in loop.body if isinstance(n,ast.If) and ast.unparse(n.test)=='n == 282')
statements=branch.orelse
start=next(i for i,n in enumerate(statements) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='binding')
end=next(i for i,n in enumerate(statements) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='dest')
ns.update(src=src,EXPECTED_CODE=code,EXPECTED_MAIN=base)
exec(compile(ast.Module(body=statements[start:end],type_ignores=[]),str(script),'exec'),ns)
assert ns['measured']=={'passed':6293,'skipped':5,'failed':0}
assert ns['run']('git','merge-base',code,head)==code
paths=ns['run']('git','diff','--no-renames','--name-only',code,head).splitlines(); assert all(p.startswith(('docs/','.changeset/')) for p in paths)
p={'statusCheckRollup':[{'__typename':'CheckRun','name':n,'status':'COMPLETED','conclusion':'SUCCESS'} for n in required],'mergeable':'MERGEABLE','mergeStateStatus':'CLEAN'}
assert ns['readiness'](p)['ci']=='passed_at_observation'
checks=[]
for kind in ['missing','duplicate','in_progress','extra_failed']:
 q=copy.deepcopy(p)
 if kind=='missing':q['statusCheckRollup'].pop()
 elif kind=='duplicate':q['statusCheckRollup'].append(copy.deepcopy(q['statusCheckRollup'][0]))
 elif kind=='in_progress':q['statusCheckRollup'][0]['status']='IN_PROGRESS'
 else:q['statusCheckRollup'].append({'__typename':'CheckRun','name':'extra','status':'COMPLETED','conclusion':'FAILURE'})
 assert ns['readiness'](q)['ci']=='pending_or_failed_at_observation';checks.append(kind)
result={'status':'passed','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'published_head':head,'code_sha':code,'base_sha':base,'full_log':ns['full_log'],'measured':ns['measured'],'packages':len(ns['rows']),'commands_bound':len(ns['verification']['commands']),'manifest_members':len(ns['manifest_names']),'reviewed_source_paths':list(ns['binding']['reviewed_files']),'readiness_negative_cases':checks,'archive_path':str(src),'scope':'Exact script validation statements replayed against immutable git archive; no live checkpoint/RPC/GitHub mutation.'}
(OUT/'independent-final-refresh-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
