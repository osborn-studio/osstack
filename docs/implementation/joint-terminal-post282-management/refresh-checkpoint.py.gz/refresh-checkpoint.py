"""One-off owner checkpoint; run only after frozen candidate is pushed to #279."""
from pathlib import Path
import json,subprocess,datetime,hashlib,sys,shutil,importlib.util,gzip,os,stat,re
if not __debug__: raise RuntimeError('Do not disable checkpoint guards')
R=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/terminal-post282')
D=R/'docs/design/2026-10-27-joint-engineering'
OUT=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-terminal-post282-20261027')
EXPECTED_MAIN='ede5aadced37ac9dc29dd21f0e307ad2c46d2976'
EXPECTED_CODE='cb76b6432d597d1c057d241f17e652308286b8ee'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b): return hashlib.sha256(b).hexdigest()
def run(*args): return subprocess.check_output(args,cwd=R,text=True).strip()
def save(p,data): p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def relative(p): return str(p.relative_to(D))
def ref(p): return {'path':relative(p),'sha256':digest(p.read_bytes())}
def diff_proof(code,head,dest):
 assert re.fullmatch('[0-9a-f]{40}',code) and re.fullmatch('[0-9a-f]{40}',head)
 assert run('git','merge-base',code,head)==code,'code is not ancestor of observed head'
 data=subprocess.check_output(['git','diff','--no-renames',code,head],cwd=R)
 paths=run('git','diff','--no-renames','--name-only',code,head).splitlines()
 assert all(p.startswith(('docs/','.changeset/')) for p in paths),'unreviewed product diff'
 dest.write_bytes(data)
 return {'code_sha':code,'head_sha':head,'changed_paths':paths,'diff_path':relative(dest),'diff_sha256':digest(data),'net_diff_empty':not paths}
def check_archive(src):
 manifest=json.loads((src/'archive-manifest.json').read_text());names=[]
 for item in manifest['files']:
  name=item.get('path',item.get('file'));names.append(name)
  target=src/name
  assert not target.is_symlink() and target.resolve().is_relative_to(src.resolve()),'archive path escape'
  data=target.read_bytes();assert digest(data)==item['sha256'],name
  rawhash=item.get('raw_sha256',item.get('original_sha256'))
  if name.endswith('.gz'): assert rawhash and isinstance(item.get('raw_bytes',item.get('original_bytes')),int)
  if rawhash:
   raw=gzip.decompress(data) if name.endswith('.gz') else data
   assert digest(raw)==rawhash and len(raw)==item.get('raw_bytes',item.get('original_bytes')),name
 assert len(set(names))==len(names)
 assert {'audit-code-binding.json','test-summary.json','verification.json'}.issubset(names)
 # README is a separately hash-bound ledger report; manifest cannot hash itself.
 actual={str(x.relative_to(src)) for x in src.rglob('*') if x.is_file()}
 assert actual-set(names)==({'archive-manifest.json'} | ({'README.md'} if 'README.md' not in names else set())),'unbound extra archive files'
 assert all(not x.is_symlink() for x in src.rglob('*'))
 for link in re.findall(r'\]\(([^)]+)\)',(src/'README.md').read_text()):
  if '://' not in link and not link.startswith('#'):
   assert (src/link.split('#')[0]).exists(),'missing relative archive link'
def materialize_archive(head):
 # Read all evidence bytes from the immutable, actually observed published commit.
 prefix='docs/implementation/joint-terminal-post282/'
 src=OUT/('published-archive-'+head);src.mkdir(exist_ok=False)
 paths=run('git','ls-tree','-r','--name-only',head,'--',prefix).splitlines();assert paths
 for path in paths:
  name=path.removeprefix(prefix);target=src/name
  assert target.resolve().is_relative_to(src.resolve())
  mode=run('git','ls-tree',head,'--',path).split()[0];assert mode in ['100644','100755'],'reject symlink'
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(subprocess.check_output(['git','show',head+':'+path],cwd=R))
 return src
subprocess.run(['git','fetch','origin'],cwd=R,check=True)
assert run('git','rev-parse','origin/main')==EXPECTED_MAIN,'main drift; revalidate'
E=D/'evidence/joint-execution/terminal-post282'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');E.mkdir(parents=True,exist_ok=False)
old=(D/'execution-ledger.json').read_bytes();ledger=json.loads(old)
assert ledger.get('checkpoint_proof_version')==2 and isinstance(ledger.get('checkpoint_history'),list)
validator_bytes=(D/'validate-execution.py').read_bytes()
assert validator_bytes==subprocess.check_output(['git','show',EXPECTED_MAIN+':docs/design/2026-10-27-joint-engineering/validate-execution.py'],cwd=R),'validator changed; separate audit required'
history=E/('ledger-before-'+digest(old)+'.json');history.write_bytes(old)
ledger['checkpoint_history'].append(ref(history));previous={'path':relative(history),'sha256':digest(old),'scope':'Immutable historical observation; prior current labels are time-bound.'}
fields='number,url,state,isDraft,headRefName,headRefOid,baseRefName,mergeCommit,mergedAt,reviewDecision,statusCheckRollup,mergeable,mergeStateStatus'
start=now();prs=[]
for n in range(272,283):
 p=json.loads(run('gh','pr','view',str(n),'--json',fields));p['observed_at']=now();prs.append(p)
prmap={p['number']:p for p in prs}
assert prmap[282]['state']=='MERGED' and prmap[282]['mergeCommit']['oid']==EXPECTED_MAIN
assert prmap[282]['headRefOid']=='f81b72eb813533357e5317871dcbc5febe004244'
assert prmap[279]['state']=='OPEN' and prmap[279]['baseRefName']=='main'
ledger.update(main_sha=EXPECTED_MAIN,observed_at=now(),prs=prs,observation_window={'started_at':start,'scope':'Sequential live forge observations; no atomic GitHub/local snapshot claim.'})
required=['check','graph-macos-fixtures (22)','graph-macos-fixtures (24)','graph-runtime-matrix (20.6.0)','graph-runtime-matrix (22.23.1)']
def readiness(p):
 rows=[c for c in p['statusCheckRollup'] if c.get('__typename')=='CheckRun']
 checks={c['name']:c for c in rows}
 passed=(len(checks)==len(rows) and all(checks.get(n,{}).get('conclusion')=='SUCCESS' and checks[n]['status']=='COMPLETED' for n in required)
         and all(c.get('status')=='COMPLETED' and c.get('conclusion') in ['SUCCESS','SKIPPED','NEUTRAL'] for c in rows))
 return {'ci':'passed_at_observation' if passed else 'pending_or_failed_at_observation','approval':'user_owned','mergeable':p['mergeable'],'merge_state':p['mergeStateStatus']}
for part in ledger['handoff']['successor_deliveries']:
 n=part['pr'];p=prmap[n]
 if n not in [279,282]: continue
 part.update(head_sha=p['headRefOid'],previous_delivery={'pr':n,**previous},previous_observation=previous,merge_readiness=readiness(p))
 if n==282:
  part.update(state='merged',merge_sha=p['mergeCommit']['oid'],evidence_status='historical_merged_code')
  part['audit']['status']='historical_merged_code';part['validation']['status']='passed_for_code_sha_historical_merged'
  part['code_head_proof']=diff_proof(part['code_sha'],p['headRefOid'],E/'loader-code-to-merged-head.diff')
  part['base_scope']='Original tested base retained; #282 merge does not rebind historical product tests to its merge commit.'
 else:
  src=materialize_archive(p['headRefOid']);check_archive(src)
  binding=json.loads((src/'audit-code-binding.json').read_text())
  assert binding['model']=='claude-sonnet-5-5' and binding['verdict']=='PASS' and binding['reviewed_base']==EXPECTED_MAIN
  code=binding['code_sha'];assert code==EXPECTED_CODE;assert run('git','merge-base',code,EXPECTED_MAIN)==EXPECTED_MAIN
  summary=json.loads((src/'test-summary.json').read_text());assert summary['code_sha']==code and summary['failed']==0 and summary['passed']>0 and summary['packages']==22
  verification=json.loads((src/'verification.json').read_text());assert verification['code_sha']==code and verification['base_sha']==EXPECTED_MAIN
  assert verification['status']=='passed' and all(c['exit_code']==0 and c['code_sha']==code for c in verification['commands'])
  full_commands=[c for c in verification['commands'] if c['command'] in ['pnpm test',['pnpm','test']] and c.get('code_sha')==code]
  assert len(full_commands)==1,'expected one final full-suite run'
  full_log=full_commands[0]['log'];assert '/' not in full_log and full_log.endswith('.log')
  log=gzip.decompress((src/(full_log+'.gz')).read_bytes()).decode()
  rows=re.findall(r'(packages/\S+) test: +Tests +([^\n]+)',log)
  assert len(rows)==22 and len({r[0] for r in rows})==22
  measured={key:sum(int(m.group(1)) for _,line in rows if (m:=re.search(r'(\d+) '+key,line))) for key in ['passed','skipped','failed']}
  assert measured=={k:summary[k] for k in measured},'raw test counts differ'
  manifest_names={item.get('path',item.get('file')) for item in json.loads((src/'archive-manifest.json').read_text())['files']}
  for command in verification['commands']:
   name=command['log'];assert name in manifest_names or name+'.gz' in manifest_names,'command log not hash-bound by manifest'
  assert full_log+'.gz' in manifest_names,'full run log not hash-bound'
  assert verification['validation_source']==full_log
  for command in verification['commands']:
   data=(src/(command['log']+'.gz')).read_bytes();assert digest(gzip.decompress(data))==command['log_sha256']
  for field in ['raw_report','input','raw_response']:
   name=binding[field];assert name in manifest_names
   raw=gzip.decompress((src/name).read_bytes());assert digest(raw)==binding[field+'_sha256']
  audit_response=json.loads(gzip.decompress((src/binding['raw_response']).read_bytes()))
  assert audit_response.get('is_error') is False and 'claude-sonnet-5-5' in audit_response.get('modelUsage',{})
  report=gzip.decompress((src/binding['raw_report']).read_bytes()).decode()
  assert report==audit_response['result'] and re.search(r'^VERDICT: PASS\s*$',report,re.M)
  for path,sha in binding['reviewed_files'].items():
   assert digest(subprocess.check_output(['git','show',code+':'+path],cwd=R))==sha
  # Copy the complete verified bundle: README links must remain resolvable.
  dest=E/'terminal';shutil.copytree(src,dest);check_archive(dest)
  part.update(state='revalidating' if p['isDraft'] else 'ready',base_sha=EXPECTED_MAIN,code_sha=code,evidence_status='current_for_code_sha')
  part['code_head_proof']=diff_proof(code,p['headRefOid'],E/'terminal-code-to-observed-head.diff')
  part['audit']={'model':'claude-sonnet-5-5','verdict':'PASS','status':'current_for_code_sha'}
  part['validation']={'code_sha':code,**{k:summary[k] for k in ['passed','skipped','failed','packages']},'status':'passed_for_code_sha'}
  for field,name in [('report','README.md'),('audit_binding','audit-code-binding.json'),('archive_manifest','archive-manifest.json')]:
   part['validation'][field]=relative(dest/name);part['validation'][field+'_sha256']=digest((dest/name).read_bytes())
ledger['handoff']['successor_obligations']={str(p['pr']):f"{p['state']} at observed head {p['head_sha']}; see exact scope/test base. Merge does not qualify full runtime." for p in ledger['handoff']['successor_deliveries']}
helper=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/session-debt-20261026/ledger.py');raw=helper.read_bytes()
ns={'__name__':'checkpoint_rpc_helper'};exec(compile(raw,str(helper),'exec'),ns);rpc=ns['rpc']
assert raw==helper.read_bytes()
sock=Path('/tmp/osstack-debt-ledger.sock').lstat();assert stat.S_ISSOCK(sock.st_mode) and sock.st_uid==os.getuid() and not(sock.st_mode & 0o077)
(E/'ledger-rpc-helper.py').write_bytes(raw)
m=ledger['management'];m['rpc_helper']={**ref(E/'ledger-rpc-helper.py'),'socket':'/tmp/osstack-debt-ledger.sock','scope':'Actual helper code and owner-observed socket; home remains deployment metadata.'};m['socket_observation']={'uid':sock.st_uid,'mode':oct(stat.S_IMODE(sock.st_mode)),'observed_at':now()}
boards=['joint-firstmate-pstack','firstmate-upgrade-roadmap','session-pilot-debt']
for b in boards:save(E/(b+'.json'),rpc('kanban.board',{'board':b,'include_archived':True}))
m['board_snapshots']=[ref(E/(b+'.json')) for b in boards];m['snapshot']=relative(E/(boards[0]+'.json'));m['snapshot_sha256']=digest((E/(boards[0]+'.json')).read_bytes())
cards={c['card_id']:c for col in json.loads((E/(boards[0]+'.json')).read_text())['columns'] for c in col['cards']}
for node in ledger['milestones']:
 if 'board_status' in node:
  state=cards[node['card_id']]['status'];assert state!='done' or node['state']=='done','joint board completion differs from milestone acceptance'
  node['board_status']=state
# Four schema-defined receipt names; receipt content distinguishes new vs historical.
m['receipts']=[]
for name in ['subagent-dispatch-receipts.json','terminal-preflight-receipt.json','board-final-receipts.json','automation-receipt.json']:
 receipt=json.loads((OUT/name).read_text());assert receipt['base_sha']==EXPECTED_MAIN
 assert datetime.datetime.fromisoformat(receipt['observed_at'])>=datetime.datetime.fromisoformat(prmap[282]['mergedAt'].replace('Z','+00:00'))
 if name=='board-final-receipts.json':
  allcards={c['card_id']:c for b in boards for col in json.loads((E/(b+'.json')).read_text())['columns'] for c in col['cards']}
  for cid,expected in receipt['expected_statuses'].items():assert allcards[cid]['status']==expected
 shutil.copyfile(OUT/name,E/name);m['receipts'].append(ref(E/name))
m['heartbeat']={**json.loads((OUT/'automation-receipt.json').read_text()),'observation_authority':'Owner-attested update tool receipt and re-read config; no scheduler execution attestation'}
m['evidence_scope']='Current owner-collected post-#282 evidence for the next metadata commit; not asserted present at earlier observed PR heads. Full historical checkpoints are immutable.'
for n in [279,282]:
 p=json.loads(run('gh','pr','view',str(n),'--json','headRefOid,state,isDraft,baseRefName'));assert all(prmap[n][k]==v for k,v in p.items()),'PR changed during observation'
subprocess.run(['git','fetch','origin'],cwd=R,check=True);assert run('git','rev-parse','origin/main')==EXPECTED_MAIN
ledger['observation_window']['finished_at']=now()
vns={'__name__':'checkpoint_validator','__file__':str(D/'validate-execution.py')};exec(compile(validator_bytes,str(D/'validate-execution.py'),'exec'),vns)
result=vns['validate_published'](ledger);assert result['status']=='checkpoint_consistent';print(result)
assert (D/'execution-ledger.json').read_bytes()==old,'central ledger changed during refresh'
assert (D/'validate-execution.py').read_bytes()==validator_bytes,'validator changed during refresh'
temp=D/'execution-ledger.json.next';save(temp,ledger);os.replace(temp,D/'execution-ledger.json')
print('NOT DONE: final staged doc-link audit, 128 checkpoint tests, metadata review, push, exact head/CI recheck still required.')
save(OUT/'checkpoint-result.json',{'path':relative(E),'observed_at':ledger['observed_at'],'main_sha':EXPECTED_MAIN,'pr279_head':prmap[279]['headRefOid']})
