from pathlib import Path
import subprocess,os,json,hashlib,datetime
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-first-use'); s=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-first-use-20261030/root-validation')
e=os.environ.copy(); e['PATH']='/opt/homebrew/opt/node@22/bin:'+e['PATH']; e['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack'
def snapshot(name):
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=w).decode().split('\0'); data={p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in paths if p and (w/p).is_file()}; (s/name).write_text(json.dumps(data,indent=2))
results=[]
for name,args in [('build',['pnpm','build']),('full',['pnpm','test']),('typecheck',['pnpm','typecheck:check']),('lint',['pnpm','lint']),('inventory',['node','scripts/generate-public-exports.mjs','--check'])]:
 if name=='full': snapshot('full-before.json')
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (s/(name+'.log')).open('wb') as out: r=subprocess.run(args,cwd=w,env=e,stdout=out,stderr=subprocess.STDOUT)
 results.append({'name':name,'argv':args,'exit':r.returncode,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()}); (s/'results.json').write_text(json.dumps(results,indent=2)); print(name,r.returncode,flush=True)
 if name=='full': snapshot('full-after.json')
 if r.returncode: break
