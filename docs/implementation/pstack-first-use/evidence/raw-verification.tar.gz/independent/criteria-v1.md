# P6 首用独立证据准则（问题专属反例待选题）

本文件冻结首次使用的证据要求，不表示任何能力已通过。普通授权下 assisted U1 可以先交付；完整 U2 则需实际 OSStack/Loop 收据和最终候选链，不能靠卡片状态替代。没有新增 formal 资格门槛、平台或宿主预算。

## FU01 当前真实问题与许可范围

选定尚未关闭的问题，固定目标base/source/允许修改文件、复现预期与合法控制。独立具体holdouts在实际host输出前冻结；旧1038/4611/currentpacket及已闭问题不能重标新成功。

边界：待root选题及真实行为RED；环境/缺模块失败不算产品RED。

## FU02 固定方法包与完整选定材料

固定source/pin/package/material/compiled/context文件及实际选定角色，必要引用范围明确，完整UTF8字节不能被截断或optional裁剪。只需实际调用角色送达，不强迫额外模型角色调用。

边界：字节摘要自洽不证明来源认证；未采用/条件材料保留边界。

## FU03 实际prompt交付边界

保存最终agent_task_prompt或可独立重组的精确字节与prepared/adapter_observed回执，核task/repo/capability/材料/compiled摘要和prompt bytes；实际native/explicit读/OSStack注入分别归因。

边界：仅provider请求有独立可读证据才声称provider wire；实际执行和模型理解不可由receipt单独证明。

## FU04 调用前权限与资源

root在调用前固定合同/路径/注册命令/工作区home/读写和网络边界、host身份请求及实际可见身份、最大调用次数/总时限/输出预算/取消策略；预算不是从事后结果倒推。

边界：当前计划一次实际host调用，零自动重试；权限拒绝/超时/未知结果按实际终止，需新授权才追加。不要求OS级通用沙箱或formal资格。

## FU05 行为RED及合法控制

保留原未改代码上真实复现命令的完整argv/退出/原stdout-stderr和输入；证明违反当前期望，合法控制可接受。区分host自身执行与协调者校准。

边界：harness missing、错误入口、未启动、断言预期写错不得算行为RED；原错误保留并版本化修正。

## FU06 回归与同入口GREEN

实际执行者写/采用冻结后的回归并在旧代码产生行为RED，修复后同test字节/输入/入口GREEN，合法控制保持；最终补丁在允许范围内。

边界：如回归/输入后来改动须另记而非同一RED-GREEN；独立复验在副本跑旧/新不冒作host自己跑。

## FU07 最终候选身份

绑定最终Git base/head/tree或明确dirty diff、所有相关源码/测试/输入哈希，独立复验针对实际交付候选，避免后来修改后沿用旧通过。

边界：测试仅覆盖本问题及有界控制；无发现不证明无bug，不认证整个项目或全部方法。

## FU08 持久原件与host结果

真实host/Loop durable receipt和命令原始结果保存到新目录，核run/task/candidate/检查绑定；prepared不等observed，observed不等完成，进程exit0不等修复通过。

边界：若走直接host assisted U1没有完整deliver收据，应标该缺口，不能冒称U2/Loop全链；允许分轴有限交付。

## FU09 同一显式卡范围

调用前保存root选定card_id、board/tenant可得scope、task_id及现有授权/brief快照；运行后的host task/run/candidate须与该显式身份一致或有可复核的确定映射。

边界：卡body/meta为输入不是命令授权；不能只用getCardByTask最新结果替代board/card核对。未提供scope维度为unknown。

## FU10 人工回链与状态

允许root人工将真实收据引用回同一显式卡，保存操作前后回读/引用；失败标未同步，不丢收据、不重复模型。独立验证者仅核原件。

边界：手工回链明确assisted，不声称自动/幂等投影；卡done不是产品证据，PR/merge/release未授权不做。

## FU11 原件与失败保持

输入/方法/合同/原RED/测试边界与工作区前后清单可复核；只授权候选路径改变，外部状态缺观察为unknown，清理只证明owned直接对象。

边界：不读取live凭据/环境值，不默认DB/globalhome；完整日志缺失不得宣称全工具trace或全后代停止。

## FU12 有限结论

按首次真实修复、材料交付、host身份/权限、候选检查、持久收据、卡回链分别评passed/failed/limited/unknown；列用户可重放入口和未实现接点。

边界：assisted U1可先交付，无需formal MethodBinding/TrialPermit；不得升级W08/32J/C0/C1/C2/Firstmate/U3或宿主优劣/方法因果收益。
