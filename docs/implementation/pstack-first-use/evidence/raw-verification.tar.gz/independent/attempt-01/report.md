# P6 首次调用独立结果：BLOCKED / 未修复

原冻结保持。本次一个原生 Codex 调用，约 55.59 秒，launcher exit 0；这不是任务通过。

模型先执行规定复现命令，Vitest 在外部 scratch 创建目录时 EPERM，零测试。随后单独 cat/sed 两份相关源码；返回全文与固定 Git 字节一致。没有编辑。宿主随后独立 Node22 检查 exit0、Node26 检查 exit1，artifact target miss；Loop escalated 并因 no-progress 停止。宿主检查不能归为模型 GREEN。

32286 字节 builder 材料完整进入 36134 字节实际记录 argv prompt，与 prepared/adapter_observed 两份持久收据一致；仅 AgentTask/argv 边界，不证明 provider wire、理解或认证模型身份。9133 tracked 文件前后 hash 相同；Loop 展示的四项 dist diff 是原有构建差异，非模型补丁。

卡号及 board/task 显式一致，但 card.task_id 仍 null，最终手工回链读回尚未观察；不能声称自动卡任务关联。未证明完整 OS 副作用边界或所有后代清理。

- **FU01 passed**：Exact current Node26 harness defect retained; coordinator original RED and Node22 legal baseline, not runtime merge bug.
- **FU02 passed**：32,286 selected builder material bytes exactly match final recorded argv data block and disk; compiled artifact hash/size matches both receipts.
- **FU03 limited**：36,134-byte actual recorded argv prompt equals both durable receipt hashes; no provider wire/comprehension/native Skill invocation or resolved model identity proof.
- **FU04 limited**：Freeze precedes one native invocation, 55.59s, no retries; configured workspace-write omitted required external scratch write. No universal OS command/read fence.
- **FU05 failed**：Model original command attempted, but EPERM during setup and zero tests; original Node26 behavior not reproduced by model.
- **FU06 failed**：No edit, no candidate GREEN or same-test repair sequence.
- **FU07 limited**：9,133 tracked before/after hashes exactly equal. No new candidate; pre-existing four fresh knowledge/dist plus prepared untracked methods are root setup, not model changes.
- **FU08 failed**：Prepared/adapter_observed context receipts exist; local verifier false, Node22 exit0/Node26 exit1 and artifact target miss; Loop escalated and no-progress stop.
- **FU09 limited**：Exact task/card/board mapping in input and Loop context; native card.task_id null and receipt tenant default vs caller tenant null do not establish authenticated DB identity.
- **FU10 unknown**：Manual same-card final backlink/readback not supplied at review time; no automatic projection claim.
- **FU11 limited**：Recorded commands are atomic allowed reproduction plus two single source reads; returned source equals fixed Git bytes; tracked unchanged. Full untracked/OS side effects and all descendant cleanup not attested.
- **FU12 passed**：Outcome retained as blocked/incomplete, no qualification, U2, formal gate, causal superiority or Firstmate claim.
