# Node 26 单文件测试兼容性验收补充

2026-10-30T11:07:39.959516+00:00

**N01** Observed defect is test-harness compatibility, not a demonstrated production merge-policy defect. Original Node26 named test fails at options.mode transform; Node22 same named test passes. Preserve exact commands/runtime versions and original failures.

**N02** Same named test after repair must actually execute all original assertions on Node22 and Node26; bounded complete delivery.test.ts must pass on each. No added skip/todo, swallowed exception, mocked transpiler success, assertion removal or conditional bypass. Name-filter deselection of 64 other tests in the original targeted probe is not a new skip regression; whole-file check resolves coverage.

**N03** Unmutated positive control executes real deliverToGitHub with ScenarioRunner and records exactly one intercepted merge. Contradictory duplicate SUCCESS plus CANCELLED current checks reject with current-required-check error and zero merge.

**N04** Exactly one final uniqueness-guard anchor is removed in the in-memory source mutation. That genuinely evaluated mutant must accept the identical contradictory fixture and record exactly one intercepted merge, no push/watch. The expected mutant behavior is acceptance demonstrating the omitted safety check, not rejection. Printed output alone is no proof.

**N05** Independent sensitivity control in an owned copy removes or neutralizes the production final uniqueness guard. Repaired unchanged test must fail its normal-source safety/anchor assertion, rather than a transpilation/import infrastructure error. Never modify the live product tree or invoke real forge commands.

**N06** Final changed tracked path set is only packages/github/src/delivery.test.ts. Production delivery/candidate-evidence, dependency manifest, lockfiles and test policy stay byte-identical. Preserve exact candidate and test hash across Node22/26 verification.

**N07** Task repair may change how the existing source-mutant test transpiles/evaluates source, but must preserve fixture, anchor uniqueness, normal safety refusal, mutant contrast and command assertions. No requirement for a newly invented regression file for this existing broken test.

**N08** Coordinator baseline and later independent controls are distinct from model-issued actions. Actual host method/prompt/receipt/scope evidence remains governed by FU01–12; test repair success alone cannot certify native CLI delivery, reported model identity, formal qualification, or real GitHub merge safety.
