
from pathlib import Path
import datetime,gzip,hashlib,json,os,stat
source=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-first-use-20261030/independent/ci314')
dest=Path.cwd()/'docs/implementation/pstack-method-bridge/ci-final'
scratch=Path(__file__).parent
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not dest.exists(), 'destination exists; refuse overwrite'
sha=lambda b:hashlib.sha256(b).hexdigest()
original={}
for p in sorted(source.iterdir()):
 assert p.is_file() and not p.is_symlink(), 'unexpected source member'
 b=p.read_bytes();original[p.name]={'bytes':len(b),'sha256':sha(b)}
for row in json.loads((source/'manifest.json').read_text()):
 assert original[row['path']]=={'bytes':row['bytes'],'sha256':row['sha256']}
report=json.loads((source/'report.json').read_text())
assert original['full.log']=={'bytes':report['log_bytes'],'sha256':report['log_sha256']}
dest.mkdir()
for p in sorted(source.iterdir()):
 b=p.read_bytes()
 if p.name=='full.log':
  q=dest/'full.log.gz'
  with q.open('xb') as f:
   with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as g:g.write(b)
  restored=gzip.decompress(q.read_bytes())
  assert restored==b
 else:
  q=dest/p.name
  with q.open('xb') as f:f.write(b)
 os.chmod(q,stat.S_IMODE(p.stat().st_mode))
readme='''# PR314 CI 最终证据

[CI run 41043889043](https://github.com/osborn-studio/osstack/actions/runs/41043889043) 对应 PR314 → PR313 的 synthetic 合并检查：metadata head 为 b161223bb3d2a3574a3ce9797ae07cbcd63c3fb3，实际 checkout 为 cb3b7d4c8ef5b3c52c955e54328f99edc6cdacb5。五个适用 job SUCCESS，Paid DeepSeek semantic smoke SKIPPED。check/Test 的 22 唯一包为 7420 passed / 7 skipped / 0 failed；单独 TAP 和矩阵重复执行未混入总数。

PR314 保持 Draft，等待 parent 合入 main 后再对实际 main 核验。本记录不是当前 main 的通过证明，也不是本次 P6 或新增 writableRoots 修复的 CI 结果。

full.log.gz 是完整原始 full.log 的无损 gzip，已逐字节解压比较：原 2,285,637 bytes，SHA256 1ebb49006f27516c9afecef7e9e5d2c1c096f31751400e3865d2681d05d83018。其他输入原件逐字节保留，包括 manifest.json、pending-receipt.json 和三次状态查询，旧 pending 不表示最终状态。

publication-manifest.json 绑定本目录全部 payload 的 size/hash；原 manifest.json 仍按原 full.log 名称记录原输入。读取 full.log.gz 后可按原 hash 校验。report.json/report.md/parse.py 保留独立统计及边界。本次仅本地证据出版，没有重跑 CI、下载或重哈希远端 artifact、运行产品或更新 PR。
'''
(dest/'README.md').write_text(readme)
members=[]
for p in sorted(dest.iterdir()):
 b=p.read_bytes();members.append({'path':p.name,'type':'file','mode':oct(stat.S_IMODE(p.stat().st_mode)),'size':len(b),'sha256':sha(b)})
manifest={'schema_version':1,'excludes':['publication-manifest.json'],'members':members,'lossless_compression':{'source_path':'full.log','stored_path':'full.log.gz','source_bytes':original['full.log']['bytes'],'source_sha256':original['full.log']['sha256'],'roundtrip_bytes_equal':True},'original_input_manifest':'manifest.json'}
(dest/'publication-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checks=[]
for row in members:
 p=dest/row['path'];b=p.read_bytes()
 assert len(b)==row['size'] and sha(b)==row['sha256']
 checks.append({'path':p.name,'matches_manifest':True})
for p in source.iterdir():
 b=p.read_bytes();assert original[p.name]=={'bytes':len(b),'sha256':sha(b)}
receipt={'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(Path.cwd()),'source':str(source),'destination':str(dest),'action':'copy original files; gzip full log with mtime0; verify source manifest, roundtrip, payload hashes and unchanged originals','files':len(members)+1,'payload_checks':checks,'originals_unchanged':True,'publication_manifest_sha256':sha((dest/'publication-manifest.json').read_bytes()),'exit_code':0}
(scratch/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
