# Audit: `CodexCliAdapter` explicit `writableRoots`

**Verdict: PASS_WITH_CONCERNS**

I found no concrete code blocker. This is a static trace only: no test or typecheck output was supplied, and the README says verification is still pending, so nothing below says "tests pass". The real native task stays as recorded: stopped before tests on scratch EPERM, no change, not a success. Nothing in this diff changes that grade.

## Blockers
None. The three argv sites (`invoke`, `startSession`, `resumeSession`) are consistent with each other and with the tests. In `resume`, `--add-dir` sits before the `resume` subcommand. Roots are absolute, so they cannot start with `-`. They are passed as separate argv elements with no shell. The probe path never reads `writableRoots`. Nothing reads `OSSTACK_SCRATCH_ROOT`. The caller's array is copied and frozen.

## Concerns

1. **"Bounded" only means "not `/`".** `normalizeWritableRoots` rejects only `directory === parse(directory).root`.
   - It would accept `$HOME`, `/Users`, `/private`, the repo root, `CODEX_HOME` and `.git`.
   - The internal message "not a bounded directory" and the README's "task-specific" wording describe caller intent, not enforcement.
   - Say so in the JSDoc, or add rejection of `HOME`, `CODEX_HOME` and ancestors of `cwd`.

2. **The grant lasts as long as the adapter instance, not the task.** `this.writableRoots` is applied to every `invoke`, `startSession` and `resumeSession`.
   - A shared or registry-held adapter gives the grant to unrelated tasks.
   - A session started on one instance can be resumed on another with different roots. Nothing ties `native_session_id` to its roots.
   - Require one adapter per task in the docs, or move the roots to a per-call input later.

3. **A stale canonical snapshot is reused on every spawn.** You already accept that there is no concurrent path fence, but the effect is wider than a single construct-to-spawn race.
   - The same string goes to later turns and resumes.
   - If the scratch parent is writable inside the sandbox (workspace or tmp), a first turn could replace the scratch directory with a symlink.
   - A later `--add-dir <snapshot>` would then be resolved by the new Codex process at that moment. I can't tell from the supplied material whether Codex re-canonicalizes it.
   - The exposure depends on parent writability, and I have no evidence it occurs.
   - Optional hardening: before each spawn, re-run `realpathSync` and fail closed if it differs from the snapshot or the path is gone. This narrows the window but does not close it. The README should still say "snapshot, not fence".

4. **Real-CLI acceptance of the argv is unproven.** All new tests use a fake bash binary, so they lock argv order and nothing about Codex behavior.
   - Whether `--add-dir` takes one value per occurrence, so it can't swallow the positional prompt, is unconfirmed.
   - Whether it is accepted before `resume` is unconfirmed.
   - Whether a resumed session honors it, or keeps its persisted policy, is unconfirmed.
   - The permissions-profile rejection that blocked your probes may also apply to the `-s workspace-write --add-dir` path on this CLI version. The original run's acceptance of `-s workspace-write` does not cover `--add-dir`.
   - A help listing shows the flag exists. It does not show these behaviors.

## Untested OS behavior (do not claim)

5. None of these has been observed:
   - Whether the grant makes the Vitest scratch `mkdir` succeed.
   - Seatbelt handling of `/var` → `/private/var`. The adapter passes the realpath, which is the right input, but this is unobserved.
   - Whether Codex carves out `.git` or `.codex` inside added roots.
   - What happens if the directory vanishes before spawn.
   - Case-insensitive or Unicode path aliases on APFS. Dedupe could miss them, which is harmless but unverified.

## Minor correctness and documentation

6. Several small mismatches between the code and its descriptions:
   - The cap of eight applies to raw entries before dedupe. Nine identical entries are rejected, though the README reads as if dedupe came first.
   - The catch collapses EACCES, ELOOP and similar errors into "existing non-root directories", and the error never names the offending entry.
   - JS `realpathSync` runs a lexical `resolve` first, so `link/..` resolves to the parent of the link, not of its target. The "root via normalization" test passes through that lexical collapse, not through kernel semantics.
   - The README says roots are "valid only when" the sandbox is `workspace-write`. The code throws for any other sandbox with nonempty roots and does not ignore them.

## Test strength (optional)

7. The tests cover the main paths but could be sharper:
   - Rejection tests match only `/writableRoots/`, so they can't tell the failure reasons apart. Only the sandbox test is unambiguous, because it uses a valid directory.
   - The "ambient scratch" test is a regression guard only. The code never reads that variable, and in legacy env mode the child still inherits `OSSTACK_SCRATCH_ROOT="/"`.
   - Default `startSession` argv has no exact assertion. `invoke` default and the existing `resume` test do.
   - There is no test of `writableRoots` combined with a replaced `env`.
   - There is no test that a second spawn reuses the same roots.
   - There is no test with a `repo_path` that overlaps a root.
   - `join(root, ".")` is not a distinct spelling after `join` normalizes it. The symlink alias is the real dedupe check.

## Claims and evidence scope

8. What the README supports and what it does not:
   - **Supported by the tests:** the three argv routes, canonical dedupe, caller-array copy, the probe staying untouched, unchanged default argv, and no ambient grant.
   - **Overstated:**
     - "已安装 Codex CLI 接口的显式接线" rests only on help output (see finding 4).
     - "已到模型" is an inference from native turn and tool events, which the README caveats correctly.
     - "代码验证" cannot be cited yet.
   - **Manual coupling:**
     - The advice to set both `writableRoots:[X]` and child `OSSTACK_SCRATCH_ROOT:X` is not validated by the adapter. A mismatch brings EPERM back.
     - The adapter doesn't expose the canonical roots, so the caller can't align them exactly.
   - **Grade consistency:** the README correctly keeps "blocked, no patch, not GREEN, not retried". Any later claim that this code "fixes" the original blocker would be unsupported.

9. **Commit scope.** Four modified `packages/knowledge/dist/*` files and the untracked `pstack-local-methods/` and docs directory are in the worktree. The README says the dist files predate the run. Keep them out of this change, which should contain only `codex-cli.ts`, its test, and the docs.

## Before relying on it
- Keep the change as is.
- Add the wording fixes from findings 1, 2, 3 and 6.
- For the next real run, pre-register a check of real-CLI `--add-dir` parsing and effect (finding 4) before treating any scratch write as authorized.