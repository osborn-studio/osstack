# 固定 pstack 方法的首次实际 Loop 调用：已到模型，测试环境阻塞

本次把 pstack **0.15.36 / c742dd61706fbacc1b95f1a20b7b988cf096ce6c** 的固定材料实际送入已有 OSStack Loop 和 Codex CLI，使用当前真实卡 `joint-firstmate-pstack/card_ebb91eda`。结果是 **blocked before native reproduction**；没有补丁，没有 GREEN，不是 U2 或 `local_verified`。原尝试只执行一次，后续接线修复不改变这个成绩。

## 用户现在距离直接使用还差哪段

材料采用、纯编译、完整材料调用前核验和持久收据已有候选；本次证明 32,286 字节 builder 材料进入 36,134 字节实际调用 prompt，并出现原生 turn 与工具调用。仍缺的是在正确的项目与临时目录权限内完成一个真实修复，然后独立核验最终候选、把收据回到同卡。普通 CLI `deliver` 还默认使用只读 Codex；其适配器缺少用于 V2 最终收据的 reported runtime identity。因此本次明确用现有 `LoopEngine`、`createHostExecutionContext`、`CodexCliAdapter` 的显式 assisted U1 调用，不删除 V2 校验，不声称统一 CLI 的端到端交付已完成。

## 实际任务与失败

目标仅 `packages/github/src/delivery.test.ts`：现有变异测试在 Node 26.5.0 因 `stripTypeScriptTypes` 的 transform 模式报错，同一测试在 Node 22.22.1 通过。root 新基线分别为 1 fail / 1 pass，其余 64 为名称筛选未执行。模型须自己先复现，再最小修复，最后运行双版本整文件检查；不得跳过断言或修改生产安全逻辑。

实际模型执行第一条冻结复现命令时，Vitest setup 在统一 scratch 根创建目录被 macOS sandbox 拒绝（EPERM），**零测试执行**。它随后分别读取 scratch setup 与 scratch API 源码，报告阻塞并停止，没有修改文件。原生 exit 0 / turn.completed 仅表示模型完成回复；Loop 的实际检查得到 Node22 成功、Node26 失败及目标补丁缺失，最终为 `escalated` / no-progress，未误记任务完成。9,133 个 tracked 文件前后摘要一致；运行前已有四份 fresh knowledge/dist，不归模型产物，也不称 clean committed tree。

## 本批只修实际遇到的宿主接点

新增 `CodexCliAdapter` 可选 `writableRoots`，供调用者显式授予任务专用 scratch 目录。仅非空且 sandbox 为 `workspace-write` 时有效；最多八项绝对、现存目录，拒绝根目录、非法路径和文件，canonical 去重并复制调用者数组。invoke、startSession、resumeSession 均通过独立 `--add-dir` 参数传递，resume 的父参数顺序保留。默认 argv 和只读策略不变，availability probe 不带写权限，不从 OSSTACK_SCRATCH_ROOT 或其他环境变量自动扩大授权。

该配置属于已安装 Codex CLI 接口的显式接线；参数传递测试不是 OS 隔离证明。本机 `codex exec --help` 确认支持 `--add-dir`；额外无模型 sandbox 控制因新版命令要求 permissions profile，而配置无该表，在命令执行前拒绝，原件保留。未用这些拒绝宣称目录授权已执行成功，未重跑原模型任务来翻绿。

后续调用应在统一 scratch 根下面创建**本任务专用**根，再同时显式设置 adapter 的 `writableRoots:[taskScratch]` 与子环境 `OSSTACK_SCRATCH_ROOT:taskScratch`。不要授予整个历史归档根；先验证安装版本的权限行为。记录匹配 build、全部输入、权限与预算，再开展下一项真正的新需求。原 Node26 缺陷仍未修，不换名重放本 packet。完成定义仍是实际 RED → 修复 → GREEN → 独立最终候选 → 同卡证据；不能把目录参数修复当成这条链已完成。

## 证据与限制

- 一个 native invocation，600 秒预算，`sources:[]`、单 task、maxIterations=1、`useWorktree:false`；root 自有隔离工作树。避免普通 Loop 的自动 worktree 成功合并路径。
- 两份持久 execution-context 收据，边界为 AgentTask prompt；并非 provider wire、模型理解、原生 slash 发现或模型身份认证。
- 原生工具只运行冻结复现命令与两次单独 source read；提示词命令限制不是 OS 命令围栏。认证/环境继承，未声称独立 principal；全后代终止未认证。
- 看板 native `task_id` 与 `tenant_id` 均为 null；body 显式绑定本 task，使用人工同卡回链，不冒称自动 DB task 外键或自动投影。
- 实际构建入口使用当次已核 hash 的 CLI chunk，尚非稳定 npm 子路径。方法包是项目局部产物；原 helper 把包写到 workspace 外的首次请求拒绝，改为合法项目局部位置后准备成功，不是产品失败。
- 12 项通用准则与 8 项 Node26 准则预冻；新增 writableRoots 独立准则另冻。保持原 FAILED/LIMITED、原24PS/19W/48A与32J正式状态不变。Firstmate 深运行禁止。

代码验证、独立核验、归档摘要与发布状态由同目录后续记录补齐。PR312→313→314→本批按人类合并及 actual-main 重验顺序；不合 feature base，不自动批准、合并或发布。
