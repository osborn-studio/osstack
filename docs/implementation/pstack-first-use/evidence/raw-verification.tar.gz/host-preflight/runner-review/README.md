# U1 runner/config 只读核验

审查发生在root已派发后，不称为响应前预冻。全部7项freeze文件哈希匹配；compiled/task/repository/proposal和三role文件哈希匹配，三检查原始command hash与P4 check registry一致。未发现重试、自动merge、PR或daemon路径。仅实际builder role会被当前Loop调用，不能宣称reviewer/verifier材料也已消费。

单次runOnce、sources[]、一个inputTask、maxIterations1、useWorktreefalse、verifier[]、lessonDraftsfalse保持U1。codex-record的独占invocation-start记录阻止第二次实际user调用，help可用性probe不是模型调用。

必须保留的限制：继承环境/认证；命令与路径约束是prompt非OS fence；targetPaths不拒所有额外文件，最终应核全差异；Loop600秒与wrapper650秒不同且不保证descendant停止。card机器task_id=null，仅body手工映射。未执行模型、产品或测试，没有改文件、进程与原始输入。等root/C对真实候选和原始输出做独立验收。
