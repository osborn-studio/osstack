# Root-selected U1: real builder + deterministic checks, no V2 completion claim

This supersedes the proposed deliver invocation for this experiment only; prior report and manifest remain unchanged. Root selected direct existing LoopEngine + createHostExecutionContext + CodexCliAdapter, with external independent human review. No V2 guard is removed: V2 is not the entry used. No local_verified / formal qualification / identity attestation claim.

## Imports and real types

- `LoopEngine`, `Task` are exports of @osstack/loop (`packages/loop/src/index.ts`, types.ts:28).
- `CodexCliAdapter` is exported by @osstack/agents.
- `createHostExecutionContext` is exported by CLI source `packages/cli/src/execution-context-host.ts:46`. It is NOT a stable package subpath. Current root build produced `packages/cli/dist/execution-context-host-56HZY76J.js` with that named export; root must pin actual chunk and dependencies/build hashes (or use its normal source-loader path). Do not hardcode the chunk as a reusable public installer API.
- `createHostExecutionContext({adapters:[recordedRealCodexAdapter], workspacePath:canonicalTaskRepo,configPath:actualPreparedContext}, explicitHome)` returns adapters + receiptRefs; no contractDigest/brief is needed for U1.
- `Task.parse({task_id:actualCompiledTaskId,capability:'code.write',prompt:actualGoal,priority:50,source:'manual'})`. Plan executor matches kind code.write to capability id `codex-cli.code.write`; methods.roles uses that exact ID and role builder. No reviewer adapter is invoked in this U1, so do not count unused reviewer/verifier materials as delivered. Recipe may retain all three roles; only selected role receipt proves delivery to adapter boundary.

## Minimal options (fill actual paths/goal)

```
new LoopEngine({
  workspacePath: isolatedTaskRepo,
  stateFilePath: absoluteHomeStateJson,
  markdownPath: absoluteHomeStateMarkdown,
  sources: [], inputTasks: [task],
  agentId: 'codex-cli', adapters: context.adapters,
  verifierAgentIds: [],
  useWorktree: false,
  maxIterations: 1,
  commandTimeoutMs: 600000,
  budget: {max_task_iterations:1,max_runtime_ms:600000,no_progress_limit:1},
  lessonDrafts: {enabled:false},
  verifyCommands: [frozenNode22Check, frozenNode26Check],
  artifactVerification: {requireGitDiff:true},
}).runOnce()
```

The repo is already a fresh owned scratch Git checkout. Do NOT casually set `useWorktree:true`: default Loop success creates and merges a commit (loop-engine.ts:1230 onward) unless the separate artifact_only candidate mechanism is supplied. useWorktree:false on the already isolated repo avoids implicit commit/merge and permits retained raw patch. Omit publish, selfImprovement, goalCommand, executeCommand, and all discovery sources. Explicit home/scratch and auth-minimal adapter env remain mandatory. Root runner must preserve actual result/verification details; it must not turn a zero outer process exit into task success without inspecting Loop state.

Adapter constructor: sandbox workspace-write, strictCompletion true, absolute verified binary, explicit env, cwd fallback task repo. Actual AgentTask.context.repo_path comes from executor and overrides cwd. Environment/model/native tool configuration must be recorded separately; adapter has no model or literal-command allowlist option. Atomic check names are deterministic Loop verifier commands; they do not enforce all model tool calls. Budget describes time/iterations, not enforced model dollar limit. Root recording wrapper must forward genuine adapter events, not synthesize review/identity/completion.

## Actual task binding and acceptance

Root reported real historical/current test mismatch: Node26 namedtest1fail/64filteredskip versus Node22 namedtest1pass/64filteredskip. Those root records must be bound before model start; this report did not run them. Target is the actual delivery.test.ts compatibility case, not a fabricated fixture. Root owns allowed exact source/test edits and independent hidden controls. After repair, both Node22 and Node26 entire65-test-file results plus byte/path diff should be retained; allowed_paths is a runner/independent review check here, NOT a V2-admission guard or OS fence. Source tree and compiled method bundle must be independently captured; candidate may not alter helper, original inputs, root environment or central files.

P5 prepared/adapter_observed hashes demonstrate that the full selected method text reached AgentTask.prompt before genuine invoke. They do not attest provider transmission, model understanding or autonomous reviewer behavior. External independent review does not become a fabricated Loop ReviewArtifact. If material loading, model invocation, code change, either Node check or scope fails, preserve the exact axis/result and stop; no retry or budget expansion follows from this draft.
