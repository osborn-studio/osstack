# P6 guarded-local → Loop → Codex 首用静态预检

固定Git：28ece8fc7da5b1e737c75f7c4dbb74281af32da4。只读源码；没有产品/模型调用、可用性probe、配置安装、daemon、DB或测试执行。JSON草案类型来自真实schema，尚未运行schema验证，零hash及大写路径是必须替换的占位值，不是合格输入。

## 最短可行范围与当前硬阻断

可以准备 **assisted U1**：调用公开 handleDeliverCommand(args, {...createDeliverCommandDeps(), adapters: ...})，注入真实 CodexCliAdapter({sandbox:'workspace-write',strictCompletion:true,env:显式私有环境}) 与真实独立reviewer。保留所有现有policy/role/source/worktree/verification fences。不修改默认CLI，也不能称“原生CLI已支持本次写权限”。普通deliver没有adapters override时走defaultAdapters，Codex默认read-only（deliver-command.ts:373–378；agents/index.ts:79–94；codex-cli.ts:270–277）。

**完整V2 local_verified目前不能诚实闭环**：CodexCliAdapter没有runtimeIdentity()；配置agent_runtime最多产生configured，缺配置则inferred。profile路由只要求adapter层独立，所以可能实际执行后才在最终receipt构造被reported身份要求阻断。delivery-contract-host.ts:72–80同时要求builder/reviewer reported且不同adapter以及不同provider或model；不能通过自写返回reported或伪造review来过关。Kimi能从真实provider探测获得reported，但本轮没测可用性，不能假定有认证/模型。root应在耗费模型预算前决定：仅批准U1真实builder/检查与诚实blocked，或另做被批准的真实identity观测接线。不能删guard将它包装成成功。

## 配置与调用草案

1. 自有小Git任务仓库，固定实际base HEAD，freeze待修源文件与tests/repair.test.mjs两条allowed_paths；不得用大仓库/含秘密checkout。将repo-policy.draft.json与policy.draft.json按对应JSON内容写为 .osstack/repo.yaml/.osstack/policy.yaml（JSON是YAML子集），纳入任务base后才冻结base。标准命令唯一为 `node --test tests/repair.test.mjs`，10s命令timeout。repo verification standard注册的字符串哈希用 deliveryCheckReference()；它不是P4 logical CheckRegistry的同一个hash体系，不得直接复制P4引用。
2. OSSTACK_HOME/OSSTACK_CONFIG/OSSTACK_SCRATCH_ROOT与HOME/CODEX_HOME均指向显式独占路径；只复制获准的最小认证方式，不复制整份全局配置/不写默认home。空独占OSStack home没有source-context.json，因此source observer opt-in为空；packs:[]。不要启动serve。
3. profile.draft.json保留codex-cli coding / kimi-code test-verify、fallback为空；两实际可用adapter缺一即保持blocked。profile选择不是模型选择；agent_runtime身份配置不控制真实CLI模型，也不会成为reported。
4. 用 createDeliverCommandDeps().deliveryContractPolicy(realpath(repo)) 的**真实只读结果**填policy_digest/budget_ref，不能手工猜hash：bin.ts:9570–9667会读取base Git中的repo/policy、私有overlay，并哈希effective repo+policy+private_policy_id+protected_policy_paths。allowed标准checks/review_policy_ref/profile/task/goal/base全部对应。请求仅build+verify、local_verified、publication none、merge_authority none。
5. P4编译产物/prepare方法配置真实绑定同canonical_repo/task/check事实；methods.compiled引用准确bytes。方法capability builder=`codex-cli.code.write`；Kimi reviewer=`kimi-code.code.review`。role标签不是权限；单个evaluator不会自动产生第三verifier调用。若实际选其他adapter必须用它真实capability ID，不能占位照跑。
6. run-outline.json给实际参数形状。用 `handleDeliverCommand`公开依赖注入而非--execute（V2明确拒--execute）。真实Loop内部 `sources:[]` + 唯一 `inputTasks`，禁task_queue；强制isolated worktree、角色分离、requireGitDiff、1 iteration/1 review、5分钟wall、no-progress1。不直接重写Loop绕过admission。

## Read / 命令 / 路径权限事实

Codex adapter真实spawn argv为 `exec --json --skip-git-repo-check -s <sandbox> -C <task.context.repo_path> <prompt>`（codex-cli.ts:526–538），调用者env替换可隔离认证配置。它有读源码、代码写入和code.test能力广告；实际工具/命令权限来自已验证Codex运行环境，adapter本身没有Read路径allowlist、literal command allowlist、-m/model或token/cost上限参数。workspace-write不是只允许两文件、只允许这条test。命令前缀与prompt约定不能称OS fence；模型自行复合shell也不会被OSStack这里逐条解析阻止。

原子host检查是另一路：repo verification.standard精确字符串→冻结contract registry_ref→Loop verifier执行→commandAudit/exit确认。若任务必须保证模型只能执行逐条某literal，当前adapter本身不满足；需采用已验证native权限配置/隔离边界，或停在explicit blocked，不能把后验路径校验冒称preventive filesystem限制。allowed_paths在staged候选检查，source fence与review-boundary检测变更；不预防所有副作用。模型wall终止也非所有descendants已停证明。

不要直接使用createImprovementExecutionAdapters(options)套到本Loop：它只支持codex/kimi且boundAdapter固定repo_path，Loop生成subworktree会不同（improvement-execution-adapters.ts:18–24/61–77）。本次直接真实adapter读取Loop提供candidate cwd；仍保留独占sandbox限制。此建议不隐式授权任意shell/网络。

## 真实收据链与验收范围

准备：未授权/缺政策/错base/不匹配check/profile/task、缺材料/compiled漂移/超预算都应invoke0；当前74/76定向历史只作接线支持，不冒认这次真实host通过。首次task以已冻结真实小bug+RED同路径测试为题，合法控制由独立者另持，不能向模型给补丁答案。

执行：记录真实adapter JSONL、实际task/capability/candidate cwd、P5 prepared与adapter_observed收据（明确仅AgentTask prompt非provider wire/理解证明）、原始RED→编辑→GREEN、每命令exit/预算/停止情况。Loop verifier独立再跑唯一registered check与真实reviewer，review outcome保持真实，不覆写失败。成功后verificationFence校验同候选状态，strict治理、stageGuardedCandidate、allowed_paths、captureDeliveryCandidate(tree/diff/base)、persist/readverify receipt、source fence再次检查，才可写local_verified。当前Codex reported身份缺口应使最终receipt失败，不能用外部测试green代签。

建议最小验证矩阵（未执行）：合法同task/compiled进入真实builder；材料/compiled漂移invoke0；错误capability/task invoke0；writer改非allowed路径不签；真实test失败不签；reviewer不可用/变化/不approved不签；identity仅configured不签；源checkout必须未变，candidate与独占state保留。任务若只达builder候选，要按轴说明真实修复/检查结果与最终delivery未签，而非总PASS。

## 后续需要root明确落实的具体项

冻结真实小bug、base/paths/测试与caller授权边界；私有认证与Codex实际模型/权限配置；真实reviewer可用性及工具范围；P4 logical检查和host command registry的显式对应；身份观测缺口的处理范围。没有新scheduler、MethodBinding资格、Firstmate、watcher、merge或自动publication需求。
