Explicit Codex writable roots repair

Commit bcb596cd18dc64e0a6d308ea411a93226ea826af

Only codex-cli.ts and its test changed. 19 original failures retained, then a partial implementation missed invoke (1 failure retained). Final focused 36/36 passed; target agents typecheck passed after test fixture inference annotations. All commands, stdout/stderr, times and original/final bytes are retained.

Optional writableRoots is copied, canonicalized and deduplicated at construction; max eight input entries, only nonempty with workspace-write. Existing absolute non-root directories required; invalid input rejects. Parent --add-dir pairs reach invoke/start/resume. Default args unchanged and no roots from env. Availability probe has no added write flags. Tests run fake CLI subprocesses only, not actual models or sandbox enforcement. No full, original failed P6 retry, product target repair, DB, publication or central edits.

Root separately reports real codex-cli 0.160.1 exec --help advertises --add-dir, while its independent codex sandbox controls were rejected before command execution because the new permissions profile configuration was absent. Those controls did not demonstrate macOS directory authorization. Actual OS write enforcement remains unknown; this author did not run those commands or a native task.
