# writableRoots 有限静态复核

结论：未发现确认的产品缺陷。本报告只静态读取 bcb596cd 的两文件和当前 README，没有运行模型、测试、构建或旧首用重试。

- 默认仍 read-only，未配置或空 roots 不增加参数；环境 scratch 路径不隐式变成 writableRoots。
- 构造时限制原输入最多八项，解析真实路径、拒绝根目录/非目录、去重复制；调用者之后修改原数组不改变已保存目录。
- invoke、startSession、resumeSession 均独立传参；resume 的 sandbox/cwd/add-dir 在子命令前。可用性探针不带写目录参数。
- README 明确首用在 Vitest scratch setup EPERM 后阻塞，未产生修复/GREEN；模型退出 0 不代表 Loop 完成。参数测试也没有被表述为 OS 隔离验证成功。

两项非阻断措辞建议：将“显式授予”改为“向宿主显式请求加入可写目录”；明确目录存在性与 canonical 路径是构造时快照，调用前不重验，也不提供路径替换 fencing。后者是当前边界的说明，不要求本切片新增安全体系。

精确源码、测试、文档、实际 run/result.json 哈希见 report.json。独立 C 的 27 项 fake-binary 结果由其单独报告，本报告未重复执行或扩大其证明范围。
