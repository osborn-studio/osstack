import { stripTypeScriptTypes } from 'node:module';
const mode = process.argv[2];
try { const output = stripTypeScriptTypes('const n: number = 1;', { mode }); console.log(JSON.stringify({version:process.version,execPath:process.execPath,mode,output})); }
catch(error) { console.error(JSON.stringify({version:process.version,execPath:process.execPath,mode,name:error.name,code:error.code,message:error.message})); process.exitCode=1; }
