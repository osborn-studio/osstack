# Node runtime compatibility diagnosis

Candidate 2389dcd9 and base dd63b1c5 have byte-identical packages/github/src/delivery.test.ts and delivery.ts. The current worktree matches candidate bytes. The failing test at line1087 invokes node:module stripTypeScriptTypes with mode transform.

The same minimal typed const input succeeds with mode transform on Node22.22.1. Node26.5.0 rejects that option (ERR_INVALID_ARG_VALUE, allowed only strip); strip succeeds in both runtimes. Thus the observed full-run stop is a preexisting test API compatibility gap exposed by the Node26 invocation, not a changed adoption implementation. Full-run original result is copied as evidence, not rerun.

No source change, full suite, product drive or model call. This establishes only the stated API difference and unchanged source. It does not prove complete Node22 suite success or general product support on either version. A future repair would need separately scoped regression validation; no host task has been dispatched.
