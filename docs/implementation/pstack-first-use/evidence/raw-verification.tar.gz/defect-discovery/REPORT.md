# P6 bounded defect discovery

Baseline: 28ece8fc7da5b1e737c75f7c4dbb74281af32da4. Context-aware read-only diagnosis, not a fresh execution or completed repair. Root is sole execution owner. This discovery only writes its new scratch directory.

## Decision and boundary

This is a genuine still-present developer validation harness compatibility defect, suitable for the agreed first-use task. It is not a demonstrated production delivery/merge defect. The unsupported runtime option is invoked by OSStack's test harness and prevents its existing safety mutation oracle from completing. Both root and GitHub package manifests declare Node >=20 with no upper bound excluding 26. Main CI uses 22; graph matrices use 20/22/24. Those facts do not certify all development tests on 26, and this bounded repair must not claim to do so.

The historical adoption report explicitly left this gap for a future real task. Requested Git delivery.test.ts and delivery.ts are byte-identical to the old failing candidate 2389dcd9 and the new actual pstack-first-use worktree. The scoped intervening Git history has no changes. This is not a known closed issue. Root must still record fresh current RED before any repair.

Static inspection also found CLI guarded-git-runtime.test.ts:670 uses the same option. It remains an unexecuted related risk and separate obligation; do not expand the single-file task.

## Preserved observations

Historical full stdout: delivery.test.ts had 65 tests, 64 pass and 1 fail; the package had 224 tests, 223 pass and 1 fail. It is not the earlier 107-test count. The failed test is:

source mutant omitting unique final current checks permits stale green plus cancelled merge only after full positive baseline

Line1087 calls stripTypeScriptTypes in transform mode. Old Node26.5.0 stderr is ERR_INVALID_ARG_VALUE: options.mode must be strip, received transform. Old four-way typed-const probes record Node26 transform exit1 / strip exit0, Node22.22.1 both modes exit0. These old small probes do not show what implementation will work for complete delivery source.

Complete old diagnosis files, their source blobs, probe script and stdout/stderr are copied unchanged under historical/runtime-diagnosis. Historical full stdout/stderr and later Node22-native full logs are also retained. Old full-result-original.json binds candidate2389, start/end, exit1 and unchanged tracked bytes. No old success is rebound to this new candidate.

## Minimal task and behavioral acceptance

Own only packages/github/src/delivery.test.ts. Read adjacent delivery.ts and candidate-evidence.ts without changing production policy. ScenarioRunner rejects unexpected commands, and all three paths use this fake runner. No GitHub write is needed or authorized.

Preserve all existing oracles: valid current evidence completes one fake merge; original delivery rejects contradictory SUCCESS+CANCELLED checks before merge; intentionally mutated source missing the final uniqueness check completes exactly one fake merge with no push/watch. Desired outcome is full assertion execution on both runtimes, not merely avoiding an exception. No skip, swallowed error, disabled mutation, or weakening assertions. No patch or implementation choice is supplied by this discovery.

## Exact later execution

proposed-commands.json contains full argv/cwd/env for the named test and Node22 legal control; neither was executed here. Cwd is the prepared actual pstack-first-use checkout. Node26 PATH begins /opt/homebrew/Cellar/node/26.5.0/bin; Node22 PATH begins /opt/homebrew/opt/node@22/bin. Filesystem inspection confirms these binary paths exist and records their resolved targets. It does not replace an actual process.version/execPath record; root should capture those immediately before running.

The named command in each environment is:

```sh
pnpm --filter @osstack/github exec vitest run src/delivery.test.ts -t 'source mutant omitting unique final current checks permits stale green plus cancelled merge only after full positive baseline'
```

Expected before repair on Node26: nonzero with the recorded mode error. After repair: same entry exit0 and all mutation assertions reached. Node22 same named test is the legal runtime control. Bounded regression removes only the -t selection and runs the complete delivery.test.ts file under each runtime. No full suite is needed for the proposed task. Existing dependencies must already be prepared; unavailable runtime/dependencies are separate environment blockers, not substitute results.

Both command declarations explicitly set OSSTACK_SCRATCH_ROOT to the new execution directory and OSSTACK_HOME to its unused-home child. No DB is opened by this test. Existing setup owns a temporary short /tmp symlink pointing to its scratch worker and cleans it.

## Evidence and limits

source-bindings.json records Git blobs/SHA256/current-file equality and equality to original failed bytes. commands.json captures Git-read argv/cwd/times/exit/stdout/stderr. task-candidate.json is a symptom/acceptance brief, not an implementation answer. manifest.json binds all artifacts except itself. No test, Node API probe, product drive, model, DB, worktree creation, patch, card or full ran in this discovery. Fresh RED and controls belong to root's actual execution records.
