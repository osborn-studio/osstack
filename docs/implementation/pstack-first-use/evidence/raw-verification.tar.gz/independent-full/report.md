# 全仓日志与源绑定独立核验

`1438f3c5ec6775befe4be22d6074ca204b27ae8a`，pnpm test exit0，独立22唯一包：7448 passed / 5 skipped / 0 failed。

9134 tracked 路径集合相同；9份docs在执行期间变更，因此不能声称全字节不变。packages/scripts保持稳定；4份初始dirty knowledge/dist保持同字节，与保存fresh副本一致。adapter两源与bcb候选完全一致。

保留首次错误命令 generate-public-exports.mjs 的 MODULE_NOT_FOUND/exit1；正确 generate-inventory.mjs --check exit0。这是文件名调用错误，不是产品清单断言失败。

未重跑产品、模型或full。
