from pathlib import Path
import json,re,hashlib,subprocess,datetime
r=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-first-use-20261030');src=r/'root-validation';out=r/'independent-full';h=lambda b:hashlib.sha256(b).hexdigest();raw=(src/'full.log').read_bytes();s=re.sub(r'(?:\x1b|\^\[)\[[0-?]*[ -/]*[@-~]','',raw.decode());packages={}
for i,l in enumerate(s.splitlines(),1):
 m=re.search(r'packages/([^ ]+) test:\s+Tests\s+(.*)',l)
 if not m:continue
 assert m[1]not in packages
 vals={k:int(n)for n,k in re.findall(r'(\d+) (passed|skipped|failed)',m[2])};packages[m[1]]={k:vals.get(k,0)for k in ['passed','skipped','failed']};packages[m[1]]['line']=i
assert len(packages)==22
before=json.loads((src/'full-before.json').read_text());after=json.loads((src/'full-after.json').read_text());assert set(before)==set(after)
changes=[{'path':p,'before':before[p],'after':after[p]}for p in sorted(before)if before[p]!=after[p]]
assert len(changes)==9 and all(v['path'].startswith('docs/')for v in changes)
commands=json.loads((src/'results.json').read_text());full=next(v for v in commands if v['name']=='full');assert full['exit']==0;head=full['head'];wt='/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-first-use';dist=[]
for name in ['index.d.ts','index.d.ts.map','index.js','index.js.map']:
 p='packages/knowledge/dist/'+name;b=subprocess.check_output(['git','show',head+':'+p],cwd=wt);saved=(r/'fresh-dist'/p).read_bytes();dist.append({'path':p,'git_sha256':h(b),'before':before[p],'after':after[p],'saved_fresh_sha256':h(saved),'initial_dirty':h(b)!=before[p],'stable_during_full':before[p]==after[p]})
 assert h(saved)==before[p] and before[p]==after[p] and h(b)!=before[p]
code=[]
for p in ['packages/agents/src/adapters/codex-cli.ts','packages/agents/src/adapters/codex-cli.test.ts']:
 b=subprocess.check_output(['git','show',head+':'+p],cwd=wt);a=subprocess.check_output(['git','show','bcb596cd18dc64e0a6d308ea411a93226ea826af:'+p],cwd=wt);assert b==a and h(b)==before[p]==after[p];code.append({'path':p,'sha256':h(b),'same_as_bcb':True})
wrong=next(v for v in commands if v['name']=='inventory');correct=next(v for v in json.loads((src/'additional-results.json').read_text())if v['name']=='inventory-correct-command');badlog=(src/'inventory.log').read_text();assert wrong['exit']==1 and 'MODULE_NOT_FOUND'in badlog and 'generate-public-exports.mjs'in badlog and correct['exit']==0
x={'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binding':head,'full_command':full,'packages':packages,'total':{k:sum(v[k]for v in packages.values())for k in ['passed','skipped','failed']},'tracked_count':len(before),'tracked_path_set_equal':True,'changed_during_full':changes,'all_tracked_bytes_unchanged':False,'product_and_scripts_unchanged':not any(v['path'].startswith(('packages/','scripts/'))for v in changes),'initial_dirty_knowledge_dist':dist,'candidate_source_binding':code,'inventory_harness_error':{'original':wrong,'actual_error':'MODULE_NOT_FOUND for nonexistent scripts/generate-public-exports.mjs','corrected':correct,'classification':'wrong command filename, not product inventory failure'},'limits':['Full run is exact code+changeset 1438f3c5 plus retained fresh dist; documentation changed during run. Do not claim clean tree or all bytes unchanged.','No independent full/product/model run. Only existing raw logs, receipts and Git objects inspected.','The original P6 blocked model outcome is not changed by these product validation results.']};(out/'report.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');(out/'report.md').write_text('# 全仓日志与源绑定独立核验\n\n`%s`，pnpm test exit0，独立22唯一包：%s passed / %s skipped / %s failed。\n\n9134 tracked 路径集合相同；9份docs在执行期间变更，因此不能声称全字节不变。packages/scripts保持稳定；4份初始dirty knowledge/dist保持同字节，与保存fresh副本一致。adapter两源与bcb候选完全一致。\n\n保留首次错误命令 generate-public-exports.mjs 的 MODULE_NOT_FOUND/exit1；正确 generate-inventory.mjs --check exit0。这是文件名调用错误，不是产品清单断言失败。\n\n未重跑产品、模型或full。\n'%(head,x['total']['passed'],x['total']['skipped'],x['total']['failed']))
inputs=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for p in sorted(src.iterdir())if p.is_file()];(out/'input-hashes.json').write_text(json.dumps(inputs,indent=2)+'\n');print(json.dumps({'total':x['total'],'changes':[v['path']for v in changes],'log_sha256':h(raw)}))
