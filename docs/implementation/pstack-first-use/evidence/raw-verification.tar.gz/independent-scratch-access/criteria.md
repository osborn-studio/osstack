# Explicit writableRoots 独立冻结

2026-10-30T11:11:31.536387+00:00

**WA01** Omitted writableRoots and empty [] preserve byte-for-byte legacy argv for invoke/openSession/resumeSession.

**WA02** Accept explicitly supplied 1 and 8 absolute existing directories with workspace-write. No automatic directory creation.

**WA03** Reject 9 entries before spawning; bound declared count rather than allowing dedup to evade cap.

**WA04** Reject nonempty roots with omitted/read-only/danger-full-access sandbox; empty list remains legacy-compatible.

**WA05** Reject filesystem root / and any canonical alias resolving to /.

**WA06** Reject relative, empty, NUL-containing paths and non-string elements/non-array input.

**WA07** Reject nonexistent path and regular file; reject dangling symlink. Canonical directory symlink alias may resolve to permitted existing directory.

**WA08** Canonicalize and deduplicate aliases/repeats preserving first occurrence order. Do not retain mutable caller array or use later array mutations.

**WA09** invoke passes one literal --add-dir/value pair per canonical root in exec parent flags before the task prompt; spaced/punctuation path stays a single argv value, never shell source.

**WA10** openSession passes the same canonical root pairs as parent exec flags before prompt.

**WA11** resumeSession passes canonical root pairs before resume subcommand, session ID and prompt.

**WA12** Availability/session preflight remains query/help only and receives no --add-dir/write-capability flags.

**WA13** Explicit child env is copied and preserved, not merged with unrelated ambient env. Omitted env remains historical inheritance. Never derive writable roots implicitly from env or scratch paths.

**WA14** Invalid configuration yields no subprocess. No model invocation in independent probe; fake binary captures actual argv/environment and emits minimal native protocol.

**WA15** Evidence distinguishes CLI configuration/argv propagation from actual OS sandbox effect. Root separately owns no-model sandbox control; this does not authorize host retry or change original blocked outcome.
