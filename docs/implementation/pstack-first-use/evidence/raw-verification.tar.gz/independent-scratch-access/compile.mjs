import ts from '/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-first-use/node_modules/typescript/lib/typescript.js';
import {execFileSync} from 'node:child_process';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const root='/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-first-use-20261030/independent-scratch-access';
const wt='/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-first-use';
const hash=b=>createHash('sha256').update(b).digest('hex');const records=[];
for(const [name,ref]of [['old','28ece8fc7da5b1e737c75f7c4dbb74281af32da4'],['new','bcb596cd18dc64e0a6d308ea411a93226ea826af']]){
 const source=execFileSync('git',['show',ref+':packages/agents/src/adapters/codex-cli.ts'],{cwd:wt,encoding:'utf8'});const out=root+'/compiled-'+name;mkdirSync(out);writeFileSync(out+'/source.ts',source);
 const result=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},reportDiagnostics:true});if(result.diagnostics?.length)throw Error(JSON.stringify(result.diagnostics));
 const replacements={'@osstack/core':wt+'/packages/core/dist/index.js','../base.js':wt+'/packages/agents/dist/base.js'};let code=result.outputText;for(const [k,v]of Object.entries(replacements))code=code.replace('from "'+k+'"','from '+JSON.stringify(pathToFileURL(v).href));writeFileSync(out+'/adapter.mjs',code);
 records.push({name,ref,source_sha256:hash(source),compiled_sha256:hash(code),module:out+'/adapter.mjs',compiler_version:ts.version,runtime_import_resolution_only:replacements,dependencies:Object.entries(replacements).map(([specifier,path])=>({specifier,path,sha256:hash(readFileSync(path))}))});
}
writeFileSync(root+'/compile-bindings.json',JSON.stringify(records,null,2)+'\n');
