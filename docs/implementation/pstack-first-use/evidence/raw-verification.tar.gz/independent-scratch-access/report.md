# writableRoots 独立限定核验

候选 bcb596cd 的同一份预冻27检查全部通过。原28ece为9通过/18失败，表示旧API不支持新配置，不能称18个历史bug。

公共 invoke/startSession/resumeSession 的实际fake进程argv均含canonical去重后 --add-dir，resume父flags位置正确；无参数和空数组保持旧argv。非法目录/根/相对/NUL/文件/不存在/超8/非workspace-write均构造拒绝且零进程。复制caller数组和env，preflight不附写权限，未从ambient env推导新root。

候选源SHA `7abc045c8fd186bc35ef2ca9b3f99b699c818ed874b52fd62b19acee45b1c1a0`，fresh dist `ea2ba90f26d46909dd42d1e30a00ec05720c9f0c9556d84775283a851628134a`。隔离转译实际代码在还原imports并去source-map注释后与fresh dist逐字相等；源码diff只两个adapter源/测试文件。

没有启动模型或重试P6；不证明OS隔离、任意未来目录状态或完整产品验收。原P6 BLOCKED不变。
