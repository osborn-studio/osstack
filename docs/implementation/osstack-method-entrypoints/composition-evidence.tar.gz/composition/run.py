import pathlib,subprocess,os,json,hashlib,datetime,sys,shutil
r=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-291-main-proof');s=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/osstack-method-entrypoints-20261028/composition')
sha=lambda b:hashlib.sha256(b).hexdigest()
env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(s/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack',OSSTACK_UPDATE_CHECK='0');env.pop('OSSTACK_SOCKET',None)
commands=[{'label':'merge','argv':['git','merge','--no-edit','7228af775ea13f2c0d8ebb2790c669dc07cfb89c'],'cwd':str(r),'exit_code':0,'stdout':'merge.stdout','stderr':'merge.stderr'}]
def run(label,argv,timeout=900):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (s/(label+'.stdout')).open('wb') as out,(s/(label+'.stderr')).open('wb') as err:
  try:p=subprocess.run(argv,cwd=r,env=env,stdout=out,stderr=err,timeout=timeout);code=p.returncode
  except subprocess.TimeoutExpired:code='timeout'
 record={'label':label,'argv':argv,'cwd':str(r),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'environment_override':{k:env[k] for k in ['PATH','OSSTACK_HOME','OSSTACK_SCRATCH_ROOT','OSSTACK_UPDATE_CHECK']},'unset':['OSSTACK_SOCKET'],'stdout':label+'.stdout','stdout_sha256':sha((s/(label+'.stdout')).read_bytes()),'stderr':label+'.stderr','stderr_sha256':sha((s/(label+'.stderr')).read_bytes())};commands.append(record);(s/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(label,'exit',code,flush=True)
 if code!=0:raise RuntimeError(label+' failed; no retry')
 return (s/(label+'.stdout')).read_bytes()
assert run('initial-status',['git','status','--porcelain'])==b''
head=run('head-binding',['git','show','-s','--format=%H%n%P%n%T','HEAD']).decode().strip().splitlines();assert head[1]=='f92914e0a98bd3e5f82765fddc5a275a93637f30 7228af775ea13f2c0d8ebb2790c669dc07cfb89c';assert head[2]=='3e2f587932ee9ab47fd2613587b3a738ed1fb6cf'
assert run('merge-tree',['git','merge-tree','--write-tree',*head[1].split()]).decode().strip()==head[2]
assert not (r/'node_modules').exists()
(s/'composition.json').write_text(json.dumps({'head':head[0],'parents':head[1].split(),'tree':head[2],'merge_tree_equal':True,'initial_clean':True,'initial_node_modules_present':False,'scope':'fresh install/build; both actual smoke package scripts and 241 Python document checks, not combined whole-repository suite'},indent=2)+'\n')
paths=run('knowledge-tracked',['git','ls-files','packages/knowledge/dist']).decode().splitlines();backups={p:(r/p).read_bytes() for p in paths};(s/'knowledge-before.json').write_text(json.dumps({p:sha(b) for p,b in backups.items()},indent=2)+'\n')
built={};failure=None
try:
 run('node-version',['node','--version']);run('install',['pnpm','install','--frozen-lockfile']);run('build',['pnpm','build'])
 built={p:sha((r/p).read_bytes()) for p in paths};(s/'knowledge-after-build.json').write_text(json.dumps(built,indent=2)+'\n')
 for label,script in [('skills','smoke:skills-check'),('engineering','smoke:engineering-decision')]:
  raw=run(label,['pnpm',script],300).decode();receipt=None
  decoder=json.JSONDecoder()
  for i,c in enumerate(raw):
   if c!='{':continue
   try:
    obj,end=decoder.raw_decode(raw[i:])
    if not raw[i+end:].strip() and isinstance(obj,dict) and 'evidence' in obj:receipt=obj;break
   except json.JSONDecodeError:pass
  assert receipt is not None,'no final receipt'
  e=pathlib.Path(receipt['evidence']['directory']);assert e.is_relative_to('/Volumes/AIMATE_WORK/tmp/osstack/smoke')
  saved=json.loads((e/'receipt.json').read_text());ri=json.loads((e/'run.json').read_text());mf=json.loads((e/'manifest.json').read_text());cleanup=json.loads((e/'cleanup.json').read_text())
  checks={'receipt_matches':receipt==saved,'passed':receipt['status']=='passed','unqualified':receipt['provider_qualified'] is False,'fixture_absent':not pathlib.Path(ri['fixture_root']).exists(),'bindings_unchanged':ri['bindings_unchanged'] is True}
  if label=='engineering':checks.update(applied=receipt['action_receipt']=='applied',observed_turn=receipt['completion_level']=='observed_turn',removed=cleanup['scratch_removed'] is True,process_exited=cleanup['process_exit_confirmed'] is True,head_bound=ri['bindings']['git_head']==head[0])
  else:checks.update(driver_exit=receipt['driver_exit']==0,removed=cleanup['fixture_removed'] is True,cases_all=len(receipt['cases'])==5 and all(c['verification_status']=='passed' for c in receipt['cases']))
  filechecks=[]
  for f in mf['files']:
   assert pathlib.PurePosixPath(f['path']).name==f['path']
   data=(e/f['path']).read_bytes();filechecks.append({'path':f['path'],'hash_matches':sha(data)==f['sha256'],'bytes_match':len(data)==f['bytes']})
  checks['manifest_verified']=all(x['hash_matches'] and x['bytes_match'] for x in filechecks)
  (s/(label+'-evidence-verification.json')).write_text(json.dumps({'original_evidence':str(e),'checks':checks,'manifest_files':filechecks},indent=2)+'\n');shutil.copytree(e,s/(label+'-evidence'));assert all(checks.values()),checks
 run('document-checks',['/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-handoff-20261027/venv/bin/python','-m','unittest','discover','-s','docs/design/2026-10-27-joint-engineering','-p','test_validate_*.py'],300)
except Exception as ex:failure=str(ex);print('FAILURE',failure,flush=True)
finally:
 restored=[];blocked=[]
 for p,b in backups.items():
  current=(r/p).read_bytes()
  if current==b:continue
  if p in built and sha(current)==built[p]:(r/p).write_bytes(b);restored.append(p)
  else:blocked.append(p)
 (s/'knowledge-cleanup.json').write_text(json.dumps({'restored_owned_build_outputs':restored,'refused_unknown_changes':blocked},indent=2)+'\n')
 final=run('final-status',['git','status','--porcelain'])
 (s/'result.json').write_text(json.dumps({'status':'failed' if failure or blocked else 'passed','failure':failure,'knowledge_unknown_changes':blocked,'final_worktree_clean':not final,'limitations':['not a combined whole-repository test run','not runtime/provider/principal/gate qualification']},indent=2)+'\n')
 if failure or blocked:sys.exit(1)
print('COMPOSITION PASSED',flush=True)
