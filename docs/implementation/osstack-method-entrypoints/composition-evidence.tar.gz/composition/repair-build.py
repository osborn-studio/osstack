exec(compile((__import__('pathlib').Path(__file__).parent/'run.py').read_text().split("assert run('initial-status'")[0],str(__file__),'exec'))
commands=json.loads((s/'commands.json').read_text())
head=json.loads((s/'composition.json').read_text())['head']
def verify(label):
 raw=(s/(label+'.stdout')).read_text();decoder=json.JSONDecoder();receipt=None
 for i,c in enumerate(raw):
  if c!='{':continue
  try:
   obj,end=decoder.raw_decode(raw[i:])
   if not raw[i+end:].strip() and isinstance(obj,dict) and 'evidence' in obj:receipt=obj;break
  except json.JSONDecodeError:pass
 assert receipt is not None
 e=pathlib.Path(receipt['evidence']['directory']);assert e.is_relative_to('/Volumes/AIMATE_WORK/tmp/osstack/smoke')
 saved=json.loads((e/'receipt.json').read_text());ri=json.loads((e/'run.json').read_text());mf=json.loads((e/'manifest.json').read_text());cleanup=json.loads((e/'cleanup.json').read_text())
 fixture=ri['fixture_root'] if label.startswith('engineering') else cleanup['fixture_path']
 checks={'receipt_matches':receipt==saved,'passed':receipt['status']=='passed','unqualified':receipt['provider_qualified'] is False,'fixture_absent':not pathlib.Path(fixture).exists(),'bindings_unchanged':ri['bindings_unchanged'] is True}
 if label.startswith('engineering'):checks.update(applied=receipt['action_receipt']=='applied',observed_turn=receipt['completion_level']=='observed_turn',removed=cleanup['scratch_removed'] is True,process_exited=cleanup['process_exit_confirmed'] is True,head_bound=ri['bindings']['git_head']==head)
 else:checks.update(driver_exit=receipt['driver_exit']==0,removed=cleanup['fixture_removed'] is True,cases_all=len(receipt['cases'])==5 and all(c['verification_status']=='passed' for c in receipt['cases']),head_bound=ri['git_head']==head)
 filechecks=[]
 for f in mf['files']:
  assert pathlib.PurePosixPath(f['path']).name==f['path']
  data=(e/f['path']).read_bytes();filechecks.append({'path':f['path'],'hash_matches':sha(data)==f['sha256'],'bytes_match':len(data)==f['bytes']})
 checks['manifest_verified']=all(x['hash_matches'] and x['bytes_match'] for x in filechecks)
 (s/(label+'-evidence-verification.json')).write_text(json.dumps({'original_evidence':str(e),'checks':checks,'manifest_files':filechecks},indent=2)+'\n');shutil.copytree(e,s/(label+'-evidence'));assert all(checks.values()),checks
paths=list(json.loads((s/'knowledge-before.json').read_text()));backups={p:(r/p).read_bytes() for p in paths};built={};failure=None
try:
 # Previous harness finally correctly restored generated dist. Rebuild is needed
 # for the remaining dependent smoke; the successful skills invocation is not repeated.
 run('knowledge-force-rebuild',['pnpm','exec','tsc','--build','packages/knowledge','--force'])
 built={p:sha((r/p).read_bytes()) for p in paths};(s/'knowledge-after-force-rebuild.json').write_text(json.dumps(built,indent=2)+'\n')
 assert built == json.loads((s/'knowledge-after-build.json').read_text()), 'force output differs from initial build'
 run('engineering-rebuilt',['pnpm','smoke:engineering-decision'],300);verify('engineering-rebuilt')
 run('document-checks',['/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-handoff-20261027/venv/bin/python','-m','unittest','discover','-s','docs/design/2026-10-27-joint-engineering','-p','test_validate_*.py'],300)
except Exception as ex:failure=str(ex);print('FAILURE',failure,flush=True)
finally:
 restored=[];blocked=[]
 for p,b in backups.items():
  current=(r/p).read_bytes()
  if current==b:continue
  if p in built and sha(current)==built[p]:(r/p).write_bytes(b);restored.append(p)
  else:blocked.append(p)
 (s/'knowledge-force-cleanup.json').write_text(json.dumps({'restored_owned_build_outputs':restored,'refused_unknown_changes':blocked},indent=2)+'\n')
 final=run('final-repaired-status',['git','status','--porcelain'])
 (s/'repaired-result.json').write_text(json.dumps({'status':'failed' if failure or blocked else 'passed','failure':failure,'prior_harness_failure':'run.py used engineering fixture_root for skills; no product failure, original result.json retained; skills execution not repeated','knowledge_unknown_changes':blocked,'final_worktree_clean':not final,'limitations':['not a combined whole-repository test run','not runtime/provider/principal/gate qualification']},indent=2)+'\n')
 if failure or blocked:sys.exit(1)
print('COMPOSITION PASSED',flush=True)
