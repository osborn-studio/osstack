from pathlib import Path
p=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/osstack-method-entrypoints/scripts/lib/osstack-method-export.mjs')
s=p.read_text().replace('open, readdir, realpath', 'open, opendir, realpath')
s=s.replace('return buffer.subarray(0, length);','return Buffer.from(buffer.subarray(0, length));')
s=s.replace("    for (const name of (await readdir(join(sourceRoot, rel))).sort()) {\n      count();", "    const entries = [];\n    for await (const entry of await opendir(join(sourceRoot, rel))) { count(); entries.push(entry.name); }\n    for (const name of entries.sort()) {")
s=s.replace("      const path = `${rel}/${name}`; const info", "      if (name.startsWith('.')) throw Error(`source_format: ${rel}/${name}`);\n      const path = `${rel}/${name}`; const info")
s=s.replace("      else files.set(path, await boundedRead(join(sourceRoot, path), budget));", "      else {\n        if (!name.endsWith('.md')) throw Error(`source_format: ${path}`);\n        files.set(path, await boundedRead(join(sourceRoot, path), budget));\n      }")
a=s.index('// The canonical materials');b=s.index('function localTarget',a)
s=s[:a]+'''// A deliberately small Markdown subset: single-line, unnested labels; simple
// destinations; no titles or HTML navigation. Unsupported navigation fails closed.
// Code masking and delimiter scans are linear in the bounded source size.
function maskCode(text) {
  let fence = null;
  return text.split('\\n').map(line => {
    const marker = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
    if (fence) {
      if (marker && marker[1][0] === fence.char && marker[1].length >= fence.length && !marker[2].trim()) fence = null;
      return ' '.repeat(line.length);
    }
    if (marker) { fence = { char: marker[1][0], length: marker[1].length }; return ' '.repeat(line.length); }
    const runs = [];
    for (let i = 0; i < line.length;) {
      if (line[i] !== '`') { i++; continue; }
      const start = i; while (line[i] === '`') i++;
      runs.push({ start, end: i, next: null });
    }
    const next = new Map();
    for (let i = runs.length - 1; i >= 0; i--) {
      const run = runs[i]; const length = run.end - run.start;
      run.next = next.get(length) ?? null; next.set(length, i);
    }
    const chars = [...line];
    // Use code-unit offsets, including when a label contains non-BMP Unicode.
    const masked = line.split('');
    for (let i = 0; i < runs.length; i++) {
      const run = runs[i]; if (run.next === null) continue;
      const close = runs[run.next]; masked.fill(' ', run.start, close.end); i = run.next;
    }
    return masked.join('');
  }).join('\\n');
}
function destinations(text, sourcePath) {
  const spans = []; const prose = maskCode(text); const labels = [];
  const unsupported = () => { throw Error(`link_unsupported: ${sourcePath}`); };
  function targetAt(start, inline) {
    let i = start;
    while (prose[i] === ' ' || prose[i] === '\\t') i++;
    const angle = prose[i] === '<'; if (angle) i++;
    const begin = i;
    while (i < prose.length && !/[\\s]/.test(prose[i]) && prose[i] !== (angle ? '>' : ')')) {
      if (prose[i] === '(' || (!angle && prose[i] === '<')) unsupported();
      i++;
    }
    if (i === begin || (angle && prose[i] !== '>')) unsupported();
    const end = i; if (angle) i++;
    while (prose[i] === ' ' || prose[i] === '\\t') i++;
    if (inline ? prose[i] !== ')' : i < prose.length && prose[i] !== '\\n' && prose[i] !== '\\r') unsupported();
    spans.push({ target: prose.slice(begin, end), start: begin, end });
    return inline ? i : i - 1;
  }
  for (let i = 0; i < prose.length; i++) {
    if (prose[i] === '[') { if (labels.length) labels[labels.length - 1].nested = true; labels.push({ start: i, nested: false }); }
    else if (prose[i] === ']') {
      const label = labels.pop();
      if (prose[i + 1] === '(') {
        if (!label || label.nested || prose.slice(label.start, i).includes('\\n')) unsupported();
        i = targetAt(i + 2, true);
      } else if (prose[i + 1] === ':' && label) {
        const lineStart = prose.lastIndexOf('\\n', label.start) + 1;
        const prefix = prose.slice(lineStart, label.start);
        if (/^ {0,3}$/.test(prefix)) {
          if (label.nested || prose[label.start + 1] === '^' || prose.slice(label.start, i).includes('\\n')) unsupported();
          i = targetAt(i + 2, false);
        }
      }
    } else if (prose[i] === '<') {
      const end = prose.indexOf('>', i + 1);
      if (end === -1) break;
      if (/\\b(?:href|src|srcset)\\s*=/i.test(prose.slice(i + 1, end))) unsupported();
      i = end;
    }
  }
  return spans;
}
''' +s[b:]
s=s.replace("    const chars = [...line];\n",'')
s=s.replace('const spans = destinations(text);','const spans = destinations(text, sourcePath);')
s=s.replace("  validateOptions({ host, output, dryRun });\n  const requested", "  validateOptions({ host, output, dryRun });\n  sourceRoot = resolve(sourceRoot); // Strip trailing separators before lstat: never follow a final-component symlink.\n  const requested")
s=s.replace("  for (const name of ['.agents', '.claude', '.codex', '.osstack']) {\n    const forbidden = resolve(homedir(), name);", "  const protectedHomes = ['.agents', '.claude', '.codex', '.osstack'].map(name => resolve(homedir(), name));\n  for (const key of ['CODEX_HOME', 'CLAUDE_CONFIG_DIR', 'OSSTACK_HOME']) if (process.env[key]) protectedHomes.push(resolve(process.env[key]));\n  for (const forbidden of protectedHomes) {")
s=s.replace("a.path.localeCompare(b.path, 'en')", "a.path < b.path ? -1 : a.path > b.path ? 1 : 0")
s=s.replace("destinations(file.bytes.toString('utf8'))", "destinations(file.bytes.toString('utf8'), file.path)")
s=s.replace("link_scope: 'inline Markdown and reference-definition destinations; file existence checked, fragment anchors not qualified'", "link_scope: 'simple single-line unnested Markdown labels and reference definitions, without titles; unsupported navigation rejected; file existence checked, fragment anchors not qualified'")
p.write_text(s)
