# Exporter repair handoff

Frozen two assigned files, uncommitted. Root owns the documentation fix B2, remaining review, full-suite evidence and publishing. No package/product source, CLI wrapper, docs or ledger was edited by this worker.

## Confirmed and repaired

- **B1:** actual RED for hard-wrapped labels, nested labels and badge/outer-link navigation. Scanner now fails closed for these unsupported forms before output reservation. It accepts a deliberately narrow format: single-line unnested Markdown labels, simple destinations and reference definitions; no titles, HTML navigation or non-http/mailto URI autolinks. Error includes source path. Existing canonical material passes unchanged. No generic Markdown-engine compatibility claim.
- **B3:** actual RED: 200,000 `[` and 200,000 `<` input subprocesses exceeded 4 seconds and were killed. The 20,000-backtick input passed on the original implementation; no failure is claimed for it. Replaced pathological global backtracking regexes with bounded-source delimiter scanning and code masking. All three final child tests complete within their 4-second wall limit (entire final 49-test suite about 0.8 seconds locally). No benchmark guarantee for other machines; subprocess timeout is the regression guard.
- **B4:** actual trailing-slash source-root symlink bypass reproduced. Normalize root with resolve before lstat so the final symlink is refused in the actual CLI-style input form.
- Direct optional robustness: bounded opendir enumeration, exact-sized retained source buffers, deterministic code-unit path ordering and independently recomputed source_digest, reject hidden/unsupported non-.md reference files, guard explicit CODEX_HOME/CLAUDE_CONFIG_DIR/OSSTACK_HOME roots as well as fixed names.

## Tests and evidence

- Initial RED: 42 tests, 29 passed / 13 failed. All raw output retained.
- Final GREEN: 49 passed / 0 failed / 0 skipped, including actual canonical full exports for **both** hosts, source nonmutation and all output manifest hashes; 2 node syntax checks and assigned-file diff check passed.
- Existing symlink CLI test already did real canonical **dry-run**, contradicting a blanket claim of no real-tree coverage. Added real full export coverage as useful stronger validation rather than labeling the existing test fake.
- Additional checks retain Unicode offsets, code examples and longer fence closers; reject titles/multiline destinations, multiline reference definitions, srcset and unsafe autolinks. An unmatched angle must not hide a later escaping Markdown link.
- `commands.json`, raw red/green attempts, original two files, final two snapshots, `repair.patch` and `freeze.json` bind the exact inputs/outcomes. Historical command metadata is explicitly marked recorded after execution rather than inventing start timestamps.

## Boundaries

Unsupported Markdown is intentionally rejected, not silently rewritten. Fragments are not qualified, native host discovery is not tested, external URLs are not fetched, hostile concurrent tree mutation is not supported. This does not prove source filesystem case/identity security against malicious races or turn exports into installation/qualification.

B2 belongs to root. The optional setup authorization advice was not applied: no change to user authorization or autonomy semantics. No full suite was started, no model called, no commit/PR/push/ledger action performed. Only the final two files in freeze.json are owned by this repair; unrelated dirty files and root's build outputs remain untouched.
