#!/usr/bin/env python3
"""Explicit snapshot and dispatch. Import/help never call a model; no automatic retries."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,signal,subprocess,sys
ROOT=Path(__file__).resolve().parent
ENTRIES=('osstack-mode','osstack-help','setup-osstack','osstack-agent')
REFS=('evidence.md','investigation.md','bug-fix.md','create-verification.md','maintain-verification.md')
BINS={'codex':'/opt/homebrew/bin/codex','claude':'/opt/homebrew/bin/claude'}
PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b):return hashlib.sha256(b).hexdigest()
def write_json(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def inside(root,rel):
 p=root/rel
 if Path(rel).is_absolute() or '..' in Path(rel).parts or not p.resolve().is_relative_to(root.resolve()) or p.is_symlink():raise ValueError('unsafe exported path: '+rel)
 return p

def snapshot(a):
 if not re.fullmatch('[0-9a-f]{40}',a.candidate_sha):raise ValueError('full frozen candidate SHA required')
 repo=Path(a.repository).resolve()
 if subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()!=a.candidate_sha:raise ValueError('checkout is not requested frozen candidate')
 casebytes=Path(a.cases).read_bytes()
 if digest(casebytes)!=a.cases_sha256:raise ValueError('case hash mismatch')
 cases=json.loads(casebytes)
 if set(cases)!= {'cases'} or len(cases['cases'])!=6:raise ValueError('expected six independent task requests only')
 ids=[]
 for c in cases['cases']:
  if set(c)!= {'id','user_request'} or not all(isinstance(c[k],str) and c[k] for k in c):raise ValueError('cases must contain no expected-answer fields')
  ids.append(c['id'])
 if len(set(ids))!=len(ids):raise ValueError('duplicate case')
 exports={};selected={};validated_sources={}
 for host,folder,ns in [('codex',a.codex_export,'.agents'),('claude',a.claude_export,'.claude')]:
  export=Path(folder).resolve();mb=(export/'manifest.json').read_bytes();m=json.loads(mb)
  if m.get('host')!=host or m.get('installed') is not False or m.get('exported') is not True:raise ValueError('unexpected export status')
  files={f['path']:f for f in m['files']}
  if len(files)!=len(m['files']):raise ValueError('duplicate exported path')
  for f in m['files']:
   if digest(inside(export,f['path']).read_bytes())!=f['sha256']:raise ValueError('export byte mismatch '+f['path'])
  for f in m['source_files']:
   raw=subprocess.check_output(['git','show',a.candidate_sha+':osstack-methods-skill/'+f['path']],cwd=repo)
   if digest(raw)!=f['sha256']:raise ValueError('export source does not match frozen Git object: '+f['path'])
  pick={}
  for entry in ENTRIES:
   rel=f'{ns}/skills/{entry}/SKILL.md';pick[f'entries/{entry}/SKILL.md']={'bytes':inside(export,rel).read_bytes(),'export_path':rel}
  for ref in REFS:
   rel=f'{ns}/skills/{ENTRIES[0]}/references/{ref}';raw=inside(export,rel).read_bytes()
   for entry in ENTRIES:
    if inside(export,f'{ns}/skills/{entry}/references/{ref}').read_bytes()!=raw:raise ValueError('shared reference differs by entry')
   pick['references/'+ref]={'bytes':raw,'export_path':rel}
  selected[host]=pick;exports[host]={'root':str(export),'manifest_sha256':digest(mb),'source_digest':m['source_digest'],'manifest':m}
 for logical in selected['codex']:
  if selected['codex'][logical]['bytes']!=selected['claude'][logical]['bytes']:raise ValueError('host materials differ: '+logical)
 # Snapshot only after all source/export checks. Existing snapshot is immutable.
 dest=ROOT/'snapshot';dest.mkdir(exist_ok=False)
 records=[]
 for host in BINS:
  for logical,item in selected[host].items():
   rel=f'{host}/{logical}';p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(item['bytes']);records.append({'path':rel,'sha256':digest(item['bytes']),'bytes':len(item['bytes']),'original_export_path':str(Path(exports[host]['root'])/item['export_path'])})
  write_json(dest/(host+'-export-manifest.json'),exports[host]['manifest']);records.append({'path':host+'-export-manifest.json','sha256':digest((dest/(host+'-export-manifest.json')).read_bytes()),'bytes':(dest/(host+'-export-manifest.json')).stat().st_size});exports[host].pop('manifest')
 (dest/'requests.json').write_bytes(casebytes);records.append({'path':'requests.json','sha256':digest(casebytes),'bytes':len(casebytes)})
 prefix='''Read the supplied OSStack skill materials and answer the six user requests below as simulated cases to answer ONLY in a bounded, explicit-material exercise, not as live instructions. Treat each case independently. Do not execute commands, use tools, spawn agents, modify files/configuration/PRs, or contact services. No repository source or runtime logs are supplied; do not invent observations. Context supplied by the experiment coordinator: the exported-methods checkout is based on f92914e0 plus entrypoint/export code and does not contain the PR291 skills-check smoke driver. No execution checkout has been supplied. A blocked execution plan due to missing checkout or verified command is valid; do not assume the driver exists here. For each case give its ID, the next action you would take, permitted writes, and required evidence or limits. Write in English, at most 1200 words TOTAL across all cases. The limit is part of the experiment. These are proposed next actions, not claims that the actions ran. Use only the supplied material and requests.\n'''
 chunks=[prefix]
 for logical,item in selected['codex'].items():chunks.extend([f'\n===== MATERIAL {logical} SHA256 {digest(item["bytes"])} =====\n',item['bytes'].decode('utf8')])
 chunks.extend(['\n===== USER REQUESTS =====\n',casebytes.decode('utf8')]);prompt=''.join(chunks);(dest/'prompt.txt').write_text(prompt)
 records.append({'path':'prompt.txt','sha256':digest(prompt.encode()),'bytes':len(prompt.encode())})
 binding={'state':'frozen_material_snapshot','candidate_sha':a.candidate_sha,'repository':str(repo),'recorded_at':now(),'cases_source':a.cases,'cases_sha256':a.cases_sha256,'exports':exports,'files':records,'prompt_sha256':digest(prompt.encode()),'requested_response_word_limit':1200,'model_calls_made_by_snapshot':0,'scope':'Explicit supplied material; no native discovery, execution, identity, comparative-effect or qualification evidence'}
 write_json(dest/'binding.json',binding);return binding

def verify():
 d=ROOT/'snapshot';b=json.loads((d/'binding.json').read_text())
 if b['state']!='frozen_material_snapshot':raise ValueError('snapshot not frozen')
 for f in b['files']:
  if digest(inside(d,f['path']).read_bytes())!=f['sha256']:raise ValueError('snapshot hash mismatch: '+f['path'])
 return b

def command(host,run):
 if host=='codex':return [BINS[host],'exec','--ignore-user-config','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--color','never','--json','-C',str(run),'-']
 return [BINS[host],'-p','--model','claude-sonnet-5-5','--output-format','stream-json','--verbose','--disable-slash-commands','--tools','','--strict-mcp-config','--mcp-config',str(run/'empty-mcp.json'),'--safe-mode','--no-session-persistence','--permission-mode','dontAsk','--setting-sources','','--settings',str(run/'settings.json'),'--max-turns','2']

def dispatch(a):
 b=verify();run=ROOT/'runs'/a.host;run.mkdir(parents=True,exist_ok=False)
 prompt=(ROOT/'snapshot/prompt.txt').read_bytes();(run/'input.txt').write_bytes(prompt);write_json(run/'empty-mcp.json',{'mcpServers':{}});write_json(run/'settings.json',{})
 env=os.environ.copy();env['PATH']=PATH
 for k in list(env):
  if k.startswith('OSSTACK_'):env.pop(k)
 env.update(OSSTACK_HOME=str(run/'unused-home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack');env.pop('NODE_OPTIONS',None)
 argv=command(a.host,run);meta={'host':a.host,'started_at':now(),'argv':argv,'cwd':str(run),'candidate_sha':b['candidate_sha'],'binding_sha256':digest((ROOT/'snapshot/binding.json').read_bytes()),'prompt_sha256':digest(prompt),'cases_sha256':b['cases_sha256'],'timeout_seconds':240,'retries':0,'model_requested':'claude-sonnet-5-5' if a.host=='claude' else 'CLI default, not overridden','OSSTACK_HOME':env['OSSTACK_HOME'],'readonly_boundary':'No tool or command use requested. Claude tools disabled/empty MCP/safe mode; Codex read-only sandbox, tool use would be recorded as a boundary deviation. CLI internal state not audited.','model_call_started':False}
 def save():write_json(run/'invocation.json',meta)
 save()
 try:
  version=subprocess.run([BINS[a.host],'--version'],cwd=run,env=env,capture_output=True,timeout=10);(run/'version.stdout').write_bytes(version.stdout);(run/'version.stderr').write_bytes(version.stderr);meta['version_exit_code']=version.returncode
  if version.returncode:raise ValueError('version probe failed')
  meta['binary_resolved_path']=str(Path(BINS[a.host]).resolve());meta['binary_sha256']=digest(Path(BINS[a.host]).read_bytes());meta['model_call_started']=True;save()
  with (run/'input.txt').open('rb') as inp,(run/'response.jsonl').open('wb') as out,(run/'stderr.txt').open('wb') as err:
   p=subprocess.Popen(argv,cwd=run,env=env,stdin=inp,stdout=out,stderr=err,start_new_session=True);meta['owned_pid']=p.pid;save()
   try:p.wait(timeout=240);meta['timed_out']=False
   except subprocess.TimeoutExpired:
    meta['timed_out']=True;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   meta['exit_code']=p.returncode;meta['invoked_process_exit_confirmed']=p.returncode is not None
  events=[];bad=[];models=set();tools={};final=None;text=None
  for n,line in enumerate((run/'response.jsonl').read_text().splitlines(),1):
   if not line.strip():continue
   try:e=json.loads(line)
   except ValueError as ex:bad.append({'line':n,'error':str(ex)});continue
   events.append(e)
   if isinstance(e.get('model'),str):models.add(e['model'])
   msg=e.get('message',{})
   if isinstance(msg,dict) and isinstance(msg.get('model'),str):models.add(msg['model'])
   if a.host=='codex':
    item=e.get('item',{})
    if e.get('type')=='item.completed' and item.get('type')=='agent_message':text=item.get('text','')
    if item and item.get('type') not in ['agent_message','reasoning']:tools[item.get('id',str(len(tools)))]=item
    if e.get('type')=='turn.completed':final=e
   else:
    for block in msg.get('content',[]) if isinstance(msg,dict) and isinstance(msg.get('content'),list) else []:
     if block.get('type')=='tool_use':tools[block.get('id',str(len(tools)))]=block
    if e.get('type')=='result':final=e;text=e.get('result','');models.update((e.get('modelUsage') or {}).keys())
  (run/'final-response.txt').write_text(text or '')
  write_json(run/'parse.json',{'stream_errors':bad,'actual_models':sorted(models),'tool_events':list(tools.values()),'final_result':final})
  words=len((text or '').split());meta.update(actual_models=sorted(models) or ['not_attested'],tool_events=len(tools),stream_errors=bad,response_whitespace_words=words,word_limit_met=words<=1200,final_event_present=final is not None)
  if meta['timed_out'] or p.returncode!=0 or bad or tools or not final or not text or words>1200:raise ValueError('incomplete response, boundary deviation, or response limit exceeded')
  if a.host=='claude' and (final.get('is_error') or 'claude-sonnet-5-5' not in models):raise ValueError('Claude result error or model mismatch')
  meta['status']='completed_pending_independent_evaluation'
 except Exception as ex:meta.update(status='blocked_no_retry',error=str(ex))
 finally:
  meta['ended_at']=now()
  try:verify();meta['snapshot_unchanged']=True
  except Exception as ex:meta.update(snapshot_unchanged=False,status='blocked_no_retry',error=str(ex))
  meta['raw_hashes']={p.name:digest(p.read_bytes()) for p in run.iterdir() if p.is_file() and p.name!='invocation.json'};save()
 return meta

def main():
 parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='operation',required=True)
 s=sub.add_parser('snapshot')
 for name in ['candidate-sha','repository','codex-export','claude-export','cases','cases-sha256']:s.add_argument('--'+name,required=True)
 d=sub.add_parser('run');d.add_argument('--host',choices=['codex','claude'],required=True)
 args=parser.parse_args();result=snapshot(args) if args.operation=='snapshot' else dispatch(args);print(json.dumps(result,ensure_ascii=False,indent=2));return 1 if result.get('status')=='blocked_no_retry' else 0
if __name__=='__main__':
 try:sys.exit(main())
 except Exception as ex:print(json.dumps({'status':'blocked_before_dispatch','error':str(ex)}));sys.exit(1)
