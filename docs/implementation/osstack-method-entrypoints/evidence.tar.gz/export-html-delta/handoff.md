# Final HTML delta, after preserved round2

Root requested closing the known quoted-greater-than HTML navigation hole. Actual focused RED:2tests,1pass/1fail. Replaced first-greater-than lookup with a single linear quote-aware angle scan; no tag registry or general HTML parser. Existing href/src/srcset rejection now sees attributes after a quoted greater-than. Actual angle Markdown destination + HTTP/mailto autolink positive control passes, as do canonical material exports. Final62tests:62pass,0fail,0skip; both syntax checks and assigned-file diffcheck pass.

This supersedes only the explicit quoted-greater-than remaining limitation of round2 handoff; prior round2 archive remains unchanged. R1-R4 dispositions remain in round2. Final actual files and hashes are in this freeze.json; no further writes, no commit, full suite, model, PR or ledger actions. Small Markdown subset and no native discovery/runtime/formal qualification claims remain.
