# Container-prefix performance delta

Only the requested new performance defect was fixed. Original exact input: `"- ".repeat(200000) + "x" + "[a]:".repeat(120000)` in one reference file. Actual pre-fix dry-run subprocess exceeded4s and was SIGKILLed (RED,~4005ms). The implementation now caches the longest leading container-character prefix once for each line; ordinary prefix checks inspect at most3characters, and repeated colon labels compare offsets. Newline invalidates the cache. This avoids rescanning the400k prefix120k times.

Final same-input child passed at~220ms locally. Full focused exporter suite63passed/0failed/0skipped; both node syntax checks and assigned-path diffcheck passed. No full repository suite, model, PR, commit, ledger or optional scope expansion. Both assigned files are frozen in freeze.json; all previous audit repair archives remain unchanged. This is a bounded local regression observation, not a universal timing guarantee.
