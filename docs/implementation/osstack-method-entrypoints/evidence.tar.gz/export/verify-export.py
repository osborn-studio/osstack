from pathlib import Path
import subprocess,hashlib,json,datetime,os,re
scratch=Path(__file__).resolve().parent
repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/osstack-method-entrypoints')
node='/opt/homebrew/opt/node@22/bin/node'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(scratch/'actual').mkdir(exist_ok=False)
rows=[]
for host in ['codex','claude']:
 output=scratch/'actual'/host
 argv=[node,str(repo/'scripts/export-osstack-methods.mjs'),'--host',host,'--output',str(output)]
 env=dict(os.environ);env.update(PATH='',OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (scratch/(host+'.stdout')).open('wb') as out,(scratch/(host+'.stderr')).open('wb') as err:r=subprocess.run(argv,cwd=repo,env=env,stdout=out,stderr=err,timeout=10)
 row={'host':host,'argv':argv,'cwd':str(repo),'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'PATH':'','output':str(output)}
 assert r.returncode==0
 receipt=json.loads((scratch/(host+'.stdout')).read_text());m=json.loads((output/'manifest.json').read_text());assert receipt['manifest_sha256']==sha(output/'manifest.json')
 links=0
 for f in m['files']:
  p=output/f['path'];assert not p.is_symlink() and p.is_file();assert sha(p)==f['sha256'] and p.stat().st_size==f['bytes'];assert sha(repo/'osstack-methods-skill'/f['source_path'])==f['source_sha256']
  if p.suffix=='.md':
   # Independent ordinary-inline-link check over the actual canonical corpus.
   for target in re.findall(r'\]\(([^\s)]+)\)',p.read_text()):
    if target.startswith(('https://','http://','#','mailto:')):continue
    dest=(p.parent/target.split('#')[0]).resolve();assert dest.is_relative_to((output/m['namespace']).resolve()) and dest.is_file(),(p,target)
    links+=1
 row.update(files=len(m['files']),local_links_checked=links,manifest_sha256=sha(output/'manifest.json'),all_source_and_output_hashes_match=True,exported=receipt['exported'],installed=receipt['installed'],host_discovery_verified=receipt['host_discovery_verified'])
 rows.append(row)
(scratch/'actual-export-verification.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
