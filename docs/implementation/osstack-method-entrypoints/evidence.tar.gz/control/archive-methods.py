from pathlib import Path
import json,hashlib,tarfile
r=Path(__file__).resolve().parent.parent
out=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/osstack-method-entrypoints/docs/implementation/osstack-method-entrypoints')
directories=['materials','export','independent','host-use','export-repair','export-repair-round2','export-html-delta','audit','audit-closure','audit-final','audit-prefix-closure','export-prefix-delta','pr291-live-evidence','control']
files=[]
for name in directories:
 for p in (r/name).rglob('*'):
  if p.is_symlink() or not p.is_file() or '__pycache__' in p.parts:continue
  files.append(p)
records=[]
for p in sorted(files):
 b=p.read_bytes();records.append({'path':p.relative_to(r).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'scope':'Method candidate source/test failures, actual model audits and explicit-host experiments; historical SHA bindings retained','files':records}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for e in records:t.add(r/e['path'],arcname=e['path'],recursive=False)
with tarfile.open(archive) as t:
 for e in records:
  b=t.extractfile(e['path']).read();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
print(json.dumps({'members':len(records),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
