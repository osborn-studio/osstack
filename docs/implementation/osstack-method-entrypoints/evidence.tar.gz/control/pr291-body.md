Skill source checks could inspect Git output at process `exit` before stdout/stderr had drained and misclassify a valid tracked ref. This PR waits for stream `close`, preserves the original deadline, and adds a real compiled-CLI verifier for healthy, missing-ref, drift, mixed and empty inputs. CI now retains raw verifier evidence on success and failure.

The first CI run passed full package tests and 25 driver tests but failed the actual mixed case. A controlled real-Git reproduction demonstrates the corrected output-drain defect; the exact historical CI trigger is not proven because that job did not upload its mixed stdout. Original failure, reproduction and audit are retained. No predicate, case selection, expected exit or concurrency was weakened.

Validation on candidate `ff6bfeb69973a7d700e4e2288a9a8e5859efb2d7`, including latest main `f92914e0`:

- Full `pnpm test`: 7,144 passed, 5 skipped, 0 failed.
- Registry 43 tests, verifier 25 tests, and five real CLI scenarios passed (product exits 0/1/2/1/0); root verified all 49 evidence manifest members and fixture cleanup.
- Actual Claude CLI `claude-sonnet-5-5` audit: PASS, no blockers. Original opinions and optional follow-ups retained.
- Lint exit0 (21 existing warnings), registry build/typecheck, changeset coverage and 241 final document checks passed.
- Publication commit adds documentation/evidence only after the audited candidate; new-head CI remains the final readiness check.

Evidence: `docs/implementation/skills-check-verification/ci-followup/README.md`. Earlier script audit and host-use experiments retain their original SHA bindings and limitations. The naming inventory records adapted OSStack entry names while preserving upstream authorship/history. This change does not install skills, activate providers, authorize autonomous merging or pass formal runtime gates.

Keep Draft until applicable checks on the latest published head pass. Approval and merge remain with gilberthello.
