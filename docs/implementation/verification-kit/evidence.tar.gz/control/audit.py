import subprocess,pathlib,json,hashlib,datetime,sys,shutil
base=pathlib.Path(__file__).parent
r=base if len(sys.argv)==1 else base/sys.argv[1]
r.mkdir(exist_ok=True)
if r != base:
 for name in ["settings.json","empty-mcp.json"]: shutil.copyfile(base/name,r/name)
repo=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/verification-kit')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
paths=['scripts/smoke-engineering-decision.mjs','scripts/lib/engineering-verification-evidence.mjs','scripts/smoke-engineering-decision.test.mjs','scripts/fixtures/engineering-crash-host.ts']
paths += [str(p.relative_to(repo)) for p in sorted((repo/'osstack-methods-skill').rglob('*.md'))]
paths += [str(p.relative_to(repo)) for p in sorted((repo/'docs/implementation/verification-kit').glob('*.md'))]
prompt='''Audit and adversarially challenge this OSStack verification-tooling slice. User wants practical pstack verification and portable Codex/Claude materials, not renewed identity bureaucracy. This is developer tooling using existing authorized local deterministic fixture, not J03 runtime admission or full D2a qualification. Check real command behavior, preflight no side effects, process ownership, evidence persistence/redaction/content binding, failures after applied, inability to clean up, negative tests, portable host instructions, honest claims. Return PASS or REVISE with specific confirmed findings (severity/path/line/scenario/minimal fix), separating optional suggestions. Do not demand unrelated runtime gates for this standalone tool. You have no tools; all reviewed source is below. No task execution. Candidate SHA: '''+sha+'\n'
if r != base:
 prompt += '\nPrevious independent audit (verify fixes against full source below):\n' + (base/'audit-report.md').read_text()
manifest=[]
for p in paths:
 b=(repo/p).read_bytes();manifest.append({'path':p,'sha256':hashlib.sha256(b).hexdigest()});prompt+='\n===== '+p+' =====\n'+b.decode()
prompt += '\n===== README change =====\n' + subprocess.check_output(['git','diff','HEAD~1','HEAD','--','README.md'],cwd=repo,text=True)
(r/'audit-input.txt').write_text(prompt)
args=['/opt/homebrew/bin/claude','-p','--model','claude-sonnet-5-5','--effort','high','--output-format','json','--disable-slash-commands','--tools','','--strict-mcp-config','--mcp-config',str(r/'empty-mcp.json'),'--safe-mode','--no-session-persistence','--permission-mode','dontAsk','--setting-sources','','--settings',str(r/'settings.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'audit-input.txt').open() as inp,(r/'audit-response.json').open('w') as out,(r/'audit-stderr.txt').open('w') as err:
 try: code=subprocess.run(args,cwd=r,stdin=inp,stdout=out,stderr=err,timeout=900).returncode
 except subprocess.TimeoutExpired: code=124
binding={'candidate_sha':sha,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'model_requested':'claude-sonnet-5-5','files':manifest,'prompt_sha256':hashlib.sha256((r/'audit-input.txt').read_bytes()).hexdigest(),'response_sha256':hashlib.sha256((r/'audit-response.json').read_bytes()).hexdigest()}
try:
 v=json.loads((r/'audit-response.json').read_text());binding['modelUsage']=v.get('modelUsage');binding['is_error']=v.get('is_error');(r/'audit-report.md').write_text(v.get('result',''));print(v.get('result',''))
except Exception as e: binding['parse_error']=str(e)
(r/'audit-binding.json').write_text(json.dumps(binding,indent=2)+'\n');print('exit_code',code)
