# Verdict: PASS

F1–F5 from the previous audit are fixed in the source below, and I found no new blocking defects. One Low item (N1) is a one-line fix and needs no re-review. I reviewed source only and ran nothing.

## Previous findings: verified against source

| ID | Status | Evidence |
|---|---|---|
| F1 | Fixed | `engineeringBindings` now does `lstat(packages/<name>)`, rejects symlinks, and `continue`s on non-directories. The test `content bindings ignore a stray non-directory packages entry` would throw `ENOTDIR` under the old code, so it is a real regression guard. |
| F2 | Fixed | `engineeringFailureDetails` keeps `actual`, `expected`, `operator` and `message`, and these land in `diagnostics.failure_details`. `stage = "invocations"` is set before the check and `invocationCount` is persisted. The reason string uses `error.message` for `ERR_ASSERTION`. A test covers this. |
| F3 | Fixed | `fixture daemon start` is appended to `observations.ndjson` with `pid`, `process_started`, argv and an ownership note, immediately after `fork`. `readyPromise.catch(()=>{})` is attached first, so the async write cannot lose ready/exit. `cleanup.json` carries `pid` and `process_started`, and `process_exit_confirmed = !processStarted \|\| …`. The success test asserts `observations.pid === cleanup.pid`. |
| F4 | Fixed | `sanitizeEvidence` strips controls first, then redacts. `sanitizeEngineeringRecord` is applied recursively to keys and values on every disk write. `createBoundedEvidenceTail` redacts before truncating and withholds token-prefix overlaps across chunks. The tests assert on-disk bytes (`disk evidence strips controls…`) and cover the chunk, control and truncation boundaries. |
| F5 | Fixed | The test is renamed to `cleanup removal and workflow observation helpers preserve distinct component outcomes`, with a comment that it is a component check only. The claim now matches what it exercises. |

## Confirmed findings

**N1. Low. The success test's own timeout is shorter than the runner it waits on.**
- Path: `scripts/smoke-engineering-decision.test.mjs`, test `successful compiled user flow retains independently verifiable evidence…`: `{ timeout: 90000 }` on the test, `timeout: 150000` on `runJsonCommand`.
- Scenario: the runner's internal deadline is 90 s, plus up to 6 s of `stopChild`, the binding digests and `rm` closeout. A slow machine therefore makes `node:test` fail the test at 90 s while the runner is still finishing. This is a false failure, not an orphan, because the runner is not killed until 150 s.
- Claim mismatch: `audit.md` says the outer budget was raised to 150 s to cover the run, which is only true for the `execFile` option.
- Minimal fix: use `{ timeout: 160000 }` on the test.

## Checked and confirmed OK

- **Preflight has no side effects.** It uses only `stat`, `lstat`, `access`, `require.resolve` and PATH lookup, and the helper's imports are built-ins only. Tests assert the scratch and evidence paths stay absent, and that `--doctor` fails without git and without a build. The limitations text honestly says that SQLite load and behavior are verified only by a run.
- **Process ownership.**
  - Cleanup uses the child handle only.
  - The SIGTERM-to-SIGKILL path is tested with a real child that ignores SIGTERM.
  - Early exit, forced exit and non-zero exit cannot produce a pass.
  - Any failure, including a failed `rm`, preserves the scratch root.
  - The authority file and `observation.json` are removed on every failure.
- **Evidence.**
  - The reservation is an exclusive `mkdir` plus `wx`, race-tested.
  - Files are 0600 in a 0700 directory.
  - The manifest is `wx` and its hashes are recomputed in the test.
  - `run.json` records source, build and git head, and `final_bindings` is re-checked after the run.
  - Failed commands keep exact argv, cwd and exit data.
  - The stdout receipt is deep-equal to the saved `receipt.json`.
- **Failure after applied.** A business pass followed by a stop or removal failure is written as `status: failed` with a separate `workflow_observation`. Evidence-write failure also keeps the observation in the stderr JSON. Removal failure writes `cleanup.json` with `error_code` and the diagnostics fall back gracefully when the root is already gone.
- **Claims.** `provider_qualified:false` and the `unverified` list are consistent with `feature-map.md`, `engineering-decision.md`, `host-usage.md` ("no observed host-run evidence") and the README. I found no reach into J03 or D2a.
- **Deferred L1–L3 (exit vs close, second signal, IPC error).** `audit.md` discloses these and disclaims orphan recovery, which is honest. The PID in the durable observation log gives an operator something to act on after a second Ctrl-C. They remain non-blocking.

## Optional suggestions (not required)

- **Socket path length in one test.** `the crash fixture ignores an inherited product socket override` deletes `OSSTACK_ENGINEERING_FIXTURE_SOCKET`, so the fixture binds an absolute `<root>/d.sock`. The runner's own comment says scratch roots can exceed the macOS `sockaddr_un` limit. I cannot see the real path lengths, so this is unconfirmed. If it flakes on a long `OSSTACK_SCRATCH_ROOT`, keep `d.sock` and cwd and only override `OSSTACK_SOCKET`.
- **`present()` and a file as evidence parent.** `present()` still rethrows `ENOTDIR`, so `--doctor --evidence-dir <file>/x` exits with a raw error instead of `ready:false` with a failed check. Treat `ENOTDIR` as absent there as well.
- **Doctor and symlinks.** `--doctor` can report ready, but the run can still fail closed on an `evidence_binding_symlink`. A read-only binding walk in doctor, skipping the git call, would close the gap.
- **`[redacted-partial]` marker.** Any stderr ending in `f` (the first character of the token) is shown with `[redacted-partial]` and loses that trailing character. This is harmless but can confuse a reader.
- **Stale status line.** The `feature-map.md` status names candidate `9b29a027` and says the final candidate needs a re-run. That is honest now; update it when the run on the final SHA is recorded.
- **Portable-docs wording.**
  - The `SKILL.md` description says "Shares one method set across Codex and Claude". "Intended for" matches `host-usage.md` until observed host runs exist.
  - The negation sentences (MethodBinding, `method-control`, "authenticated independent principal", "pre-frozen oracle") could shrink to one line, since a non-OSStack reader cannot interpret them.
- **Earlier optional items still open.** These are receipt-level digests, `run.json` via temp-file plus rename, a manifest check for unlisted files, tests for `parseEngineeringOptions` usage errors, symlink rejection and `bindings_changed_during_run`, and `.DS_Store` exclusion from the digests.

## Limits of this review

- **Not in the paste.** The README change block was empty. I did not see `startDaemon`'s SIGTERM handling, `createScratchDir`, or `delivery.json`.
- **No execution.** Passing smoke and test results on `348aed70dd5aa183f447b3f3fda55594eafc22af` are not confirmed by this review. That evidence has to come from the delivery record.
- **Anchors.** The source has no line numbers, so locations are file plus code anchor.