# Verdict: REVISE

The slice is mostly sound, but four small defects affect the things you asked me to check. None needs new gates or identity machinery. I reviewed only the pasted source. The pasted source has no line numbers, so locations are given as file plus code anchor. I could not see `startDaemon`'s SIGTERM handling or `createScratchDir`, so I treat the clean-exit path as working, as the success test implies.

## Confirmed findings (fix before PASS)

**F1. Medium. `--doctor` says ready, but the run aborts on a stray file in `packages/`.**
- Path: `scripts/lib/engineering-verification-evidence.mjs`, `present()` and the `packages` loop in `engineeringBindings`.
- Scenario: a non-directory entry exists in `packages/`, for example Finder's `.DS_Store` (the platform here is darwin).
  - `present(join(repo,'packages','.DS_Store','src'))` calls `lstat`, which fails with `ENOTDIR`.
  - `present` rethrows anything except `ENOENT`, so `engineeringBindings` throws.
  - `runSmoke` aborts with a raw `ENOTDIR` before evidence is reserved.
  - `--doctor` reported `ready: true` because it never calls `engineeringBindings`.
- Minimal fix: treat `ENOTDIR` as absent in `present`, or skip non-directories in the packages loop. Add a test with a stray file in a fixture `packages/`.

**F2. Medium. Every business-predicate failure is reported as `ERR_ASSERTION`.**
- Path: `scripts/smoke-engineering-decision.mjs`, the `catch (error)` in `runSmoke`: `${error.code ?? error.message}`.
- Scenario: `AssertionError.code` is `'ERR_ASSERTION'`, so `invocations.length !== 1`, `replay.replay`, `state === 'applied'`, the drain counters and the `observed_turn` check all produce `engineering_smoke_failed:<stage>:ERR_ASSERTION`.
  - The expected and actual values are not in `receipt.json`, `diagnostics.json` or the stderr JSON.
  - The invocation count is never persisted either, only left in the preserved `invocations.log`.
  - The invocation assertion also runs while `stage` is still `"reconcile"`.
- Minimal fix:
  - For assertion errors, use `error.message.split('\n')[0]` or `actual`/`expected` instead of `code`.
  - Set `stage = "invocations"` before that check.
  - Add `invocations` to the failure diagnostics.

**F3. Medium. The owned process is not recorded anywhere durable.**
- Path: `runSmoke`, after `fork(...)`; `cleanup.json`; `diagnostics.json`.
- Scenario: `stopChild` throws `fixture_cleanup_failed: process exit unconfirmed; preserve scratch evidence`, or the runner is killed. `evidence.md` requires "owned resource identifiers" and says never to kill by name, yet no file contains `fixture.pid`, so an operator has nothing safe to act on. Two related problems:
  - For failures before `fork` (bundle failure, `mkdir` failure), `cleanup.json` says `process_exit_confirmed: false`. That is computed as `shutdown !== undefined && (exit_code !== null || signal !== null)` on a never-started child, and it looks the same as an orphan. The `create_fixture` branch does record `process_started: false`; the main path does not.
- Minimal fix:
  - Append `{stage:'start_fixture', pid: fixture.pid}` to `observations.ndjson` immediately after `fork`, so it survives a runner crash.
  - Add `pid` and `process_started` to `cleanup.json` and the diagnostics.
  - Compute `process_exit_confirmed` as `!started || exit_code !== null || signal !== null`.

**F4. Medium. The credential-redaction claim is untested and slightly mis-ordered.**
- Path: `engineering-verification-evidence.mjs` `sanitizeEvidence`; `smoke-engineering-decision.mjs` `sanitizedDiagnostic`, and `fixtureStderr = (...).slice(-8192)`.
- Scenario (test gap): if `sanitizeEvidence` were changed to return its input unchanged, no test would fail.
  - The unit test covers only the smoke file's separate `sanitizedDiagnostic` copy.
  - The success test's `/fixture-only-…/` check passes vacuously, because the CLI never echoes the credential.
- Scenario (ordering): `sanitizedDiagnostic` redacts first and then strips control bytes, so `fixture-only-ab\x1bcd…` reassembles into the full token after redaction. `fixtureStderr` is also truncated to 8192 characters before redaction, so a token straddling the cut leaves an unredacted partial.
- Both are low-probability and the credential is a random fixture token, but the fix is trivial.
- Minimal fix:
  - Strip control bytes first, then redact, in both functions.
  - Redact before truncating, or keep `secret.length` of overlap.
  - Add one test that calls `appendEngineeringObservation` and `writeEngineeringEvidence` with a credential and control bytes, and asserts the bytes on disk.

**F5. Low-Medium. The "failure after applied" test name overclaims.**
- Path: test `an applied observation survives failed cleanup without becoming a passed run`.
- Scenario: it checks only `removeFixtureRoot` with an injected failing remove, `engineeringWorkflowObservation` (a pure merge) and `assertCleanShutdown`. The real `finally` wiring is unexercised:
  - `receipt.json` carrying `workflow_observation`;
  - `status: failed` and the exit code;
  - the preserved root.
- Reading `runSmoke`, that path looks correct. This is a coverage and honesty gap, not a behavior bug.
- Minimal fix: rename the test to describe what it checks, or add a small injection seam such as `runSmoke({ evidenceDir, remove })` and one end-to-end test.

## Lower-severity findings (non-blocking)

- **L1.** `waitForExit` resolves on `'exit'`, not `'close'`. Trailing fixture stderr may not be read before diagnostics are snapshotted, so the boot-failure test's `/injected_git_failure/` assertion can flake. Wait for `'close'` with a short bound before snapshotting.
- **L2.** `process.once("SIGINT")` means a second Ctrl-C uses the default behavior, killing the runner and orphaning the daemon with an unsealed evidence directory. Use `process.on`, and make the second signal a no-op or force `SIGKILL` of the fixture first.
- **L3.** No permanent `'error'` listener is attached to `fixture` after readiness. An IPC error would be an uncaught exception that skips cleanup.
- **L4.** If evidence writing itself fails after the business pass, the outer catch emits a failure without `workflow_observation`, so the applied observation is not in the printed error. If `writeEngineeringEvidence` throws inside the `create_fixture` branch, `error.evidence` is lost. Both are edge cases.
- **L5.** `provider_credentials_inherited: false` is a literal. It is true by construction from the `fixtureEnvironment` whitelist, but computing it would be more honest.
- **L6.** In `smoke-engineering-decision.test.mjs`, the success test calls the runner with `timeout: 85000` while the runner's internal deadline is 90000. On a slow machine the test SIGKILLs the runner and orphans the daemon. Make the caller's budget exceed the runner's.

## Optional suggestions (not required)

- Put `source_digest`, `build_digest` and `git_head` into the receipt itself, so a copied stdout receipt carries its candidate binding without opening `run.json`.
- The daemon is bundled from `packages/cli/src` via esbuild while the CLI runs from `dist`. Both are digested, but a stale `dist` is not detected. One sentence in `engineering-decision.md` saying "daemon fixture is source-bundled; CLI is compiled" would make the claim exact.
- Reject or warn on `--evidence-dir` inside digest-bound paths. It currently fails closed with `bindings_changed_during_run`, which is confusing.
- Exclude `.DS_Store` from the digests; they make the source digest non-reproducible across checkouts.
- Tests for `parseEngineeringOptions` usage errors, for `engineeringBindings` symlink rejection, and for the `bindings_changed_during_run` branch.
- Write `run.json` via temp-file plus rename, and have the manifest flag unlisted extra files.
- Portable docs: `SKILL.md`, `create-verification.md` and `evidence.md` use repo-internal vocabulary (MethodBinding, "authenticated independent principal", "pre-frozen oracle", `method-control`) that a non-OSStack host cannot interpret. That is the bureaucracy you want to avoid. The "what this is not" sentences could be trimmed to one line. The `SKILL.md` description "Shares one method set across Codex and Claude" could say "intended for" until `host-usage.md`'s observed-run cells are filled.

## Checked and confirmed OK

- **Preflight.** `--doctor` and `--dry-run` use only `lstat`, `stat`, `access`, `require.resolve` and PATH lookup. The helper's top-level imports are all built-ins, so importing causes no side effects. The tests assert the untouched scratch and evidence paths.
- **Evidence directory.** The exclusive `mkdir` plus `wx` reservation is race-safe and tested. The manifest uses `wx`. Files are 0600 in a 0700 directory.
- **Process ownership.**
  - Cleanup uses the child handle, never a name or PID sweep.
  - SIGTERM then SIGKILL escalation is tested with a real child that ignores SIGTERM.
  - Forced, early or non-zero exit cannot produce a pass.
  - The scratch root is preserved when exit is unconfirmed.
  - The authority file and `observation.json` are removed on failure.
- **Evidence content.** The `run.json` bindings and `final_bindings` are checked after the run. Exact argv, cwd and exit code are kept for failed commands. A business pass followed by a cleanup failure is recorded as `failed` with a separate `workflow_observation`, and is never printed as `passed`.
- **Claims.** Receipts say `provider_qualified:false` with an explicit `unverified` list. `host-usage.md` says "no observed host-run evidence". `feature-map.md` says "pending actual run". `feature-map.md`, `README.md` and `engineering-decision.md` are consistent with the code. I found no standalone-tool overreach into J03 or D2a.

When F1–F4 are fixed and F5 is renamed or seamed, I would re-review and expect PASS. L1–L6 can go in a follow-up.