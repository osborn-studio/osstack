import hashlib, json, os, pathlib, subprocess, datetime
R=pathlib.Path('/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/verification-kit')
S=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/verification-kit-20261028/next-baseline')
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
write(S/'expectations.json', {'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'type':'independent engineering regression expectation; not formal gate oracle','negative':{'input':'file:// owned repository, nonexistent refs/heads/does-not-exist, blessed SHA equals existing main commit','expected':'nonzero exit and explicit no_matching_ref diagnostic; do not conflate failed check with zero drift'},'positive':{'input':'same file:// repository, refs/heads/main, blessed SHA exactly main','expected':'exit 0 and up-to-date'},'scope':'CLI exit semantics only; no installation/execution of skills, network or default home'})
for name in ['home','xdg','tmp','template','hooks','cwd','local-origin','negative-home','positive-home']: (S/name).mkdir(exist_ok=False)
(S/'empty-gitconfig').write_text('')
env={'PATH':'/opt/homebrew/opt/node@22/bin:/usr/bin:/bin','HOME':str(S/'home'),'XDG_CONFIG_HOME':str(S/'xdg'),'TMPDIR':str(S/'tmp'),'OSSTACK_SCRATCH_ROOT':str(S/'scratch'),'OSSTACK_UPDATE_CHECK':'0','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_SYSTEM':'/dev/null','GIT_CONFIG_GLOBAL':str(S/'empty-gitconfig'),'GIT_CONFIG_COUNT':'1','GIT_CONFIG_KEY_0':'core.hooksPath','GIT_CONFIG_VALUE_0':str(S/'hooks'),'GIT_TEMPLATE_DIR':str(S/'template'),'GIT_ALLOW_PROTOCOL':'file','GIT_TERMINAL_PROMPT':'0','LANG':'C','LC_ALL':'C'}
write(S/'environment.json',env)
commands=[]
def run(label,argv,cwd,extra=None):
 e={**env,**(extra or {})}; start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(argv,cwd=cwd,env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 (S/(label+'.stdout')).write_bytes(p.stdout); (S/(label+'.stderr')).write_bytes(p.stderr)
 record={'label':label,'argv':argv,'cwd':str(cwd),'environment_override':extra or {},'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout_file':label+'.stdout','stdout_sha256':sha(p.stdout),'stderr_file':label+'.stderr','stderr_sha256':sha(p.stderr)}
 commands.append(record); write(S/'commands.json',commands); return p
origin=S/'local-origin'
assert run('git-init',['/usr/bin/git','init','--initial-branch=main',str(origin)],S/'cwd').returncode==0
(origin/'README.md').write_text('Local owned regression fixture only.\n')
assert run('git-add',['/usr/bin/git','add','README.md'],origin).returncode==0
assert run('git-commit',['/usr/bin/git','-c','user.name=Local Regression Fixture','-c','user.email=fixture@example.invalid','-c','commit.gpgsign=false','commit','-m','fixture'],origin).returncode==0
head=run('git-fixture-head',['/usr/bin/git','rev-parse','HEAD'],origin).stdout.decode().strip()
node='/opt/homebrew/opt/node@22/bin/node'; cli=str(R/'packages/cli/dist/bin.js')
run('node-version',[node,'--version'],S/'cwd')
run('candidate-head',['/usr/bin/git','rev-parse','HEAD'],R)
run('candidate-status',['/usr/bin/git','status','--porcelain'],R)
paths=['packages/cli/src/skills-command.ts','packages/cli/src/bin.ts','packages/skill-registry/src/manifest.ts','packages/skill-registry/src/watcher.ts','package.json','pnpm-lock.yaml']
files=[]
for rel in paths:
 b=(R/rel).read_bytes(); files.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
for pkg in sorted((R/'packages').iterdir()):
 if (pkg/'dist').is_dir():
  for p in sorted((pkg/'dist').rglob('*')):
   if p.is_file():
    b=p.read_bytes(); files.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b)})
write(S/'bindings-before.json',{'repository':str(R),'scope':'target source files, root package/lock, all existing package dist files; no independent build provenance attestation','files':files})
results=[]
for label,ref in [('negative','refs/heads/does-not-exist'),('positive','refs/heads/main')]:
 manifest={'version':1,'sources':[{'id':'owned-fixture','origin':origin.as_uri(),'ref':ref,'blessed_sha':head,'auto_minor':False}]}
 path=S/(label+'-home')/'skills.config.yaml'; write(path,manifest)
 write(S/(label+'-input.json'),{'manifest':manifest,'manifest_path':str(path),'manifest_sha256':sha(path.read_bytes())})
 result=run(label,[node,cli,'skills','check'],S/'cwd',{'OSSTACK_HOME':str(path.parent)})
 results.append({'case':label,'exit_code':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode(),'manifest_unchanged':sha(path.read_bytes())==sha((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())})
changes=[]
for f in files:
 p=R/f['path']
 if not p.is_file() or sha(p.read_bytes())!=f['sha256']:changes.append(f['path'])
write(S/'results.json',{'expectations_sha256':sha((S/'expectations.json').read_bytes()),'fixture_commit':head,'candidate_bindings_unchanged':not changes,'changed_files':changes,'cases':results,'reproduced':results[0]['exit_code']==0 and 'no_matching_ref' in results[0]['stdout'] and results[1]['exit_code']==0 and 'up-to-date' in results[1]['stdout']})
print((S/'results.json').read_text())
