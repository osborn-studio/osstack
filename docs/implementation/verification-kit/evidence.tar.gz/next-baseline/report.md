# Skills check local baseline reproduction

Observed 2026-10-28T06:27:52.950930+00:00 against verification-kit HEAD `348aed70dd5aa183f447b3f3fda55594eafc22af` and the exact working source/build bytes in `bindings-before.json`. Existing knowledge/dist changes are preserved in `candidate-status.stdout`; this run did not modify repository files. Content checks before and after the probe were equal. This is an independently exercised engineering regression, not formal oracle/principal qualification.

## Result

**Reproduced.** With a real owned Git repository and a `file://` origin:

- Negative: `refs/heads/does-not-exist`, with blessed SHA set to the actual main commit, printed `unreachable: no_matching_ref` then `0 source(s) drifted from blessed_sha.`, but exited **0**; stderr empty.
- Positive control: `refs/heads/main`, blessed SHA equal to main, printed `up-to-date` and exited **0**; stderr empty.
- Both input manifests remained byte-identical. No skill was installed or executed, no DB/daemon was started, and no package/repository file was edited.

`expectations.json` was saved before any fixture execution. The negative expectation was nonzero exit on an uncheckable tracked ref, without requiring a particular nonzero number. This expectation was not changed after observing output.

## Source explanation

`packages/skill-registry/src/watcher.ts` returns `ok: false`, `drifted: false`, `reason: no_matching_ref` for an empty successful `git ls-remote` response. `packages/cli/src/skills-command.ts` prints the failed entry and continues without incrementing a failure count; its final exit depends exclusively on `drifted > 0`. Thus the real observed failure is incorrectly represented as process success. The positive control distinguishes this from a broken local origin or Git transport.

## Isolation and evidence

`reproduce.py` uses an explicit, newly built environment recorded in `environment.json`. HOME/XDG_CONFIG_HOME/TMPDIR and each OSSTACK_HOME are local scratch paths. Git global config is an owned empty file, system config disabled, templates/hooks are owned empty directories, terminal prompting disabled, and `GIT_ALLOW_PROTOCOL=file` permits only the local transport. OSSTACK_SOCKET and provider credentials are absent. Fixture commit identity is explicitly dummy test data.

`commands.json` contains actual argv, cwd, environment overrides, timestamps, exit codes, and stdout/stderr SHA-256 values for every invoked subprocess. Individual files preserve original stdout/stderr bytes. `negative-input.json` and `positive-input.json` preserve full input manifest content and hashes. `results.json` records observations; `bindings-before.json` hashes the relevant source files, lock/package metadata, and all existing package dist bytes. Selected source files are copied in `source/` for future inspection.

No tests beyond these two actual CLI probes were run. This does not demonstrate all watcher error classes, timeout handling, other source backends, dependency closure, native host operation, or any release/runtime gate. It identifies one existing CLI exit-semantics defect for a follow-up change, without modifying the current frozen candidate.
