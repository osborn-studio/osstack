from pathlib import Path
p=Path('scripts/lib/engineering-verification-evidence.mjs');s=p.read_text()
s=s.replace("  for (const name of ordered(await readdir(join(repository, 'packages')))) {\n", "  for (const name of ordered(await readdir(join(repository, 'packages')))) {\n    const entry = await lstat(join(repository, 'packages', name));\n    if (entry.isSymbolicLink()) throw Error('evidence_binding_symlink:packages/' + name);\n    if (!entry.isDirectory()) continue;\n")
s=s.replace("let value = String(text ?? '');", "let value = String(text ?? '').replace(/[\\u0000-\\u0008\\u000b-\\u001f\\u007f]/g, '');")
s=s.replace("  return value.replace(/[\\u0000-\\u0008\\u000b-\\u001f\\u007f]/g, '');", "  return value;")
pos=s.index('export async function reserveEngineeringEvidence')
s=s[:pos]+'''// Normalize string values before JSON escapes controls; never treat serialized
// JSON as the sanitization boundary. Evidence inputs are plain JSON records.
function sanitizeRecord(value, secrets) {
  if (typeof value === 'string') return sanitizeEvidence(value, secrets);
  if (Array.isArray(value)) return value.map(item => sanitizeRecord(item, secrets));
  if (value !== null && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [sanitizeEvidence(key, secrets), sanitizeRecord(item, secrets)]));
  return value;
}
export function createBoundedEvidenceTail(secrets = [], limit = 8192) {
  let pending = ''; let tail = '';
  const tokens = secrets.filter(Boolean);
  return {
    push(chunk) {
      const clean = sanitizeEvidence(pending + sanitizeEvidence(chunk), tokens);
      let overlap = 0;
      for (const token of tokens) for (let size = 1; size < token.length && size <= clean.length; size++) {
        if (clean.endsWith(token.slice(0, size))) overlap = Math.max(overlap, size);
      }
      pending = overlap ? clean.slice(-overlap) : '';
      tail = (tail + (overlap ? clean.slice(0, -overlap) : clean)).slice(-limit);
    },
    // Withhold even incomplete token prefixes from snapshots. The unsanitized
    // overlap is bounded by the longest credential and never written to disk.
    read() { return (tail + (pending ? '[redacted-partial]' : '')).slice(-limit); },
  };
}
''' +s[pos:]
s=s.replace("sanitizeEvidence(JSON.stringify(value, null, 2) + '\\n', secrets)", "JSON.stringify(sanitizeRecord(value, secrets), null, 2) + '\\n'")
s=s.replace("sanitizeEvidence(JSON.stringify(value) + '\\n', secrets)", "JSON.stringify(sanitizeRecord(value, secrets)) + '\\n'")
p.write_text(s)
p=Path('scripts/smoke-engineering-decision.mjs');s=p.read_text()
s=s.replace('appendEngineeringObservation, engineeringBindings', 'appendEngineeringObservation, createBoundedEvidenceTail, engineeringBindings')
start=s.index('export function sanitizedDiagnostic');end=s.index('export async function runJsonCommand',start)
s=s[:start]+'''export function sanitizedDiagnostic(text, secrets = []) {
  return sanitizeEvidence(text, secrets).slice(-2048);
}
export function engineeringFailureDetails(error) {
  return { code: error.code ?? null, message: String(error.message ?? error),
    ...(error.code === 'ERR_ASSERTION' ? { actual: error.actual, expected: error.expected, operator: error.operator } : {}) };
}

'''+s[end:]
s=s.replace('const { observe, ...childOptions }', 'const { observe, secrets = [], ...childOptions }')
s=s.replace('String(cause.stderr ?? "").slice(-8192)', 'sanitizeEvidence(cause.stderr, secrets).slice(-8192)')
s=s.replace("const cleanup = { process_exit_confirmed: false, process_started: false", "const cleanup = { pid: null, process_exit_confirmed: true, process_started: false")
a=s.index("    await writeEngineeringEvidence(evidence, 'run.json', { schema_version: 1, status: 'incomplete'")
b=s.index('\n  }\n  const credential',a)
s=s[:a]+'''    try {
      await writeEngineeringEvidence(evidence, 'run.json', { schema_version: 1, status: 'incomplete', provider_qualified: false, bindings, reason: error.message });
      await writeEngineeringEvidence(evidence, 'cleanup.json', cleanup);
      await writeEngineeringEvidence(evidence, 'receipt.json', { schema_version: 1, status: 'failed', provider_qualified: false, reason: error.message, cleanup, evidence });
      await sealEngineeringEvidence(evidence);
    } catch (writeError) { error.evidence_write_error = writeError.code ?? 'unavailable'; }
    throw error;'''+s[b:]
s=s.replace('  let fixtureStderr = "";', '  const fixtureStderr = createBoundedEvidenceTail([credential]);\n  let failureDetails;\n  let invocationCount = null;')
s=s.replace('env, timeout: remaining(), observe:', 'env, timeout: remaining(), secrets: [credential], observe:')
s=s.replace('fixture.stderr.on("data", chunk => { fixtureStderr = (fixtureStderr + String(chunk)).slice(-8192); });', '''fixture.stderr.setEncoding('utf8');
    fixture.stderr.on("data", chunk => fixtureStderr.push(chunk));
    await appendEngineeringObservation(evidence, { stage, command: 'fixture daemon start', pid: fixture.pid ?? null,
      process_started: fixture.pid !== undefined, executable: process.execPath, argv: [join(root, 'host.mjs'), root, 'complete'], cwd: root,
      observed_at: new Date().toISOString(), ownership: 'this runner child handle; PID alone is not authorization to signal a later process' }, [credential]);''')
s=s.replace('    const invocations = (await readFile', '    stage = "invocations";\n    const invocations = (await readFile')
s=s.replace('    assert.equal(invocations.length, 1);', '    invocationCount = invocations.length;\n    assert.equal(invocationCount, 1, "adapter invocation count");')
s=s.replace('    failure = new Error(sanitizeEvidence(`engineering_smoke_failed:${stage}:${error.code ?? error.message}`, [credential]));', '''    failureDetails = engineeringFailureDetails(error);
    failure = new Error(sanitizeEvidence(`engineering_smoke_failed:${stage}:${error.code === 'ERR_ASSERTION' ? error.message : error.code ?? error.message}`, [credential]));''')
s=s.replace('      let cleanup = { process_exit_confirmed: shutdown !== undefined && (shutdown.exit_code !== null || shutdown.signal !== null),', '''      const processStarted = fixture?.pid !== undefined;
      let cleanup = { pid: fixture?.pid ?? null, process_started: processStarted,
        process_exit_confirmed: !processStarted || (shutdown !== undefined && (shutdown.exit_code !== null || shutdown.signal !== null)),''')
s=s.replace('diagnostics = { stage, reason: failure.message, commands: trace, shutdown: shutdown ?? null,', 'diagnostics = { stage, reason: failure.message, failure_details: failureDetails ?? null, invocations: invocationCount, pid: fixture?.pid ?? null, process_started: processStarted, commands: trace, shutdown: shutdown ?? null,')
s=s.replace('sanitizedDiagnostic(fixtureStderr, [credential])', 'sanitizedDiagnostic(fixtureStderr.read(), [credential])')
s=s.replace('stderr: fixtureStderr, stderr_retention:', 'stderr: fixtureStderr.read(), stderr_retention:')
s=s.replace('      if (failure) failure.evidence = evidence; else receipt = finalReceipt;', '      if (failure) { failure.evidence = evidence; failure.workflow_observation = finalReceipt.workflow_observation; } else receipt = finalReceipt;')
s=s.replace('      failure.evidence = evidence;\n    } finally', '      failure.evidence = evidence;\n      failure.workflow_observation = engineeringWorkflowObservation(receipt, actionObservation);\n    } finally')
s=s.replace("...(error.preflight ? { preflight: error.preflight } : {}),", "...(error.workflow_observation ? { workflow_observation: error.workflow_observation } : {}),\n      ...(error.evidence_write_error ? { evidence_write_error: error.evidence_write_error } : {}),\n      ...(error.preflight ? { preflight: error.preflight } : {}),")
p.write_text(s)
p=Path('scripts/smoke-engineering-decision.test.mjs');s=p.read_text().replace('timeout: 85000','timeout: 150000')
s=s.replace("test('an applied observation survives failed cleanup without becoming a passed run'", "// Component checks only: this does not inject failure into the complete finally path.\ntest('cleanup removal and workflow observation helpers preserve distinct component outcomes'")
s=s.replace("assert.equal(cleanup.process_exit_confirmed, true); assert.equal(cleanup.scratch_removed, true);", "assert.equal(cleanup.process_exit_confirmed, true); assert.equal(cleanup.scratch_removed, true);\n    assert.equal(cleanup.process_started, true); assert.ok(Number.isInteger(cleanup.pid));\n    assert.ok(observations.some(row => row.command === 'fixture daemon start' && row.pid === cleanup.pid));")
s=s.replace("assert.equal(receipt.status, 'failed'); assert.equal(receipt.cleanup.process_started, false);", "assert.equal(receipt.status, 'failed'); assert.equal(receipt.cleanup.process_started, false); assert.equal(receipt.cleanup.process_exit_confirmed, true);")
p.write_text(s)
