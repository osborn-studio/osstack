from pathlib import Path
p=Path('scripts/smoke-engineering-decision.mjs');s=p.read_text()
s=s.replace('const execFileAsync = promisify(execFile);', '''import {
  appendEngineeringObservation, engineeringBindings, engineeringPreflight, parseEngineeringOptions,
  reserveEngineeringEvidence, sanitizeEvidence, sealEngineeringEvidence, writeEngineeringEvidence,
} from './lib/engineering-verification-evidence.mjs';

const execFileAsync = promisify(execFile);''')
a=s.index('export async function runJsonCommand(');b=s.index('// The child shares',a)
s=s[:a]+'''export async function runJsonCommand(command, args, options = {}) {
  const { observe, ...childOptions } = options;
  const startedAt = new Date().toISOString();
  let stdout; let stderr;
  try {
    ({ stdout, stderr } = await execFileAsync(command, args, {
      ...childOptions, encoding: "utf8", timeout: options.timeout ?? 10000,
      killSignal: "SIGKILL", maxBuffer: 1024 * 1024,
    }));
  } catch (cause) {
    await observe?.({ started_at: startedAt, ended_at: new Date().toISOString(), exit_code: typeof cause.code === 'number' ? cause.code : null,
      spawn_error: typeof cause.code === 'string' ? cause.code : null, signal: cause.signal ?? null, killed: cause.killed === true,
      stdout: String(cause.stdout ?? ''), stderr: String(cause.stderr ?? '') });
    const error = new Error("command_failed");
    Object.defineProperty(error, "stderr", { value: String(cause.stderr ?? "").slice(-8192) });
    throw error;
  }
  await observe?.({ started_at: startedAt, ended_at: new Date().toISOString(), exit_code: 0, signal: null, stdout, stderr });
  try { return JSON.parse(stdout); } catch { throw new Error("command_invalid_json"); }
}

''' + s[b:]
s=s.replace('export async function runSmoke() {\n  if (!existsSync(cliPath)) throw new Error("missing_build: run pnpm build before this smoke");', '''export async function runSmoke({ evidenceDir } = {}) {
  const preflight = await engineeringPreflight({ repository, evidenceDir });
  if (!preflight.ready) {
    const error = new Error('preflight_failed:' + preflight.checks.filter(check => !check.ok).map(check => check.id).join(','));
    error.preflight = preflight; throw error;
  }
  const bindings = await engineeringBindings(repository);''')
s=s.replace('  const root = await realpath(await createScratchDir("smoke", "engineering-decision"));', '''  const evidence = await reserveEngineeringEvidence(evidenceDir, scratchRoot());
  const root = await realpath(await createScratchDir("smoke", "engineering-decision"));''')
s=s.replace('  const trace = [];', '''  const runInfo = { schema_version: 1, run_id: evidence.run_id, started_at: new Date().toISOString(), fixture_root: root,
    status: 'running', provider_qualified: false, bindings, environment: { node: process.version, platform: process.platform, arch: process.arch,
      fixture_home: env.OSSTACK_HOME, socket: env.OSSTACK_SOCKET, provider_credentials_inherited: false,
      inherited_keys: Object.keys(env).filter(key => !key.includes('CREDENTIAL')).sort() } };
  const trace = [];''')
s=s.replace('  const cli = async (family, ...args) => {', '''  const record = command => observation => appendEngineeringObservation(evidence, { stage, command, ...observation }, [credential]);
  const cli = async (family, ...args) => {''')
s=s.replace('{ cwd: root, env, timeout: remaining() });\n    trace.push', '{ cwd: root, env, timeout: remaining(), observe: record(`${family} ${args[0]}`) });\n    trace.push')
s=s.replace('  try {\n    await mkdir(env.HOME', "  try {\n    await writeEngineeringEvidence(evidence, 'run.json', runInfo, [credential]);\n    await mkdir(env.HOME")
s=s.replace('    stage = "start_fixture";', "    runInfo.fixture_bundle_sha256 = createHash('sha256').update(await readFile(join(root, 'host.mjs'))).digest('hex');\n    stage = \"start_fixture\";")
s=s.replace('fixtureRpc("daemon.drain", { timeout_ms: 0 }, { cwd: root, env, timeout: remaining() })', 'fixtureRpc("daemon.drain", { timeout_ms: 0 }, { cwd: root, env, timeout: remaining(), observe: record("daemon.drain") })')
s=s.replace('fixtureRpc("health", {}, { cwd: root, env, timeout: remaining() })', 'fixtureRpc("health", {}, { cwd: root, env, timeout: remaining(), observe: record("health") })')
s=s.replace('failure = new Error(`engineering_smoke_failed:${stage}:${error.code ?? error.message}`);', 'failure = new Error(sanitizeEvidence(`engineering_smoke_failed:${stage}:${error.code ?? error.message}`, [credential]));')
a=s.index('      if (interrupted && !failure)');b=s.index('    } finally {\n      process.off',a)
s=s[:a]+'''      if (interrupted && !failure) failure = new Error("engineering_smoke_failed:interrupted");
      try {
        const after = await engineeringBindings(repository);
        runInfo.final_bindings = { source_digest: after.source.digest, build_digest: after.build.digest, git_head: after.git_head };
        runInfo.bindings_unchanged = after.source.digest === bindings.source.digest && after.build.digest === bindings.build.digest;
        if (!runInfo.bindings_unchanged) failure ??= new Error('engineering_smoke_failed:bindings_changed_during_run');
      } catch { failure ??= new Error('engineering_smoke_failed:binding_recheck_failed'); }
      let cleanup;
      let diagnostics;
      if (failure) {
        await rm(env.OSSTACK_ENGINEERING_AUTH_FILE, { force: true });
        await rm(join(root, "observation.json"), { force: true });
        diagnostics = { stage, reason: failure.message, commands: trace, shutdown: shutdown ?? null,
          fixture_stderr: sanitizedDiagnostic(fixtureStderr, [credential]), command_stderr: sanitizedDiagnostic(commandStderr, [credential]) };
        failure.diagnostics_path = join(root, "failure.json");
        failure.diagnostics = diagnostics;
        await writeFile(failure.diagnostics_path, JSON.stringify(diagnostics, null, 2), { mode: 0o600 });
        cleanup = { process_exit_confirmed: shutdown !== undefined && (shutdown.exit_code !== null || shutdown.signal !== null),
          exit_code: shutdown?.exit_code ?? null, signal: shutdown?.signal ?? null, forced: shutdown?.forced ?? null, scratch_removed: false };
      } else {
        await rm(root, { recursive: true, force: true });
        cleanup = { process_exit_confirmed: true, exit_code: shutdown.exit_code, signal: shutdown.signal, forced: shutdown.forced, scratch_removed: true };
        receipt.cleanup = cleanup;
      }
      runInfo.ended_at = new Date().toISOString(); runInfo.status = failure ? 'failed' : 'passed';
      const finalReceipt = failure ? { schema_version: 1, status: 'failed', provider_qualified: false, reason: failure.message,
        workflow_observation: receipt ? { ...receipt, status: 'observed' } : null, cleanup, evidence } : { ...receipt, evidence };
      await writeEngineeringEvidence(evidence, 'run.json', runInfo, [credential]);
      await writeEngineeringEvidence(evidence, 'cleanup.json', cleanup, [credential]);
      await writeEngineeringEvidence(evidence, 'receipt.json', finalReceipt, [credential]);
      if (diagnostics) await writeEngineeringEvidence(evidence, 'diagnostics.json', diagnostics, [credential]);
      await sealEngineeringEvidence(evidence);
      if (failure) failure.evidence = evidence; else receipt = finalReceipt;
    } catch (error) {
      failure ??= new Error('engineering_smoke_failed:evidence_or_cleanup:' + (error.code ?? error.message));
      failure.evidence = evidence;
''' + s[b:]
s=s.replace('    if (process.argv.length > 2) throw new Error("usage: node scripts/smoke-engineering-decision.mjs");\n    console.log(JSON.stringify(await runSmoke(), null, 2));', '''    const options = parseEngineeringOptions(process.argv.slice(2));
    if (options.mode !== 'run') {
      const report = await engineeringPreflight({ repository, evidenceDir: options.evidenceDir, mode: options.mode });
      console.log(JSON.stringify(report, null, 2)); if (!report.ready) process.exitCode = 1;
    } else console.log(JSON.stringify(await runSmoke(options), null, 2));''')
s=s.replace('reason: error.message,\n      ...(error.diagnostics_path', 'reason: error.message,\n      ...(error.preflight ? { preflight: error.preflight } : {}), ...(error.evidence ? { evidence: error.evidence } : {}),\n      ...(error.diagnostics_path')
s=s.replace('import { existsSync } from "node:fs";\n','')
p.write_text(s)
