from pathlib import Path
p=Path('scripts/smoke-engineering-decision.mjs');s=p.read_text()
s=s.replace('  const root = await realpath(await createScratchDir("smoke", "engineering-decision"));', '''  let root;
  try { root = await realpath(await createScratchDir("smoke", "engineering-decision")); }
  catch (cause) {
    const error = new Error('engineering_smoke_failed:create_fixture:' + (cause.code ?? 'unavailable'));
    error.evidence = evidence;
    const cleanup = { process_exit_confirmed: false, process_started: false, scratch_removed: false, reason: 'fixture_not_created' };
    await writeEngineeringEvidence(evidence, 'run.json', { schema_version: 1, status: 'incomplete', provider_qualified: false, bindings, reason: error.message });
    await writeEngineeringEvidence(evidence, 'cleanup.json', cleanup);
    await writeEngineeringEvidence(evidence, 'receipt.json', { schema_version: 1, status: 'failed', provider_qualified: false, reason: error.message, cleanup, evidence });
    await sealEngineeringEvidence(evidence); throw error;
  }''')
s=s.replace('  let receipt;\n', '  let receipt;\n  let actionObservation;\n')
s=s.replace('    assert.equal(actionReceipt.state, "applied");', '''    assert.equal(actionReceipt.state, "applied");
    actionObservation = { action_receipt: 'applied', completion_level: view.observation_proof.kind,
      same_key_replay: replay.replay, observed_at: new Date().toISOString(), provider_qualified: false };''')
a=s.index('      let cleanup;\n');b=s.index('      runInfo.ended_at',a)
s=s[:a]+'''      let cleanup = { process_exit_confirmed: shutdown !== undefined && (shutdown.exit_code !== null || shutdown.signal !== null),
        exit_code: shutdown?.exit_code ?? null, signal: shutdown?.signal ?? null, forced: shutdown?.forced ?? null, scratch_removed: false };
      let diagnostics;
      if (!failure) {
        const removal = await removeFixtureRoot(root);
        cleanup = { ...cleanup, ...removal };
        if (!removal.scratch_removed) failure = new Error('engineering_smoke_failed:cleanup:' + removal.error_code);
        else receipt.cleanup = cleanup;
      }
      if (failure) {
        diagnostics = { stage, reason: failure.message, commands: trace, shutdown: shutdown ?? null,
          fixture_stderr: sanitizedDiagnostic(fixtureStderr, [credential]), command_stderr: sanitizedDiagnostic(commandStderr, [credential]) };
        // Cleanup can partially remove the root. Independent evidence still closes
        // out even when the original diagnostic can no longer be written there.
        try {
          await rm(env.OSSTACK_ENGINEERING_AUTH_FILE, { force: true });
          await rm(join(root, "observation.json"), { force: true });
          failure.diagnostics_path = join(root, "failure.json");
          await writeFile(failure.diagnostics_path, JSON.stringify(diagnostics, null, 2), { mode: 0o600 });
        } catch (error) { diagnostics.fixture_cleanup_error = error.code ?? 'unavailable'; delete failure.diagnostics_path; }
        failure.diagnostics = diagnostics;
      }
      await appendEngineeringObservation(evidence, { stage: 'fixture_exit', command: 'fixture daemon',
        exit_code: shutdown?.exit_code ?? null, signal: shutdown?.signal ?? null, stderr: fixtureStderr, stderr_retention: 'last 8192 characters' }, [credential]);
''' + s[b:]
s=s.replace('workflow_observation: receipt ? { ...receipt, status: \'observed\' } : null, cleanup, evidence', "workflow_observation: engineeringWorkflowObservation(receipt, actionObservation), cleanup, evidence")
a=s.index('export async function runSmoke(')
s=s[:a]+'''export async function removeFixtureRoot(root, remove = rm) {
  try { await remove(root, { recursive: true, force: true }); return { scratch_removed: true }; }
  catch (error) { return { scratch_removed: false, error_code: error.code ?? 'fixture_remove_failed' }; }
}
export function engineeringWorkflowObservation(receipt, actionObservation) {
  return receipt || actionObservation ? { ...actionObservation, ...receipt, status: 'observed', provider_qualified: false } : null;
}

''' + s[a:]
p.write_text(s)
