from pathlib import Path
import hashlib,json,re,subprocess,datetime
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-loop-long-path-20261030');O=R/'independent-final';W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-permission-preflight')
H=lambda b:hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
log=(R/'validation/full.log').read_text(); clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',log); rows=[]
for ln in clean.splitlines():
 m=re.match(r'^(packages/\S+) test:\s+Tests\s+(.*)$',ln)
 if m:
  nums={k:int(v) for v,k in re.findall(r'(\d+) (passed|skipped|failed)',m[2])};rows.append({'package':m[1],'passed':nums.get('passed',0),'skipped':nums.get('skipped',0),'failed':nums.get('failed',0),'raw':ln})
assert len(rows)==len({r['package'] for r in rows})==22
sums={k:sum(r[k] for r in rows) for k in ('passed','skipped','failed')};assert sums=={'passed':7449,'skipped':5,'failed':0}
before=j(R/'validation/full-before.json');after=j(R/'validation/full-after.json');binding=j(R/'validation/full-binding.json');assert before==after and len(before)==9172
commit=binding['head'];assert commit=='cd30b6ccddbd0e02d5607683a97c36d3ba96db11'; names=subprocess.check_output(['git','ls-tree','-r','--name-only',commit],cwd=W).decode().splitlines();assert set(names)==set(before)
# Verify every recorded before hash against its exact Git blob, allowing only declared initially generated dist.
entries=subprocess.check_output(['git','ls-tree','-r',commit],cwd=W).decode().splitlines(); objects=[(l.split('\t',1)[1],l.split()[2]) for l in entries]
proc=subprocess.run(['git','cat-file','--batch'],cwd=W,input=('\n'.join(sha for n,sha in objects)+'\n').encode(),stdout=subprocess.PIPE,check=True); buf=proc.stdout; at=0; gitdiff=[]
for name,sha in objects:
 end=buf.index(b'\n',at); header=buf[at:end].split(); size=int(header[2]);data=buf[end+1:end+1+size];at=end+1+size+1
 if H(data)!=before[name]:gitdiff.append(name)
assert sorted(gitdiff)==sorted(['packages/knowledge/dist/index.d.ts','packages/knowledge/dist/index.d.ts.map','packages/knowledge/dist/index.js','packages/knowledge/dist/index.js.map'])
prompt=(R/'audit/prompt.txt').read_text(); manifest=j(R/'audit/input-manifest.json'); sources=[]
for x in manifest:
 rel=x['path']; b=(R/'audit'/Path(rel).name).read_bytes();assert len(b)==x['size'] and H(b)==x['sha256'];assert b.decode() in prompt
 git=subprocess.check_output(['git','show',commit+':'+rel],cwd=W);assert b==git==(W/rel).read_bytes()
 native=R/'independent-native/candidate-source'/rel
 if native.exists():assert native.read_bytes()==b
 sources.append({**x,'exact_in_audit_prompt':True,'equal_tested_commit_and_current':True,'equal_native_snapshot':native.exists()})
resp=j(R/'audit/response.json');disp=j(R/'audit/dispositions.json');assert resp['is_error']==False and 'PASS_WITH_CONCERNS' in resp['result'] and 'no confirmed defect' in resp['result'];assert H((R/'audit/response.json').read_bytes())==disp['review_response_sha256'];assert resp['modelUsage']['claude-sonnet-5-5']
results=j(R/'validation/results.json');current_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip();status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=W).decode();(O/'current-status.txt').write_text(status)
out={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'assessment':'verified_bounded_full_and_static_audit_evidence','full':{'commit':commit,'package_count':len(rows),'totals':sums,'packages':rows,'root_command_receipt':results,'tracked_count':len(before),'before_after_identical':True,'git_path_set_equal':True,'initial_generated_dist_differ_from_git_only':gitdiff,'current_head_at_verification':current_head,'later_docs_and_changeset_not_relabelled_full':True},'source_bindings':sources,'audit':{'verdict':'PASS_WITH_CONCERNS','confirmed_defects_reported':0,'actual_modelUsage_keys':list(resp['modelUsage']),'one_turn':resp['num_turns'],'tools':j(R/'audit/argv.json'),'all_three_source_files_exact_in_prompt':True,'response_hash_matches_dispositions':True,'limitation':'Actual static tool-less review; its pending full/independent language belongs to audit time, not evidence that later tests were run by reviewer. Optional rename/binary coverage and pre-existing limitations remain opinions/limits, not reproduced bugs.'},'limits':['No test/build/model rerun by independent verifier.','Source equality verified for actual native snapshots, audit inputs, tested commit and current source; full belongs only to cd30b6cc tree and supplied recorded before/after.','Later docs/changeset edits have not received this whole-tree full run.','No provider identity or formal/local_verified qualification claim; original Node26 BLOCKED retained.']}
(O/'report.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
paths=['validation/full.log','validation/full-before.json','validation/full-after.json','validation/full-binding.json','validation/results.json','audit/prompt.txt','audit/response.json','audit/input-manifest.json','audit/dispositions.json','audit/argv.json','audit/process.json']
(O/'input-hashes.json').write_text(json.dumps([{'path':p,'bytes':(R/p).stat().st_size,'sha256':H((R/p).read_bytes())} for p in paths],indent=2)+'\n')
print(json.dumps({'totals':sums,'tracked':len(before),'initial_dirty':gitdiff,'sources':sources,'receipt':results},indent=2))
