# 最终 full 与实际审计绑定核验

独立从完整 full.log 的 22 个唯一 package Tests 汇总得 **7,449 passed / 5 skipped / 0 failed**，无重复计数。命令回执记录 pnpm test exit 0，约 506.37 秒，绑定 `cd30b6ccddbd0e02d5607683a97c36d3ba96db11`。

运行前后 **9,172 个 tracked 路径及全部 SHA256 完全相同**。另逐 Git blob 核对测试提交：仅最初已有的四份 knowledge/dist 与 Git 不同，恰好符合 initial_dirty 声明；它们在 full 前后未变。后续文档与 changeset note 编辑未获得此 whole-tree full 结果，不可改标成后续提交全仓已测。

两份实际 native 产出的源码与抢先保存的 native 快照、审计输入、full 测试提交、当前源文件逐字一致：

- discover.ts：`3f5fa285f338753dfe54d421ba48fe47212ebe47f2024cfa6ca4a92991fabf0c`
- discover.test.ts：`12cac79a44b14d1029361f8281f35c6217de9ab517c67c5a98e12ac521176f06`

审计 input-manifest 的三份源文件（含 types.ts）均核 bytes/hash，完整文本确实在实际 prompt 中。原 response.json hash 与 dispositions 绑定一致；实际回报 modelUsage 包含 claude-sonnet-5-5，一轮结果 **PASS_WITH_CONCERNS，无确认缺陷**。argv 禁用工具，审计自述未运行测试；其“full/独立向量 pending”属于审计当时状态，不是后续执行缺失，也不是审计者跑过这些验证。rename/binary 覆盖、diff_stat 表示变化、原有大输出/非 UTF-8 等意见保留其可选或未复现范围。

本次只读核原件，无新测试、build、模型调用。Assisted U1 与原 Node26 BLOCKED 结论保持，不升级正式资格或 local_verified。核验脚本、22 包明细和输入 hash 已保存；此目录停止写入，待包外归档验证。
