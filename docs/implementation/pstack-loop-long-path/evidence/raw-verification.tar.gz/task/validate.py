from pathlib import Path
import subprocess,hashlib,json,os,time
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-permission-preflight');o=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-loop-long-path-20261030/validation');o.mkdir(exist_ok=True)
env=dict(os.environ,PATH='/opt/homebrew/opt/node@22/bin:'+os.environ['PATH'],OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
def snapshot():
 return {p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in subprocess.check_output(['git','ls-files','-z'],cwd=w).decode().split('\0') if p and (w/p).is_file()}
pre=snapshot();(o/'full-before.json').write_text(json.dumps(pre,indent=2)+'\n');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();results=[]
for name,cmd in [('full',['pnpm','test']),('typecheck',['pnpm','typecheck:check']),('lint',['pnpm','lint']),('inventory',['node','scripts/generate-inventory.mjs','--check'])]:
 t=time.time()
 with (o/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append(dict(name=name,argv=cmd,exit_code=r.returncode,elapsed_seconds=time.time()-t,head=head));(o/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 if name=='full':
  post=snapshot();(o/'full-after.json').write_text(json.dumps(post,indent=2)+'\n');(o/'full-binding.json').write_text(json.dumps(dict(head=head,count_before=len(pre),count_after=len(post),bytes_equal=pre==post,changed=[k for k in set(pre)|set(post) if pre.get(k)!=post.get(k)],initial_dirty=subprocess.check_output(['git','status','--short'],cwd=w).decode()),indent=2)+'\n')
 if r.returncode:break
print(json.dumps(results))
