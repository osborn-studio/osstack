import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
const [checkoutArg, outputArg] = process.argv.slice(2);
if (!checkoutArg || !outputArg) throw Error('usage: harness.mjs CHECKOUT NEW_OUTPUT');
const checkout = resolve(checkoutArg), output = resolve(outputArg);
mkdirSync(output);
const started = new Date().toISOString();
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const harness = readFileSync(new URL(import.meta.url));
const vectorsBytes = readFileSync(new URL('./vectors.json', import.meta.url));
const vectors = JSON.parse(vectorsBytes);
if (hash(vectorsBytes) !== '16368b4cece4493ec8ac38046946efe0c0d78724f489e11fb2799ea6ba27e967') throw Error('frozen vectors drift');
const home = join(output, 'home'), template = join(output, 'empty-template');
mkdirSync(home); mkdirSync(template);
for (const key of Object.keys(process.env)) if (key.startsWith('GIT_')) delete process.env[key];
Object.assign(process.env, { HOME: home, GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_SYSTEM: '/dev/null', GIT_OPTIONAL_LOCKS: '0', OSSTACK_SCRATCH_ROOT: output, OSSTACK_HOME: join(output,'unused-home') });
const envRecord = Object.fromEntries(['PATH','HOME','GIT_CONFIG_NOSYSTEM','GIT_CONFIG_GLOBAL','GIT_CONFIG_SYSTEM','GIT_OPTIONAL_LOCKS','OSSTACK_SCRATCH_ROOT','OSSTACK_HOME','COLUMNS','TERM'].filter(k=>process.env[k]!==undefined).map(k=>[k,process.env[k]]));
let seq=0; const commands=[];
function git(args,cwd) {
  const start=new Date().toISOString(), child=spawnSync('git',args,{cwd,env:process.env});
  const label='git-'+String(seq++).padStart(3,'0');
  writeFileSync(join(output,label+'.stdout'),child.stdout??Buffer.alloc(0)); writeFileSync(join(output,label+'.stderr'),child.stderr??Buffer.alloc(0));
  commands.push({argv:['git',...args],cwd,start,end:new Date().toISOString(),exit:child.status,signal:child.signal,error:child.error?.message,stdout:label+'.stdout',stderr:label+'.stderr'});
  if(child.status!==0) throw Error('Git fixture/read failed: '+label);
  return child.stdout;
}
const buildPaths=['packages/loop/dist/index.js','packages/loop/dist/discover.js'];
const sourcePaths=['packages/loop/src/discover.ts','packages/loop/src/discover.test.ts'];
function snapshot(label, paths) {
 return paths.map((path,i)=>{
   const bytes=readFileSync(join(checkout,path));
   writeFileSync(join(output,label+'-'+i+'.blob'),bytes);
   return {path,bytes:bytes.length,sha256:hash(bytes)};
 });
}
const before={build:snapshot('build-before',buildPaths),source_observed:snapshot('source-before',sourcePaths)};
writeFileSync(join(output,'pre-run-binding.json'),JSON.stringify({started,checkout,node:process.version,execPath:process.execPath,harness_sha256:hash(harness),vectors_sha256:hash(vectorsBytes),env:envRecord,...before},null,2)+'\n');
const {GitDiffScanner}=await import(pathToFileURL(join(checkout,'packages/loop/dist/index.js')).href);
git(['--version'],output);
const results=[];
for(const vector of vectors.vectors) {
 const fixture=join(output,vector.id);mkdirSync(fixture);
 git(['init','--quiet','--template='+template],fixture);
 for(const file of vector.files) {const path=join(fixture,file.path);mkdirSync(dirname(path),{recursive:true});writeFileSync(path,file.index_text);}
 git(['add','--',...vector.files.map(f=>f.path)],fixture);
 for(const file of vector.files) writeFileSync(join(fixture,file.path),file.worktree_text);
 const indexBefore=hash(readFileSync(join(fixture,'.git/index')));
 const filesBefore=vector.files.map(f=>({path:f.path,sha256:hash(readFileSync(join(fixture,f.path)))}));
 git(['diff','--stat'],fixture);
 git(['diff','--numstat','-z'],fixture);
 let tasks=[],error=null;try {tasks=await new GitDiffScanner(fixture).scan();}catch(e){error={name:e.name,message:e.message,stack:e.stack};}
 const expected=vector.files.filter(f=>f.expected_change_lines>0);
 const checks=[];
 const check=(name,pass,details={})=>checks.push({name,pass,...details});
 check('scan_did_not_throw',error===null,{error});
 check('task_count',tasks.length===vector.expected_task_count,{expected:vector.expected_task_count,actual:tasks.length});
 const actual=tasks.map(t=>t.context?.file);
 check('exact_unique_paths',actual.length===expected.length && new Set(actual).size===expected.length && expected.every(f=>actual.includes(f.path)),{expected:expected.map(f=>f.path),actual});
 for(const f of expected) {
  const matching=tasks.filter(t=>t.context?.file===f.path), task=matching[0];
  check('one_task_for:'+f.path,matching.length===1);
  check('exact_target_exists:'+f.path,task!==undefined && existsSync(join(fixture,task.context.file)));
  check('task_shape:'+f.path,task?.capability==='code.review' && task?.source==='git_diff');
  check('literal_prompt:'+f.path,typeof task?.prompt==='string' && task.prompt.includes(f.path));
  check('change_lines:'+f.path,task?.context?.change_lines===f.expected_change_lines,{expected:f.expected_change_lines,actual:task?.context?.change_lines??null});
  check('priority:'+f.path,task?.priority===f.expected_priority,{expected:f.expected_priority,actual:task?.priority??null});
 }
 check('priority_descending',tasks.every((t,i)=>i===0||tasks[i-1].priority>=t.priority));
 check('excluded_unchanged', (vector.excluded_paths??[]).every(p=>!actual.includes(p)));
 check('index_unchanged',hash(readFileSync(join(fixture,'.git/index')))===indexBefore);
 check('file_bytes_unchanged',filesBefore.every(f=>hash(readFileSync(join(fixture,f.path)))===f.sha256));
 results.push({id:vector.id,fixture,passed:checks.every(c=>c.pass),checks,tasks,index_before_sha256:indexBefore,files_before:filesBefore});
}
const after={build:snapshot('build-after',buildPaths),source_observed:snapshot('source-after',sourcePaths)};
const buildUnchanged=JSON.stringify(before.build)===JSON.stringify(after.build);
const report={started,ended:new Date().toISOString(),checkout,node:process.version,execPath:process.execPath,harness_sha256:hash(harness),vectors_sha256:hash(vectorsBytes),before,after,build_unchanged:buildUnchanged,source_unchanged:JSON.stringify(before.source_observed)===JSON.stringify(after.source_observed),source_matches_original_baseline:before.source_observed[0].sha256===vectors.source_binding.source_sha256,dist_matches_original_baseline:before.build[1].sha256===vectors.source_binding.build_sha256,results,summary:{passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length,total:results.length},limits:['Actual scanner only, no task execution or adapters.','Source may change during native work; source snapshots are observations, not executed module identity.','Build stability is required for result validity.','Multiple failing vectors describe one path-identity defect, not multiple product bugs.']};
writeFileSync(join(output,'commands.json'),JSON.stringify(commands,null,2)+'\n');
writeFileSync(join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
process.exitCode=buildUnchanged && report.summary.failed===0 ? 0 : 1;
