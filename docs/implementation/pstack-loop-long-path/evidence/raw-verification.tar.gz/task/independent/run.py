from pathlib import Path
import subprocess,os,sys,json,datetime
s=Path(__file__).parent
phase=sys.argv[1]
argv=['/opt/homebrew/opt/node@22/bin/node',str(s/'harness.mjs'),'/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/pstack-permission-preflight',str(s/phase)]
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin'
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(argv,capture_output=True,env=env)
(s/(phase+'.stdout')).write_bytes(p.stdout);(s/(phase+'.stderr')).write_bytes(p.stderr)
meta=dict(argv=argv,cwd=str(Path.cwd()),env={'PATH':env['PATH']},start=start,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=p.returncode)
(s/(phase+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
if (s/phase/'report.json').exists():
 r=json.loads((s/phase/'report.json').read_text());print(json.dumps({k:r[k] for k in ['summary','build_unchanged','source_unchanged','source_matches_original_baseline','dist_matches_original_baseline']}))
else:print(p.stderr.decode()[-2500:])
