# Independent scanner acceptance result

The same frozen harness and four frozen vectors were executed twice: old dist exit1 with 3 failing long-path cases and 1 passing legal control; fresh root-built dist exit0 with 4/4 cases passing. The three old failures are manifestations of one target-path identity defect, not three separate product bugs. Neither harness nor vector bytes changed.

Harness SHA256: 536c626d9578f42cf919c74bc153051263722fa188fcde8c943d9f028cbcc3c3. Vector SHA256: 16368b4cece4493ec8ac38046946efe0c0d78724f489e11fb2799ea6ba27e967.

New source discover.ts SHA256 3f5fa285f338753dfe54d421ba48fe47212ebe47f2024cfa6ca4a92991fabf0c; test source 12cac79a44b14d1029361f8281f35c6217de9ab517c67c5a98e12ac521176f06. New executed discover.js SHA256 34303a8e5f0a0f74ab00063237c5a8e007276a950420b0ab647d29e3afcd28ca. Public index.js stays b172f8282df8e44ab0ffe0d489241af0d8200ae45aea4f4a6cf62ca55ef17b60. Source/test match root native-candidate bytes; source and executed modules remained unchanged during new run. Root performed the fresh build; this independent task did not build.

New results verify exact long ASCII paths, short-file controls, counts and priority order (4 modified lines→20, 2→10), two distinct long neighbors with identical tails, ordinary internal-space path, and unchanged-file exclusion. Every case checks fixture index/file bytes remained unchanged. All emitted tasks are captured; none were executed.

## Read-only numstat contract review

- The switch uses NUL-separated records and separate insertion/deletion fields, preserving the complete pathname for the frozen cases. Counts are their sum, and existing min(changes*5,100) priority is retained.
- Binary records with '-' counts are explicitly skipped. Old stat output's 'Bin' field did not match its numeric-count regex, so skipping binaries is consistent with the old behavior. No binary runtime case was added or claimed.
- Empty filename fields consume the following old/new pathname records and select the new path. This follows the intended machine record framing; no actual rename fixture was executed here. Rename detection/mode/configuration remains outside this narrow acceptance, and no broader Git-state support is asserted.
- context.diff_stat now contains the raw numeric numstat record, not the old decorative stat line. For the rename branch that raw header alone would not contain the destination pathname; context.file still supplies it. This is a visible payload-content change, not silently identical presentation.
- A source search for the exact diff_stat field found only this producer under packages; Task context is an open z.record(z.unknown()), with no typed display-string contract or internal parser found. No concrete internal regression was identified, so tests were not broadened. External consumers of that informal context field were not audited or certified.

## Evidence and limits

comparison.json joins exact old/new hashes and results. new-dist/ and new-dist.stdout/.stderr/.json preserve raw output, command/env/time/exit, source/build snapshots, per-case Git logs and fixture content. old-payload-verification.json confirms every payload in the earlier old-manifest remains byte-identical. The original README is intentionally preserved as the historical pending-stage note; this file records the completed independent comparison.

This proves bounded scanner behavior over four declared local fixtures. It does not independently prove the native model's method consumption, overall Loop/host/card flow, permission enforcement, formal admission, current-main acceptance, all Git states or a full suite. Those require root's separate records. No product/test edit, model, adapter, DB, build or full-suite run occurred in this independent check.
