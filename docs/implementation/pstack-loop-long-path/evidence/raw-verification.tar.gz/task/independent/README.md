# Independent scanner acceptance

The earlier frozen four vectors were implemented as one harness before execution. Harness SHA256 536c626d9578f42cf919c74bc153051263722fa188fcde8c943d9f028cbcc3c3; vectors SHA256 16368b4cece4493ec8ac38046946efe0c0d78724f489e11fb2799ea6ba27e967.

Actual old-dist result: exit1, three failing long-path vectors and one passing ordinary-space/short-neighbor control. These are three manifestations of one path-identity bug, not three product bugs. The long+short vector still records the short file checks, counts and priorities. Old built discover.js remained c2bb37d0bff91c8da4ea2442254c892c218f114a4d89df9390525043c4be8fdf before/after. Source snapshot at this run still matched original ba21266e and was unchanged during this short probe; that is a timed observation, not an assumption about ongoing native work.

All raw tasks/checks, Git fixture commands/stdout/stderr, file/index before hashes, source/build blobs, runtime/path, argv/cwd/env/times/exit and full process output are retained. No task was executed, no adapter/model/DB was called and no build or product/test file was changed.

New-dist execution is pending root's native completion and fresh build. The exact same harness and frozen vectors must be reused in a new output directory; do not overwrite old results or rebuild as part of this independent check.
