from pathlib import Path
import json,hashlib,subprocess,shlex,datetime,stat
R=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-loop-long-path-20261030'); O=R/'independent-native'
W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-permission-preflight')
H=lambda b:hashlib.sha256(b).hexdigest()
def j(p):return json.loads(p.read_text())
def write(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
freeze=j(R/'freeze.json'); inv=j(R/'run/invocation-start.json'); events=[json.loads(l) for l in (R/'run/native.stdout.jsonl').read_text().splitlines()]; exit=j(R/'run/native-exit.json')
checks={}; checks['frozen_input_hashes']={n:H((R/n).read_bytes())==h for n,h in freeze['inputs'].items()}
assert all(checks['frozen_input_hashes'].values())
checks['frozen_vectors_hash']=H((R/'independent/vectors.json').read_bytes())==freeze['independent_vectors_sha256']; assert checks['frozen_vectors_hash']
start=datetime.datetime.fromtimestamp(inv['started_unix'],datetime.timezone.utc); assert datetime.datetime.fromisoformat(freeze['frozen_at'])<start
checks['runtime_seconds']=exit['ended_unix']-inv['started_unix']; assert checks['runtime_seconds']<600 and exit['exit_code']==0 and not exit['signals']
assert sum(e['type']=='turn.started' for e in events)==sum(e['type']=='turn.completed' for e in events)==1
argv=inv['argv']; assert argv[:9]==['exec','--json','--skip-git-repo-check','-s','workspace-write','-C',str(W.resolve()),'--add-dir',str(R/'task-scratch')]
prompt=argv[-1]; promptb=prompt.encode(); body=prompt.split('<OSSTACK_METHOD_REFERENCE_V1>\n',1)[1].rsplit('\n</OSSTACK_METHOD_REFERENCE_V1>',1)[0]; md=json.loads(body.split('\n',1)[1]); material=md['materials'][0]; b=(R/'prepared-bundle-v2/builder.md').read_bytes(); assert material['text'].encode()==b and len(b)==32286 and H(b)==material['sha256']
checks['actual_argv_prompt']={'bytes':len(promptb),'sha256':H(promptb),'material_bytes':len(b),'material_sha256':H(b),'complete_material_byte_match':True,'provider_wire':'not_attested'}
receipts=[]
for ref in j(R/'run/context-receipt-refs.json'):
 p=Path(ref['path']); d=j(p); assert H(p.read_bytes())==ref['digest']; assert d['prompt_sha256']==H(promptb) and d['prompt_bytes']==len(promptb)
 m=d['method_context']; assert m['material_bytes']==len(b) and m['materials'][0]['sha256']==H(b)
 cb=(W/m['compiled']['path']).read_bytes(); assert H(cb)==m['compiled']['sha256'] and len(cb)==m['compiled']['bytes']
 assert (W/m['materials'][0]['path']).read_bytes()==b
 assert d['task_id']==freeze['task_id'] and d['repo_path']==str(W.resolve()) and m['task_id']==freeze['task_id']
 receipts.append({'path':str(p),'sha256':ref['digest'],'phase':d['phase'],'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sampled_at_ms':d['sampled_at_ms'],'observed_at_ms':d.get('observed_at_ms'),'method_context':m})
assert [x['phase'] for x in receipts]==['prepared','adapter_observed'];checks['receipts']=receipts
before=j(R/'product-before.json'); after=j(O/'tracked-current.json'); changed=[n for n in before if before[n]!=after.get(n)]; assert sorted(changed)==sorted(freeze['write_scope']); assert before.keys()==after.keys()
checks['tracked_snapshot']={'count':len(before),'changed':changed,'unchanged':len(before)-len(changed),'path_set_same':True,'sample_time':j(O/'candidate-source/binding.json')['at_utc'],'initial_fresh_dist_unchanged':all(before[n]==after[n] for n in before if n.startswith('packages/knowledge/dist/'))}
# Compare the captured native files against original Git, independent of later formatting.
oldtest=subprocess.check_output(['git','show',freeze['parent']+':packages/loop/src/discover.test.ts'],cwd=W).decode()
newtest=(O/'candidate-source/packages/loop/src/discover.test.ts').read_text(); a=newtest.index('  it("GitDiffScanner preserves full long ASCII paths"'); z=newtest.index('  it("createScanner should create',a)
rest=newtest[:a]+newtest[z:]; rest=rest.replace('mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync','mkdirSync, mkdtempSync, writeFileSync'); assert rest==oldtest
checks['original_test_bytes_preserved_except_new_test_and_imports']=True
commands=[]
for i,e in enumerate(events):
 it=e.get('item',{})
 if e['type']=='item.completed' and it.get('type')=='command_execution':
  sh=shlex.split(it['command']); assert sh[:2]==['/bin/zsh','-lc'] and len(sh)==3
  out=it['aggregated_output']; commands.append({'event_index_zero_based':i,'item_id':it['id'],'actual_command':it['command'],'shell_body':sh[2],'exit_code':it['exit_code'],'output_bytes':len(out.encode()),'output_sha256':H(out.encode())})
products=[c for c in commands if 'vitest.mjs' in c['shell_body']]; expected=freeze['check_registry']['commands']; assert [c['shell_body'] for c in products]==[expected['repro'],expected['repro'],expected['regress'],expected['accept']]; assert [c['exit_code'] for c in products]==[1,0,0,0]
assert [c['event_index_zero_based'] for c in products]==[14,19,21,23]
changes=[{'index':i,**e['item']} for i,e in enumerate(events) if e['type']=='item.completed' and e.get('item',{}).get('type')=='file_change']; assert [c['index'] for c in changes]==[12,17]
assert changes[0]['changes'][0]['path'].endswith('/discover.test.ts') and changes[1]['changes'][0]['path'].endswith('/discover.ts')
assert 'AssertionError:' in events[14]['item']['aggregated_output'] and '.../ordinary-directory-abcdefghij/target.ts' in events[14]['item']['aggregated_output']; assert 'Tests  9 passed (9)' in events[23]['item']['aggregated_output']
# Match all observed read output to retained source bytes or frozen Git. No command is rerun.
readmatches=[]
for c in commands:
 if 'vitest.mjs' in c['shell_body']:continue
 args=shlex.split(c['shell_body']); rel=args[-1]
 if c['event_index_zero_based']<12:data=subprocess.check_output(['git','show',freeze['parent']+':'+rel],cwd=W)
 else:data=(O/'candidate-source'/rel).read_bytes()
 if args[0]=='sed':
  lo,hi=map(int,args[2].rstrip('p').split(','));data=b''.join(data.splitlines(keepends=True)[lo-1:hi])
 assert H(data)==c['output_sha256'];readmatches.append({'index':c['event_index_zero_based'],'path':rel,'bytes':len(data),'sha256':H(data),'matches':True})
checks['read_output_matches']=readmatches
checks['native_sequence']={'commands':commands,'file_changes':changes,'product_checks':products,'same_test_assessment':'One test update before RED and no later test update in complete captured event stream; original assertions intact in final source. No per-phase RED file hash was recorded, so exact historical test bytes are supported by trace, not independently time-snapshotted.'}
result=j(R/'run/result.json'); verifier=j(R/'run/host-verifier.json'); task=result['completedTasks'][0]; assert task['outcome']=='success' and task['iterations']==1 and verifier['verdict']['pass']; assert [x['exit_code'] for x in verifier['verdict']['verify_commands']]==[0,0]
checks['host_loop']={'loop_id':result['loop_id'],'run_id':task['run_id'],'outcome':task['outcome'],'iterations':task['iterations'],'commands':verifier['verdict']['verify_commands'],'artifact_gate_claim':next(x for x in verifier['verdict']['evaluations'] if x['spec_id']=='verify-artifact'),'note':'Artifact gate counted 16 total dirty/untracked paths; independent before/after isolates only 2 native product edits. This gate alone is not a two-file write fence.'}
setup=j(R/'setup-binding.json'); chunk=Path(setup.get('host_chunk',str(W/'packages/cli/dist/execution-context-host-56HZY76J.js'))); checks['host_chunk_current_hash']=H(chunk.read_bytes());assert checks['host_chunk_current_hash']==j(R/'run/dispatch.json')['host_chunk_sha256']
prepared=[]
for directory,name in [('prepared-bundle','pstack-long-path-methods'),('prepared-bundle-v2','pstack-long-path-methods-v2')]:
 for f in (R/directory).glob('*'):
  assert f.read_bytes()==(W/name/f.name).read_bytes(); prepared.append({'path':name+'/'+f.name,'bytes':f.stat().st_size,'sha256':H(f.read_bytes()),'matches_prepared_copy':True})
checks['untracked_preparation_files']=prepared
checks['scope_limits']=['Only tracked inventory and Git-visible untracked files were compared; no global filesystem/ignored-file inventory or proof of all side effects.','Native trace has no patch payload or per-test-phase file hash; source attribution uses file_change sequence, exact readback and immediate snapshot.','The material is complete at recorded AgentTask/adapter argv boundary; provider wire, model comprehension, resolved model identity, environment purity, principal identity and universal sandbox bounds are not attested.','Workspace-write permits whole isolated workspace; two-file task scope is a task instruction and observed after-state, not an OS write fence.','Task/card/board mapping is explicit manual context; tenant null in task and default in receipts, no automatic card foreign key or board write proved.','Host reports local verifier success; this is assisted U1, not formal qualification or local_verified promotion. Original Node26 packet remains BLOCKED.','No product test, build, model call or executable probe was rerun by this verifier.']
checks['assessment']='bounded_native_repair_evidence_supported_with_stated_limits';checks['created_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
write('verification.json',checks)
paths=list(freeze['inputs'])+['freeze.json','run/result.json','run/host-verifier.json','run/dispatch.json','run/invocation-start.json','run/native.stdout.jsonl','run/native.stderr.log','run/native-exit.json','run/context-receipt-refs.json','preparation-correction.json']
inputs=[{'path':str(R/n),'bytes':(R/n).stat().st_size,'sha256':H((R/n).read_bytes())} for n in paths]
inputs.extend({'path':x['path'],'bytes':Path(x['path']).stat().st_size,'sha256':x['sha256']} for x in receipts);write('input-hashes.json',inputs)
print(json.dumps({'assessment':checks['assessment'],'tracked':checks['tracked_snapshot'],'commands':len(commands),'receipts':len(receipts),'runtime':checks['runtime_seconds']},indent=2))
