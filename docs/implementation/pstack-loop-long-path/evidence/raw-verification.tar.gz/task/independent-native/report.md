# Native long-path 修复独立核验

结论：**本次有界 native 修复闭环的实际证据成立，保留下列限制。** 原 Node26 packet 仍是 BLOCKED，未复跑或升级。此报告只审核既有原件，没有运行产品测试、build 或模型。

## 实际执行

冻结在 11:51:15.241815 UTC，调用开始 11:51:16.152397 UTC，结束 11:53:43.588937 UTC；约 147.44 秒，低于 600 秒。一条 turn.started 和一条 turn.completed，launcher exit 0，无终止信号。记录中有 10 条完成的 shell 工具命令（6 次允许的源码/配置读取、4 次测试）以及两次 file_change。所有读取返回的字节均与原 Git 或抢先保存的 native 源码相符。

按 JSONL 的零基事件索引：

| 事件 | 实际行为 | 结果 |
|---|---|---|
| 12 | 只更新 discover.test.ts | 新增真实 Git 长 ASCII 路径测试 |
| 14 | 新命名测试、旧实现 | exit 1；预期完整 219 字符路径，实际截短为 `.../ordinary-directory-abcdefghij/target.ts` |
| 17 | 更新 discover.ts | 使用 NUL 分隔 numeric diff 数据保留文件名 |
| 19 | 同一命名测试命令 | exit 0，1 pass / 8 因选择器未运行 |
| 21 | 原优先级控制命令 | exit 0，1 pass / 8 因选择器未运行 |
| 23 | PRIMARY 整个 discover.test.ts | exit 0，9 pass，没有跳过 |

RED 是真实行为断言失败，非测试启动或 missing-module 错误。完整事件流在 RED 后没有再次修改测试；最终 diff 逐字保留所有原测试，仅新增测试和所需 imports。原件没有记录 RED 时完整测试文件 hash，因此“同测试”由事件顺序、断言位置与最终文件支持，不能冒称当时独立文件快照。工具命令外层均是 `/bin/zsh -lc`，内层每条为独立授权命令；没有额外链式命令或 fallback。测试内部已有 Git fixture 初始化/commit 属于授权测试行为，不是产品仓库提交。

Host Loop 随后独立运行原优先级控制和 PRIMARY，均 exit 0；Loop 记录一轮 success，local-verifier 的两个命令和 artifact gate 通过。模型自身 4 次测试和随后 host 2 次检查分别保留，不能合并冒称一个外部 oracle。

## 材料与执行边界

实际 adapter argv 的最终 prompt 是 **36,405 bytes**，SHA256 `2da94bd0e1bf182d76f11f3211b8bc1b97b7bce3fe57d97cb0ba99fcabfd0d13`。其中 JSON 转义的 builder 解码后为 **32,286 bytes**，逐字等于 prepared-bundle-v2 和工作区原件，SHA256 `5f7ed62b3f5202894712c2dcff140b220fbb6ae5d35e71d64724f07ef9a0cdfd`。这是固定版本的选定完整材料组合，不是递归全上游技能包。

两份持久化记录（prepared、adapter_observed）均逐文件重算 digest 成立，并绑定同 task/run/repo、实际 prompt hash、builder bytes/hash 与 compiled 文件 bytes/hash。字段明确 `agent_task_prompt_not_provider_wire`、`caller_declared`、`untrusted_reference`、`recompiled_caller_facts`。实际 argv 采用 workspace-write，唯一 `--add-dir` 是本任务 task-scratch；root 包装器附加 approval_policy=never。没有 provider 内部 wire、模型理解、认证 principal、resolved model、认证环境纯度或完整后代清理证明。

## 写入范围和原件归属

11:56:28.898703 UTC 在 root 格式化之前保存两份 native 源码。对 product-before 的 **9,171 个 tracked 路径**独立逐 hash 比较：只有两个授权文件变化；其余 9,169 个一致，路径集合相同。初始四份 knowledge/dist 相对 Git 脏，但相对本轮 before 未变。

- discover.ts：`3f5fa285f338753dfe54d421ba48fe47212ebe47f2024cfa6ca4a92991fabf0c`
- discover.test.ts：`12cac79a44b14d1029361f8281f35c6217de9ab517c67c5a98e12ac521176f06`

Git-visible 的 10 个 untracked 文件全部属于两份 root 准备的 method bundle，并与 scratch prepared copies 逐字相同；v2 是冻结前修正 219 字符描述后另存的新包，原包保留。Host artifact gate 报告的 16 个 dirty/untracked 路径包含这 10 个准备文件和 4 个初始 dist，不能说 native 新改了 16 个文件。该 gate 本身也不是两文件白名单证明。

未做全机器或 ignored 文件 inventory；不声称没有任何其他临时产物或全部副作用。workspace-write 是整个隔离工作区权限，两个文件限制来自任务约定和实际 after-state，不是 OS 两文件围栏。源码 context.diff_stat 现在是 numeric record，模型已披露；本报告不将命名路径测试推广成所有 Git/binary/rename 政策已通过。

Task/card/board 在 freeze、任务正文和 Loop context 明确一致；这是手工回链，native_task_id/tenant_id 仍 null，回执 tenant 为 default，不证明自动外键或看板写入。结论限 assisted U1；不升级 formal qualification 或 `local_verified`。

完整机器检查及路径/hash 见 verification.json、input-hashes.json；raw JSONL/回执保留在原 run/home 目录。源快照、Git diff 和核验脚本在本目录。之后 root 格式化或提交需单独绑定，不回写此 native 输出快照。
