import {GitDiffScanner} from "/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/pstack-permission-preflight/packages/loop/dist/index.js";
const tasks=await new GitDiffScanner("/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-permission-preflight-20261030/scanner-baseline/fixture").scan();
const expected=["ordinary-directory-abcdefghij/ordinary-directory-abcdefghij/ordinary-directory-abcdefghij/ordinary-directory-abcdefghij/ordinary-directory-abcdefghij/ordinary-directory-abcdefghij/ordinary-directory-abcdefghij/target.ts", "short.ts"];
const actual=tasks.map(x=>x.context.file);
console.log(JSON.stringify({expected,actual,tasks},null,2));
process.exit(actual.length===2 && expected.every(x=>actual.includes(x))?0:1);
