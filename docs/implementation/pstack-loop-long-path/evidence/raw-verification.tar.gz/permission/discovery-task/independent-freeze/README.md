# Independent scanner acceptance freeze

The root fresh-build baseline is a real scanner RED: exit1, long file returned as .../ordinary-directory-abcdefghij/target.ts, short.ts correct. Its source SHA, discover.js SHA, probe SHA, public index re-export, JSON outputs, and both tracked index/worktree contents were independently read and verified. Full originals and build log are copied here. This review does not re-run the scanner or claim a fresh independent execution.

vectors.json freezes four bounded cases before repair: original long ASCII path plus short control; exact change counts and descending priority; two distinct long neighboring paths with identical tails; ordinary internal-space/short neighboring paths with an untouched tracked file excluded. Cases beyond the root baseline remain unexecuted. Expected values come from fixture literals, not proposed implementation output.

Only exact changed-file target preservation and existing counts/priority are required. UUIDs, tie ordering and decorative diff_stat width are not test oracles. No staged/untracked/rename/binary behavior rewrite, full Git coverage, new scheduler, DB, model, or provider call is required. The separate native permission diagnostic does not establish P6. No product implementation or patch is supplied.

Original discovery report and scanner-baseline inputs remain unchanged. verification.json contains read-only checks and command metadata; manifest.json binds this new directory excluding itself.
