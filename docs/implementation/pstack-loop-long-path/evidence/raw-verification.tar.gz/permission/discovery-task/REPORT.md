# Loop long-path discovery candidate

Frozen Git: e5d23c02cb417791d7004f39887c57ed9a10c38a. Context-aware read-only diagnosis. No product/test edit, Loop run, database, model, full, worktree creation or central write occurred.

## Candidate and evidence strength

The existing GitDiffScanner derives the actual target file and review prompt from the human-readable file column of git diff --stat. Long valid repository-relative paths can be shortened by Git's display formatting. The scanner then records that abbreviated label as context.file and instructs the reviewer to review it. A user using Loop git_diff discovery on an ordinary deeply nested source file can therefore receive a task targeting a nonexistent .../suffix path.

This is a concrete functional target-identity issue, not optional security hardening. It is unrelated to the closed alias/offguard cases and old Node26 packet. Source history still contains this implementation; the current isolated checkout matches the frozen source. The inspected published debt snapshot and discover tests did not contain a closure or regression for this path. That limited search does not prove no external issue exists.

A readonly Git command was actually executed twice during diagnosis (first visible tool read, second retained exactly here): git diff --no-index --stat /dev/null against an existing long-path repository document. Both produced an abbreviated .../boards-published/joint-firstmate-pstack.json label. Its input file exists, the label interpreted as a workspace path does not, and the exact regex used by the scanner captures that label. Exit1 is Git's expected difference result. This only examines a repository document's stat; no Firstmate runtime or content workflow was invoked.

Important limit: this is an actual Git display observation plus source analysis, not a fresh scan() reproduction. The readonly no-index command is a formatting control, not the scanner's git diff --stat invocation. A scratch tracked-file fixture below must confirm the normal invocation before accepting this candidate for assisted execution.

## Current user route and exact source

- packages/cli/src/bin.ts handleLoopCommand, around10212–10243: existing loop start takes workspace and repeated --source options.
- packages/loop/src/loop-engine.ts:543 calls discover; :856–864 constructs the declared scanners. git_diff is a default discovery source.
- packages/loop/src/discover.ts:44 executes git diff --stat; :57 extracts its display label; :60 stores file; :66 uses file in the review prompt; :69–72 stores the context. No conversion back to an actual repository pathname occurs.
- packages/loop/src/executor.ts:208 forwards plan.task.prompt into the agent task, with workspace repo_path at:211.
- packages/loop/src/discover.test.ts:37–53 only covers small.ts and large.ts for this scanner; it does not cover long filenames.

Thus the user-facing expectation is a review task identifying the exact changed file under the declared workspace. The observed formatting and current code imply an abbreviated target instead. This is not a claim that every agent fails: a model might infer the real file, but the deterministic task's target is still wrong.

## Smallest non-product-modifying reproduction proposal

Do not run a live Loop, use a DB, or invoke an adapter. Root can run a single scratch-only Node probe after the checkout is built, importing the public GitDiffScanner from the built package (verify the source/build binding first).

1. In a new owned scratch directory, initialize a standalone Git fixture (not a worktree), with isolated Git config and hooks disabled. Create one ASCII path consisting of several ordinary directory components with total path length over200, and a short control file short.ts. Stage their initial contents; a commit is unnecessary because unstaged diff compares worktree to index.
2. Append one line to each file. Capture raw git diff --stat and a machine-readable changed-path listing solely as independent expected-path evidence.
3. Call new GitDiffScanner(fixture).scan() once. Do not execute any produced task.
4. Assert exactly two code.review tasks, and that their context.file set equals the two complete relative paths, with matching prompt filenames. Capture exact output/error and exit. The short-path case is the legal control; the long-path assertion should expose the present bug if Git abbreviates it.
5. Preserve the fixture and raw outputs for the real assisted task; no target source or tests are edited for discovery. If the normal Git command does not abbreviate under the fixture environment, retain the outcome and do not call this a confirmed RED.

A future scoped fix would own discover.ts and a focused discover.test.ts regression only after that RED. Acceptance is exact target-path preservation for that single ordinary long ASCII filename plus the existing short-path/prioritization behavior. No new scheduler, capabilities, models, broad hostile-filename policy, binary handling or unrelated scanner redesign is required for this candidate.

## Freeze status

Candidate ready for one bounded reproduction, **not yet independently confirmed by actual scan() execution**. No solution patch or implementation prescription is supplied. source/ contains complete frozen Git blobs, source-bindings.json records hashes and current-checkout equality, readonly-git-stat.* and display-observation.json retain the actual local observation, operations.json records command metadata. manifest.json binds payloads except itself.
