# 补充：进程级 -c 命令，不写配置文件

Root 优先进程级配置，这可以避免保存私有 config.toml。下面仍是未执行模板；协调者先创建 canonical 的 WORKSPACE、TASK_SCRATCH、NEGATIVE 三个独占目录（第三个目录由外层写入确认普通 OS 可写），另设空 PRIVATE_HOME、PRIVATE_CODEX_HOME。所有目录在新任务 scratch 下，不给共同父根 write。新 profile 名不与现有配置共享。

```sh
env -i PATH=/usr/bin:/bin HOME="$PRIVATE_HOME" CODEX_HOME="$PRIVATE_CODEX_HOME" TMPDIR="$TASK_SCRATCH" \
 /opt/homebrew/bin/codex sandbox --include-managed-config -P osstack_probe_20261030 -C "$WORKSPACE" \
 -c 'permissions.osstack_probe_20261030.filesystem.":root"="deny"' \
 -c 'permissions.osstack_probe_20261030.filesystem.":minimal"="read"' \
 -c "permissions.osstack_probe_20261030.filesystem.\"$WORKSPACE\"=\"write\"" \
 -c "permissions.osstack_probe_20261030.filesystem.\"$TASK_SCRATCH\"=\"write\"" \
 -c "permissions.osstack_probe_20261030.filesystem.\"$NEGATIVE\"=\"read\"" \
 -c 'permissions.osstack_probe_20261030.network.enabled=false' \
 -- /bin/sh -c 'printf "%s\n" probe > "$1"' probe "$TARGET"
```

三次仅更换 TARGET 为 WORKSPACE/probe.txt、TASK_SCRATCH/probe.txt、NEGATIVE/probe.txt。此 shell 模板要求这几个协调者生成路径不含双引号/反斜线/控制字符；更稳妥是协调者通过 argv 数组构造，路径键与 TOML 字符串用 JSON 字符串编码（不经 shell 二次求值）。不添加 `-s`、sandbox_mode、danger flags 或任何 model 命令。

来源：本机 sandbox --help 证明 -c dotted TOML override 与显式 -P 及 --include-managed-config；官方 https://learn.chatgpt.com/docs/permissions 证明 filesystem 表路径→read/write/deny，network.enabled=false 与 :minimal 平台读例外。模板仅基于这些来源，尚无运行验证。

**legacy sandbox_mode 优先级不能过度断言：**官方文档明确普通会话中加载到 legacy sandbox_mode 或显式 --sandbox 时会使用旧系统而非 default_permissions。它没有明确证明独立 sandbox -P 子命令是否也走该优先级。本机帮助称 -P 从 active config stack 选择命名 profile，但这不是完整实现证据。已安装 npm 包无 Rust 源码/schema，嵌入字符串不够证明该分支。因此不声称在任意默认用户配置中 -P 一定胜出。

推荐空私有 CODEX_HOME + HOME、进程级新 profile，既不读/复制原用户配置与 auth，也消除默认用户 legacy 配置干扰。保留 --include-managed-config；系统/管理层如冲突或拒绝，记录启动前 blocked，不能移除约束或当成写入负例。若坚持加载默认用户配置，则上述优先级仍未证，本轮不能给无条件可执行承诺。无模型实际允许/拒绝对照本身应同时验证 profile 效果，但也不覆盖旧 adapter -s/--add-dir 路径。
