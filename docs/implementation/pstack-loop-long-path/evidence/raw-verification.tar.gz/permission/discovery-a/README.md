# Codex CLI 0.160.1 权限格式调查（未执行对照）

结论：本机 `codex sandbox` 直接接受命令，不使用 `macos` 子命令。`-P NAME` 读取命名 permissions profile；`workspace-write` 是旧 sandbox mode，不是该选项的已定义 profile 名。官方内置 profile 名含冒号（如 `:workspace`），但其默认系统临时目录写权限比本次目标宽，因此建议用自定义精确路径 profile。此前缺 `[permissions]` 的失败没有证明目录权限失效。

本机绑定：CLI 0.160.1；native binary SHA256 `09fa44fdc37a5fc70dc1ace31235f90468a2e193d0e85f7552eab068ea2582be`。安装包没有发现可直接使用的本地 JSON 配置 schema；本机 help 提供参数，二进制嵌入字段/报错只作格式交叉证据，不当作执行验证。

官方来源：[Permissions](https://learn.chatgpt.com/docs/permissions)（实际全文已取，工具文本见归档）。该页给出 permissions.<name>.filesystem 路径映射、read/write/deny、network.enabled 和优先级，并说明 macOS 使用 Seatbelt，不能执行的策略应拒绝。`:minimal` 是平台运行时读例外，并非完全无系统访问。文档为当前官方页面，并非固定 0.160.1 源码；实际 help 与嵌入字符串相符，尚未进行配置解析或执行证明。

## 待审查最小对照

`config.template.toml` 是精确模板；`proposed-commands.sh.txt` 给两条完整命令，尚未执行。协调者只在全新独占任务目录创建 work、allowed、denied、home、codex-home、tmp。将模板的占位符替换为真实 canonical 绝对目录，仅写私有 CODEX_HOME/config.toml。不得复制用户配置或认证，不把历史 scratch 根设为 write。

同一 profile 对 work/denied 只读、allowed 可写、其余默认 deny（平台 minimal 读例外），网络关闭。不使用旧 `-s`/sandbox_mode，不继承 `:workspace` 的系统 temp 写权限。`--include-managed-config` 保留管理约束，若命令因此被拒，只记录 blocked，不移除管理规则。

两条命令只改变目标文件路径，固定 `/bin/sh` + printf，无模型、登录shell、网络或产品测试。用 minimal env 避免认证环境继承。协调者须限时并分别记录完整 argv/config/版本、stdout/stderr/exit、前后目录清单与文件内容。

成功判据：allowed 子进程实际执行、exit0、文件精确为 probe 加 LF；denied 同样抵达子进程、由写入权限拒绝、exit非零且文件不存在。缺父目录、找不到 shell、配置解析错误或管理策略启动前拒绝不能充当有效负对照。此结果最多证明这两条固定命令的本次目录权限行为，不证明 CodexCliAdapter --add-dir、模型工具权限、任意子进程或完整 OS isolation。对 adapter 的旧模式仍需单独已授权验证，不能由新 profile 对照直接替代。

## 调查偏差与未知

调查时误把 `codex sandbox macos --help` 当旧式帮助命令，本版本实际尝试启动名为 macos 的可执行文件，execvp 报不存在。没有目标写入命令或模型执行，已立即告知 root；原输出记于 local-evidence.json，不把此次误调用说成纯帮助成功。之后仅重读 version/help与本地文件。

还保留一次错误文档 URL `/docs/config-file/permissions` 返回404，随后取得正确 `/docs/permissions`。未读 auth 或用户配置、未改默认配置、未执行上述允许/拒绝探针、未重试旧 Node26 packet。配置层合并及本机管理策略可能造成额外限制；当前尚不能声明拟议 profile 实际可执行。
