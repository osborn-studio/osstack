# 本机任务 scratch 权限预检独立判据

冻结于 2026-10-30T11:42:56.683115+00:00；未看作者方案，未观察写入探针。

**PP01** Before command execution freeze canonical paths for exactly this fresh owned workspace, separate extra task-scratch, and a separate owned deny-control outside both and their ancestors. No historical scratch root, global config modification, old Node26 packet, model or product tests. Reject accidental common broad writable ancestor covering deny-control.

**PP02** Record actual installed CLI version/binary fingerprint, exact argv/cwd, declared configuration/profile/sandbox-state and allowed env changes. Configuration must retain sandbox; no danger-full-access/disabled sandbox workaround. Help and --add-dir argv alone are not execution evidence.

**PP03** All three directories and fresh unique marker names must have independently recorded pre-state. Owned deny directory must be ordinarily writable by the same user outside the sandbox, established by narrow setup evidence, so missing/nonwritable directory cannot masquerade as sandbox enforcement. No preexisting success marker.

**PP04** Actual bounded no-model child command must attempt a fresh known-byte marker write in workspace and extra task-scratch. Independent post-read must confirm both exact bytes/hash and path; exit0 or child success message alone insufficient. Record per-write outcomes and errors separately.

**PP05** Same sandbox invocation must attempt the fresh deny-control marker, retain actual denial/error and prove its absence plus unchanged baseline. An attempted write that succeeds is FAILED boundary, not acceptable. ENOENT/EEXIST, no attempt, silent timeout or unrelated script failure do not prove permission denial.

**PP06** Distinguish configuration rejection before child start (BLOCKED), child launch with incomplete/ambiguous evidence (UNKNOWN), and completed three-write probe. Raw stdout/stderr/exit, child-start witness and per-target result must survive; one aggregate exit cannot substitute for per-target evidence.

**PP07** Actual writes may only concern the three owned probe locations and declared logs/config. Do not enumerate credentials/global environment or change global configuration. Record timeout/cancellation and owned cleanup; do not infer complete descendant cleanup or all filesystem/read/network fences.

**PP08** Only if PP01–07 evidence establishes exact selected positive writes and denied negative write may report SUCCESS for this machine/build/config/three-path probe. This is not native model first-use success, future sandbox attestation, arbitrary shell security, full OS isolation or repair of prior blocked packet. Any later config/path change requires a new explicitly versioned binding.

**PP09** Prepare and preserve all attempted commands including malformed CLI syntax/config failures. A corrected command can be a separate preflight attempt, never overwrite or relabel the original failure. No model budget exists in this task.

**PP10** Independent verifier reads final raw records and marker inventories without rerunning product/model or trusting self-report alone. If execution configuration does not provide enough evidence to establish sandbox-active/write scope, mark that axis UNKNOWN rather than asserting universal guarantees.

成功只证明本次三个具体路径；配置拒绝为blocked，漏证据为unknown，实际越权写为failed。历史Node26包保持blocked。
