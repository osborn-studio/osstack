# probe-01：BLOCKED 配置解析

完整stdout为空，exit1，stderr为带引号的filesystem key不是absolute。没有 CHILD_STARTED/RESULT；三个marker当前均不存在。这证明本次配置未进入预定写入命令，不证明允许或拒绝文件权限。

原plan/receipt/stdout/stderr hashes一致，计划早于调用。原件不改；probe-02必须单独冻结记录。
