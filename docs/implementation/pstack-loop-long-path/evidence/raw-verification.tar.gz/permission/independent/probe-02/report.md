# probe-02：有限 named-profile 成功

CHILD_STARTED 和三个实际结果0/0/1完整；workspace31字节/task-scratch34字节与冻结值及收据hash一致。deny写尝试返回Operation not permitted，marker不存在且目录仍空；目录属于当前用户、普通写access成立，计划另保留事前普通写入digest。

仅该named-profile三路径成立，不证明adapter --add-dir/native模型能力；01和旧Node26失败不变。
