# Native 权限诊断：有限成功

一次实际 adapter invoke，16.93秒，恰好一条命令。原始事件 CHILD_STARTED、workspace/task-scratch写成功、deny EPERM；独立文件读取确认35/38字节和hash准确，deny marker不存在。

实际展示 `/bin/zsh -lc <command>`，其shell body与冻结Node单命令逐字相等，解析只含interpreter/script两参数，无附加命令/重定向/替代路径。这是tool传输包装，不是NP03实质偏离；未修改准则，也不认证shell启动配置。

实际argv含workspace-write和唯一taskScratch --add-dir；source/build/当前binary fingerprints与freeze一致，四输入未变。仅此本机权限诊断成功。PP01配置BLOCKED、PP02 named-profile成功、原P6 BLOCKED保持分别记录。

身份、继承认证环境、所有OS围栏及全后代清理均未认证。
