# 新 native 权限诊断预冻

2026-10-30T11:47:39.272305+00:00

**NP01** New standalone permission diagnostic only: one real CodexCliAdapter.invoke, fresh explicit task/workspace/taskScratch/denyControl, no old Node26 packet, product/test/repair/DB/board/PR operation. Root freezes exact task scope and finite time/call budget before dispatch; no automatic second turn.

**NP02** Freeze exact candidate adapter/source/build/CLI identity, script and interpreter bytes, prompt/argv/env delta, fresh canonical directories and marker pre-state. Public adapter configured workspace-write plus writableRoots containing ONLY new taskScratch; default/implicit historical roots prohibited.

**NP03** Model permitted exactly one literal command executing the frozen Node probe script, with fixed cwd/args and no compound command, redirection, fallback, additional read/write shell, config edits, network or repair. On inability/permission refusal stop; no retry/session escalation.

**NP04** Probe is coordinator-authored immutable test material, not model-produced fix. It attempts fresh exact-byte markers at workspace/taskScratch/owned external denyControl and emits child-start plus individual outcomes. Deny directory is ordinarily writable outside sandbox and not under either allowed root; retain proof and absence before call.

**NP05** Actual native raw tool events must show the one intended command executed, not mere request/text or reported summary. Independently inspect positive marker bytes/hash, deny attempted permission error and absent marker; self-report/exit0 is insufficient. Unexpected deny write is FAILED boundary.

**NP06** Record actual native argv --add-dir canonical taskScratch and retained sandbox, raw stdout/stderr/event indices/exit/time, adapter events and any durable receipt available. Different standalone named-profile PP02 evidence cannot substitute for this native path; callback/executable/session unavailability is BLOCKED, incomplete trace is UNKNOWN.

**NP07** Original frozen script/prompt/config/inputs remain unchanged; before/after inventory separates expected marker/log writes from unauthorized edits. No global configuration/credentials enumeration or env widening. Native refusal/config-block leaves all unavailable axes unresolved rather than permission success.

**NP08** SUCCESS means this one native diagnostic issued the frozen command and observed two permitted writes plus denied external control with consistent raw/files/argv. It does not mean P6 repair, methods understood, authenticated model/provider, all OS fences, future task readiness, or automatic retry authorization. Prior PP01 and old P6 grades remain unchanged.
