# PR315 CI终态独立核对

Run 41048799532 已完成 failure。4项矩阵成功、check失败、Paid DeepSeek跳过。head `08342874b1ffdbdf447f38d5221ffbb9aed8eeda`，父分支 `codex/pstack-method-bridge-delivery` / `b161223bb3d2a3574a3ce9797ae07cbcd63c3fb3`；日志显示真实合成checkout，非main。

check/Test唯一22包合计 **7445 passed / 7 skipped / 1 failed**。唯一失败是 `packages/cli/src/graph-review-findings.test.ts:83` 的停止审查取消测试：预期 cancelled，实际 cancel_pending。本核验没有推测它是波动或归责本批变更。

Lint、Build、Inventory、Typecheck成功；Test之后的独立方法导出、健康查询、材料读取、实际2/5场景、地图维护、投影等步骤全部跳过。本run不能证明这些步骤通过。包内source和adapter相关测试的真实日志行另外列在report.json，不和独立脚本混计。

完整原始日志gzip无损保留（解压1268559字节），命令/退出码/JSON元数据及ANSI清理后的独立统计脚本均保留。未下载artifact，未改Ready/PR/board，未重跑CI或测试。
