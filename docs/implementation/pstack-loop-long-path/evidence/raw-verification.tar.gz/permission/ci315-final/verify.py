from pathlib import Path
import json,gzip,re,hashlib,datetime
p=Path(__file__).parent
raw=gzip.decompress((p/'full.log.gz').read_bytes())
text=re.sub(r'(?:\x1b|\^\[)\[[0-?]*[ -/]*[@-~]','',raw.decode())
run=json.loads((p/'run.json').read_text());pr=json.loads((p/'pr.json').read_text())
packages=[];checkout=[];failures=[];taps={};keytests=[]
lines=text.splitlines()
for number,line in enumerate(lines,1):
 a=line.split('\t',2)
 if len(a)!=3 or a[0]!='check':continue
 step=a[1];body=re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+\s','',a[2])
 if step=='Test':
  m=re.search(r'packages/(\S+) test:\s+Tests\s+(.*?)\s+\((\d+)\)\s*$',body)
  if m:
   counts={k:int(n) for n,k in re.findall(r'(\d+)\s+(passed|skipped|failed)',m[2])}
   assert sum(counts.values())==int(m[3])
   packages.append({'package':m[1],**{k:counts.get(k,0) for k in ('passed','skipped','failed')},'line':number})
  if any(x in body for x in [' FAIL ','AssertionError:','Tests  1 failed','ERR_PNPM_RECURSIVE']):failures.append({'line':number,'text':body})
  if any(x in body for x in ['codex-cli.test.ts','manifest.test.ts','source-adoption.test.ts','source-snapshot.test.ts','bug-fix-compiler.test.ts','method-context.test.ts','execution-context-host.test.ts']):keytests.append({'line':number,'text':body})
 if step=='Run actions/checkout@v7' and ('HEAD is now' in body or re.fullmatch(r'[a-f0-9]{40}',body)):checkout.append({'line':number,'text':body})
 m=re.search(r'^# (tests|pass|fail|skipped) (\d+)$',body)
 if m:taps.setdefault(step,{})[m[1]]=int(m[2])
assert len(packages)==len({x['package'] for x in packages})==22
assert run['headSha']==pr['headRefOid']=='08342874b1ffdbdf447f38d5221ffbb9aed8eeda'
assert pr['baseRefName']=='codex/pstack-method-bridge-delivery'
assert any('Merge '+run['headSha']+' into '+pr['baseRefOid'] in c['text'] for c in checkout)
assert run['status']=='completed' and run['conclusion']=='failure'
assert sum(j['conclusion']=='success' for j in run['jobs'])==4
assert sum(j['conclusion']=='failure' for j in run['jobs'])==1
assert sum(j['conclusion']=='skipped' for j in run['jobs'])==1
sums={k:sum(x[k] for x in packages) for k in ('passed','skipped','failed')}
check=next(j for j in run['jobs'] if j['name']=='check')
steps=[{'number':s['number'],'name':s['name'],'conclusion':s['conclusion']} for s in check['steps']]
report={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':run['databaseId'],'result':run['conclusion'],'head':run['headSha'],'base_branch':pr['baseRefName'],'base_sha':pr['baseRefOid'],'synthetic_checkout_lines':checkout,'jobs':[{'name':j['name'],'conclusion':j['conclusion']} for j in run['jobs']],'unique_packages':len(packages),'package_totals':sums,'packages':packages,'key_package_file_logs':keytests,'check_steps':steps,'standalone_tap_summaries':taps,'failure_evidence':failures,'raw_log':{'compressed_sha256':hashlib.sha256((p/'full.log.gz').read_bytes()).hexdigest(),'uncompressed_bytes':len(raw),'uncompressed_sha256':hashlib.sha256(raw).hexdigest()},'limits':['Single status query; no polling or rerun. Full log and PR metadata fetched read-only only after terminal status.','Parent feature-branch synthetic checkout, not actual main validation.','Method/health/source standalone contracts and real journey/map/projection smokes after Test were skipped. No successful execution claimed for them.','No artifacts downloaded or independently rehashed; log evidence is not artifact contents verification.','Failure cause beyond expected cancelled versus actual cancel_pending has not been investigated; no flake classification or source attribution inferred.','PR remains Draft in observed metadata; no mutation performed.']}
(p/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(p/'README.md').write_text(f'''# PR315 CI终态独立核对\n\nRun 41048799532 已完成 failure。4项矩阵成功、check失败、Paid DeepSeek跳过。head `{run['headSha']}`，父分支 `{pr['baseRefName']}` / `{pr['baseRefOid']}`；日志显示真实合成checkout，非main。\n\ncheck/Test唯一22包合计 **{sums['passed']} passed / {sums['skipped']} skipped / {sums['failed']} failed**。唯一失败是 `packages/cli/src/graph-review-findings.test.ts:83` 的停止审查取消测试：预期 cancelled，实际 cancel_pending。本核验没有推测它是波动或归责本批变更。\n\nLint、Build、Inventory、Typecheck成功；Test之后的独立方法导出、健康查询、材料读取、实际2/5场景、地图维护、投影等步骤全部跳过。本run不能证明这些步骤通过。包内source和adapter相关测试的真实日志行另外列在report.json，不和独立脚本混计。\n\n完整原始日志gzip无损保留（解压{len(raw)}字节），命令/退出码/JSON元数据及ANSI清理后的独立统计脚本均保留。未下载artifact，未改Ready/PR/board，未重跑CI或测试。\n''')
print(json.dumps({'totals':sums,'checkout':checkout,'keytests':keytests,'standalone':taps},ensure_ascii=False,indent=2))
