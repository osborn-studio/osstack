# 单次取消诊断结果：通过但发现被吞异常

运行 `run-07755dbbeb`，Node22.22.1，源头 `cd30b6ccddbd0e02d5607683a97c36d3ba96db11`，只执行1个review取消case，6个原case被过滤，exit0，外层3.904秒。12项原run manifest全部hash/bytes核对一致。六个相关源码前后不变，原测试不变，临时测试已删除。没有重跑。

## 实际观察

两次 cancel_called 相隔1ms；其后一个cancel_fulfilled，另一个cancel_rejected，异常为 **DECISION_CONFLICT**。调用栈指向 GraphRecoveryStore.commit 对同receipt的snapshot/proof/decision一致性检查，经 GraphReconciler.reconcile 到 GraphDelivery.cancel。未为call分配ID，故不能将成功/失败对应到“公开取消”或“close触发”中的某一条。

断言前以及finally快照中，graph_runs为cancelled/revision31；review与tests动作failed，其他前置动作confirmed；未释放admission=0。worker journal记录launched、exited，没有exit_unconfirmed。原断言均通过。因此本次确实完成了取消收口，另一并发取消遭遇的冲突没有破坏本次最终结果。

这证实了被吞异常路径存在，但不能断言原CI的cancel_pending由同一原因造成：原CI没有这个trace，而且该局部运行最终有一次成功投影。不能把“测试通过”写成无异常，也不能把这条冲突直接写成已修复的根因。

## Git状态差异的精确范围

status前后不等新增以下12项（无移除）：

- ` M .changeset/loop-exact-diff-paths.md`
- ` M docs/design/2026-10-27-joint-engineering/delivery-rollup.json`
- ` M docs/design/2026-10-27-joint-engineering/delivery-status.md`
- ` M docs/design/2026-10-27-joint-engineering/execution-ledger.json`
- ` M docs/design/2026-10-27-joint-engineering/execution.md`
- ` M docs/design/2026-10-27-joint-engineering/project-operations.md`
- ` M docs/design/2026-10-27-joint-engineering/pstack-feature-queue.md`
- ` M docs/implementation/pstack-fixed-release/LOOP-AND-BOARD-FIRST.md`
- ` M docs/implementation/pstack-fixed-release/PLAN.md`
- ` M docs/verification/bug-fix-method-handoff.md`
- `?? docs/implementation/pstack-loop-long-path/README.md`
- `?? docs/implementation/pstack-loop-long-path/USER-PATH.md`

其中9项为已有中央/文档、1项changeset文本、2项新增README/USER-PATH。根据root协调消息，系全仓结束后并行整合文档；Git状态本身只证明路径差异，不证明作者身份。原四个knowledge/dist状态和既有局部材料状态保留，六个诊断源哈希全部相同，不能把git_status_equal=false误报成诊断源码改动，也不能称整个工作树未变化。

## 结论与下一步

原 **CI315仍FAILED且原因未闭合**。本次1次局部通过以及root另报的22包全仓通过，均不能替代修复或改变旧CI结论。后续需要一个有界、可控的取消交错回归：给两条调用观测ID，在recovery snapshot/proof/commit边界设置有限barrier，记录fence/revision/receipt/异常/journal/hold。应区分首次投影前失败与成功后的重复冲突，并保留真实停止unknown控制；不靠加sleep、接受cancel_pending或盲目CIrerun消除红灯。

当前仅完成只读复核；未修改产品或原始记录。SQLite两映像留本地，允许后续归档仅列hash并明确排除。观察微任务与快照I/O会改变时序，不能声称无扰动复现。
