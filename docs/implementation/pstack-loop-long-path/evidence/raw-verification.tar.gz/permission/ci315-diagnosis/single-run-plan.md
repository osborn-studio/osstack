# 单次 CI315 复现脚本（尚未执行）

Root 完成当前全仓队列并审查脚本后，可执行一次：

```sh
python3 /Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-permission-preflight-20261030/ci315-diagnosis/run-once.py --execute-once --full-ended
```

两个开关是协调者确认，不是脚本自动证明其他任务已结束。没有开关只打印提示。脚本创建不可覆盖的 single-execution-claimed.json，禁止自动第二次运行；首次失败也保留 claim。不得删除 claim 来重复直到绿。

脚本先验证当前 graph-review-findings.test.ts 精确 SHA e4556215481b1e2709137f460418856a0cf4b3c09ccc496827da98c19a354096，再创建唯一文件名临时测试。六相关源在启动时与结束时分别绑定哈希、HEAD与git status原件保存，不要求当前checkout干净但不改已有脏文件。原测试所有判断、cancel/close等待和超时原样保留，仅添加：

- GraphDelivery.cancel 包装返回原 Promise（不是等待后新 Promise），附加 fulfilled/rejected 观察；同步抛错原样重抛。异常不转换成成功、不重试取消。
- 原 close 后、原断言前保存 graph_runs/actions/admissions 与 worker launch/event表；finally 原 close 前再次保存。表上限1000行，JSON上限8MiB。
- 同步 db.serialize 保存完整SQLite映像（上限16MiB），失败只记录诊断不足，不替代测试结果。原fixture仍由既有Vitest scratch清理；该映像不含source worktree/verification JSON文件的额外副本，因此不能称完整fixture归档。

仅 Node22 运行一次精确 named case，其他原参数化case被过滤（不计通过）。180秒外层期限、每流16MiB上限；达到限制向本次进程组TERM，5秒未退出再KILL。现有test setup继续将OSSTACK_HOME重定位到本次独占scratch worker内，不碰默认DB。stdout/stderr/命令/env overrides/源码/结果/快照/清单保留。正常或异常结束仅在临时测试仍等于本脚本所写字节时移除它；否则保留并报清理错误，绝不删除原测试或他人改动。

限制：观察Promise会添加observer微任务，DB只读查询/serialize和写诊断会占用时间，因此这不是无扰动trace；一次通过不能推断CI已修复、一次失败也须结合cancel异常与journal解读。只保存结果，不放宽unknown策略、不自动更新测试/产品/PR、不运行模型。此脚本只有Python语法静态compile已执行；未启动runner或Vitest。
