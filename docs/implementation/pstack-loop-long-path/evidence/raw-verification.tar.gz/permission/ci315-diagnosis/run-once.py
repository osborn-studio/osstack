#!/usr/bin/env python3
"""Root-dispatched only. No action without BOTH flags. One execution claim, no retry."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,subprocess,time,uuid
BASE=Path(__file__).resolve().parent
WORK=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pstack-permission-preflight')
EXPECTED='e4556215481b1e2709137f460418856a0cf4b3c09ccc496827da98c19a354096'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v): p.write_text(json.dumps(v,indent=2,default=str)+'\n')
def git(*a): return subprocess.check_output(['git',*a],cwd=WORK)
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute-once',action='store_true');a.add_argument('--full-ended',action='store_true');opts=a.parse_args()
 if not(opts.execute_once and opts.full_ended):
  print('NOT EXECUTED. Root must first confirm full suite ended, inspect this script, then supply --execute-once --full-ended.');return 0
 source=WORK/'packages/cli/src/graph-review-findings.test.ts';original=source.read_bytes()
 if sha(original)!=EXPECTED:raise RuntimeError('SOURCE_CHANGED: inspect and prepare a new bounded plan, do not silently rebase')
 if not (WORK/'node_modules').is_dir():raise RuntimeError('Existing dependencies required; no install performed')
 node=Path('/opt/homebrew/opt/node@22/bin/node')
 version=subprocess.check_output([str(node),'--version'],text=True).strip()
 if not version.startswith('v22.'):raise RuntimeError('Node22 required')
 claim=BASE/'single-execution-claimed.json'
 with claim.open('x') as f:json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid()},f)
 run=BASE/('run-'+uuid.uuid4().hex[:10]);run.mkdir();(run/'home').mkdir();(run/'scratch').mkdir()
 (run/'source-original.ts').write_bytes(original)
 before=git('status','--porcelain=v1','--untracked-files=all');(run/'git-before.txt').write_bytes(before)
 bindings={}
 for name in ['graph-review-findings.test.ts','graph-rpc.ts','graph-delivery.ts','graph-runtime.ts','graph-worker-manager.ts','graph-reconciler.ts']:
  p=WORK/'packages/cli/src'/name;bindings[name]=sha(p.read_bytes())
 injection=r'''
// Diagnostic-only observers. Return original cancel promise; never replace/recover rejection.
const __diagEvents: unknown[] = [];
let __diagSequence = 0;
const __diagOriginalCancel = GraphDelivery.prototype.cancel;
function __diagEvent(value: unknown) { try { __diagEvents.push({ at: Date.now(), value }); } catch { /* diagnostic only */ } }
GraphDelivery.prototype.cancel = function (...args: Parameters<typeof __diagOriginalCancel>) {
  __diagEvent({ kind: 'cancel_called' });
  try {
    const pending = __diagOriginalCancel.apply(this, args);
    void pending.then(
      value => { __diagEvent({ kind: 'cancel_fulfilled', value }); },
      error => { __diagEvent({ kind: 'cancel_rejected', error: String(error), stack: error instanceof Error ? error.stack : null }); },
    );
    return pending;
  } catch (error) { __diagEvent({ kind: 'cancel_sync_throw', error: String(error) }); throw error; }
};
function __diagCapture(db: ReturnType<typeof openDb>, fixtureRoot: string, stage: string) {
  const id = __diagSequence++;
  try {
    const tables: Record<string, unknown> = {};
    for (const table of ['graph_actions', 'graph_runs', 'graph_action_admissions', 'graph_worker_launches', 'graph_worker_process_events']) {
      try { tables[table] = db.prepare(`SELECT * FROM ${table} LIMIT 1000`).all(); }
      catch (error) { tables[table] = { diagnostic_error: String(error) }; }
    }
    const encoded = JSON.stringify({ stage, fixtureRoot, tables, events: __diagEvents }, null, 2);
    if (Buffer.byteLength(encoded) > 8 * 1024 * 1024) throw Error('DIAGNOSTIC_JSON_LIMIT');
    __diagWrite(__diagJoin(__diagRoot, `snapshot-${id}.json`), encoded, { flag: 'wx' });
    try {
      const bytes = db.serialize();
      if (bytes.length <= 16 * 1024 * 1024) __diagWrite(__diagJoin(__diagRoot, `database-${id}.sqlite`), bytes, { flag: 'wx' });
      else __diagEvent({ kind: 'database_snapshot_omitted', bytes: bytes.length });
    } catch (error) { __diagEvent({ kind: 'database_snapshot_error', error: String(error) }); }
  } catch (error) { console.error('DIAGNOSTIC_CAPTURE_ERROR', String(error)); }
}
'''
 text=original.decode();prefix="import { writeFileSync as __diagWrite } from 'node:fs';\nimport { join as __diagJoin } from 'node:path';\nconst __diagRoot = "+json.dumps(str(run))+";\n"
 text=prefix+text
 anchor="const quoteShell = (value: string)"
 if text.count(anchor)!=1:raise RuntimeError('Unexpected injection anchor')
 text=text.replace(anchor,injection+'\n'+anchor,1)
 marker="    expect(row.state).toBe(mode === 'unknown' ? 'unknown' : 'failed');"
 if text.count(marker)!=1:raise RuntimeError('Unexpected snapshot anchor')
 text=text.replace(marker,"    __diagCapture(f.db, f.root, 'after-service-close-before-original-assertions');\n"+marker,1)
 marker2='  } finally { await f.close(); }'
 if text.count(marker2)<1:raise RuntimeError('Missing cleanup anchor')
 text=text.replace(marker2,"  } finally { __diagCapture(f.db, f.root, 'finally-before-original-close'); await f.close(); }",1)
 generated=text.encode();(run/'source-instrumented.ts').write_bytes(generated)
 temp=WORK/'packages/cli/src'/('graph-review-ci315-diagnostic-'+uuid.uuid4().hex+'.test.ts')
 env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(run/'home'),OSSTACK_SCRATCH_ROOT=str(run/'scratch'))
 command=['pnpm','--filter','@osstack/cli','exec','vitest','run','src/'+temp.name,'-t','^settles stopped review cancellation with revoked execute, holding only unproven stop$']
 save(run/'command.json',{'argv':command,'cwd':str(WORK),'node':str(node),'node_version':version,'head':git('rev-parse','HEAD').decode().strip(),'environment_overrides':{k:env[k] for k in ['PATH','OSSTACK_HOME','OSSTACK_SCRATCH_ROOT']},'deadline_seconds':180,'stream_cap_bytes':16777216,'original_source_sha256':sha(original),'instrumented_sha256':sha(generated),'source_bindings':bindings,'semantics_limit':'Observer microtasks, read queries and snapshots can perturb scheduling; no claim of identical timing or production fix.'})
 proc=None;reason=None;result={};started=time.monotonic()
 try:
  with temp.open('xb') as f:f.write(generated)
  with (run/'stdout.log').open('wb') as so,(run/'stderr.log').open('wb') as se:
   proc=subprocess.Popen(command,cwd=WORK,env=env,stdout=so,stderr=se,start_new_session=True)
   while proc.poll() is None:
    if time.monotonic()-started>180:reason='timeout';break
    if so.tell()>16777216 or se.tell()>16777216:reason='output_limit';break
    time.sleep(.2)
   if reason:
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   else:proc.wait()
  result={'exit':proc.returncode,'termination_reason':reason,'elapsed_seconds':time.monotonic()-started,'test_invocations':1}
 finally:
  if proc is not None and proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  if temp.exists() and sha(temp.read_bytes())==sha(generated):temp.unlink();result['own_temp_test_removed']=True
  elif temp.exists():result['own_temp_test_removed']=False;result['cleanup_error']='Temporary test changed; retained rather than deleting changed file'
  else:result['own_temp_test_removed']=True
  result['original_source_unchanged']=source.read_bytes()==original
  result['source_bindings_after']={name:sha((WORK/'packages/cli/src'/name).read_bytes()) for name in bindings}
  after=git('status','--porcelain=v1','--untracked-files=all');(run/'git-after.txt').write_bytes(after)
  result['git_status_equal']=before==after
  save(run/'result.json',result)
  members=[]
  for f in sorted(run.iterdir()):
   if f.is_file():b=f.read_bytes();members.append({'path':f.name,'bytes':len(b),'sha256':sha(b)})
  save(run/'manifest.json',{'files':members})
 print(json.dumps({'run':str(run),**result},indent=2))
 return 0 if result.get('exit')==0 and not reason else 1
if __name__=='__main__':raise SystemExit(main())
