# CI315 取消状态失败只读诊断

结论：确认现象，尚未确认根因。不能把它称为 writableRoots 回归，也不能依据一次CI失败断言纯波动。六个直接相关源文件在 PR315 head08342874、父b161223b和当前所读checkout逐字相同，绑定见 source-binding.json；本次未运行测试/构建/改源码。

实际日志：review场景2044ms后失败；tests、tests-slow-stop、unknown三控制均过。第82行action state=failed断言已经通过，第83行graph_runs仍cancel_pending。第84行持有admission计数及后续完整停止证据断言因前一失败未执行，因此不能推断全部释放或物理停止均已证实。

## 调用链与疑点

1. graph-review-findings.test.ts:75 等reviewStarted后撤销execute许可；78发取消；79 await service.close，再83查DB。不是忘记await，也不是现有15ms轮询直接决定最终断言。
2. graph-rpc.ts:196–198 先持久cancel_pending，然后fire-and-forget driver.cancel，并吞其异常。close/drain:346再次await cancel，350等待entry.done与DB用户停止；355用allSettled不向调用方暴露失败。
3. graph-delivery.ts:354–384 只有worker实退出、actionsSettled、journal及executor inventory均通过，才reconcile投影cancelled。verify/reconcile有多次await和revision fence。run:417遇stopping直接返回，499关闭runtime，不自动补一次cancelled投影。
4. graph-runtime.ts:182–186有5s action drain预算；manager:139–140与186–196默认约3s后才exit_unconfirmed。2044ms总场景耗时不支持把本次直接归因于这些默认timeout；仍需原运行journal/异常才能排除其他路径。
5. 因而存在可调查的调度/并发settlement路径：首次fire-and-forget cancel、shutdown中的第二次cancel、run终止之间可能出现恢复fence/证据检查失败。close仅保证DB安全停止，不等同所有业务取消已投影。此为源码推导的候选原因，不是已复现产品缺陷。静态证据不足以说简单加轮询即可修好；close后没有保证仍有推进者，盲等可能只掩盖问题。

## 最小有意义下一步（未执行）

在匹配head/合成树及Node22新鲜build上，仅运行：

`pnpm --filter @osstack/cli exec vitest run src/graph-review-findings.test.ts -t 'settles stopped review cancellation with revoked execute, holding only unproven stop'`

使用独占 OSSTACK_HOME/OSSTACK_SCRATCH_ROOT，保留完整日志；第一次若通过，不等于CI已修。需要确认间歇性时由root预先限定少量顺序重复次数，不能无限retry直到绿。

更关键的受控诊断是只在隔离测试夹具记录两次cancel的抛错及stack、stop.worker/actionsSettled、cancelled投影前后revision、worker journal、尚未释放admission/requiredEffectKeys，且保留失败SQLite/fixture。不要吞异常然后只看最终状态。再用可控barrier重现候选交错：若已证worker停止和无hold而close后永久pending，是业务收口问题；若真实停止仍未知则pending正确，应修测试前提而不是放宽生产判定。不得把unknown控制改成cancelled、删除物理停止验证，或无依据增加timeout。

本轮未执行以上命令，也未给任何生产修复结论。误放CI输出已复制到正确新scratch（14payload+原manifest逐字核对），旧误放目录保留；原已发布raw archive/manifest与head Git blob完全相同，未被覆盖。
