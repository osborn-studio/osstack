import {CodexCliAdapter} from "/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/pstack-permission-preflight/packages/agents/dist/index.js";
import {readFileSync,appendFileSync,writeFileSync} from 'node:fs';
const p="/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-permission-preflight-20261030/native-probe";
const adapter=new CodexCliAdapter({bin:p+'/codex-record',cwd:p+'/workspace',sandbox:'workspace-write',writableRoots:[p+'/task-scratch'],strictCompletion:true,env:{...process.env,OSSTACK_HOME:p+'/home',OSSTACK_SCRATCH_ROOT:p+'/task-scratch'}});
const task={run_id:'permission-native-20261030',session_id:'permission-native-20261030',task_id:'permission-native-20261030',capability_id:'codex-cli.code.test',prompt:readFileSync(p+'/prompt.txt','utf8'),context:{repo_path:p+'/workspace'}};
const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),140000);
try{for await(const ev of adapter.invoke(task,controller.signal)){appendFileSync(p+'/run/events.jsonl',JSON.stringify(ev)+'\n');if(ev.type==='done'||ev.type==='error')console.log(JSON.stringify(ev));}}finally{clearTimeout(timer);writeFileSync(p+'/run/runner-end.json',JSON.stringify({ended_at:new Date().toISOString()}));}
