**Verdict: PASS** (limited, static, Sonnet 5.5). R1-R4 are closed in the supplied text at `622ead8`, and the CI ordering is correct. I executed nothing, so every "should pass" below comes from tracing the code by hand.

## R1-R4 closure

- **R1 (CLI containment):** closed. `report-pr-candidate.test.mjs` adds `canonical containment refuses {existing-outside-parent, escaping-symlink-parent, scratch-root-itself}`.
  - Each variant sets `OSSTACK_SCRATCH_ROOT=narrow` and restores it in `finally`. Each asserts exit 2, zero runner calls, an empty `outside`, and `narrow` containing only `escape`.
  - Deleting `within()` makes the first two variants create `outside/report` and exit 0, so they would fail.
  - The old "missing outside parent" test is still there, but its title is now accurate.
  - The `scratch-root-itself` case is also refused by the exclusive `mkdir` (EEXIST). It proves the behaviour but not the `rel !== ''` clause on its own. This is non-blocking.
- **R2 (StatusContext and pending):** closed. All five `StatusContext` states map as expected (SUCCESS → `no_observed_blocker`, FAILURE/ERROR → `blocked`, PENDING → `waiting`, EXPECTED → `unknown`), with name mapping via `context` and the raw row asserted. A QUEUED `CheckRun` with a null conclusion gives `checks_pending` and `waiting`.
- **R3 (never-clears assertions):** closed.
  - Missing-name-alone with `checks([])` gives `complete=true`, no blockers and `unknown`.
  - The duplicate-name test asserts the `required_checks_ambiguous` unknown, and removing that push would fail it.
  - I traced the budget test's clock sequence `[0,1,2,3]` then 90000. The initial call is retained (`initial`, receipt, raw, `exit_code 0`) and checks, threads and final all get `budget_exhausted`, so the issue codes and receipts are covered.
- **R4 (library negatives):** closed. Cases are present for `command_failed`, `response_size`, `invalid_json`, `repository_mismatch` (all asserting receipt, raw and retained initial/final), cross-page `duplicate_id`, thread `pr_mismatch`, `hasNextPage` with a null cursor, MERGED/CLOSED precedence, and matching pins giving `stable` and `no_observed_blocker`.
  - My static counts are 45 vitest cases and 14 CLI tests. That is 27 + 18 and 11 + 3, which matches the original counts plus the additions.

## CI build order

The order is correct. `pnpm -r build` and Inventory run before Typecheck and `pnpm -r test`, and "Read-only PR snapshot contracts (offline)" (`pnpm test:pr-candidate`) comes after all of them. So `packages/github/dist/pr-candidate-snapshot.js` exists when the CLI tests import it. The step is not gated on `heavy_smoke`. `graph-runtime-matrix` builds but never runs this suite, which is fine.

Two things I could not verify: that the `@osstack/github` build emits that exact `dist` filename (the earlier full run at 8a711 implies it does), and that `scripts/lib/scratch.mjs` reads `OSSTACK_SCRATCH_ROOT` at call time and creates the default root. This step sets no env, unlike some others. If `scratch.mjs` caches the env at import, the new containment tests would fail loudly rather than pass vacuously.

## Reporting constraints (not blocking, but state them)

1. **"First pass" has no receipt here.** The 8a711 full-suite run predates these tests and does not cover them. Cite the actual command output for the new vitest and `node --test` runs, or say "statically traced, not run".
2. **"Production unchanged" is not shown for `622ead8`.** The lineage table lists only `c8f3aa11`, `8a711bd1` and `8a89e670`, so add `622ead8` or the diff.
3. **"Subsequent changes tests/docs only" is unproven.** `ci.yml` and `package.json` are neither tests nor docs. If the `test:pr-candidate` step or script was added after 8a711, list those paths instead of using that phrase.
4. **The independent-coverage JSON is for candidate `c8f3aa11`.** It still says StatusContext, malformed/oversize transport and deadline stress were not independently run. The new author-written fixtures now cover those, but they are not independent coverage. Don't cite the JSON as covering the closure candidate.

## Still open (optional, production unchanged by design)

- The case-sensitive `nameWithOwner` check.
- `missing_required` is populated when checks were not collected.
- Null `statusCheckRollup` and the refusal codes are not distinguished.
- There is no `Promise.race` on the runner timeout.

Fixed since the original audit: the "exact raw receipts" title, the `Exit0` typo, the `package.json` description churn, and the README notes on name-only matching, null review decision, runner-honored timeouts and the scratch-root default.