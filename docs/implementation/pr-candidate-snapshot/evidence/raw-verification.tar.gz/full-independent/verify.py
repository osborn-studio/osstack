from pathlib import Path
import json,re,hashlib,subprocess,datetime
out=Path(__file__).parent;src=out.parent/'root'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['full.stdout','full.stderr','full-binding.json','full-before.json','full-after.json'];bindings=[{'path':'../root/'+n,'bytes':(src/n).stat().st_size,'sha256':sha(src/n)}for n in files]
b=json.loads((src/'full-binding.json').read_text());before=json.loads((src/'full-before.json').read_text());after=json.loads((src/'full-after.json').read_text())
assert b['exit_code']==0 and b['argv']==['pnpm','test']
assert len(before)==len(after)==b['tracked_files']==8509 and before==after
assert all(re.fullmatch('[0-9a-f]{64}',h) for h in before.values())
args=['git','ls-tree','-r','--name-only','-z',b['head']]
p=subprocess.run(args,cwd='/Volumes/AIMATE_WORK/Developer/CodeX/osstack',capture_output=True);assert p.returncode==0
(out/'tracked-git-paths.raw').write_bytes(p.stdout);(out/'tracked-git-paths.command.json').write_text(json.dumps({'argv':args,'exit_code':p.returncode},indent=2)+'\n')
assert set(p.stdout.decode().strip('\0').split('\0'))==set(before)
packages=[];done=set()
for n,line in enumerate((src/'full.stdout').read_text().splitlines(),1):
 t=re.sub(r'(?:\x1b\[|\^\[\[)[0-?]*[ -/]*[@-~]','',line)
 m=re.fullmatch(r'packages/([^ ]+) test:\s+Tests\s+(.+)',t)
 if m:
  vals={k:int(v) for v,k in re.findall(r'(\d+) (passed|skipped|failed)',m[2])}
  packages.append({'package':m[1],'line':n,**{k:vals.get(k,0)for k in ['passed','skipped','failed']},'raw_summary':line})
 m=re.fullmatch(r'packages/([^ ]+) test: Done',t)
 if m:done.add(m[1])
assert len(packages)==len({x['package']for x in packages})==22 and done=={x['package']for x in packages}
totals={k:sum(x[k]for x in packages)for k in ['passed','skipped','failed']}
assert totals['failed']==0
expected=['packages/knowledge/dist/index.d.ts','packages/knowledge/dist/index.d.ts.map','packages/knowledge/dist/index.js','packages/knowledge/dist/index.js.map']
assert sorted(x[3:] for x in b['initial_status'].splitlines())==sorted(expected)
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':b['head'],'execution_binding':b,'source_bindings':bindings,'package_count':22,'totals':totals,'packages':packages,'done_markers_match':True,'tracked_check':{'count':8509,'snapshot_keys_equal_git_tree':True,'before_after_hash_values_identical':True,'changed':[],'initial_generated_dirty_paths':expected},'limits':['Read-only independent recalculation of supplied raw output and snapshots; not an independent re-execution.','Test workspace was not a clean committed tree: four fresh generated knowledge/dist outputs were already dirty; no claim that their bytes equal HEAD.','8509 before/after tracked-file snapshots are equal; this does not attest intermediate changes or untracked state.','No repository/ledger/PR/model or test execution performed.']}
(out/'report.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'report.md').write_text(f'''# Independent full-suite record review

Bound head `{b['head']}`. Recorded `pnpm test` exited0, {b['started_at']} → {b['finished_at']}.

Exact final Tests lines: **22 unique packages; {totals['passed']} passed /{totals['skipped']} skipped /{totals['failed']} failed**. Every package also has a Done marker. Per-package raw line references and counts are in report.json; no standalone or repeated suite included.

Both snapshots contain exactly **8509** tracked paths and identical SHA256 values. Their path set independently equals `git ls-tree -r` for the bound head. No changed tracked hash observed across endpoints. The initial status explicitly contains four freshly generated knowledge/dist files: this was a stable built workspace, **not a clean committed-tree execution**. Snapshots do not prove there were no transient or untracked changes.

Only original records were read and independently recalculated. No full-suite or product test rerun, model call, repository change, or ledger update. All five raw source hashes are bound in report.json; original files unchanged.
''')
assert all(sha(src/n)==x['sha256']for n,x in zip(files,bindings))
m=[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted(out.iterdir())if f.is_file() and f.name!='manifest.json']
(out/'manifest.json').write_text(json.dumps({'files':m},indent=2)+'\n')
print(json.dumps({'totals':totals,'report_sha256':sha(out/'report.json'),'manifest_sha256':sha(out/'manifest.json')}))
