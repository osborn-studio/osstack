// Offline transport adapter only. No candidate is imported unless an explicit module argument is supplied.
// Frozen expected outcomes stay in vectors.json; returned schema scoring awaits the author's public types.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const hash = value => createHash('sha256').update(value).digest('hex');
const clone = value => structuredClone(value);
function factsNode(facts) {
  const { repo, pr, transport_error, ...rest } = facts;
  return { __typename: 'PullRequest', number: pr, ...rest };
}
function wire(kind, fixture, pageIndex) {
  const f = kind === 'initial' ? fixture.initial : kind === 'final' ? fixture.final : fixture[kind === 'checks' ? 'check_pages' : 'thread_pages'][pageIndex];
  if (!f) throw Error(`harness_missing_fixture_page:${kind}:${pageIndex}`);
  if (f.transport_error) return { stdout: '', stderr: `synthetic_${f.transport_error}`, exitCode: f.transport_error === 'timeout' ? 124 : 1 };
  let repository;
  if (kind === 'initial' || kind === 'final') repository = { nameWithOwner: f.repo, pullRequest: factsNode(f) };
  else if (kind === 'checks') repository = { nameWithOwner: f.repo, object: { __typename: 'Commit', oid: f.oid, statusCheckRollup: f.connection === null ? null : { contexts: clone(f.connection) } } };
  else repository = { nameWithOwner: f.repo, pullRequest: { ...factsNode(fixture.initial), number: f.pr, reviewThreads: clone(f.connection) } };
  const body = { data: { repository } };
  if (f.errors) body.errors = clone(f.errors);
  return { stdout: JSON.stringify(body), stderr: '', exitCode: 0 };
}
export function makeOfflineRunner(fixture) {
  const calls = []; let facts = 0, checks = 0, threads = 0, now = 1_800_000_000_000;
  return {
    calls, clock: () => { now += 10; return now; },
    runner: { run: async (command, args, options) => {
      const row = { command, args: [...args], options: clone(options), ordinal: calls.length + 1 };
      calls.push(row);
      if (command !== 'gh' || args[0] !== 'api' || args[1] !== 'graphql') throw Error('harness_non_read_command');
      const queryArg = args.find(a => typeof a === 'string' && a.startsWith('query='));
      if (!queryArg || /\bmutation\s*[{(]/.test(queryArg)) throw Error('harness_missing_or_mutating_query');
      if (!(options.timeoutMs > 0 && options.timeoutMs <= 10000)) throw Error('harness_timeout_bound');
      if (calls.length > 8) throw Error('harness_query_count_bound');
      const query = queryArg.slice(6);
      let kind, page;
      if (query.includes('statusCheckRollup')) { kind = 'checks'; page = checks++; }
      else if (query.includes('reviewThreads')) { kind = 'threads'; page = threads++; }
      else { kind = facts++ === 0 ? 'initial' : 'final'; page = 0; }
      const result = wire(kind, fixture, page);
      Object.assign(row, { kind, page, response: result, response_sha256: hash(result.stdout) });
      return result;
    } },
  };
}
async function main() {
  const [candidateModule, vectorsPath, output] = process.argv.slice(2);
  if (!candidateModule || !vectorsPath || !output || process.argv.length !== 5) throw Error('usage: node runner-harness.mjs ABSOLUTE_FROZEN_MODULE ABSOLUTE_VECTORS ABSOLUTE_NEW_OUTPUT');
  if (![candidateModule, vectorsPath, output].every(p => p.startsWith('/'))) throw Error('absolute_paths_required');
  const vectorBytes = await readFile(vectorsPath); const source = await readFile(candidateModule);
  const { inspectPrCandidate } = await import(pathToFileURL(candidateModule));
  if (typeof inspectPrCandidate !== 'function') throw Error('harness_candidate_interface');
  await mkdir(output, { recursive: false });
  const results = [];
  for (const vector of JSON.parse(vectorBytes).vectors) {
    const f = vector.fixture; const h = makeOfflineRunner(f);
    const input = { repo: 'example/project', pr: 17, requiredChecks: f.requiredChecks };
    if (f.expectedHead !== undefined) Object.assign(input, { expectedHead: f.expectedHead, expectedBase: f.expectedBase });
    let returned, error;
    try { returned = await inspectPrCandidate(input, h.runner, h.clock); }
    catch (e) { error = { name: e.name, message: e.message }; }
    const result = { id: vector.id, input, expected: vector.expected, calls: h.calls, returned, error, scoring: 'pending_public_return_types_no_automatic_pass' };
    await writeFile(join(output, `${vector.id}.json`), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
    results.push({ id: vector.id, call_count: h.calls.length, error: error ?? null });
  }
  await writeFile(join(output, 'binding.json'), JSON.stringify({ candidate_module: resolve(candidateModule), candidate_module_sha256: hash(source), vectors_sha256: hash(vectorBytes), runner_sha256: hash(await readFile(new URL(import.meta.url))), mode: 'offline_injected_transport_no_network_no_forge_mutation', results }, null, 2) + '\n', { flag: 'wx' });
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) await main();
