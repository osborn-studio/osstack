import pathlib,json,hashlib,datetime,subprocess
B=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr306-main-retarget-20261030/next-candidate')
R=B/'root'; O=B/'independent'; P=R/'live-pr306'
h=lambda x:hashlib.sha256(x).hexdigest()
load=lambda p:json.loads(p.read_text())
t=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
g=load(R/'live-guard.json'); b=load(R/'live-binding.json');m=load(P/'manifest.json');s=load(P/'snapshot.json');q=load(P/'queries.json')
assert h((R/'live-guard.json').read_bytes())==b['guard_sha256'];assert g['argv']==b['argv'];assert b['exit_code']==0
assert t(g['at'])<t(b['started_at'])<=t(q[0]['started_at']);assert t(q[-1]['finished_at'])<=t(b['finished_at'])
for kind in ['stdout','stderr']:assert h((R/('live.'+kind)).read_bytes())==b[kind+'_sha256']
assert len(m['files'])==10
for f in m['files']:
 p=P/f['path'];assert '..' not in p.relative_to(P).parts;assert p.is_file() and not p.is_symlink();v=p.read_bytes();assert len(v)==f['bytes'] and h(v)==f['sha256'] and (p.stat().st_mode&0o777)==f['mode']
assert sorted(str(p.relative_to(P))for p in P.rglob('*')if p.is_file())==sorted([f['path']for f in m['files']]+['manifest.json'])
assert m['execution_path']=='default_delivery_runner' and m['merge_authorized'] is False
assert [v['label']for v in q]==['initial','checks-1','threads-1','final']
for v in q:
 assert v['command']=='gh' and v['args'][:2]==['api','graphql'];query=next(a for a in v['args']if a.startswith('query='));assert query.startswith('query=query Candidate') and 'mutation' not in query
 assert v['exit_code']==0 and v['issue']is None and v['timeout_ms']<=10000
 raw=load(P/'raw'/ (v['label']+'.stdout'));assert 'errors'not in raw;assert raw['data']['repository']['nameWithOwner']==s['repo']
for label in ['initial','final']:
 assert load(P/'raw'/(label+'.stdout'))['data']['repository']['pullRequest']==s[label]
for field in ['headRefOid','baseRefOid','headRefName','baseRefName']:assert s['initial'][field]==s['final'][field]
assert s['binding']['status']=='stable' and s['binding']['head']==s['binding']['expected_head'] and s['binding']['base']==s['binding']['expected_base']
assert s['summary']=='blocked' and s['merge_authorized']is False
assert s['blockers']==['forge_blocked'];assert set(s['waiting'])=={'checks_pending','review_required','draft'};assert s['unknowns']==['checks_not_success']
checks=load(P/'raw'/'checks-1.stdout')['data']['repository']['object'];assert checks['oid']==s['binding']['head'];assert checks['statusCheckRollup']['contexts']['nodes']==[r['raw']for r in s['checks']['rows']]
assert s['review']['threads']['complete'] and s['checks']['complete']
repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';source_proof=[]
for path,digest in g['source_hashes'].items():
 values={ref:h(subprocess.check_output(['git','show',ref+':'+path],cwd=repo))for ref in ['c8f3aa11fc007171c23c64e09b402351174c834c',b['code']]};assert set(values.values())=={digest};source_proof.append({'path':path,'sha256':digest,'git_objects':list(values)})
refs={str(p.relative_to(B)):{'sha256':h(p.read_bytes()),'bytes':len(p.read_bytes())}for p in [R/'live-guard.json',R/'live-binding.json',R/'live.stdout',R/'live.stderr',P/'manifest.json',P/'snapshot.json',P/'queries.json']+[P/f['path'] for f in m['files']]}
report={'status':'verified_retained_live_read_receipts','queries':len(q),'manifest_members':len(m['files']),'guard_before_calls':True,'source_proof':source_proof,'pins':s['binding'],'observation':{'summary':s['summary'],'blockers':s['blockers'],'waiting':s['waiting'],'unknowns':s['unknowns']},'scope':'Root obtained one actual read-only non-atomic snapshot; candidate was blocked at the recorded time. Independent verifier only read retained receipts and Git objects, made zero forge calls. No Ready/merge qualification, no product fix or host-model experiment. UTF-8 decoded response strings re-encoded as retained bytes; not authenticated original wire bytes. Authentication environment was inherited, not isolated.','evidence':refs}
(O/'live-read-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'queries':len(q),'manifest_members':len(m['files']),'summary':s['summary'],'report_sha256':h((O/'live-read-review.json').read_bytes())}))
