import { readFile, writeFile, mkdir, readdir, lstat, symlink } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { join } from 'node:path';
import { makeOfflineRunner } from './runner-harness.mjs';
import { runPrCandidateReport } from '/Users/osborn/Developer/CodeX/.worktrees/osstack/pr-candidate-snapshot-author/scripts/report-pr-candidate.mjs';
const base = '/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr306-main-retarget-20261030/next-candidate/independent';
const out = join(base, 'cli-c8');
await mkdir(out);
const inside = join(out,'scratch'), outside=join(out,'outside');
await mkdir(inside); await mkdir(outside); await symlink(outside,join(inside,'escape'),'dir');
process.env.OSSTACK_SCRATCH_ROOT=inside;
const vectors=JSON.parse(await readFile(join(base,'vectors.json'),'utf8')).vectors;
const fixture=id=>structuredClone(vectors.find(v=>v.id===id).fixture);
const digest=b=>createHash('sha256').update(b).digest('hex');
const rows=[];
async function inventory(root,prefix='') { const rows=[]; for(const name of (await readdir(join(root,prefix))).sort()) {const path=join(prefix,name), stat=await lstat(join(root,path)); if(stat.isDirectory()) rows.push(...await inventory(root,path)); else { assert(stat.isFile()); rows.push(path); }} return rows; }
async function run(id,args,{caseId='clear',exit=2,summary,zero=true,existing=false}={}) {
 const h=makeOfflineRunner(fixture(caseId));
 const outputIndex=args.indexOf('--output'), output=outputIndex<0?null:args[outputIndex+1];
 const before=await readdir(outside);
 const result=await runPrCandidateReport(args,{runner:h.runner,clock:h.clock});
 const checks=[]; let failure=null,manifest=null;
 try {assert.equal(result.exitCode,exit); checks.push('exit');
 if(zero){assert.equal(h.calls.length,0); checks.push('zero_queries'); if(output&&!existing) {try {await lstat(output);assert.fail('rejected_output_created');}catch(e){if(e.code!=='ENOENT')throw e;}}}
 if(summary){assert.equal(result.summary,summary);checks.push('summary');}
 assert.deepEqual(await readdir(outside),before);checks.push('outside_unchanged');
 if(!zero){const mb=await readFile(join(output,'manifest.json'));manifest=JSON.parse(mb);assert.equal(result.manifest_sha256,digest(mb));assert.equal(manifest.execution_path,'injected_runner');assert.equal(manifest.merge_authorized,false);const paths=[];
 for(const item of manifest.files){assert(!item.path.includes('..'));const bytes=await readFile(join(output,item.path));const stat=await lstat(join(output,item.path));assert(stat.isFile());assert.equal(bytes.length,item.bytes);assert.equal(digest(bytes),item.sha256);assert.equal(stat.mode&0o777,item.mode);assert.equal(item.mode,0o600);paths.push(item.path);}
 assert.deepEqual((await inventory(output)).sort(),[...paths,'manifest.json'].sort());assert.equal(new Set(paths).size,paths.length);
 const q=JSON.parse(await readFile(join(output,'queries.json'),'utf8'));assert.equal(q.length,h.calls.length);
 for(const call of h.calls){assert.equal(await readFile(join(output,'raw',`${call.kind==='checks'||call.kind==='threads'?call.kind+'-'+(call.page+1):call.kind}.stdout`),'utf8'),call.response.stdout);}
 checks.push('complete_manifest_hash_size_mode_inventory','raw_equals_injected_transport_strings','query_receipts');}
 }catch(e){failure={name:e.name,message:e.message};}
 const row={id,args,result,calls:h.calls,checks,failure,manifest};rows.push(row);await writeFile(join(out,id+'.json'),JSON.stringify(row,null,2)+'\n',{flag:'wx'});
}
const args=(p)=>['--repo','example/project','--pr','17','--required-check','test','--output',p];
await run('valid-clear',args(join(inside,'clear')),{exit:0,summary:'no_observed_blocker',zero:false});
await run('valid-unknown',args(join(inside,'unknown')),{caseId:'check-NEUTRAL',exit:0,summary:'unknown',zero:false});
await run('valid-blocked',args(join(inside,'blocked')),{caseId:'failed-plus-missing',exit:0,summary:'blocked',zero:false});
await run('initial-unavailable',args(join(inside,'unavailable')),{caseId:'initial-unavailable',exit:3,summary:'unknown',zero:false});
await run('outside-existing-parent',args(join(outside,'refused')));
await run('symlink-parent-outside',args(join(inside,'escape','refused')));
await run('equal-scratch-root',args(inside),{existing:true});
await run('existing-output',args(join(inside,'clear')),{existing:true});
await run('terminal-symlink',args(join(inside,'escape')),{existing:true});
await run('relative-output',args('relative-new'));
await run('bad-repo',['--repo','x;echo bad','--pr','17','--output',join(inside,'bad-repo')]);
await run('bad-pr',['--repo','example/project','--pr','0','--output',join(inside,'bad-pr')]);
await run('unknown-flag',[...args(join(inside,'unknown-flag')),'--merge','true']);
await run('duplicate-flag',[...args(join(inside,'duplicate-flag')),'--pr','17']);
await run('unpaired-pins',[...args(join(inside,'unpaired-pins')),'--expect-head','a'.repeat(40)]);
await run('duplicate-required',[...args(join(inside,'duplicate-required')),'--required-check','test']);
await run('control-required',[...args(join(inside,'control-required')),'--required-check','test\nmutation']);
const summary={candidate:'c8f3aa11fc007171c23c64e09b402351174c834c',scope:'offline CLI exported API with injected transport; no live forge/no native subprocess CLI coverage claimed',cases:rows.length,passed:rows.filter(r=>!r.failure).length,failed:rows.filter(r=>r.failure).map(r=>({id:r.id,failure:r.failure})),script_sha256:digest(await readFile(new URL(import.meta.url)))};
await writeFile(join(out,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'}); console.log(JSON.stringify(summary,null,2)); if(summary.failed.length)process.exitCode=1;
