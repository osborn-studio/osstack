# Read-only candidate snapshot independent acceptance

- **PC01 Bound identity:** Stable repo/PR/head/base/branch-name bracket is necessary for a favorable current summary. Change any identity field or mismatch paired expected pins => candidate_changed; failure of final facts => unknown. Retain old facet pins; no silent repoll.

- **PC02 No authority upgrade:** Stable complete success with explicit unique required names, approvedreview, no unresolvedthreads and cleanmerge yields only no_observed_blocker, merge_authorizedfalse. Empty/unspecified requirements must not imply policy-completeallgreen. forge policy notcollected, evaluatedmergecommitunknown and nonatomicsnapshot limitations remain.

- **PC03 Checks remain distinct:** Keep SUCCESS/FAILURE/PENDING/CANCELLED/TIMED_OUT/SKIPPED/NEUTRAL/ACTION_REQUIRED/unknown distinct. Only unique matching success satisfies a declared name. Missing/duplicate/nullrollup stays uncertain; known failure survives alongside missing names and pending.

- **PC04 Review and integration axes:** Conflict, draft, changesrequested, unresolvedoutdated thread and failedcheck remain separate observations. Final stable-identity review/mergeability/state facts supersede initial values. MERGED/CLOSED terminal observations cannot authorize actions; individual approvalhead notcollected.

- **PC05 Complete pagination:** 100+1 checks/threads consumes page2 and finds required check/unresolved thread there. Three-page cap, null/nonprogress cursor, truncated or malformed page cannot imply complete or zero threads. Checkpage repository/oid mismatch makes candidatefacetunknown; preserve earlier data.

- **PC06 Query failures:** Initial identity unavailable=>CLI3 with unavailable report when output owned. Later auth/ratelimit/timeout/nonzero/malformedJSON/nullrepo/partialGraphQLerrors=>unknown/partial, not CI failure/emptyclear. Preserve raw even when data and errors coexist.

- **PC07 Bounded fixed read commands:** Only fixed gh api graphql reads with variables, never mutation/commentbody/code/ghprwrite/gitcheckout/fetch/watch/retry. Atmost8reads, perquery<=10s, total90s incl injectclock deadline. Recordactual16MiB runner cap vs smaller postparse cap honestly; no OSsandboxclaim.

- **PC08 Validation before network:** Strict repo slug, positive safePR, paired40hexpins, unique nonempty bounded requirednames and strict flags. Invalidarguments, existingoutput/symlink/nonownedpath rejected beforeforgecalls; exit2, nooverwrite.

- **PC09 Preserve full evidence:** New scratch output only, rawstdout/stderr+queryargv/timing/exit bound by hash/bytes manifest; no environment/token enumeration or serialization. Rawforge metadata canbe sensitive; comments notrequested. Exit0 meansreportwritten, notready.

- **PC10 Adversarial content inert:** Hostile string in returned names/paths/URLs cannot alterargv or invoke commands. Unknown enums and malformedshape failclosed; do not execute fixture text. Defaultauth viaexisting runner only.

- **PC11 Current-source attribution:** Pin actual implementationbase/head, retain sourcehashes and originalfailedprobes. Source/manifest consistency is not authenticatedindependentprincipal. No historicalhost experiment replay/gradechange.

- **PC12 Bounded live confirmation:** After offlinecandidate tests, atmostone rootauthorized read-only realPRsnapshot demonstrates realAPIshape/currentpins/rawoutput; incomplete observations remainlimited. Not required to manufactureCIgreen or authorizeReady/merge; no watcher.

Offline vectors retain fixed expectations; wire adaptation is not permission to soften outcomes. No ready/merge authority is conferred.
