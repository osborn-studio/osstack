import {readFile,writeFile} from 'node:fs/promises';import {join} from 'node:path';
const root='/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr306-main-retarget-20261030/next-candidate/independent';const {vectors}=JSON.parse(await readFile(join(root,'vectors.json')));const scored=[];
for(const v of vectors){const x=JSON.parse(await readFile(join(root,'candidate-c8',v.id+'.json'))),s=x.returned?.snapshot,e=v.expected;const assertions=[];const add=(name,value)=>assertions.push({name,passed:!!value});add('returned',!!s&&!x.error);if(s){add('no authority',s.merge_authorized===false&&s.forge_policy_coverage==='not_collected'&&s.evaluated_merge_commit==='unknown');add('bounded reads',x.calls.length<=8&&x.calls.every(c=>c.command==='gh'&&c.args[0]==='api'&&c.args[1]==='graphql'&&c.options.timeoutMs<=10000));
if(e.summary&&e.summary!=='unavailable')add('summary',s.summary===e.summary);
if(e.summary==='unavailable')add('unavailable library identity',s.initial===null&&s.binding.status==='unknown');
if(e.never_summary)add('not favorable',s.summary!==e.never_summary);
if(e.binding)add('binding',s.binding.status===e.binding);
if(e.preserve_conclusion)add('raw state retained',s.checks.rows.some(c=>c.raw.conclusion===e.preserve_conclusion));
if(e.known_failure)add('failure retained',s.checks.rows.some(c=>c.name===e.known_failure&&c.state==='failure'));
if(e.missing)add('missing retained',s.checks.missing_required.includes(e.missing));
if(e.required_test==='ambiguous')add('ambiguous required',s.checks.ambiguous_required.includes('test'));
if(e.required_test==='missing')add('missing required',s.checks.missing_required.includes('test'));
if(e.required_test==='success')add('page2 required',s.checks.rows.some(c=>c.name==='test'&&c.state==='success')&&s.checks.complete);
if(e.unresolved_id)add('page2 unresolved outdated',s.review.unresolved.some(t=>t.id===e.unresolved_id&&t.isOutdated)&&s.review.unresolved.length===e.unresolved_count);
if(e.threads_complete!==undefined)add('thread completeness',s.review.threads.complete===e.threads_complete);
if(e.checks==='unknown')add('checks uncertainty',!s.checks.complete);
if(e.final_review)add('final review',s.review.decision===e.final_review);
if(e.final_mergeable)add('final integration',s.final.mergeable===e.final_mergeable);
if(e.raw_errors_preserved)add('raw partial GraphQL retained',x.returned.raw.some(r=>r.stdout.includes('bounded synthetic API failure')));
}
scored.push({id:v.id,passed:assertions.every(a=>a.passed),assertions,summary:s?.summary,note:v.id==='initial-unavailable'?'Frozen unavailable is semantic; library enum is unknown with initialnull. Actual CLI exit3 checked separately.':undefined});}
await writeFile(join(root,'candidate-c8-score.json'),JSON.stringify({vector_sha256:'4763a0b996efc9ad52a3f6a498e52440fe3eaa822128b3110819c95006a16381',scored,passed:scored.filter(x=>x.passed).length,total:scored.length},null,2)+'\n');console.log(JSON.stringify({passed:scored.filter(x=>x.passed).length,total:scored.length,failures:scored.filter(x=>!x.passed)}));
