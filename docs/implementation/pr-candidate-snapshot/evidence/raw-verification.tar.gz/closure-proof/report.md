# Limited closure proof

Production TS and CLI bytes match at c8,8a711 and622ead8. Complete8a711→622 diff has five paths: two tests, README, readiness reference and package.json. Package change only restores a literal em dash; parsed JSON is identical. CI and aliases already existed at8a711.

Root receipts bind new GitHub152/CLI14/export94 passing runs to622. GitHub includes45 candidate cases. These are inspected root runs, not independent replay. Original independent25+17 remain c8 with their original limits.

The compiled module exists in root and author trees with equal hash. Git build configuration maps src to dist. Scratch reads process.env on each call; createScratchDir creates parent recursively. scratchRoot alone does not create it; this CLI requires existing root/parent. These are static observations, not new execution.

No confirmed reporting constraint issue remains. Initial report-helper syntax error is retained separately and was not a product failure. Original independent directory remains frozen.
