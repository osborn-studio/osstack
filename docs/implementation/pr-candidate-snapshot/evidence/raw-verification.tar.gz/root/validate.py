import subprocess,pathlib,os,json,hashlib,datetime
w=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/pr306-control');r=pathlib.Path(__file__).parent
env={**os.environ,'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack','OSSTACK_HOME':str(r/'unused-home')};env.pop('OSSTACK_SOCKET',None)
h=subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip()
commands=[('github',['pnpm','--filter','@osstack/github','test']),('cli',['pnpm','test:pr-candidate']),('exports',['pnpm','test:method-export']),('import',['node','--input-type=module','-e',"const t=performance.now(); await import('./packages/github/dist/index.js'); console.log(JSON.stringify({loadMs:performance.now()-t}));"])]
receipts=[]
for name,args in commands:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'.stdout')).open('w') as o,(r/(name+'.stderr')).open('w') as e:code=subprocess.run(args,cwd=w,env=env,stdout=o,stderr=e).returncode
 item={'name':name,'argv':args,'head':h,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code}
 for suffix in ['stdout','stderr']:item[suffix+'_sha256']=hashlib.sha256((r/(name+'.'+suffix)).read_bytes()).hexdigest()
 receipts.append(item);(r/'focused-receipts.json').write_text(json.dumps(receipts,indent=2));print(name,code,flush=True)
 if code:raise SystemExit(code)
paths=subprocess.check_output(['git','-C',str(w),'ls-files','-z']).split(b'\0')
def snapshot(label):
 out={os.fsdecode(x):hashlib.sha256((w/os.fsdecode(x)).read_bytes()).hexdigest() for x in paths if x and (w/os.fsdecode(x)).is_file()};(r/(label+'.json')).write_text(json.dumps(out,indent=2));return out
before=snapshot('full-before');start=datetime.datetime.now(datetime.timezone.utc).isoformat();status=subprocess.check_output(['git','-C',str(w),'status','--short'],text=True)
with (r/'full.stdout').open('w') as o,(r/'full.stderr').open('w') as e:code=subprocess.run(['pnpm','test'],cwd=w,env=env,stdout=o,stderr=e).returncode
after=snapshot('full-after');(r/'full-binding.json').write_text(json.dumps({'head':h,'argv':['pnpm','test'],'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'initial_status':status,'tracked_files':len(before),'tracked_bytes_unchanged':before==after,'changed':[x for x in before if before[x]!=after.get(x)],'note':'Fresh four knowledge/dist initially dirty; not clean committed tree. No dist restore until all validation complete.'},indent=2));print('full',code,flush=True)
