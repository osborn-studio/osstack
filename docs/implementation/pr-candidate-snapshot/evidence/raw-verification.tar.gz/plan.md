# Next candidate: one bounded read-only PR snapshot

**Build a single-PR snapshot, not the upstream watcher.** The next queue outcome is a current candidate report that keeps CI, review and integration separate. The detailed implementable interface, response rules and test vectors are in `contract.json`; synthetic examples in `offline-cases.json` have not been executed.

## Exact source and actual gap

All source bytes are fixed in `source-map.json`: OSStack control `b2c18a2051e4aed5b88ca6665426596476fa7ff8` and pstack `99b609a72323b70204eab407c622f436e858e112`. Upstream `playbooks/babysit.md` steps1/5/6/9 supply one-shot check mode, conflict/review/CI distinctions, complete forge observations and the human merge boundary. `scripts/watch-pr/{github,policy,types}.ts` supplies paginated reads and explicit query/CI/thread state classes. `opening-a-pr.md` separates opening from babysitting. Do not copy its default drive/polling, Origin selection, write actions or always-ready publication policy into this slice.

Current `@osstack/github` already has useful pieces. `AttentionCiReader` reads current-head CI but caches results and lacks base/review observations. `observeCurrentGreenCandidate` is a read-only delivery hint, but requires branch/body/local-clean/protection context and returns undefined for non-green cases instead of a useful blocker report. `ingestStack` records branch names and aggregate checks; its `mapRollupToCheckState` does not retain all skipped/neutral distinctions. `fetchRepoGithubStatus` is a portfolio overview, not an exact candidate inspection. None should be advertised as absent or copied wholesale.

## Thin interface and boundaries

Library: `inspectPrCandidate(input, runner, clock)`. CLI: `node scripts/report-pr-candidate.mjs --repo OWNER/REPO --pr N --output ABSOLUTE_NEW_ROOT [--expect-head SHA --expect-base SHA] [--required-check NAME ...]`.

Read initial PR identity/facts, current-head check pages, review-thread pages, then final identity/facts. Pin checks to the initial commit object; detect head/base/branch/repository drift before consolidation. Limit each connection to three100-item pages, detect stalled cursors, preserve partial results as unknown. At most8 queries, each10s, total90s, no retries or polling. Reuse `DeliveryCommandRunner` and its safe argv/environment behavior; no candidate checkout or source execution. Do not record token/environment values.

Return observations and blocker lists, never merge permission. A favorable summary is `no_observed_blocker`, not READY or merge_ready. Requirements are caller-declared or unspecified; branch protection/rulesets/queue policy, individual approval commit and evaluated CI merge commit remain explicitly unknown/not_collected. This avoids pretending that the first slice solves complete forge policy. A failed query is not CI failure or an empty review queue. Skip/neutral remain distinct; known failure remains visible alongside missing data.

Exit0 means a report was produced, including a blocked/unknown report; exit2 is invalid input/output refusal; exit3 is an unavailable initial identity. Report artifacts retain command timings, exit codes, raw hashes and candidate scope. A new output path is required; no overwrite. Status checks can change immediately after observation: head/base bracketing is not an atomic forge transaction.

## Concrete use and independent work

After publishing PR306, the coordinator runs one snapshot against `osborn-studio/osstack`, PR306, with the actual published head/base pins if known. CI5-success/paid-smoke-skipped is preserved as observed; exact required names must come from the caller's policy context. After a retarget/push, take a fresh snapshot into a new directory. No watcher, re-run, approval or merge starts. This is useful even if full policy coverage remains unknown: it replaces repeated ad-hoc status collection and prevents accidental reuse of stale candidate evidence.

A owns `packages/github/src/pr-candidate-snapshot.ts` and `.test.ts`. B owns `scripts/report-pr-candidate.mjs`, `.test.mjs` and its implementation README. Root owns the barrel export, any package/CI/changeset wiring and an optional short link in the existing readiness material. No method is added. Select actual latest main when implementation starts; no dependency on PR305 projection or PR306 map maintenance. Fixed-source design here is not authority to reuse an old main blindly.

## Required finite tests

Stable clear candidate; head or base change; wrong expected pins; conflicts plus review+CI blockers; pending/failure/missing/duplicate/skipped/neutral checks; review required versus changes requested;100+1thread pagination; null/repeated cursors and caps; check-page wrong SHA; API/auth/rate/timeout/malformed/partialGraphQL failure; final-review-state change; strict output ownership; and a runner allowlist proving read-only calls. Synthetic examples do not claim actual GitHub execution. After implementation, one authorized real snapshot is sufficient for a bounded live demonstration. No model call or new host experiment is needed.

The artifact is scheduling/design input, not acceptance evidence, runtime qualification or PS17/PS18 completion.
