**Verdict: REVISE.** I found no confirmed security defect, and no invalid claim in the supplied docs. The REVISE is for test gaps that leave the fail-closed and containment claims under-proven.

## Required findings

1. **The CLI "output outside scratch" test is vacuous** (`scripts/report-pr-candidate.test.mjs`).
   - `/not-the-scratch-root/pr-report` doesn't exist, so `realpath(dirname(...))` throws ENOENT and the run exits 2 before `within()` is reached. Deleting `within()` would leave the test green.
   - That containment check is the only enforcement of "must be under OSSTACK_SCRATCH_ROOT".
   - Add these cases, each asserting exit 2, zero runner calls, and nothing written outside the root:
     - an existing parent outside the root;
     - a symlink inside scratch that points outside and is used as the parent;
     - `--output` equal to the scratch root itself.

2. **The `StatusContext` arm and the pending path have no coverage.**
   - Name mapping through `context` and every `StatusContext` state are untested. These are `SUCCESS`, `FAILURE`/`ERROR`, `PENDING` and `EXPECTED` or other values.
   - `checks_pending` → `waiting` is also untested. Only `REVIEW_REQUIRED` exercises `waiting`.
   - Add a `CheckRun` with `QUEUED` or `IN_PROGRESS` and a null conclusion. Add a `StatusContext` that satisfies a required name, one that fails, and one with an unknown state.

3. **The "never clears" assertions are weak or missing.**
   - A required name that is missing with everything else green is never tested. The only missing-name test also has a failing check, so the blocker masks it. Assert `unknown`.
   - The duplicate-name test asserts only `ambiguous_required`. It never asserts that the summary is not `no_observed_blocker`. Removing the `required_checks_ambiguous` unknown would still pass.
   - The "whole budget … retaining prior observations" test asserts only `summary` and `calls ≤ 1`. It doesn't check that `initial` is retained, the receipts, or the issue codes.

4. **Library-level negative tests are missing for gates that already exist in code.** The CLI test covers only a single exit-1 case.
   - Missing: non-zero exit, stdout over 1 MiB, non-JSON stdout, `repository_mismatch`, `duplicate_id` across pages, thread `pr_mismatch`, and `hasNextPage` with a null cursor.
   - Missing: `merged` and `closed` summary precedence.
   - Missing: a positive case where matching expected pins give `stable` and `no_observed_blocker`.
   - The README's "request bounds" claim currently rests on only the 3-page cap and a weak budget test.

## Must verify, not confirmed

- **CI ordering.**
   - Every non-help CLI test dynamically imports `packages/github/dist/...`. Without a prior `@osstack/github` build they exit 2.
   - I can't see whether the new `pnpm test:pr-candidate` step in `ci.yml` runs after that build. Your pending root fresh/full run is where this will show.

## Optional advice

- **Case-sensitive repo check.** `nameWithOwner !== validated.repo` is case-sensitive, so `--repo Owner/Repo` always ends as `repository_mismatch` and exit 3. This is fail-closed but misleading. Compare case-insensitively, as `delivery.ts` already does.
- **Unrelated diff in `package.json`.** The description's `—` became `\u2014`. It parses the same but looks like a JSON re-serialize, so revert it and check for other churn.
- **`missing_required` when checks weren't collected.** It is populated even when the checks facet is incomplete or `not_collected`, so it reads as "absent" when the truth is "not evaluated". Derive it only when `complete`.
- **Null `statusCheckRollup`.** A commit with no checks hits `record(null)` and is reported as `invalid_response`. That is safe, but a distinct issue code would help operators.
- **Null `reviewDecision`.** A repo with no review policy yields `review_decision_unknown` and so never reaches `no_observed_blocker`. That is safe, but the README doesn't say so.
- **Name-only matching.** Required checks match by name across `CheckRun` and `StatusContext`, ignoring app or source. Add this to the limitations.
- **Runner-dependent bounds.** The 10s and 90s bounds rely on the runner honoring `timeoutMs`. There is no `Promise.race` or abort. `limits` and `limitations` are hard-coded even for an injected runner, and `Date.now` is not monotonic.
- **README and doc nits.**
  - The example breaks if `OSSTACK_SCRATCH_ROOT` is unset (it expands to `/runtime/...` and is refused). The default `tmpdir/osstack` isn't mentioned.
  - `pr-readiness.md` has the typo "Exit0".
- **Single refusal code.** A missing build and a bad output path both return `input_or_output_refused`. A distinct code would help operators.
- **Raw output is decoded strings.** The "exact raw receipts" test title overstates it, because `execFile` decodes UTF-8.

## Checked and consistent

- The request arithmetic holds: 1 + 3 + 3 + 1 = 8 queries. Per-request timeout is clamped to the remaining budget.
- Argv-only `execFile` with `-f` for strings means no injection path. Cursors are never interpreted as `@file`.
- The test counts match your claim: I count 27 vitest cases in the new file and 11 CLI tests. The CLI file count of 10 manifest files (snapshot, queries, and 4 raw pairs) is right.
- Exit-code semantics and the README match the code.
- Blockers, waiting reasons and unknowns stay separate arrays and survive a `candidate_changed` or `unknown` summary.

## Not verifiable from the supplied material

I could not verify the 134 package-test total, the Gitcode commit `8a711bd1…`, or the pinned upstream URLs, author attribution and MIT license for pstack. Attribution appears only in the README, which is reasonable since the README says no upstream source was copied. I'm not treating the pending root and 25-vector runs as passed.

Fix items 1–4 and re-submit. Items 1–3 are small additions to existing test files.