# PR307 lint repair

Original head `9d54cfdc658ac137ae9e95d08499aad77ec529f0`, CI run40926150260. The default Biome diagnostic cap hid two errors in the new required check-name control-character regex. Re-running `pnpm lint --max-diagnostics=1000` reproduced both errors and21 pre-existing warnings.

Candidate `6cea803e7b820410c188769a17341ff2c1e4f078` replaces only the regex predicate with an equivalent ASCII C0/DEL numeric check. No lint rule, ignore directive, formatter or unrelated source was changed. Added tests cover all33 disallowed ASCII controls and representative allowed printable/Unicode/C1 values. The47 focused tests pass before and after; this is lint RED→GREEN, not a false claim of behavioral failure. Both expanded lint and the exact CI `pnpm lint` command now exit0 with the same21 warnings. GitHub package tsc build passes. No full suite/model/live forge request was made.

The original CI failure log is copied byte-for-byte and bound in handoff.json. This new evidence directory does not modify any prior author or CI archive. Root owns publication and final remote checks.
