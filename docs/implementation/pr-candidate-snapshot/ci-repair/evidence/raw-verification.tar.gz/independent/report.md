# Limited PR307 lint equivalence

All277 frozen acceptance cases match old9d54 and new6cea; the omitted-list control also matches:208accepted/70rejected. Every rejected input stops before an injected runner is called. Complete clear and NEUTRAL/unknown snapshots, query receipts and raw strings are identical under the same fixed clock/responses.

ASCII0–127 was tested alone and embedded. Unicode/space/common names, length101/256/257 and list100/101, exact duplicates and case/normalization distinctions preserve the original contract. C0/DEL rejection is not weakened. Production diff only replaces the control-character predicate; the other changed file is its test.

This is bounded offline equivalence evidence from two exact Git sources transpiled in scratch with shared dependencies. No lint/full/forge/DB/model execution was performed; no old freeze or result was changed. No confirmed issue.
