import { readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { makeOfflineRunner } from '/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr306-main-retarget-20261030/next-candidate/independent/runner-harness.mjs';
const base='/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr307-lint-20261030/independent';
const author='/Users/osborn/Developer/CodeX/.worktrees/osstack/pr307-lint-author';
const repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';
const refs={old:'9d54cfdc658ac137ae9e95d08499aad77ec529f0',candidate:'6cea803e7b820410c188769a17341ff2c1e4f078'};
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=(ref,path)=>execFileSync('git',['show',ref+':'+path],{cwd:repo});
const require=createRequire(author+'/package.json'),pkg=createRequire(author+'/packages/github/package.json');
const ts=require('typescript');
assert(git(refs.old,'packages/github/src/delivery.ts').equals(git(refs.candidate,'packages/github/src/delivery.ts')));
const modules={},bindings=[];
for(const [label,ref]of Object.entries(refs)){
 const source=git(ref,'packages/github/src/pr-candidate-snapshot.ts');
 let emitted=ts.transpileModule(source.toString(),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
 emitted=emitted.replace("'./delivery.js'",JSON.stringify(pathToFileURL(author+'/packages/github/dist/delivery.js').href)).replace("'zod'",JSON.stringify(pathToFileURL(pkg.resolve('zod')).href));
 await writeFile(`${base}/${label}-module.mjs`,emitted,{flag:'wx'});await writeFile(`${base}/${label}-git-source.ts`,source,{flag:'wx'});
 modules[label]=await import(pathToFileURL(`${base}/${label}-module.mjs`));bindings.push({label,ref,source_sha256:sha(source),emitted_sha256:sha(emitted)});
}
const vectors=JSON.parse(await readFile(base+'/vectors.json','utf8')).vectors;
const rows=[];
for(const v of [...vectors,{id:'omitted-list',accepted:true}]){
 const input={repo:'example/project',pr:17,...(v.requiredChecks===undefined?{}:{requiredChecks:v.requiredChecks})};const outputs={};
 for(const [label,mod]of Object.entries(modules)){
  let accepted=false,parsed,error,transport_calls=0;
  try{parsed=mod.validatePrCandidateInput(input);accepted=true;}catch(e){error={name:e.name,message:e.message};}
  if(!accepted){try{await mod.inspectPrCandidate(input,{run:async()=>{transport_calls++;throw Error('unexpected_transport');}},()=>0);assert.fail('invalid_input_inspection_accepted');}catch(e){assert.equal(e.message,'invalid_input');}assert.equal(transport_calls,0);}
  outputs[label]={accepted,parsed,error,transport_calls};
 }
 const same=JSON.stringify(outputs.old)===JSON.stringify(outputs.candidate);rows.push({...v,outputs,passed:same&&outputs.old.accepted===v.accepted});
}
const frozen=JSON.parse(await readFile('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pr306-main-retarget-20261030/next-candidate/independent/vectors.json','utf8')).vectors;
const snapshots=[];
for(const id of ['clear','check-NEUTRAL']){
 const outputs={};for(const [label,mod]of Object.entries(modules)){const f=structuredClone(frozen.find(v=>v.id===id).fixture),h=makeOfflineRunner(f);outputs[label]={observation:await mod.inspectPrCandidate({repo:'example/project',pr:17,requiredChecks:['test']},h.runner,h.clock),calls:h.calls};}
 snapshots.push({id,outputs,equal:JSON.stringify(outputs.old)===JSON.stringify(outputs.candidate)});
}
const summary={vectors_frozen:277,extra_omitted_control:1,passed:rows.filter(r=>r.passed).length,failed:rows.filter(r=>!r.passed).map(r=>r.id),accepted:rows.filter(r=>r.outputs.candidate.accepted).length,rejected:rows.filter(r=>!r.outputs.candidate.accepted).length,snapshot_equal:snapshots.map(r=>({id:r.id,equal:r.equal})),scope:'Offline actual public validation/collector functions from old/new Git transpiled with same compiler and dependencies. No gh/DB/model/full or lint invocation.'};
await writeFile(base+'/results.json',JSON.stringify({rows,snapshots},null,2)+'\n',{flag:'wx'});await writeFile(base+'/binding.json',JSON.stringify({modules:bindings,typescript:ts.version,compiler_sha256:sha(await readFile(require.resolve('typescript'))),delivery_dist_sha256:sha(await readFile(author+'/packages/github/dist/delivery.js')),zod_path:pkg.resolve('zod'),vectors_sha256:sha(await readFile(base+'/vectors.json')),note:'Only module import locations rebased; no function edits. Same dependency source bytes at both commits.'},null,2)+'\n',{flag:'wx'});await writeFile(base+'/summary.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(summary,null,2));if(summary.failed.length||snapshots.some(r=>!r.equal))process.exitCode=1;
