# PR304 main retarget independent Git check

Maina0ecd79d has exactly303head d05c9d91 treeaefd2dca. Merging newmain with304head185d producesdbe85299, exactly304 existingtree, with no conflict. The18path main→304 binarydiff is byte-identical to303head→304diff, so303content is not lost.

Actual changes: journey script/test, two method references, CI;13docs include evidence/ledger/queue/publication records. No packages, lock, shared contracts or schemas changed. No source change needed solely for retarget.

Tree equality is not fresh validation or CI. Root should bind actual newhead and rerun applicable focused/realjourney/docs checks and currentCI per plan. No tests, models or PR changes were made. Computedmerge objects stayed in ownscratch.
