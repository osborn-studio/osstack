# PR304 retarget review: PASS (static, read-only)

I reviewed only the supplied text and ran nothing. Nothing here claims that tests or journeys were rerun on `7ef051ff` or `a0ecd79d`.

## Basis for PASS

**Integration.** The tree proof says `a0ecd79d` and `d05c9d91` share tree `aefd2dca`, and `7ef051ff` and `185d283a` share tree `dbe85299`. If those values are accurate, both the base and the head moved to new commits without changing any file content. That makes the retarget content-neutral, so the reviewed diff carries over. I could not recompute the hashes, so this rests on the supplied values.

**Scope.** I found nothing that imports PR305 work.
- The CI projection steps still consume only the default two-case output directory.
- The full journey writes to its own directory and artifact.
- The docs state that the existing projector refuses full scope, and say not to drop rows to make it accept one.

**Code and contracts.** I found no defect in the diff.
- `parseOptions` is strict.
  - It rejects an odd argument count, repeated flags, a missing value, an unknown flag, `--scope` values other than `full`, and a relative output path.
  - Omitting `--scope` still returns `{ output }`.
- `runJourney` rejects an invalid scope before `mkdir`, and a test asserts this.
- The verifier's per-case policy table matches the documented exits 0/1/2/1/0.
- The verifier does not trust the recorded expectation alone.
  - It rebuilds the fixed sources and requires the recorded sources to match.
  - It takes the old SHA from the recorded `git-03` output and compares the new `git-05` output to `current_sha`.
  - It matches raw stdout line for line, so extra or missing source rows fail.
- The tests cover each of these:
  - the per-case policy table and fixed-source reconstruction;
  - the exact stdout match and `git-05` identity;
  - doctor failure and drive failure with later rows left `not_run` and cleanup left `unknown`;
  - rejection of an unknown scope.
- I counted 25 pre-existing tests and 18 added ones, 43 in total, matching the README's "43 journey". That is a count only, not a run result.
- The `ci.yml` step is consistent with the diff.
  - It uses its own output directory and an artifact name unique per run id and attempt.
  - It uses `always() && outcome != 'skipped'`, the same pinned upload action, and `--scope full` forwarded like `--output`.
- The docs match the code on every point I checked:
  - option semantics, including that repeated scope is invalid usage;
  - the five product exits;
  - "failure stops later rows, which stay `not_run`";
  - `descendant_termination` staying `not_attested`.

## Blockers

None.

## Needed before Ready (evidence gates, not static defects)

1. **Ancestry and diff provenance.**
   - Confirm `a0ecd79d` is an ancestor of `7ef051ff` and is the PR's base on GitHub. Tree equality does not show ancestry, and pull_request CI tests the merge ref.
   - The pasted diff names no endpoints. Regenerate `git diff a0ecd79d 7ef051ff` and compare it, by file list and blob ids, with the pasted one.
2. **README is not in the diff.**
   - `docs/implementation/method-full-journey/README.md` was supplied as a file, but the diff has no hunk for it, and it points to `evidence/raw-verification.tar.gz`.
   - Either the diff is incomplete, or the README is not a repo file. In the second case, do not treat it as repo content.
   - Tree equality still covers whatever is actually in the tree, but my review covers only the five files in the diff plus the README text.
3. **Real-driver behavior for the three new cases.** Static review cannot confirm that the real driver emits exactly `git-00` to `git-05` plus the case label for drift, mixed and empty. It also cannot confirm that the real CLI prints `Checking 0 source(s)…` for empty. The new step "Full method verification journey (five real local cases)" in fresh CI on the published head, or a live full run, is the only decisive check.
4. **Projector refusal claim.**
   - The new docs state that `project-method-journey-evidence.mjs` refuses full output before creating its output directory.
   - The projector source is not in the materials, and the CI projection steps exercise only the default output.
   - Confirm with the applicable projection test or a read-only run against the full output.
5. **Changeset and export gates.** The diff has no `.changeset` file and touches `scripts/` and `osstack-methods-skill/`. Let the "Changeset coverage", "Method export contracts" and "Inventory freshness" steps decide in fresh CI.

## Optional suggestions

- Do not cite the README's "7,144 pass / 5 skip" regression as covering `a0ecd79d`. It is scoped to an earlier base and says so. Put the retarget statement in the PR body rather than the tree, since a tree edit would break the tree-equality proof. For example: "trees identical to `185d`; prior results apply by tree identity, not rerun."
- The verifier compares sources with `JSON.stringify`, which depends on key order. A key-sorted comparison would keep it from failing if `caseDefinition` reorders fields.
- If `git-03.stdout` is dropped and the manifest resealed, the error is now `fixture_old_sha` instead of the clearer `command_raw_required`. Consider adding `git-03.stdout` to the required-evidence list.
- Compare the fresh CI job duration with `timeout-minutes: 35`, since the extra five-case run adds time.