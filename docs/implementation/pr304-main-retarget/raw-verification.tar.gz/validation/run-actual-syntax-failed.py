from pathlib import Path
import importlib.util,json,hashlib
spec=importlib.util.spec_from_file_location('validation',Path(__file__).with_name('run-validation.py'));v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
R=v.R;record=v.record

def snapshot(root):
 return [{'path':str(p.relative_to(root)),'sha256':v.sha(p.read_bytes()),'bytes':p.stat().st_size}for p in sorted(root.rglob('*'))if p.is_file()]
summary={}
for scope in ['default','full']:
 out=R/('actual-'+scope);args=['node','scripts/method-verification-journey.mjs','--output',str(out)]
 if scope=='full':args+=['--scope','full']
 record('actual-'+scope,args)
 result=json.loads((R/('actual-'+scope+'.stdout')).read_text());assert result==json.loads((out/'journey.json').read_text())
 ids=['healthy','missing-ref']if scope=='default'else['healthy','missing-ref','drift','mixed','empty']
 exits=[0,1]if scope=='default'else[0,1,2,1,0]
 assert result['status']=='passed' and [x['case_id']for x in result['features']]==ids and[x['product_exit']for x in result['features']]==exits
 assert all(x['driver_exit']==0 and x['verification']=='passed' and x['cleanup']['fixture_removed']for x in result['features'])
 before=snapshot(out);(R/(scope+'-before-projection.json')).write_text(json.dumps(before,indent=2)+'\n')
 packet=R/('packet-'+scope)
 record('project-'+scope,['node','scripts/project-method-journey-evidence.mjs','--input',str(out),'--output',str(packet)],0 if scope=='default'else1)
 if scope=='default':
  record('check-default',['node','scripts/project-method-journey-evidence.mjs','--check',str(packet)])
  assert json.loads((R/'check-default.stdout').read_text())['status']=='valid'
 else:
  assert not packet.exists();assert json.loads((R/'project-full.stderr').read_text())['status']=='rejected'
 after=snapshot(out);assert before==after
 (R/(scope+'-after-projection.json')).write_text(json.dumps(after,indent=2)+'\n')
 summary[scope]={'journey_status':result['status'],'product_exits':exits,'driver_exits':[x['driver_exit']for x in result['features']],'packet_created':packet.exists(),'source_members':len(before),'source_unchanged':True,'case_manifests':result['retained']['case_manifests'],'limits':result['limitations']}
(R/'actual-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('actual verification complete',flush=True)
