# Verdict: REVISE

The core results hold up in the supplied evidence. The edits needed are narrow: attribution, raw-vs-model-visible symmetry, and evidence tiers.

**What I verified:**
- **Codex RED→GREEN.** The test file hash is identical across RED and GREEN (`9c4bdd93…`). The checker changed from `b22cbb16…` to `f8703f60…`, with a one-line patch. The incident input hash is unchanged, and `lib/*` is unchanged. RED is a real assertion failure (`0 !== 1`, 2 pass/1 fail) and GREEN is 3/0. Both controls were accepted before and after.
- **Codex helper runs.** All eight helper `result.json` files exist, with matching hashes and timing inside the 600 s budget.
- **Claude outcome.** Zero product invocations, zero writes, unchanged inventory, one denied compound command, and "exit 0 ≠ repair" is stated.
- **Pre-output correction.** The H06→H06b correction (04:57:34) precedes the dispatch (05:08:54) and both model starts (05:09:08), and `model_calls_so_far` is 0.
- **Coordinator rechecks.** All 11 rechecks match their `expected_exit`. The Claude raw-stream hash `1227d79e…` agrees between the remediation doc and the retained summary.

## Blocking issues

1. **Claude denial attribution contradicts the remediation doc.**
   - The README says the command was "outside the allowed single-command form". That presumes the atomic form is allowed. The remediation doc says the atomic form was never attempted and its native pass/fail is untested.
   - The README also omits two points:
     - The request listed four separate commands and did not forbid combining them, so this is partly task-interface ambiguity, not only model command choice.
     - Claude's final answer asked for Bash permission that `settings.json` already grants, which is a misdiagnosis.
   - **Fix:** Say the compound command was denied and the atomic form was not attempted. Add that the final answer's permission request was unsupported by the settings.
   - The denial text isn't in the extract, so don't attribute the denial specifically to `for` or `echo`. Say "compound".

2. **The raw-vs-model-visible rigor is applied to Claude only.**
   - "Codex explicitly received all three method files" rests on exact bytes in the raw event 8. Nothing shows the model-facing output was untruncated.
   - A 29.7 KB `cat` already triggered Claude's persisted-output replacement, and Codex's materials are of similar size.
   - **Fix:** Say "read via shell; raw event contains exact bytes; model-visible delivery not attested", or cite evidence of untruncated delivery.
   - Claude wording:
     - "Contains the full source" is ambiguous with the product source. Use "full reference-file bytes".
     - "No subsequent full read" should be "none observed".
     - Note that Claude's final claim of having read both references directly overstates what the preview delivered.

3. **The maintenance section needs attribution and a clearer RED→GREEN description.**
   - The README never says in this file that the coordinator, not a model host, injected the stale cell, diagnosed it, and edited the map. The maintenance README says so.
   - The GREEN came from editing the expected-value input, not product code, so it is not a bug-fix GREEN. Say the correction was justified by source inspection (`diagnosis.json`) so it doesn't read as tuning an expectation to match output.
   - No hash is supplied showing `check-map.py` was unchanged between RED and GREEN. Cite one, or soften "same comparison".

4. **The credential claim is unattributed and in tension with the extract.**
   - "Authentication was inherited, not copied" is stated as fact. The Codex record shows `CODEX_HOME` and `HOME` among the environment keys, `private_home_removed: true`, and no credential variable.
   - The extract doesn't show how Codex authenticated under that setup, so it neither confirms nor refutes "not copied".
   - **Fix:** Attribute the claim to the harness statement ("not read/copied/recorded by harness"), or explain the auth path.

5. **Control and holdout tiers are blurred.**
   - The README lumps the coordinator's eleven checks together. They are all candidate-side, except the single test run on the original.
   - H06b is byte-identical to the visible incident (a path-independence control, not new data).
   - All five rejections share the same generic stderr hash (`affeba52…`), so exit 1 doesn't show which predicate fired.
   - Baseline outcomes of H01–H05 on the original checker are not in the extract. Without them there is no holdout RED→GREEN.
   - **Fix:** Add a short tier list:
     - (a) host-run same-test RED→GREEN;
     - (b) host-run legal controls;
     - (c) coordinator candidate-side hidden checks, with H06b labelled a relocation;
     - (d) baseline discrimination, cited from the baseline-feasibility file or omitted.

## Next-step proposal: settle before freezing

- **Fallback rule.** Allowing an in-turn reissue after a denial conflicts with the request's "report the blocker without bypassing". It also blurs "zero retries" and could mask the failure being tested.
  - Recommendation: drop it. Atomic-only instructions already remove the cause.
- **Task selection.** "Newly frozen independent task" is undefined. If it reuses this incident, the fix and graded artifacts now exist.
  - Recommendation: pick a different defect and say whether it is historical or new.
- **Claim size.** With one model and n=1, a pass shows only that the atomic form is permitted and followable. Pre-register it as a feasibility check, not efficacy.
  - The first atomic call is also the native permission preflight, so a denial there ends the budgeted turn. Accept that explicitly.
- **Index base.** README and graded results use 0-based event indices (event 15). The remediation uses 1-based lines (line 16, denial line 18). Label the base.

## Non-blocking suggestions

- The "eight helper commands" list includes "bounded checker fix", which is an edit, not a helper command.
- Note that Codex also ran non-helper shell commands (heredoc writes, Python analysis). Its helper-only restriction was prompt-level, so adherence is trace-observed (RL09).
- State the requested model for each host (`gpt-6.1-sol`, `claude-sonnet-5-5`). Note that Claude's `modelUsage` is CLI self-report.
- "Same" inputs across hosts is true for the checker and six inputs only. Template hashes (105 vs 107 frozen files) and export manifests differ.
- The dispatch supplement records a "default catalog observed" for Codex, but the run used `--ignore-user-config` and similar flags. Say that this does not settle native availability.
- Disclose that dependency install used the registry (it is in the maintenance README only).
- Fix the missing spaces ("report7142passed").

## Not assessable from the supplied extract

- PR302, CI, and test counts (out of scope per your note).
- The "13-method" export count (the supplement shows 84 payload files).
- `assessment/graded-results.md` (only `graded-results.json` was supplied).
- `helper-preflight.json` and the `diagnosis.json` content.
- Raw event streams.