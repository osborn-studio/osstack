**PASS**

- **R1, Claude denial attribution: closed.** The README says the compound command was denied, the atomic form was never attempted, and its native outcome is untested. It separates the settings declaration from observed behavior. It credits the request's ambiguity and calls Claude's permission request unsupported by the declared settings. It also declines to isolate `for`, `echo` or any other token as the cause.
- **R2, raw vs model-visible: closed.** Both hosts now get the same treatment. Codex event 8 is "recorded tool read, not independently attested model-visible delivery." Claude has "full reference-file bytes" in raw output against a roughly 2 KiB preview, "no subsequent full read was observed," and its read claim is flagged as overstated. Model identity is also scoped to requested vs self-reported.
- **R3, maintenance: closed.** The README states that the coordinator injected the stale cell, diagnosed it and edited the map. It labels the result source-justified documentation drift (citing `diagnosis.json`), not a product bug-fix GREEN or a model-host action. The missing comparator hash is disclosed, and the "same comparator path" wording is not overclaimed. The registry install is disclosed.
- **R4, credentials: closed.** The claim is now a harness implementation statement. `common.py` matches it: the `env()` comment says no credential reads, copies or hashes, and it only sets `CODEX_HOME`, `CLAUDE_CONFIG_DIR` and `HOME`. The README explicitly disclaims knowledge of the CLI's authentication internals and scopes "no credential inspection" to the supplied traces.
- **R5, evidence tiers: closed.** The four tiers are separated: host regression, host controls, coordinator candidate-side checks, and baseline discrimination.
  - H06b is labeled a relocation of the visible incident bytes.
  - The generic rejection error is stated not to identify the predicate.
  - Tier 4 is cited to `independent/baseline-check/` and the feasibility report, and `baseline-feasibility.json` is consistent with that. It is not presented as model-run holdout RED→GREEN.
- **Next-step protocol: consistent across the README, remediation and amendment.**
  - The next task is a different defect, labeled historical or new.
  - No task has been selected or dispatched.
  - The first atomic call is the permission check, and a denial ends that turn.
  - There is no fallback, reissue or inherited budget.
  - It is framed as feasibility, not efficacy.
  - Event indices are labeled zero-based, and the remediation's log lines are labeled one-based.

**Non-blocking:**
- The README still has missing spaces ("at most600seconds", "returned0", "2passed/1failed").
- The remediation doc names `for`/`echo` as the attempted form. That describes the command and does not assert a cause, so it is compatible with the README.