from pathlib import Path
import json,hashlib,subprocess
p=Path(__file__).resolve().parent;repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/maintenance-real-loop');h=lambda b:hashlib.sha256(b).hexdigest()
results=[];all_bindings=[]
for phase in ['red-drive','green-drive']:
 root=p/phase;j=json.loads((root/'journey.json').read_text());assert j['status']=='passed';assert len(j['features'])==2
 for manifest in [root/'journey-manifest.json',root/'cases/healthy/manifest.json',root/'cases/missing-ref/manifest.json']:
  m=json.loads(manifest.read_text());entries=m['files'];assert len({e['path'] for e in entries})==len(entries)
  for e in entries:
   f=manifest.parent/e['path'];assert f.parent==manifest.parent and not f.is_symlink();b=f.read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256']
  actual={f.name for f in manifest.parent.iterdir() if f.is_file()};assert actual=={e['path'] for e in entries}|{manifest.name}
  results.append({'manifest':str(manifest.relative_to(p)),'members_verified':len(entries),'sha256':h(manifest.read_bytes())})
 for f in j['features']:
  c=f['cleanup'];assert c['status']=='passed' and c['fixture_removed'] and not Path(c['fixture_path']).exists();assert c['descendant_termination']=='not_attested'
  case=root/'cases'/f['case_id'];bindings=json.loads((case/'bindings.json').read_text());all_bindings.append(bindings)
  assert json.loads((case/'run.json').read_text())['git_head']=='1bf1f6caa0ac0ae7b05c3caa9bb44d7ce6517dd0'
  raw=json.loads((case/(f['case_id']+'.command.json')).read_text());assert raw['exit_code']==(0 if f['case_id']=='healthy' else 1);assert raw['direct_child_exit_confirmed']
  assert json.loads((root/(f['case_id']+'-doctor.stdout')).read_text())['ready'] is True
 assert list((root/'scratch/smoke').iterdir())==[]
assert all(b==all_bindings[0] for b in all_bindings)
for group in ['source','build']:
 for e in all_bindings[0][group]['files']:
  f=repo/e['path'];assert not f.is_symlink();b=f.read_bytes();assert len(b)==e['bytes'] and h(b)==e['sha256']
status=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
assert set(x[3:] for x in status.splitlines())=={'packages/knowledge/dist/index.d.ts','packages/knowledge/dist/index.d.ts.map','packages/knowledge/dist/index.js','packages/knowledge/dist/index.js.map'}
print(json.dumps({'status':'passed','manifests':results,'all_four_source_build_bindings_equal':True,'current_live_files_match_retained_bindings':{g:len(all_bindings[0][g]['files']) for g in ['source','build']},'fixed_source_commit':'1bf1f6caa0ac0ae7b05c3caa9bb44d7ce6517dd0','generated_changes_only':status.splitlines(),'all_four_owned_fixture_paths_absent':True,'evidence_retained':True,'descendant_termination':'not_attested','host_execution':'not_run','formal_gate_pass':False},indent=2))
