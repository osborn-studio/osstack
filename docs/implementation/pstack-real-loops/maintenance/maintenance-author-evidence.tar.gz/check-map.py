import json,sys,re,hashlib
from pathlib import Path
map_path,journey_path=map(Path,sys.argv[1:])
text=map_path.read_text();rows=re.findall(r"^\| (healthy|missing-ref) \| (\d+) \| (\d+) \|$",text,re.M)
j=json.loads(journey_path.read_text()); issues=[]
if len(rows)!=2 or {r[0] for r in rows}!={'healthy','missing-ref'}: issues.append({'reason':'map_coverage'})
if j.get('status')!='passed':issues.append({'reason':'journey_not_passed'})
features={f['case_id']:f for f in j['features']}
if set(features)!={'healthy','missing-ref'}:issues.append({'reason':'live_coverage'})
for case,product,driver in rows:
 f=features.get(case,{})
 for key,expected in [('product_exit',int(product)),('driver_exit',int(driver))]:
  if f.get(key)!=expected:issues.append({'case':case,'reason':key+'_mismatch','expected':expected,'actual':f.get(key)})
 if f.get('verification')!='passed':issues.append({'case':case,'reason':'verification_not_passed'})
 cleanup=f.get('cleanup',{})
 if cleanup.get('status')!='passed' or cleanup.get('fixture_removed') is not True:issues.append({'case':case,'reason':'cleanup_not_confirmed','cleanup':cleanup})
result={'status':'failed' if issues else 'passed','issues':issues,'map_sha256':hashlib.sha256(map_path.read_bytes()).hexdigest(),'journey_sha256':hashlib.sha256(journey_path.read_bytes()).hexdigest(),'scope':'scratch map comparison; driver retained evidence is verified separately; not an independent oracle'}
print(json.dumps(result,indent=2));sys.exit(1 if issues else 0)
