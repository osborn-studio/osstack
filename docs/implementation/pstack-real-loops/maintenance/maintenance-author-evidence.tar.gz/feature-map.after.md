# Owned skills-check maintenance fixture

Intentionally injected documentation drift. Not a production defect report.
Source: 1bf1f6caa0ac0ae7b05c3caa9bb44d7ce6517dd0.
Run both features with: node scripts/method-verification-journey.mjs --output NEW_ABSOLUTE_DIRECTORY
The wrapper runs doctor before each fresh drive; it supports no --case flag.

| Feature | Expected product exit | Expected driver exit |
|---|---|---|
| healthy | 0 | 0 |
| missing-ref | 1 | 0 |

Coverage is only these two rows. drift, mixed and empty are outside this map.
Source: scripts/lib/skills-check-verification.mjs caseDefinition and packages/cli/src/skills-command.ts.
Evidence: journey.json, journey-manifest.json, per-case manifests and raw command outputs.
Require both passed verification, removed owned fixtures, unchanged input and complete retained evidence.
Model/native-host execution, all-descendant termination, and formal gates remain unproven.
