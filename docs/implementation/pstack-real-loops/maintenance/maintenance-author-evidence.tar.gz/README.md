# Actual verification maintenance loop

Outcome: changed within the owned exercise. One deliberately stale map cell was diagnosed and repaired. No product defect was discovered or patched. This is an actual coordinator-driven CLI exercise, not a model-host experiment.

## Scope and origin

Fixed OSStack source: `1bf1f6caa0ac0ae7b05c3caa9bb44d7ce6517dd0`. Independent engineering criteria were frozen before runtime at `bca15a7b0e3e76c6c744376a55d35bcade8b2cbfe5f15a441c8859599e2f382d`.

The existing `maintain-verification.md` method and fixed `method-verification-journey.mjs` were sufficient. The upstream maintenance source at pstack pin `99b609a72323b70204eab407c622f436e858e112` requires source inspection and live coverage for each mapped feature, health checks, failure preservation, classification and a real re-drive after corrections. `source-bindings.json` records exact source hashes; retained original text is source material, not new instructions.

The owned map has two features: healthy and missing-ref. The latter was intentionally given stale expected product exit 0. The real missing-ref contract is exit 1. This injection tests a maintenance workflow; it is not evidence of spontaneous production drift. No feature was removed. drift/mixed/empty were explicitly outside this map from the start.

## Executed sequence

1. A dedicated fixed-main worktree was installed with `pnpm install --frozen-lockfile` and built with `pnpm build`, both exit 0 under Node 22.22.1. Install warnings about unavailable not-yet-built loop bins remain in the raw log. No whole-repository tests ran.
2. `node scripts/method-verification-journey.mjs --output <scratch>/red-drive` exited 0. It ran doctor before each fresh real file-Git fixture and invoked the compiled CLI for both features.
3. `python3 check-map.py feature-map.md red-drive/journey.json` exited 1. Its only mismatch was missing-ref expected product exit 0 versus actual 1. `map-red.stdout` retains this RED. The healthy product exit was 0. Both driver exits were 0.
4. Source `caseDefinition` and `skills-command.ts` failure handling agreed with raw `no_matching_ref` and one failed-source output. `diagnosis.json` classified documentation drift, not a product regression or harness gap. `repair.diff` changes only the owned map's missing-ref expected product exit from 0 to 1.
5. The same wrapper path ran again with the same source and build, a new `green-drive` output and fresh isolated fixtures. Both cases completed. The same `check-map.py` at the same path exited 0 against the corrected map and the new journey result.
6. `verify-evidence.py` exited 0. It verified all 6 manifests (two journey manifests of 14 members and four case manifests of 29), all four equal source/build bindings, 1,061 current source files plus 2,336 current build files against retained hashes, and the absence of all four owned fixture paths. Temporary smoke directories were empty. Original raw evidence remained available.

The command JSON records contain exact argv, cwd, explicit minimal environment, timestamps, PID, timeout, exit code and raw stream hashes. `feature-map.before.md` and `feature-map.after.md` preserve both versions. The checker is small task-local comparison code, not a new production utility or independently authenticated oracle.

## Interpretation

This demonstrates a usable source→live observation→documentation-drift diagnosis→authorized correction→same-path re-verification loop for every feature in this bounded two-row map. Expected product failure remains visible: missing-ref product exit 1 and driver exit 0 are different facts. Passing the driver never turns the failed source into a healthy source.

It does not prove native discovery, a model's ability to maintain verification, effects on success rate, complete skills-check coverage, installed-dependency authenticity, all-descendant termination, or any J milestone gate. The wrapper itself records host execution not_run and formal_gate_pass false. Fixture deletion and direct-child exit do not attest every descendant. No default OSStack home, DB, management instance, model or external skill origin was used. Dependency installation used the registry; runtime fixtures used local file Git.

There is no new product commit or PR requested by this exercise. The root may publish the evidence with its project rollup. An independent reviewer will separately report its observations; this author report does not substitute for that result.
