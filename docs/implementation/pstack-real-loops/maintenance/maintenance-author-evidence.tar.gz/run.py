import subprocess,sys,json,hashlib,datetime,os,signal
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/maintenance-real-loop')
label=sys.argv[1]; args=sys.argv[2:]
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(root/'home'),'OSSTACK_HOME':str(root/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack','LANG':'C','LC_ALL':'C','CI':'true'}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(label+'.stdout')).open('xb') as out,(root/(label+'.stderr')).open('xb') as err:
 p=subprocess.Popen(args,cwd=repo,env=env,stdout=out,stderr=err,start_new_session=True)
 timed=False
 try: code=p.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
record={'argv':args,'cwd':str(repo),'environment':env,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'timeout':timed,'pid':p.pid,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()}
for s in ('stdout','stderr'):
 b=(root/(label+'.'+s)).read_bytes();record[s]={'path':label+'.'+s,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(root/(label+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));sys.exit(code)
