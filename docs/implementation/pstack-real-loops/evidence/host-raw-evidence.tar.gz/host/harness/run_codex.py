from common import ROOT,H,env,save,now,sha,inventory,stop,USER
from pathlib import Path
import os,subprocess,json,hashlib,signal,shutil,sys

def main(phase):
 case=ROOT/'runs'/'codex';ev=case/'evidence';ws=case/'workspace'
 approval=json.loads((H/('dispatch-codex-'+phase+'.json')).read_text())
 if approval.get('approved') is not True or approval['runner_sha256']!=sha(Path(__file__)):raise RuntimeError('root runner approval absent/mismatched')
 prompt=H/'prompt.txt'
 if approval['prompt_sha256']!=sha(prompt):raise RuntimeError('prompt changed')
 for row in approval['frozen_files']:
  if sha(row['path'])!=row['sha256']:raise RuntimeError('frozen input changed')
 model=approval['codex_model'];before=inventory(ws)
 if before!=approval['workspace_inventory']:raise RuntimeError('frozen workspace inventory changed')
 if any(row['type']=='symlink' for row in before.values()):raise RuntimeError('fresh workspace contains symlink')
 with (ev/'run-before.json').open('x')as f:json.dump(before,f,indent=2)
 (case/'private-home').mkdir()
 record={'host':'codex','phase':phase,'at':now(),'model_requested':model,'actual_model':'not_attested_unless_raw_execution_stream_exposes_it','model_user_turns':0,'timeout_seconds':600,'automatic_retry':False,'actor':'model edits bounded local checker and test and personally executes fixed helper; no forge/network/install'};p=None
 try:
  args=['/opt/homebrew/bin/codex','-a','never','exec','--ignore-user-config','--ignore-rules','--disable','hooks','--disable','shell_snapshot','--disable','skill_mcp_dependency_install','--ephemeral','--sandbox','workspace-write','--skip-git-repo-check','--color','never','--json','-m',model,'-C',str(ws),'-']
  e=env(case,'codex',True);record.update(argv=args,cwd=str(ws),environment_keys=sorted(e),prompt_sha256=sha(prompt))
  with (ev/'run.jsonl').open('xb')as out,(ev/'run.stderr').open('xb')as err:
   p=subprocess.Popen(args,cwd=ws,env=e,stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True);record.update(pid=p.pid,model_user_turns=1);save(ev/'started.json',record)
   try:p.communicate(prompt.read_bytes(),timeout=600);record['timed_out']=False
   except subprocess.TimeoutExpired:
    record['timed_out']=True;os.killpg(p.pid,signal.SIGTERM);stop(p)
  items=[json.loads(x)for x in(ev/'run.jsonl').read_text().splitlines()];messages=[{'event_index':i,'text':x['item'].get('text',''),'item_id':x['item'].get('id')}for i,x in enumerate(items) if x.get('type')=='item.completed' and x.get('item',{}).get('type')=='agent_message'];complete=any(x.get('type')=='turn.completed'for x in items)
  save(ev/'agent-messages.json',{'messages':messages,'selection':'last completed agent_message for convenience only; no native final marker asserted','unique_final_attested':False,'requires_independent_completeness_review':True})
  final=messages[-1]['text']if messages else '';(ev/'final-response.txt').write_text(final)
  record.update(agent_message_event_indices=[m['event_index']for m in messages],final_selection='last completed agent_message; independent grading must resolve multiple messages',final_ambiguous=len(messages)!=1)
  record.update(exit_code=p.returncode,turn_completed=complete,final_whitespace_words=len(final.split()),status='observed_pending_independent_grade' if complete and p.returncode==0 and not record['timed_out']else 'blocked_no_retry')
 except Exception as ex:record.update(status='blocked_no_retry',error=str(ex))
 finally:
  if p and p.poll()is None:os.killpg(p.pid,signal.SIGTERM);stop(p)
  try:
   after=inventory(ws);save(ev/'run-after.json',after);record['complete_workspace_inventory_unchanged']=before==after
  except Exception as ex:record.update(inventory_error=str(ex),complete_workspace_inventory_unchanged=None)
  if(case/'private-home').exists():shutil.rmtree(case/'private-home')
  record.update(finished=now(),private_home_removed=not(case/'private-home').exists())
  save(ev/'run-result.json',record)
 print(json.dumps(record,indent=2))
if __name__=='__main__':
 if len(sys.argv)!=2 or sys.argv[1]not in ['repair']:raise SystemExit('repair')
 main(sys.argv[1])
