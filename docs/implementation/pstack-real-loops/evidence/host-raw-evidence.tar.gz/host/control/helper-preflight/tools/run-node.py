#!/usr/bin/python3
"""Fixed task surface: actual Node checker or model-written regression, recorded per invocation."""
import sys,subprocess,json,hashlib,os,signal,time,selectors,re
from pathlib import Path
WS=Path(__file__).resolve().parent.parent
NODE='/opt/homebrew/opt/node@22/bin/node'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def bindings():
 paths=['scripts/project-method-journey-evidence.mjs','scripts/lib/scratch.mjs','scripts/lib/skills-check-verification.mjs','scripts/packet-state-regression.test.mjs']
 paths += ['inputs/'+c+'/'+f for c in ['incident','control-a','control-b']for f in ['packet.json','manifest.json']]
 return {p:digest(WS/p) if (WS/p).is_file() else None for p in paths}
args=sys.argv[1:]
if len(args)==3 and args[0]=='check' and args[1]in ['incident','control-a','control-b']:
 command=[NODE,'scripts/project-method-journey-evidence.mjs','--check',str(WS/'inputs'/args[1])];label=args[2]
elif len(args)==2 and args[0]=='test':
 command=[NODE,'--test','scripts/packet-state-regression.test.mjs'];label=args[1]
else: raise SystemExit('usage: /usr/bin/python3 tools/run-node.py check incident|control-a|control-b UNIQUE_LABEL | test UNIQUE_LABEL')
if not re.fullmatch('[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}',label):raise SystemExit('invalid label')
result=WS/'results'/label;result.mkdir(mode=0o700)
run_tmp=result/'tmp';run_tmp.mkdir()
env={'PATH':'/opt/homebrew/opt/node@22/bin:/usr/bin:/bin','HOME':str(result/'isolated-home'),'TMPDIR':str(run_tmp),'LANG':'en_US.UTF-8','OSSTACK_HOME':str(result/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':str(WS/'results'/'scratch')}
record={'argv':command,'cwd':str(WS),'environment':env,'before':bindings(),'timeout_seconds':10,'output_limit_each':1048576,'started_at_epoch':time.time()}
(result/'command.json').write_text(json.dumps(record,indent=2)+'\n')
p=None;timed_out=False;overflow=False;counts={};streams={};start=time.monotonic()
try:
 p=subprocess.Popen(command,cwd=WS,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 sel=selectors.DefaultSelector()
 for name,pipe in [('stdout',p.stdout),('stderr',p.stderr)]:
  streams[name]=(result/name).open('xb');counts[name]=0;sel.register(pipe,selectors.EVENT_READ,name)
 while sel.get_map():
  if time.monotonic()-start>10:timed_out=True;break
  for key,_ in sel.select(.1):
   data=os.read(key.fileobj.fileno(),65536)
   if not data:sel.unregister(key.fileobj);continue
   counts[key.data]+=len(data)
   if counts[key.data]>1048576:overflow=True;break
   streams[key.data].write(data)
  if overflow:break
 if timed_out or overflow:
  os.killpg(p.pid,signal.SIGKILL)
 p.wait(timeout=2)
finally:
 if p and p.poll()is None:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=2)
 for stream in streams.values():stream.close()
 record.update(exit_code=None if p is None else p.returncode,timed_out=timed_out,output_limit_exceeded=overflow,output_bytes=counts,elapsed_seconds=time.monotonic()-start,after=bindings())
 (result/'result.json').write_text(json.dumps(record,indent=2)+'\n')
for name in ['stdout','stderr']:
 if (result/name).exists():
  (sys.stdout.buffer if name=='stdout' else sys.stderr.buffer).write((result/name).read_bytes())
print('\nEvidence: results/'+label+'/result.json',file=sys.stderr)
raise SystemExit(124 if timed_out else 125 if overflow else p.returncode if p else 126)
