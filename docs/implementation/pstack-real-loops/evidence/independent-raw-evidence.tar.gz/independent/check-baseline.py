import pathlib,json,hashlib,subprocess,datetime,shutil,os
O=pathlib.Path(__file__).parent;R=O/'baseline-check';R.mkdir(exist_ok=False);C=json.loads((O/'criteria.json').read_bytes()); H=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-evidence-projection-20261028/independent/1038dc9a/scratch');node='/opt/homebrew/opt/node@22/bin/node';h=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads(p.read_bytes());write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
inputs=R/'inputs';inputs.mkdir();
for name,old in [('incident','notrun-removed'),('control-a','doctor-failed-not-run'),('control-b','real-pair')]:shutil.copytree(H/old,inputs/name)
def hold(n,base,fn,seal=True,compact=False):
 d=inputs/n;shutil.copytree(inputs/base,d);p=j(d/'packet.json');fn(p);b=(json.dumps(p,ensure_ascii=False,separators=(',',':')) if compact else json.dumps(p,ensure_ascii=False,indent=2)+'\n').encode();(d/'packet.json').write_bytes(b)
 if seal:write(d/'manifest.json',{'schema_version':1,'files':[{'path':'packet.json','bytes':len(b),'sha256':h(b)}]})
hold('H01','control-a',lambda p:(p['features'][0].update(verification='not_run'),p['features'][0]['cleanup'].update(fixture_removed=True)))
hold('H02','control-a',lambda p:p['features'][1]['cleanup'].update(fixture_removed=False))
hold('H03','control-a',lambda p:p['features'][0].update(verification='not_run'))
hold('H04','control-a',lambda p:p['features'][0]['cleanup'].update(status='unknown'))
shutil.copytree(inputs/'control-b',inputs/'H05');f=inputs/'H05/packet.json';f.write_bytes(f.read_bytes()+b' ')
hold('H06','incident',lambda p:None,compact=True)
inv=lambda:[{'path':str(p.relative_to(inputs)),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for p in sorted(inputs.rglob('*'))if p.is_file()];before=inv();write(R/'input-inventory-before.json',before)
expected={'incident':(0,1),'control-a':(0,0),'control-b':(0,0)};expected.update({x['id']:(x['old_expected'],x['fixed_expected'])for x in C['hidden_holdouts']});results=[];env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(R/'home'),'OSSTACK_HOME':str(R/'unused-home'),'OSSTACK_SCRATCH_ROOT':str(R/'scratch')};(R/'home').mkdir();(R/'scratch').mkdir()
for idx,(label,rev) in enumerate([('baseline',C['baseline_sha']),('known-fixed',C['known_fixed_reference_sha'])]):
 root=R/label;root.mkdir()
 for p in ['scripts/project-method-journey-evidence.mjs','scripts/lib/scratch.mjs','scripts/lib/skills-check-verification.mjs']:
  f=root/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','show',rev+':'+p]))
 for name,ex in expected.items():
  argv=[node,'scripts/project-method-journey-evidence.mjs','--check',str(inputs/name)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=10);prefix=R/(label+'-'+name);prefix.with_suffix('.stdout').write_bytes(r.stdout);prefix.with_suffix('.stderr').write_bytes(r.stderr)
  try:payload=json.loads(r.stdout)
  except Exception:payload=None
  row={'name':name,'source_git_sha':rev,'argv':argv,'cwd':str(root),'environment':env,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'expected_exit_code':ex[idx],'exit_matches':r.returncode==ex[idx],'stdout_sha256':h(r.stdout),'stderr_sha256':h(r.stderr),'json_result':payload};write(prefix.with_suffix('.command.json'),row);results.append(row);print(label,name,r.returncode,ex[idx],payload)
after=inv();write(R/'input-inventory-after.json',after);assert before==after
report={'criteria_sha256':h((O/'criteria.json').read_bytes()),'node_version':subprocess.check_output([node,'--version'],env=env,text=True).strip(),'results':results,'input_unchanged':True,'unexpected':[r['name']for r in results if not r['exit_matches']],'scope':'Coordinator independent feasibility probe, not host repair execution or formal oracle. No arbitrary historical defects included.'};write(R/'report.json',report)
print('UNEXPECTED',report['unexpected'])
