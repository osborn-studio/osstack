import pathlib,json,hashlib,subprocess,datetime,re
O=pathlib.Path(__file__).parent;M=O.parent/'maintenance';W=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/maintenance-real-loop');h=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads(p.read_bytes());E=[];commands=[]
for n,ex in [('install',0),('build',0),('red-drive',0),('map-red',1),('green-drive',0),('map-green',0)]:
 d=j(M/(n+'.command.json'));assert d['exit_code']==ex and not d['timeout'];assert d['source_commit']=='1bf1f6caa0ac0ae7b05c3caa9bb44d7ce6517dd0'
 for stream in ['stdout','stderr']:
  r=d[stream];b=(M/r['path']).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256']
 commands.append({'name':n,'command_sha256':h((M/(n+'.command.json')).read_bytes()),'exit':d['exit_code'],'argv':d['argv'],'start':d['start'],'end':d['end']})
assert j(M/'map-red.stdout')['issues']==[{'case':'missing-ref','reason':'product_exit_mismatch','expected':0,'actual':1}];assert j(M/'map-green.stdout')['issues']==[]
before=(M/'feature-map.before.md').read_bytes();after=(M/'feature-map.after.md').read_bytes();assert after==before.replace(b'| missing-ref | 0 | 0 |',b'| missing-ref | 1 | 0 |') and after==(M/'feature-map.md').read_bytes()
assert j(M/'map-red.stdout')['map_sha256']==h(before) and j(M/'map-green.stdout')['map_sha256']==h(after)
manifests=[];binds=[];cleanup=[]
def verify(path):
 d=j(path); names=[]
 for r in d['files']:
  p=path.parent/r['path'];assert pathlib.PurePosixPath(r['path']).parts==(r['path'],) and not p.is_symlink();b=p.read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'];names.append(r['path'])
 assert len(names)==len(set(names));assert set(names)=={p.name for p in path.parent.iterdir() if p.is_file() and p.name!=path.name};manifests.append({'path':str(path.relative_to(M)),'sha256':h(path.read_bytes()),'members':len(names)})
for run in ['red-drive','green-drive']:
 root=M/run;verify(root/'journey-manifest.json');d=j(root/'journey.json');assert d['status']=='passed' and d['formal_gate_pass'] is False and d['model_calls']==0
 for feature in d['features']:
  case=feature['case_id'];assert case in ['healthy','missing-ref'];v=0 if case=='healthy' else 1;assert feature['product_exit']==v and feature['driver_exit']==0
  p=root/'cases'/case;verify(p/'manifest.json');assert h((p/'manifest.json').read_bytes())==feature['manifest_sha256'];rec=j(p/'receipt.json');assert rec['status']=='passed' and rec['cases'][0]['actual_exit']==v
  raw=j(p/(case+'.command.json'));assert raw['exit_code']==v
  for channel in ['stdout','stderr']:
   assert h((p/(case+'.'+channel)).read_bytes())==raw[channel+'_sha256']
  if case=='missing-ref':assert 'no_matching_ref' in (p/(case+'.stdout')).read_text() or 'no_matching_ref' in (p/(case+'.stderr')).read_text()
  c=j(p/'cleanup.json');assert c['status']=='passed' and c['fixture_removed'] is True and not pathlib.Path(c['fixture_path']).exists();assert c['descendant_termination']=='not_attested';cleanup.append(c)
  bind=j(p/'bindings.json');assert feature['bindings']=={'source_digest':bind['source']['digest'],'build_digest':bind['build']['digest']};binds.append(bind)
assert all(x==binds[0] for x in binds)
live=[]
for kind in ['source','build']:
 for f in binds[0][kind]['files']:
  b=(W/f['path']).read_bytes();assert len(b)==f['bytes'] and h(b)==f['sha256']
 live.append({'kind':kind,'files_verified':len(binds[0][kind]['files']),'digest':binds[0][kind]['digest']})
assert commands[2]['argv'][:-1]==commands[4]['argv'][:-1]
# independently reproduce map relation from table numeric cells and retained actual journey, without running author's comparator
rows=lambda b:{m[0]:(int(m[1]),int(m[2]))for m in re.findall(rb'^\| (healthy|missing-ref) \| ([01]) \| ([01]) \|$',b,re.M)}
assert rows(before)[b'missing-ref']==(0,0) and rows(after)[b'missing-ref']==(1,0)
report={'kind':'independent_bounded_retained_run_review','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'criteria_sha256':h((O/'maintenance-criteria.json').read_bytes()),'result':'scoped maintenance loop demonstrated','MT01_to_MT06':'supported within disclosed injected, coordinator-driven scope','commands':commands,'map_only_expected_diff_verified':True,'manifests':manifests,'live_source_build_checks':live,'four_distinct_fixture_paths_absent':len({x['fixture_path'] for x in cleanup})==4,'cleanup':cleanup,'limitations':['No extra driver/test/model execution by evaluator; conclusions from actual retained raw commands plus current independent byte checks.','Task-local comparator is not an authenticated oracle; independent reviewer checked its table relation and actual receipts without copying its PASS conclusion.','Injected stale map, not discovered production bug; no native host effect, causal benefit, generic coverage or formal J gate.','Current file checks and direct-child/fixture facts do not prove all descendants or global state.']}
f=O/'maintenance-review.json';f.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(h(f.read_bytes()))
