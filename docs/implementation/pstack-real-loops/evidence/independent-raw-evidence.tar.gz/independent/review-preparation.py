import pathlib,json,hashlib,datetime,subprocess,stat
O=pathlib.Path(__file__).parent;R=O.parent/'host';h=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads(p.read_bytes())
def inv(root):
 out={}
 for p in [root]+sorted(root.rglob('*')):
  st=p.lstat();a={'length':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
  if stat.S_ISDIR(st.st_mode):a['type']='directory'
  elif stat.S_ISREG(st.st_mode):a.update(type='file',sha256=h(p.read_bytes()))
  else:raise RuntimeError('unexpected initial type '+str(p))
  out[str(p.relative_to(root))]=a
 return out
proto=j(R/'protocol.json');manifest=j(R/'prepared-manifest.json');checked=[]
for f in manifest['files']:
 p=R/f['path'];b=p.read_bytes();assert len(b)==f['bytes'] and h(b)==f['sha256'],f['path'];checked.append(f['path'])
result=[];fixtures=j(O/'criteria.json')['visible_inputs'];sourcepaths=['scripts/project-method-journey-evidence.mjs','scripts/lib/scratch.mjs','scripts/lib/skills-check-verification.mjs'];hostpayloads={}
for host in ['codex','claude']:
 tpath=R/f'harness/dispatch-{host}-repair.template.json';t=j(tpath);ws=R/f'runs/{host}/workspace';assert t['approved'] is False;assert not (R/f'harness/dispatch-{host}-repair.json').exists();assert not (R/f'runs/{host}/evidence/run-before.json').exists();assert not list((ws/'results').iterdir());inventory=inv(ws);assert inventory==t['workspace_inventory'];fp={x['path'] for x in t['frozen_files']}
 for f in t['frozen_files']:assert h(pathlib.Path(f['path']).read_bytes())==f['sha256'],f['path']
 for p in [R/'harness/common.py',R/f'harness/run_{host}.py',ws/'tools/run-node.py',R/'harness/prompt.txt']:assert str(p) in fp
 assert t['criteria_sha256']==h((O/'criteria.json').read_bytes());assert t['prefreeze_supplement_sha256']==h((O/'prefreeze-supplement-1.json').read_bytes());assert t['budget']['user_turns']==1 and t['budget']['seconds']==600 and t['budget']['retries']==0 and t['budget']['product_command_seconds']==10
 for f in fixtures:assert h((ws/'inputs'/f['label']/f['path']).read_bytes())==f['sha256']
 for p in sourcepaths:assert (ws/p).read_bytes()==subprocess.check_output(['git','show',proto['historical_product']+':'+p])
 assert not (ws/'scripts/packet-state-regression.test.mjs').exists();assert not (ws/'.git').exists();hostpayloads[host]={p:h((ws/p).read_bytes())for p in sourcepaths+['tools/run-node.py','inputs/request.txt']}
 result.append({'host':host,'template_sha256':h(tpath.read_bytes()),'frozen_files':len(fp),'inventory_entries':len(inventory),'initial_regular_files':sum(x['type']=='file' for x in inventory.values()),'results_empty':True,'no_regression_test_or_linked_git_initially':True,'source_bytes_exact_1038':True,'six_input_bytes_match_originals':True})
assert hostpayloads['codex']==hostpayloads['claude']
settings=j(R/'runs/claude/state/settings.json');denied=j(R/'harness/claude-builtin-catalog.json');assert len(denied)==58 and all('Skill('+x+')' in settings['permissions']['deny'] for x in denied);assert settings['disableAllHooks'] and settings['permissions']['blockReadsOutsideWorkingDirectories'];assert settings['permissions']['additionalDirectories']==[]
report={'kind':'bounded_pre_dispatch_context_verification','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protocol_sha256':h((R/'protocol.json').read_bytes()),'prepared_manifest_sha256':h((R/'prepared-manifest.json').read_bytes()),'checked_manifest_members':len(checked),'hosts':result,'same_source_helper_request_bytes':True,'claude_frozen_nontarget_skill_denies':58,'criteria_sha256':h((O/'criteria.json').read_bytes()),'preflight_supplement_sha256':h((O/'prefreeze-supplement-1.json').read_bytes()),'permission_limit':'Tool allowlist/prefix plus write sandbox and actual trace observation, not OS-wide read/network containment. New regression JS can run code; violation remains failure/unknown based on evidence, not presumed impossible.','context_limit':'30KiB was advisory; protocol discloses exceeded source+method text, no token hard cap asserted.','decision':'engineering_ready_for_root_dispatch_only_if_current_frozen_inputs_unchanged','root_authorization':False,'requires_final_manual_confirmation':['same-context Claude zero-user-turn catalog exact59 and Codex metadata default','request live-environment versus recorded minimal product environment distinction resolved before dispatch']}
f=O/'final-preparation-check.json';f.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(h(f.read_bytes()))
