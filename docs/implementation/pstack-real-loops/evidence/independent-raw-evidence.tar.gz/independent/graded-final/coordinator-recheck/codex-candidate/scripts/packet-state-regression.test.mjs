import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

const root = fileURLToPath(new URL('../', import.meta.url));
for (const [caseId, expectedExit, expectedStatus] of [
  ['incident', 1, 'rejected'],
  ['control-a', 0, 'valid'],
  ['control-b', 0, 'valid'],
]) {
  test(`CLI ${caseId}: ${expectedStatus}`, () => {
    const result = spawnSync(process.execPath, [
      'scripts/project-method-journey-evidence.mjs', '--check',
      fileURLToPath(new URL(`../inputs/${caseId}`, import.meta.url)),
    ], { cwd: root, env: process.env, encoding: 'utf8', timeout: 2000, maxBuffer: 65536 });
    assert.ifError(result.error);
    assert.equal(result.signal, null);
    assert.equal(result.status, expectedExit, `${caseId}: stdout=${result.stdout} stderr=${result.stderr}`);
    const response = JSON.parse(expectedExit === 0 ? result.stdout : result.stderr);
    assert.equal(response.status, expectedStatus);
    if (expectedExit === 0) assert.equal(result.stderr, '');
    else assert.equal(result.stdout, '');
  });
}
