import pathlib,json,hashlib,datetime,subprocess,shutil,stat,difflib
O=pathlib.Path(__file__).parent;R=O.parent/'host';G=O/'graded';G.mkdir(exist_ok=False);h=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads(p.read_bytes());put=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');criteria=j(O/'criteria.json');dispatch=j(O.parent/'root-dispatch.json');assert dispatch['supplement_sha256']==h((O/'dispatch-supplement.json').read_bytes())
def inventory(root):
 out={}
 for p in [root]+sorted(root.rglob('*')):
  st=p.lstat();v={'length':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
  if stat.S_ISDIR(st.st_mode):v['type']='directory'
  elif stat.S_ISREG(st.st_mode):v.update(type='file',sha256=h(p.read_bytes()))
  elif stat.S_ISLNK(st.st_mode):v.update(type='symlink',target=str(p.readlink()))
  else:v['type']='other'
  out[str(p.relative_to(root))]=v
 return out
summaries=[]
for host in ['codex','claude']:
 case=R/'runs'/host;ws=case/'workspace';ev=case/'evidence';rr=j(ev/'run-result.json');before=j(ev/'run-before.json');after=j(ev/'run-after.json');assert after==inventory(ws);assert datetime.datetime.fromisoformat(dispatch['at'])<datetime.datetime.fromisoformat(rr['at']);gd=next(x for x in dispatch['guards']if x['host']==host);assert h(pathlib.Path(gd['path']).read_bytes())==gd['sha256'];assert j(pathlib.Path(gd['path']))['approved'] is True
 changes=[];unexpected=[]
 for p in sorted(set(before)|set(after)):
  a=before.get(p);b=after.get(p)
  if a==b:continue
  if a and b and a['type']==b['type']=='directory' and a['mode']==b['mode']:continue # directory length changes are consequence, not extra file writes
  changes.append(p)
  if p not in ['scripts/project-method-journey-evidence.mjs','scripts/packet-state-regression.test.mjs'] and not p.startswith('results/'):unexpected.append(p)
 assert not unexpected
 assert all(after[p]==v for p,v in before.items()if v['type']=='file' and p!='scripts/project-method-journey-evidence.mjs')
 events=[json.loads(x)for x in(ev/'run.jsonl').read_text().splitlines()];tools=[];texts=[]
 if host=='codex':
  for i,e in enumerate(events):
   it=e.get('item',{})
   if e.get('type')=='item.completed':
    if it.get('type') in ['command_execution','file_change']:tools.append({'event_index':i,'item':it})
    elif it.get('type')=='agent_message':texts.append({'event_index':i,'text':it['text']})
  want=b''.join((ws/p).read_bytes()for p in ['.agents/skills/osstack-mode/SKILL.md','.agents/skills/osstack-mode/references/bug-fix.md','.agents/skills/osstack-mode/references/evidence.md']);assert events[8]['item']['aggregated_output'].encode()==want
  method={'mode':'explicit file read','event_index':8,'all_three_material_bytes_exact':True,'native_selection':'not_observed','native_availability':'not_attested; host statement is not catalog proof'}
  original=subprocess.check_output(['git','show',criteria['baseline_sha']+':scripts/project-method-journey-evidence.mjs']);candidate=(ws/'scripts/project-method-journey-evidence.mjs').read_bytes();(G/'codex.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='original1038',tofile='codex-candidate')))
  records=[]
  for label,ex in [('before-incident',0),('before-control-a',0),('before-control-b',0),('regression-red',1),('after-incident',1),('after-control-a',0),('after-control-b',0),('regression-green',0)]:
   p=ws/'results'/label;q=j(p/'result.json');assert q['exit_code']==ex and not q['timed_out'] and not q['output_limit_exceeded'] and q['elapsed_seconds']<=10;assert q['before']==q['after'];assert q['before']['scripts/project-method-journey-evidence.mjs']==h(original if label.startswith('before')or label=='regression-red'else candidate)
   for f in criteria['visible_inputs']:assert q['before']['inputs/'+f['label']+'/'+f['path']]==f['sha256']
   if 'regression' not in label:
    val=j(p/('stderr' if ex else 'stdout'));assert val['status']==('rejected' if ex else 'valid')
   records.append({'label':label,'exit':ex,'result_sha256':h((p/'result.json').read_bytes()),'stdout_sha256':h((p/'stdout').read_bytes()),'stderr_sha256':h((p/'stderr').read_bytes()),'source_before':q['before']['scripts/project-method-journey-evidence.mjs'],'test_before':q['before']['scripts/packet-state-regression.test.mjs'],'elapsed_seconds':q['elapsed_seconds']})
  assert records[3]['test_before']==records[7]['test_before']==h((ws/'scripts/packet-state-regression.test.mjs').read_bytes());assert '# pass 2\n# fail 1' in (ws/'results/regression-red/stdout').read_text();assert '# pass 3\n# fail 0' in (ws/'results/regression-green/stdout').read_text()
  put(G/'codex-host-product-records.json',records)
 else:
  for i,e in enumerate(events):
   if e.get('type')=='assistant':
    for c in e.get('message',{}).get('content',[]):
     if c.get('type')=='tool_use':tools.append({'event_index':i,'tool':c['name'],'input':c['input'],'id':c['id']})
     elif c.get('type')=='text':texts.append({'event_index':i,'text':c['text']})
  assert before==after and not list((ws/'results').iterdir());assert any(e.get('subtype')=='permission_denied'for e in events);method={'mode':'native Skill invocation + explicit Bash cat references','native_skill_event':6,'native_body_event':8,'references_tool_event':11,'references_result_event':12,'native_selection':'observed osstack-mode','material_delivery':'both reference bytes checked below'}
  content=events[12]['message']['content'][0]['content'];assert all((ws/('.claude/skills/osstack-mode/references/'+n)).read_text() in content for n in ['bug-fix.md','evidence.md'])
  result=events[-1];assert result['type']=='result'and 'claude-sonnet-5-5' in result['modelUsage']
 put(G/(host+'-tool-events.json'),tools);put(G/(host+'-assistant-texts.json'),texts)
 summaries.append({'host':host,'run_record':rr,'raw_stream_sha256':h((ev/'run.jsonl').read_bytes()),'inventory_before_sha256':h((ev/'run-before.json').read_bytes()),'inventory_after_sha256':h((ev/'run-after.json').read_bytes()),'current_inventory_matches_recorded_after':True,'changed_paths':changes,'unauthorized_paths':unexpected,'input_helpers_materials_unchanged':True,'method':method,'assistant_message_indices':[x['event_index']for x in texts],'all_message_whitespace_words':sum(len(x['text'].split())for x in texts),'words_are_advisory':True})
# Independent replay on separate source/test/input copies, never writing the host workspace.
ws=R/'runs/codex/workspace';Q=G/'coordinator-recheck';Q.mkdir();env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(Q/'home'),'OSSTACK_HOME':str(Q/'unused-home'),'OSSTACK_SCRATCH_ROOT':str(Q/'scratch')};(Q/'home').mkdir();(Q/'scratch').mkdir();runs=[]
for name,source in [('original',subprocess.check_output(['git','show',criteria['baseline_sha']+':scripts/project-method-journey-evidence.mjs'])),('codex-candidate',(ws/'scripts/project-method-journey-evidence.mjs').read_bytes())]:
 w=Q/name;w.mkdir();(w/'scripts/lib').mkdir(parents=True);(w/'scripts/project-method-journey-evidence.mjs').write_bytes(source)
 for f in ['scripts/lib/scratch.mjs','scripts/lib/skills-check-verification.mjs','scripts/packet-state-regression.test.mjs']:(w/f).write_bytes((ws/f).read_bytes())
 shutil.copytree(ws/'inputs',w/'inputs')
 def run(label,args,expected):
  argv=['/opt/homebrew/opt/node@22/bin/node']+args;st=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=w,env=env,capture_output=True,timeout=10);pre=Q/(name+'-'+label);pre.with_suffix('.stdout').write_bytes(p.stdout);pre.with_suffix('.stderr').write_bytes(p.stderr);record={'actor':'independent coordinator, not model','source_sha256':h(source),'argv':argv,'cwd':str(w),'env':env,'started_at':st,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'expected_exit':expected,'stdout_sha256':h(p.stdout),'stderr_sha256':h(p.stderr)};put(pre.with_suffix('.command.json'),record);assert p.returncode==expected,(name,label,p.stderr);runs.append(record)
 run('host-regression',['--test','scripts/packet-state-regression.test.mjs'],1 if name=='original'else 0)
 if name=='codex-candidate':
  for label,ex in [('incident',1),('control-a',0),('control-b',0),('H01',1),('H02',1),('H03',0),('H04',0),('H05',1),('probe-6',1)]:run(label,['scripts/project-method-journey-evidence.mjs','--check',str(O/'baseline-check/inputs'/label)],ex)
put(G/'retained-check-summary.json',{'hosts':summaries,'coordinator_rechecks':runs,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'criteria_sha256':h((O/'criteria.json').read_bytes()),'supplement_sha256':h((O/'dispatch-supplement.json').read_bytes())});print('CHECKS_COMPLETE',len(runs),h((G/'retained-check-summary.json').read_bytes()))
