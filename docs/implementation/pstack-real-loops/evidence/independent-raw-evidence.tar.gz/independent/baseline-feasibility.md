# 历史修复可解性

原incident同字节1038错误接受、0e拒绝；两合法control两版本接受。H01–05与H06b独立控制符合预期。H06 compact预期错误，原协议要求canonical bytes，两版本均拒绝；原失败/标准完整保留，补充已在模型调用前冻结。

仅协调者可解性测试，不是宿主RED/testRED/fix/GREEN。待最终输入、权限、guard核验；尚未授权派发。
