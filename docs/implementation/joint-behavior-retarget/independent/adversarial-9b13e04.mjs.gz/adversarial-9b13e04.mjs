import assert from 'node:assert/strict';
import {createHash,generateKeyPairSync,sign} from 'node:crypto';
import {evaluateBehaviorRegistry as evaluate} from '/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-loader-ready/packages/core/dist/behavior-registry.js';
const encode=x=>Buffer.from(JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a<b?-1:a>b?1:0)):v));
const hash=x=>createHash('sha256').update(x).digest('hex');
const roles=['ci_verifier','host_qualifier','journey_verifier'],levels=['contract_tested','host_verified','journey_verified'];
const keys=roles.map(()=>generateKeyPairSync('ed25519'));
const now=Date.parse('2026-10-27T10:00:00Z');
const profile={os:'linux',architecture:'x64',filesystem:'ext4',isolation_profile:'test',daemon_version:'0.22.1',adapter_id:'fixture',adapter_version:'1',provider:'fixture',model:'none',executor_id:'fixture',executor_version:'1',template_id:'fixture',template_version:'1',recovery_mode:'stop_and_reconcile',host_identity_sha256:'c'.repeat(64)};
function fixture(graph,options={}) {
 const objects=new Map(), put=b=>{const h=hash(b);objects.set(h,b);return h};
 const ids=graph.map((_,i)=>`FM-${String(i+1).padStart(2,'0')}`);
 const source={repository:'https://example.invalid/repo',commit:'a'.repeat(40),path:'README.md',content_sha256:put(Buffer.from('independent fixture')),license:'MIT'};
 const manifest=put(encode({schema_version:1,kind:'behavior_source_manifest',sources:[source]}));
 const contracts=ids.map((id,i)=>({schema_version:1,kind:'behavior_contract',capability_id:id,version:'1.0.0',owner_component:'controller',trigger:'test',summary:{en:'Independent graph test.',zh:'独立图测试。'},source_manifest_sha256:manifest,sources:[source],depends_on:graph[i].map(j=>({capability_id:ids[j],version:'1.0.0'})),required_scenarios:levels.map((level,j)=>({id:`scenario-${j}`,level})),invariants:['No effects.'],semantic_differences:[]}));
 const policy=ids.map(capabilityId=>({capabilityId,contractVersion:'1.0.0',requiredScenarios:Object.fromEntries(levels.map((l,j)=>[l,[{id:`scenario-${j}`,checkerId:`checker-${j}`,checkerVersion:'1'}]]))}));
 const policyHash=hash(encode({schema_version:1,kind:'behavior_verifier_policy',capabilities:policy}));
 const registry={schema_version:1,kind:'behavior_registry',registry_version:'1.0.0',candidate_sha:'b'.repeat(40),target_code_sha256:'d'.repeat(64),entries:contracts.map(contract=>({contract,contract_sha256:hash(encode(contract))}))};
 const registryBytes=encode(registry),registryHash=hash(registryBytes),records=[],recordDigests=[];
 for(let i=0;i<ids.length;i++) {const chain=[]; for(let j=0;j<3;j++) {
   const evidence=[{scenario_id:`scenario-${j}`,checker_id:`checker-${j}`,checker_version:'1',result:'passed',artifact_sha256:put(Buffer.from(`artifact-${i}-${j}`)),subject_sha256:registry.target_code_sha256}];
   const payload={record_id:`record-${i}-${j}`,capability_id:ids[i],profile,candidate_sha:registry.candidate_sha,target_code_sha256:registry.target_code_sha256,behavior_contract_sha256:registry.entries[i].contract_sha256,source_manifest_sha256:manifest,policy_profile_sha256:policyHash,registry_sha256:registryHash,level:levels[j],evidence_bundle_sha256:put(encode({schema_version:1,candidate_sha:registry.candidate_sha,limitations:[],evidence})),evidence_refs:evidence,limitations:[],issuer_role:roles[j],issued_at:new Date(now-100000).toISOString(),expires_at:new Date(now+100000+(options.expiry?.[i]??0)).toISOString(),revocation_epoch:1,signer_key_id:`key-${j}`,required_scenario_set_sha256:hash(encode([`scenario-${j}`])),prerequisite_record_sha256:j?[chain[j-1]]:[]};
   const doc={schema_version:1,canonicalization:'RFC8785',payload,signature:{algorithm:'Ed25519',value_base64:sign(null,encode(payload),keys[j].privateKey).toString('base64')}};
   const bytes=encode(doc);chain.push(hash(bytes));records.push(bytes);
 }recordDigests.push(chain);}
 const input={registryBytes,expectedRegistrySha256:registryHash,expectedRegistryVersion:'1.0.0',nowMs:now,qualificationBytes:records,target:{candidateSha:registry.candidate_sha,targetCodeSha256:registry.target_code_sha256,policyProfileSha256:policyHash,hostProfile:profile,ciProfile:profile},policy,trust:{keys:keys.map((key,j)=>({keyId:`key-${j}`,publicKeyPem:key.publicKey.export({type:'spki',format:'pem'}).toString(),issuerRole:roles[j],capabilityIds:ids,profileSha256s:[hash(encode(profile))]})),minimumRevocationEpoch:1,maxRevocationAgeMs:3600000,maxQualificationLifetimeMs:3600000,revocations:{epoch:1,issuedAtMs:now-1000,expiresAtMs:now+1000000,revokedKeyIds:[],revokedQualificationSha256s:[]}},readArtifact:h=>objects.get(h)};
 return {input,objects,recordDigests,manifest};
}
const results=[];
function test(name,fn){fn();results.push({name,status:'PASS'});console.log('PASS '+name);}
function model(graph,blocked) {const reach=(i,seen=new Set())=>{if(blocked.has(i))return false;if(seen.has(i))return false;const next=new Set([...seen,i]);return graph[i].every(j=>reach(j,next))};return graph.map((_,i)=>reach(i));}
let seed=0x12345678;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32};
test('120 independent random 24-node graph oracles, digest revocations, input permutations',()=>{
 for(let round=0;round<120;round++) {
  const graph=Array.from({length:24},(_,i)=>Array.from({length:24},(_,j)=>j).filter(j=>j!==i&&rand()<.055));
  const f=fixture(graph);const blocked=new Set();for(let i=0;i<24;i++)if(rand()<.08){blocked.add(i);f.input.trust.revocations.revokedQualificationSha256s.push(f.recordDigests[i][round%3]);}
  const output=evaluate(f.input);assert.equal(output.status,'evaluated');assert.deepEqual(output.entries.map(x=>x.selectionEligible),model(graph,blocked),`round ${round}`);assert.equal(output.authorization,'none');
  f.input.qualificationBytes.reverse();assert.deepEqual(evaluate(f.input),output,`permutation ${round}`);
 }
});
test('24-node dependency expiry minimum propagates across full reverse chain',()=>{
 const graph=Array.from({length:24},(_,i)=>i===23?[]:[i+1]);const f=fixture(graph,{expiry:Array.from({length:24},(_,i)=>23000-i*1000)});const result=evaluate(f.input);assert.ok(result.entries.every(x=>x.selectionEligible&&x.validUntilMs===now+100000));
});
test('callback mutation cannot change queued qualification trust or policy snapshots',()=>{
 const f=fixture([[],[0],[1]]),expected=evaluate(f.input);let once=false;f.input.readArtifact=h=>{if(!once){once=true;f.input.qualificationBytes.fill(Buffer.from('{}'));f.input.trust.keys=[];f.input.policy.length=0;f.input.target.hostProfile.model='tampered';}return f.objects.get(h)};assert.deepEqual(evaluate(f.input),expected);
});
test('shared unavailable source is read once, disables all transitive dependents',()=>{
 const f=fixture([[],[0],[1],[2]]);let calls=0;f.input.readArtifact=h=>{if(h===f.manifest){calls++;throw Error('unavailable')}return f.objects.get(h)};const r=evaluate(f.input);assert.equal(calls,1);assert.ok(r.entries.every(x=>!x.selectionEligible&&x.validUntilMs===null&&x.qualificationSha256s.length===0));
});
test('strict trust extensions rejected before any artifact effect',()=>{
 for(const path of ['target','trust','key','revocation']){const f=fixture([[]]);const target=path==='target'?f.input.target:path==='trust'?f.input.trust:path==='key'?f.input.trust.keys[0]:f.input.trust.revocations;target.future_grant=true;let reads=0;f.input.readArtifact=()=>{reads++;throw Error('must not read')};assert.equal(evaluate(f.input).status,'rejected');assert.equal(reads,0);}
});
test('canonical joint digest envelope cannot be substituted for R01 registry',()=>{
 const f=fixture([[]]);f.input.registryBytes=encode({schema_version:1,kind:'source_inspection',authorization:'none'});f.input.expectedRegistrySha256=hash(f.input.registryBytes);assert.equal(evaluate(f.input).rejection,'registry_invalid');
});
test('signed cross-capability predecessor cannot complete a journey',()=>{
 const f=fixture([[],[]]);const doc=JSON.parse(f.input.qualificationBytes[2]);doc.payload.prerequisite_record_sha256=[f.recordDigests[1][1]];doc.signature.value_base64=sign(null,encode(doc.payload),keys[2].privateKey).toString('base64');f.input.qualificationBytes[2]=encode(doc);const r=evaluate(f.input);assert.equal(r.entries[0].selectionEligible,false);assert.equal(r.entries[1].selectionEligible,true);
});
test('64MiB raw qualification budget rejects all work regardless of placement',()=>{
 const oversized=Buffer.alloc(1024*1024,32);for(const prepend of [true,false]){const f=fixture([[]]);const junk=Array.from({length:65},()=>oversized);f.input.qualificationBytes=prepend?[...junk,...f.input.qualificationBytes]:[...f.input.qualificationBytes,...junk];let calls=0;f.input.readArtifact=()=>{calls++;return undefined};assert.equal(evaluate(f.input).rejection,'qualification_batch_oversized');assert.equal(calls,0);}
});
test('all artifact reads returning corrupted 8MiB remain bounded and fail closed',()=>{
 const f=fixture(Array.from({length:24},()=>[]));const bad=Buffer.alloc(8*1024*1024,127),seen=new Set();let count=0;f.input.readArtifact=h=>{assert.ok(!seen.has(h));seen.add(h);count++;return bad};const r=evaluate(f.input);assert.ok(r.entries.every(x=>!x.selectionEligible&&x.qualificationSha256s.length===0));assert.ok(count<=73,`read calls ${count}`);
});
test('policy extensions reject even when host recomputes the policy pin',()=>{
 for(const field of ['item','levels','scenario']){const f=fixture([[]]);const p=f.input.policy[0];const object=field==='item'?p:field==='levels'?p.requiredScenarios:p.requiredScenarios.contract_tested[0];object.future_requirement='deny';f.input.target.policyProfileSha256=hash(encode({schema_version:1,kind:'behavior_verifier_policy',capabilities:f.input.policy}));let calls=0;f.input.readArtifact=()=>{calls++;return undefined};assert.equal(evaluate(f.input).rejection,'invalid_context');assert.equal(calls,0);}
});
test('invalid scalar echoes do not retain or freeze caller-owned graphs',()=>{
 for(const field of ['expectedRegistrySha256','nowMs']){const f=fixture([[]]);const graph={child:{mutable:true}};graph.self=graph;f.input[field]=graph;const r=evaluate(f.input);assert.equal(r.status,'rejected');assert.equal(r.rejection,'invalid_context');assert.equal(Object.isFrozen(graph),false);assert.equal(Object.isFrozen(graph.child),false);assert.equal(typeof r.expectedRegistrySha256,'string');assert.equal(typeof r.evaluatedAtMs,'number');graph.child.mutable=false;}
 for(const input of [null,undefined]) assert.equal(evaluate(input).rejection,'invalid_context');
});
test('malformed shared source manifest parses once across 24 valid signed chains',()=>{
 const f=fixture(Array.from({length:24},()=>[]));const malformed=encode({schema_version:1,kind:'behavior_source_manifest',sources:[]});const badHash=hash(malformed);f.objects.set(badHash,malformed);
 const registry=JSON.parse(f.input.registryBytes);for(const entry of registry.entries){entry.contract.source_manifest_sha256=badHash;entry.contract_sha256=hash(encode(entry.contract));}
 f.input.registryBytes=encode(registry);f.input.expectedRegistrySha256=hash(f.input.registryBytes);
 for(let i=0;i<24;i++)for(let j=0;j<3;j++){const n=i*3+j,doc=JSON.parse(f.input.qualificationBytes[n]);Object.assign(doc.payload,{source_manifest_sha256:badHash,behavior_contract_sha256:registry.entries[i].contract_sha256,registry_sha256:f.input.expectedRegistrySha256,prerequisite_record_sha256:j?[hash(f.input.qualificationBytes[n-1])]:[]});doc.signature.value_base64=sign(null,encode(doc.payload),keys[j].privateKey).toString('base64');f.input.qualificationBytes[n]=encode(doc);}
 const parse=JSON.parse;let parses=0;JSON.parse=function(text,...args){if(text===malformed.toString())parses++;return parse(text,...args)};let r;try{r=evaluate(f.input)}finally{JSON.parse=parse}
 assert.equal(parses,1);assert.ok(r.entries.every(e=>e.reasons.includes('source_manifest_invalid')&&!e.selectionEligible&&e.validUntilMs===null));assert.deepEqual(r.qualificationRejections,[]);
});
console.log(JSON.stringify({code_sha:'9b13e04022b3068987d3807414b75f07aa2d265b',groups:results.length,random_graph_cases:120,results},null,2));
