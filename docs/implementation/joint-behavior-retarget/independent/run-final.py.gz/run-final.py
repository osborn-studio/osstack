from pathlib import Path
import hashlib,json,subprocess,datetime,time
p=Path(__file__).parent
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-loader-ready')
sha='9b13e04022b3068987d3807414b75f07aa2d265b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==sha
paths=['packages/core/src/behavior-registry.ts','packages/core/dist/behavior-registry.js','packages/protocol/src/behavior-capability.ts']
hashes=lambda:{x:hashlib.sha256((w/x).read_bytes()).hexdigest() for x in paths}
before=hashes();start=time.monotonic();observed=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p/'adversarial-9b13e04.mjs').write_bytes((p/'adversarial.mjs').read_bytes())
with (p/'results-9b13e04.txt').open('w') as f:r=subprocess.run(['/opt/homebrew/opt/node@22/bin/node',str(p/'adversarial-9b13e04.mjs')],stdout=f,stderr=subprocess.STDOUT,cwd=p)
after=hashes();assert before==after;assert r.returncode==0
meta={'code_sha':sha,'observed_at':observed,'exit_code':r.returncode,'duration_seconds':time.monotonic()-start,'node':subprocess.check_output(['/opt/homebrew/opt/node@22/bin/node','--version'],text=True).strip(),'source_and_built_hashes_before':before,'source_and_built_hashes_after':after,'artifacts':{}}
for file in ['adversarial-9b13e04.mjs','results-9b13e04.txt']:meta['artifacts'][file]=hashlib.sha256((p/file).read_bytes()).hexdigest()
(p/'manifest-9b13e04.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
