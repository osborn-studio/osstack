from pathlib import Path
import json,subprocess,datetime,hashlib,importlib.util,sys,shutil,re,os,stat,gzip
if not __debug__: raise RuntimeError('Run without -O; checkpoint guards require normal Python mode')
out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-loader-cleanup-20261027');r=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-loader-ready');d=r/'docs/design/2026-10-27-joint-engineering';e=d/'evidence/joint-execution/loader-cleanup-retarget'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(*cmd):return subprocess.check_output(cmd,cwd=r,text=True).strip()
def digest(data):return hashlib.sha256(data).hexdigest()
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['git','fetch','origin'],cwd=r,check=True);main=run('git','rev-parse','origin/main')
# This is a bounded checkpoint for this reviewed batch, not the autonomous scheduler.
expected_main='28d116f3f8c15f64bebb314308adf320d8380b2b' # fixed reviewed commit; fail on new merges rather than silently rebinding tests.
assert main==run('git','rev-parse',expected_main),'main advanced; revalidate'
e.mkdir(parents=True,exist_ok=False)
path=d/'execution-ledger.json';before=path.read_bytes();ledger=json.loads(before);before_hash=digest(before);before_path=e/('ledger-before-'+before_hash+'.json');before_path.write_bytes(before)
ledger.setdefault('checkpoint_history',[]).append({'path':str(before_path.relative_to(d)),'sha256':before_hash})
fields='number,url,state,isDraft,headRefName,headRefOid,baseRefName,mergeCommit,mergedAt,reviewDecision,statusCheckRollup,mergeable,mergeStateStatus'
start=now();prs=[]
for n in range(272,283):
 p=json.loads(run('gh','pr','view',str(n),'--json',fields));p['observed_at']=now();prs.append(p)
prmap={p['number']:p for p in prs}
ledger.update(checkpoint_proof_version=2,main_sha=main,observed_at=now(),prs=prs,observation_window={'started_at':start,'scope':'Sequential per-PR observations, not atomic; verify again before effects.'})
for node in ledger['milestones']:
 for part in node['slices']:
  n=part.get('pr')
  if n in prmap and prmap[n]['state']=='MERGED':
   part.update(state='merged',head_sha=prmap[n]['headRefOid'],merge_sha=prmap[n]['mergeCommit']['oid'])
   part['evidence_status']='historical_merged_candidate'
   if 'audit' in part:part['audit']['status']='historical_merged_candidate'
   if 'validation' in part:part['validation']['status']='passed_for_code_sha_historical_merged'
  if n in [274,281]:
   assert prmap[n]['state']=='MERGED';part.update(state='merged',head_sha=prmap[n]['headRefOid'],merge_sha=prmap[n]['mergeCommit']['oid'])
   part['evidence_status']='historical_merged_code';part['audit']['status']='historical_merged_code';part['validation']['status']='passed_for_code_sha_historical_merged'
   part['base_scope']='Historical tested base retained; merge does not rebind prior evidence to current main.'
   node['state']='blocked' if any(sibling.get('state')=='blocked' for sibling in node['slices']) else 'in_progress';node['merge_blocker']='Precursor merged; whole milestone acceptance remains pending. '+('J02b mapping/registration/dependency closure pending.' if n==281 else 'Specification only; J12 runtime recovery pending.')
prior={p['pr']:p for p in ledger['handoff'].get('successor_deliveries',[])}
def previous(n):return {'pr':n,'path':str(before_path.relative_to(d)),'sha256':before_hash,'scope':'historical observation only; current labels inside prior file were time-bound'} if n in prior else None
def verify_archive(src,dst):
 manifest=json.loads((src/'archive-manifest.json').read_text())
 for item in manifest['files']:
  name=item.get('path',item.get('file'));data=(src/name).read_bytes();assert digest(data)==item['sha256']
  original=item.get('original_sha256',item.get('raw_sha256'))
  if original:
   raw=gzip.decompress(data) if name.endswith('.gz') else data
   assert digest(raw)==original and len(raw)==item.get('original_bytes',item.get('raw_bytes'))
 shutil.copyfile(src/'archive-manifest.json',dst/'archive-manifest.json')
deliveries=[p for n,p in prior.items() if n not in [276,278,279,282]]
# PR276 merged its original head. Never bind the new hardening audit to that old product.
p=prmap[276];assert p['state']=='MERGED'
deliveries.append({'proof_version':2,'pr':276,'state':'merged','head_sha':p['headRefOid'],'base_branch':p['baseRefName'],'code_sha':p['headRefOid'],'runtime_enabled':False,'card_id':'card_9ccb91b2','scope':'Original R02 evaluator only; new audit corrections NOT in this merge','audit':{'status':'original_handoff_only','reference':ledger['handoff']['report'],'reference_sha256':ledger['handoff']['report_sha256']},'previous_delivery':previous(276),'followup_pr':282,'merge_sha':p['mergeCommit']['oid']})
for kind,n,card in [('loader',282,'card_9ccb91b2'),('cleanup',278,'card_4e8147d9')]:
 src=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-'+kind+'-ready/docs/implementation')/('joint-behavior-retarget' if kind=='loader' else 'joint-session-cleanup-retarget');dst=e/kind;dst.mkdir(exist_ok=True)
 for f in ['README.md','audit-code-binding.json']:shutil.copyfile(src/f,dst/f)
 verify_archive(src,dst)
 binding=json.loads((src/'audit-code-binding.json').read_text());v=json.loads((out/(kind+'-verification.json')).read_text())
 assert binding['code_sha']==v['code_sha'] and v.get('finished_at') and len(v['checks'])==5 and all(c['exit_code']==0 for c in v['checks'])
 for c in v['checks']:assert digest((out/c['log']).read_bytes())==c['sha256']
 rows=re.findall(r'(packages/\S+) test: +Tests +([^\n]+)',(out/(kind+'-final-frozen-tests.log')).read_text());assert len(rows)==22 and len({x[0] for x in rows})==22
 measured={key:sum(int(m.group(1)) for _,line in rows if (m:=re.search(r'(\d+) '+key,line))) for key in ['passed','skipped','failed']};assert measured==binding['validation'] and measured['failed']==0
 base=binding['reviewed_base'];assert run('git','merge-base',binding['code_sha'],base)==base
 if n==282:assert base==main and v['reviewed_base']==base
 p=prmap[n];assert p['baseRefName']=='main'
 diff=subprocess.check_output(['git','diff','--no-renames',binding['code_sha'],p['headRefOid']],cwd=r);paths=run('git','diff','--no-renames','--name-only',binding['code_sha'],p['headRefOid']).splitlines()
 assert all(x.startswith(('docs/','.changeset/')) for x in paths),'PR product changed after validation'
 (dst/'code-to-observed-head.diff').write_bytes(diff)
 proof={'code_sha':binding['code_sha'],'head_sha':p['headRefOid'],'changed_paths':paths,'diff_sha256':digest(diff),'diff_path':str((dst/'code-to-observed-head.diff').relative_to(d)),'net_diff_empty':not paths}
 checks={x['name']:x for x in p['statusCheckRollup'] if x.get('__typename')=='CheckRun'}
 required=['check','graph-macos-fixtures (22)','graph-macos-fixtures (24)','graph-runtime-matrix (20.6.0)','graph-runtime-matrix (22.23.1)']
 ci='passed_at_observation' if all(checks.get(x,{}).get('conclusion')=='SUCCESS' for x in required) else 'pending_or_failed_at_observation'
 state='merged' if p['state']=='MERGED' else 'revalidating' if p['isDraft'] else 'ready'
 status='historical_merged_code' if state=='merged' else 'current_for_code_sha'
 deliveries.append({'proof_version':2,'pr':n,'state':state,'merge_sha':p['mergeCommit']['oid'] if p['mergeCommit'] else None,'head_sha':p['headRefOid'],'base_branch':'main','base_sha':base,'code_sha':binding['code_sha'],'code_head_proof':proof,'runtime_enabled':False,'card_id':card,'scope':'R02 audit hardening follow-up to merged276' if n==282 else 'Session start cleanup only; DEBT02 and279 separate','evidence_status':status,'audit':{'model':'claude-sonnet-5-5','verdict':'PASS','status':status},'validation':{'code_sha':binding['code_sha'],**measured,'packages':len(rows),'status':'passed_for_code_sha_historical_merged' if state=='merged' else 'passed_for_code_sha','report':str((dst/'README.md').relative_to(d)),'audit_binding':str((dst/'audit-code-binding.json').relative_to(d)),'archive_manifest':str((dst/'archive-manifest.json').relative_to(d)),'archive_manifest_sha256':digest((dst/'archive-manifest.json').read_bytes()),'report_sha256':digest((dst/'README.md').read_bytes()),'audit_binding_sha256':digest((dst/'audit-code-binding.json').read_bytes())},'merge_readiness':{'ci':ci,'approval':'user_owned','mergeable':p['mergeable'],'merge_state':p['mergeStateStatus']},'previous_observation':{'path':str(before_path.relative_to(d)),'sha256':before_hash},'previous_delivery':previous(n)})
# The terminal worker uses its own archive format; validate the actual archived bytes.
src=out/'terminal-committed-archive';dst=e/'terminal';dst.mkdir(exist_ok=True)
for f in ['README.md','audit-code-binding.json']:shutil.copyfile(src/f,dst/f)
verify_archive(src,dst)
binding=json.loads((src/'audit-code-binding.json').read_text());tv=json.loads((src/'verification.json').read_text());ts=json.loads((src/'test-summary.json').read_text());assert binding['code_sha']==tv['code_sha']==ts['code_sha'] and binding['reviewed_base']==tv['base_sha']==main and ts['packages']==22 and ts['failed']==0 and tv['test_full']=='passed' and all(c['exit_code']==0 for c in tv['commands'])
import gzip
for entry in json.loads((src/'archive-manifest.json').read_text())['files']:
 data=(src/entry['path']).read_bytes() if 'path' in entry else (src/entry['file']).read_bytes()
 assert digest(data)==entry['sha256']
 if 'raw_sha256' in entry:
  raw=gzip.decompress(data) if entry.get('path','').endswith('.gz') else data
  assert digest(raw)==entry['raw_sha256'] and len(raw)==entry['raw_bytes']
terminal_log=gzip.decompress((src/'test-full.log.gz').read_bytes()).decode();terminal_rows=re.findall(r'(packages/\S+) test: +Tests +([^\n]+)',terminal_log);assert len(terminal_rows)==22 and len({x[0] for x in terminal_rows})==22
terminal_counts={key:sum(int(m.group(1)) for _,line in terminal_rows if (m:=re.search(r'(\d+) '+key,line))) for key in ['passed','skipped','failed']};assert terminal_counts=={key:ts[key] for key in terminal_counts} and binding['verdict']=='PASS'
assert run('git','merge-base',binding['code_sha'],main)==main
p=prmap[279];assert p['baseRefName']=='main' and p['state']=='OPEN'
diff=subprocess.check_output(['git','diff','--no-renames',binding['code_sha'],p['headRefOid']],cwd=r);paths=run('git','diff','--no-renames','--name-only',binding['code_sha'],p['headRefOid']).splitlines();assert all(x.startswith(('docs/','.changeset/')) for x in paths)
(dst/'code-to-observed-head.diff').write_bytes(diff)
checks={x['name']:x for x in p['statusCheckRollup'] if x.get('__typename')=='CheckRun'}
ci='passed_at_observation' if all(checks.get(x,{}).get('conclusion')=='SUCCESS' for x in required) else 'pending_or_failed_at_observation'
state='revalidating' if p['isDraft'] else 'ready';measured={k:ts[k] for k in ['passed','skipped','failed']}
deliveries.append({'proof_version':2,'pr':279,'state':state,'head_sha':p['headRefOid'],'base_branch':'main','base_sha':main,'code_sha':binding['code_sha'],'code_head_proof':{'code_sha':binding['code_sha'],'head_sha':p['headRefOid'],'changed_paths':paths,'diff_sha256':digest(diff),'diff_path':str((dst/'code-to-observed-head.diff').relative_to(d)),'net_diff_empty':not paths},'runtime_enabled':False,'card_id':'card_d1a582eb','scope':'Session terminal fence only; no cross-process DEBT02 recovery','evidence_status':'current_for_code_sha','audit':{'model':'claude-sonnet-5-5','verdict':'PASS','status':'current_for_code_sha'},'validation':{'code_sha':binding['code_sha'],**measured,'packages':22,'status':'passed_for_code_sha','report':str((dst/'README.md').relative_to(d)),'audit_binding':str((dst/'audit-code-binding.json').relative_to(d)),'archive_manifest':str((dst/'archive-manifest.json').relative_to(d)),'archive_manifest_sha256':digest((dst/'archive-manifest.json').read_bytes()),'report_sha256':digest((dst/'README.md').read_bytes()),'audit_binding_sha256':digest((dst/'audit-code-binding.json').read_bytes())},'merge_readiness':{'ci':ci,'approval':'user_owned','mergeable':p['mergeable'],'merge_state':p['mergeStateStatus']},'previous_observation':{'path':str(before_path.relative_to(d)),'sha256':before_hash},'previous_delivery':previous(279)})
ledger['handoff']['successor_deliveries']=deliveries
ledger['handoff']['successor_obligations']={str(x['pr']):f"{x['state']} at observed head {x['head_sha']}; see exact scope and evidence; merge does not qualify runtime" for x in deliveries}
ledger['handoff']['successor_obligations']['279']=f"Formal main candidate: {ts['passed']} passed/{ts['skipped']} skipped/{ts['failed']} failed; actual Sonnet5.5 {binding['verdict']}. Observe current head and CI again before approval/merge; DEBT02 remains separate."
ledger['management'].update(snapshot=str((e/'joint-firstmate-pstack.json').relative_to(d)),mode='owner-driven OSStack ledger and bounded Codex collaboration subagents; no autonomous goal_dispatch',operations='project-operations.md',management_home='/Volumes/AIMATE_WORK/tmp/osstack/runtime/session-debt-20261026/ledger-home',management_socket='/tmp/osstack-debt-ledger.sock',heartbeat={**json.loads((out/'automation-receipt.json').read_text()),'observation_authority':'Owner-attested Codex tool success plus persisted automation configuration; offline validator hashes receipt bytes, not truth of scheduler state','goal_dispatch_enabled':False})
pre=json.loads((out/'subagent-terminal/metadata.json').read_text());ledger['parallel_preflight']={'pr':279,'state':'provisional_only','candidate_sha':pre['integration_sha'],'test_commit':pre['supplemental_test_sha'],'pr_head_sha':pre['pr279_head_sha'],'tests_passed':pre['validation']['focused']['passed'],'files':pre['validation']['focused']['files'],'current_head_matches':pre['pr279_head_sha']==prmap[279]['headRefOid'],'product_qualification':False,'observation_scope':'historical preflight only; head match is time-bound, not live','report_sha256':digest((r/'docs/implementation/joint-behavior-retarget/subagent-terminal/report.md').read_bytes()),'report':'../../implementation/joint-behavior-retarget/subagent-terminal/report.md'}
sys.path.insert(0,'/Volumes/AIMATE_WORK/tmp/osstack/runtime/session-debt-20261026');helper=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/session-debt-20261026/ledger.py');helper_before=helper.read_bytes();from ledger import rpc
assert helper.read_bytes()==helper_before,'RPC helper changed across import'
socket_stat=Path('/tmp/osstack-debt-ledger.sock').stat();assert stat.S_ISSOCK(socket_stat.st_mode) and socket_stat.st_uid==os.getuid() and not(socket_stat.st_mode & 0o077),'unexpected socket owner/mode';ledger['management']['socket_observation']={'uid':socket_stat.st_uid,'mode':oct(stat.S_IMODE(socket_stat.st_mode)),'observed_at':now()}
(e/'ledger-rpc-helper.py').write_bytes(helper_before);ledger['management']['rpc_helper']={'path':str((e/'ledger-rpc-helper.py').relative_to(d)),'sha256':digest((e/'ledger-rpc-helper.py').read_bytes()),'socket':'/tmp/osstack-debt-ledger.sock','scope':'actual helper code binds socket; management_home is deployment metadata, not independently authenticated by RPC'}
for board in ['joint-firstmate-pstack','firstmate-upgrade-roadmap','session-pilot-debt']:save(e/(board+'.json'),rpc('kanban.board',{'board':board,'include_archived':True}))
board=json.loads((e/'joint-firstmate-pstack.json').read_text());cards={c['card_id']:c for col in board['columns'] for c in col['cards']}
for node in ledger['milestones']:
 if 'board_status' in node:node['board_status']=cards[node['card_id']]['status']
ledger['management']['receipts']=[]
for name in ['subagent-dispatch-receipts.json','terminal-preflight-receipt.json','board-final-receipts.json','automation-receipt.json']:
 assert (out/name).is_file();shutil.copyfile(out/name,e/name);ledger['management']['receipts'].append({'path':str((e/name).relative_to(d)),'sha256':digest((e/name).read_bytes())})
ledger['management']['snapshot_sha256']=digest((e/'joint-firstmate-pstack.json').read_bytes())
ledger['management']['board_snapshots']=[{'path':str((e/(board+'.json')).relative_to(d)),'sha256':digest((e/(board+'.json')).read_bytes())} for board in ['joint-firstmate-pstack','firstmate-upgrade-roadmap','session-pilot-debt']]
ledger['management']['evidence_scope']='Owner-collected local validation artifacts serialized in this documentation commit; not asserted to exist in earlier observed PR heads. GitHub CI is separately timestamped.'
ledger['management']['metadata_scope']='Code/head diff allows docs and changesets, including executable offline checkpoint checks; these have separate Python validation and management audit, not runtime pnpm qualification.'
for n in [276,278,279,282]:
 latest=json.loads(run('gh','pr','view',str(n),'--json','headRefOid,baseRefName,state,isDraft'));assert all(latest[k]==prmap[n][k] for k in latest),'PR changed during observation'
subprocess.run(['git','fetch','origin'],cwd=r,check=True);assert run('git','rev-parse','origin/main')==main
ledger['observation_window']['finished_at']=now()
spec=importlib.util.spec_from_file_location('v',d/'validate-execution.py');vmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(vmod);print(vmod.validate_published(ledger));temp=path.with_suffix('.tmp');save(temp,ledger);temp.replace(path)
