umask 077
: "${journey_output:?Set the absolute retained full journey path}"
packet_output="${OSSTACK_SCRATCH_ROOT:?}/runtime/skills-check-packet-$(date -u +%Y%m%dT%H%M%SZ)-$$"
node scripts/project-method-journey-evidence.mjs --input "$journey_output" --output "$packet_output" --scope full > "$packet_output.stdout" 2> "$packet_output.stderr"
projection_exit=$?
if [ "$projection_exit" -ne 0 ]; then
  exit "$projection_exit"
fi
node scripts/project-method-journey-evidence.mjs --check "$packet_output" > "$packet_output.check.stdout" 2> "$packet_output.check.stderr"
