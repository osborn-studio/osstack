# Independent CI304 log verification

Run 40835326104: five SUCCESS checks and one paid DeepSeek SKIPPED, as saved in the supplied PR snapshot. PR304 remains Draft on `codex/method-material-delivery`; no Ready/merge action performed.

- Head: `185d283af23683ad084f81a6b049fcaab251a68f`. Checkout actually tested synthetic merge `0b05194ae064388f96a86a8569a2967248225eb2`, merging that head into `d05c9d91a79d8198e671452ebc96b3d3fcc34602` (raw lines3703–3706).
- Exact `check / Test` scope:22 unique packages, **7142 passed / 7 skipped / 0 failed**. No other job or standalone step was added to this count.
- Standalone exporter:94 total =93 pass +1 skip,0 fail; skip is absent global Codex home (line8444), not94 passed. Standalone projector:49 total/49 pass/0 skip/0 fail.
- Actual full journey command ran with `--scope full` (line9936/9942). Raw JSON lines9943–10138 records healthy/missing-ref/drift/mixed/empty product exits0/1/2/1/0; all five driver exits0 and verification passed. Overall command success is inferred from the successful bash -e CI step/check and passed receipt, not an explicit numeric process footer.
- Each row records fixture_removed=true, cleanup passed, descendants not_attested. Case manifest digests/source/build digests are preserved in report.json. Logged artifact12881506061 contains183 files,895339 zip bytes with logged SHA484c019f…ed313; this read-only review did not download or rehash that artifact.
- The receipt explicitly keeps model_calls=0, host_execution=not_run, provider_qualified=false, formal_gate_pass=false. These are finite local-fixture results, not native-host or production qualifications.

Both literal `^[[` and actual ESC CSI were stripped only in parser memory. Original logs unchanged; no parser errors occurred. Full raw hashes and line-indexed package counts are in report.json. No network/model/test run or repository change occurred.
