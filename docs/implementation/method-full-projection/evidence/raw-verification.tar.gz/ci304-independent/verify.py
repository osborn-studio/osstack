from pathlib import Path
import json,re,hashlib,datetime,traceback
root=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-full-projection-20261029'); out=root/'ci304-independent'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,x): (out/name).write_text(json.dumps(x,indent=2)+'\n')
try:
 log=root/'control/ci304.log'; meta=root/'control/pr304-ci-complete.json'
 lines=log.read_text().splitlines(); pr=json.loads(meta.read_text())
 def clean(t):return re.sub(r'(?:\x1b\[|\^\[\[)[0-?]*[ -/]*[@-~]','',t)
 rows=[]
 for n,l in enumerate(lines,1):
  p=l.split('\t',2)
  if len(p)==3 and p[0]=='check':rows.append((n,p[1],clean(p[2]).split('Z ',1)[-1].lstrip('\ufeff')))
 packages=[]
 for n,step,t in rows:
  if step=='Test':
   m=re.fullmatch(r'packages/([^ ]+) test:\s+Tests\s+(.+)',t)
   if m:
    c={k:int(v) for v,k in re.findall(r'(\d+) (passed|skipped|failed)',m[2])}
    packages.append({'package':m[1],'line':n,'passed':c.get('passed',0),'skipped':c.get('skipped',0),'failed':c.get('failed',0),'summary':t})
 assert len(packages)==len({p['package'] for p in packages})==22
 totals={k:sum(p[k] for p in packages) for k in ['passed','skipped','failed']}
 standalone={}
 for step in ['Method export contracts','Model evidence projection contracts']:
  counts={}
  for n,s,t in rows:
   m=re.fullmatch(r'# (tests|pass|fail|skipped) (\d+)',t)
   if s==step and m:assert m[1] not in counts;counts[m[1]]=int(m[2])
  assert counts['tests']==counts['pass']+counts['fail']+counts['skipped']
  standalone[step]=counts
 assert standalone['Method export contracts']=={'tests':94,'pass':93,'fail':0,'skipped':1}
 assert standalone['Model evidence projection contracts']=={'tests':49,'pass':49,'fail':0,'skipped':0}
 step='Full method verification journey (five real local cases)'
 jr=[(n,t) for n,s,t in rows if s==step]; start=next(i for i,(_,t) in enumerate(jr) if t=='{')
 journey=json.loads('\n'.join(t for _,t in jr[start:]))
 assert journey['status']=='passed'
 expected=[('healthy',0,'healthy'),('missing-ref',1,'failed'),('drift',2,'drift'),('mixed',1,'failed'),('empty',0,'empty')]
 assert [(f['case_id'],f['product_exit'],f['product_status']) for f in journey['features']]==expected
 assert all(f['driver_exit']==0 and f['verification']=='passed' and f['cleanup']['fixture_removed'] is True and f['cleanup']['descendant_termination']=='not_attested' for f in journey['features'])
 checkout=[{'line':n,'text':t} for n,s,t in rows if s=='Run actions/checkout@v7' and ('HEAD is now at' in t or re.fullmatch('[0-9a-f]{40}',t))]
 assert any(x['text']=='0b05194ae064388f96a86a8569a2967248225eb2' for x in checkout)
 assert pr['headRefOid']=='185d283af23683ad084f81a6b049fcaab251a68f' and pr['isDraft']
 assert [x['conclusion'] for x in pr['statusCheckRollup']].count('SUCCESS')==5
 assert [x['conclusion'] for x in pr['statusCheckRollup']].count('SKIPPED')==1
 result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':40835326104,'raw_bindings':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in [log,meta]],'parser':'Scope exact check/Test only; remove real ANSI and literal ^[[ CSI sequences in memory; preserve source bytes. No parser failure occurred.','pr':pr,'checkout':checkout,'test_package_count':22,'test_totals':totals,'packages':packages,'standalone':standalone,'export_skip':{'line':8444,'reason':'global Codex home absent; do not create it for testing'},'full_journey':{'log_lines':[jr[start][0],jr[-1][0]],'receipt':journey,'step_exit':'0 inferred from successful bash -e step, emitted passed record and completed SUCCESS check; log has no explicit standalone numeric process-exit footer','artifact_as_logged':{'id':12881506061,'files':183,'bytes':895339,'sha256':'484c019fe05c9f32c30d710f60bfab2735106a136c547bd13373278c173ed313'}},'limits':['No network or new tests executed. Artifact archive not downloaded or independently rehashed; upload record is log evidence only.','CI tested synthetic merge 0b05194a, not bare head185d283a nor later full-projection implementation.','No full-descendant termination, model call, runtime qualification or PR readiness inferred. PR304 remains Draft on feature base per supplied snapshot.']}
 write('report.json',result)
 (out/'report.md').write_text(f'''# Independent CI304 log verification\n\nRun 40835326104: five SUCCESS checks and one paid DeepSeek SKIPPED, as saved in the supplied PR snapshot. PR304 remains Draft on `codex/method-material-delivery`; no Ready/merge action performed.\n\n- Head: `185d283af23683ad084f81a6b049fcaab251a68f`. Checkout actually tested synthetic merge `0b05194ae064388f96a86a8569a2967248225eb2`, merging that head into `d05c9d91a79d8198e671452ebc96b3d3fcc34602` (raw lines3703–3706).\n- Exact `check / Test` scope:22 unique packages, **{totals['passed']} passed / {totals['skipped']} skipped / {totals['failed']} failed**. No other job or standalone step was added to this count.\n- Standalone exporter:94 total =93 pass +1 skip,0 fail; skip is absent global Codex home (line8444), not94 passed. Standalone projector:49 total/49 pass/0 skip/0 fail.\n- Actual full journey command ran with `--scope full` (line9936/9942). Raw JSON lines9943–10138 records healthy/missing-ref/drift/mixed/empty product exits0/1/2/1/0; all five driver exits0 and verification passed. Overall command success is inferred from the successful bash -e CI step/check and passed receipt, not an explicit numeric process footer.\n- Each row records fixture_removed=true, cleanup passed, descendants not_attested. Case manifest digests/source/build digests are preserved in report.json. Logged artifact12881506061 contains183 files,895339 zip bytes with logged SHA484c019f…ed313; this read-only review did not download or rehash that artifact.\n- The receipt explicitly keeps model_calls=0, host_execution=not_run, provider_qualified=false, formal_gate_pass=false. These are finite local-fixture results, not native-host or production qualifications.\n\nBoth literal `^[[` and actual ESC CSI were stripped only in parser memory. Original logs unchanged; no parser errors occurred. Full raw hashes and line-indexed package counts are in report.json. No network/model/test run or repository change occurred.\n''')
 write('manifest.json',{'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir()) if p.is_file() and p.name!='manifest.json']})
 print(json.dumps({'totals':totals,'report_sha256':sha(out/'report.json'),'manifest_sha256':sha(out/'manifest.json')}))
except Exception:
 (out/'parser-error.txt').write_text(traceback.format_exc());raise
