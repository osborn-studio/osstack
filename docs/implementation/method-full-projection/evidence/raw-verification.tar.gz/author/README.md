# Full projection author evidence

Candidate `2fa5b2cc759a23ace3afb40f71601742c85b0ec0`, base185d283a. Only projector and tests changed. Independent criteria arrived before tests or implementation were written. Node22.22.1, no install/build/full suite/model/driver run in this slice.

The baseline-v1 command used the unchanged base projector with the retained real default journey. Tests then established RED55pass/16fail: all original49 passed, while some new rejection tests already passed on the old default-only implementation. GREEN71 passed. Five additional failed/not_run/unknown/schema regressions bring final-focused to76pass/0fail/0skip. No original failures were overwritten.

The candidate projected retained real default and full journeys and checked both packets. `compatibility-and-inputs.json` verifies that default packet.json AND manifest.json are exactly byte-identical to baseline-v1 for the same input. Full produces v2 with five rows,10 safe streams and52 logical hash references. Implicit/default projection still rejects full before creating output. Original retained journey/case files still match all original sealed hashes after projection; raw input paths are recorded only in author provenance, never in published packet references.

The actual commands ran before commit with base185d HEAD and candidate working source bytes. Per-command records bind those exact implementation hashes to the final commit; no raw HEAD is relabeled. The real input evidence came from the prior accepted journey slice, not a newly executed driver here. Input hashes verify retained-file consistency, not live source/build/fixture state or authenticated provenance.

v1 keeps its two-case closed schema and output bytes. Explicit `--scope full` publishes v2's five-case closed schema; `--check` identifies version itself. Outer two-file manifest remains version1. Failed/unrun rows preserve unknown/reported distinctions; a globally failed journey can retain individually passed rows and differing bindings. Only a globally passed journey requires all five rows and common bindings. No native use, model comprehension, OS sandbox or formal gate claim is made.
