# Verdict: PASS (static review; no confirmed blockers)

I read the supplied files and diff only. I did not run any tests, drives or projections, and I could not check the candidate hash against the diff. `smoke-skills-check.mjs`, `package.json` scripts and real retained inputs weren't provided, so I draw no conclusion about the regression result, the pending freeze verification, or the author's actual default/full projection reports.

## Confirmed blockers

None found.

What I traced, and why it holds:

- **Default v1 unchanged.** For `schema_version: 1`, the validator uses the same `IDS`, `REF_IDS`, `SCOPE`, `safeLine`, stream cap of 4 and per-stream passed-snippet checks as before. `verifyPassed(..., full=false)` keeps the original `fixed_expectation` check. The only difference is error ordering on a bad version, which doesn't change accept/reject behavior. A five-case journey is still refused by the default path at `fixed_case_set`, and a two-case journey is refused by the full path. Both directions are tested.
- **`--check` and version.** `--check` accepts no `--scope` (`parseOptions`, tested). The packet's own `schema_version` selects the v1 or v2 rules, with exact scope equality (`FULL_SCOPE` keeps `SCOPE`'s key order, so the canonical `equal` holds). Version 3, v1 with a full scope, and a v2 with the pair scope are all rejected.
- **Source, raw and Git binding before output.** `fullExpectation` in `scripts/project-method-journey-evidence.mjs` checks the following before `mkdir`:
  - `git-03` and `git-05` command records: cwd, argv, exit, direct-child confirmation, no signal/timeout/limit, raw hashes, empty stderr, and a single `run.commands` index row each.
  - Both observed SHAs are 40-hex and distinct, and `current_sha` equals the `git-05` output.
  - The fixed policy counts match.
  - `expected.sources` equals the policy-derived sources, including origin URL, ref, blessed SHA, `auto_minor` and cardinality.
  - Raw stdout, minus blank lines, equals the exact derived line list, so extra or contradictory rows are rejected.
  
  This mirrors `verifyCaseEvidence` in the wrapper.
- **Preserved failures, not_run and unknown.** The unverified-row branches are untouched. Packet-only checks still force `product_exit` null, `product_status` unknown and cleanup unknown/not_started for non-passed rows, and not_created rows carry no claims. Full-scope tests cover the failed doctor with 4 not_run rows, the late binding failure, and a verifier failure with a reported driver pass.
- **Closed packet.** Fixed keys, an allowlisted stdout-only regex, an empty stderr projection, a fixed reference-ID set (2 + 5×10 = 52, matching the test) and the canonical-bytes check. `pathToFileURL` is used only to compare against the retained `file://` origin and isn't emitted. The 64 KiB cap is not at risk.
- **Packet-level semantics for passed full rows.** Per-case exit/status from `POLICIES`, exact stdout shape, per-source line forms, and mixed healthy-head equal to drift-head. The `mixed-zero-failure` and `wrong-exit` tests cover these.
- **CI.** The full-projection step runs after the full journey step (already in base). The output is under the scratch root with an existing parent and outside the input. The `if: always() && outcome != 'skipped'` upload matches the sibling steps. Docs and CI are consistent with the code: separate commands, `--check` without `--scope`, and the non-authentication limits are stated.

## Optional improvements (none block)

1. **Packet-level drift check.** `validatePacket` doesn't require blessed ≠ head in the `drift` line, so a resealed forged packet could pass. Add `check(blessed !== head, 'passed_snippet_conflict')` for `drift` and `mixed`. The projector already guarantees this at build time.
2. **Test gaps in `project-method-journey-evidence.test.mjs`.**
   - There are no tampering cases for the new Git binding: `git_observation` (cwd, exit or argv), `git_raw` (non-empty stderr or hash), `git_index` (missing or duplicate `run.commands` row), or a missing `git-03` record.
   - Nothing exercises the mixed head-mismatch branch in the validator, and no resealed-source test targets `mixed` or `empty`.
   - Most new `assert.rejects` calls have no error-code match, so they could pass for the wrong reason. At least pin `full_raw_semantics`, `fixed_sources`, `fixed_current_sha` and `git_raw`.
   - There is no real-CLI `--scope full` run, so the `main()` path with `scope` is exercised only through `parseOptions`.
3. **Fixture-path consistency.** `receipt_cleanup_consistent` compares `cleanup()` projections, which drop `fixture_path`. In full scope, the origin is derived from `cleanup.json` alone, while the wrapper compares the raw `receipt.cleanup` and `cleanup.json`. Compare `fixture_path` raw in the full branch to stay aligned.
4. **Stricter than the wrapper.** `err.length === 0` for the git stderr is not required by `verifyCaseEvidence`. A real passed run with benign git stderr would be refused by the projector. Either drop the check or note the divergence. The author's real full-input pass report would be the evidence to confirm this doesn't happen.
5. **Check output.** `checkPacket` doesn't report the detected `schema_version`, so CI and consumers can't see which version was validated. Adding it is additive.
6. **Style.** In `validatePacket`, the `else if (!full)` body keeps the old indentation for `summaries` and `check`. Re-indent to match the surrounding code.
7. **Docs.**
   - "Projection can represent a closed failed journey" should say that an `unsealed` or unreadable case directory is refused (`unsealed_case`, `verification_status`). Only sealed or not_created failed rows project.
   - `journey_output` is a non-exported shell variable in the first block, so the second block, if run as a separate script, will stop at its `:?` guard. Say to export it or run both blocks in one script.
8. **CI.** Nothing asserts the cross-refusals (default refuses full input, and the reverse) beyond unit tests. A live negative step is not worth the added cost.

Before calling it done, someone still has to run the full regression and the independent freeze verification. This audit is not a substitute for either.