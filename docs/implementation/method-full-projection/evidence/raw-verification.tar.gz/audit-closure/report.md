# Verdict: PASS (static, no remaining blockers)

I read the supplied source, tests, docs and diff only. I did not run anything, and I can't tie the diff to candidate `1d366d4d…`. I rely on your report for the full-suite result at da059 and the pending targeted run. This is not a gate or identity qualification.

## Fix confirmed

The new check in `buildProjection` closes the contradiction I confirmed as optional 3:

- **Scope is right.** The check is gated on `full && f.verification === 'passed'`. The v1 path never reaches it, so default behavior is unchanged. Failed rows, `not_run` rows and `not_created` rows keep their existing unverified-claim handling.
- **Three-way agreement.** It requires `cleanup.json`, `receipt.cleanup` and `feature.cleanup` to carry the same absolute `fixture_path` string. This runs before `cleanup()` drops the path, which was the gap.
- **Origin anchoring.** `fullExpectation` derives `origin` from `cleaned.fixture_path`. The git `cwd`, `expected.sources` origin and the stdout semantics are now tied to the same fixture identity that the receipt and journey row assert.
- **Ordering.** The check runs after `case_manifest_binding` and `receipt_case` and before `verifyPassed`. It therefore reports the specific `cleanup_fixture_identity` code, and a resealed variant can't be masked by a different error.
- **Tests.** The `receipt` variant edits the sealed receipt and reseals the case. The `feature` variant edits `journey.json` and reseals the root. Both are pinned to `/^Error: cleanup_fixture_identity$/` and assert that no output is created. Both reach the new check, since `healthy` is the first row and nothing earlier fails. The positive test confirms consistent input still projects with no path leakage.
- **Cleanups.** The `else if (!full)` re-indent is correct, and the docs now cover the `unsealed` refusal and the `journey_output` scope.

## Docs

- **Failed-journey paragraph.** It matches the code: only sealed or `not_created` rows project, and `unsealed_case` or an unreadable case directory is refused. "Coherent" correctly covers the `missing_case_evidence` and `not_created_claim` refusals.
- **Second shell block.** The guidance matches the `:?` guard. It works in the same script, or in a new script that sets `journey_output`.
- **Git stderr note.** It is accurate to `err.length === 0` → `git_raw`. The "even if the verifier had accepted it" wording is conditional, so it makes no claim about the wrapper.

## Non-blocking notes

1. **Doc gap for the new refusal.** The narrower-than-wrapper note covers Git stderr but not the new requirement that all three `fixture_path` values agree on passed full rows. Add one sentence there. Better, move both notes into the projection section, where the paragraph currently trails the unrelated "Failure and maintenance" section.
2. **Real-bundle dependency, to confirm before freeze.** The check requires `feature.cleanup.fixture_path` to be present. The test fixture includes it, but I can't see the wrapper's `journey.json` writer. If real full journeys omit it from feature cleanup, every real passed full input would be refused. C's real-CLI projection of an actual full bundle is the evidence that settles this. Treat that run as a required condition for this PASS.
3. **Thin test coverage.** There is no test for a missing or relative `cleaned.fixture_path`, and none for a non-healthy case. The check is uniform across cases, so this is low risk.
4. **Earlier suggestions you declined.** I accept the reasoning on short-SHA equality, since distinct SHAs can share a 12-character prefix. I also accept skipping the version output.