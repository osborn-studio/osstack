import subprocess,pathlib,hashlib,json,datetime,os,sys
r=pathlib.Path(__file__).parent
cwd=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-projection-control')
label=sys.argv[1];args=sys.argv[2:]
def snapshot():
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=cwd).decode().split('\0')
 return {n:hashlib.sha256((cwd/n).read_bytes()).hexdigest() for n in tracked if n and (cwd/n).is_file()}
before=snapshot();start=datetime.datetime.now(datetime.timezone.utc).isoformat();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd).decode().strip()
(r/(label+'-before.json')).write_text(json.dumps(before,sort_keys=True))
with (r/(label+'.log')).open('w') as out:
 code=subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,env={**os.environ,'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}).returncode
after=snapshot();(r/(label+'-after.json')).write_text(json.dumps(after,sort_keys=True))
b={'head':head,'command':args,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'tracked_changed_during_run':[n for n in before if before[n]!=after.get(n)],'preexisting_generated_dist':{n:v for n,v in before.items() if n.startswith('packages/knowledge/dist/')},'log_sha256':hashlib.sha256((r/(label+'.log')).read_bytes()).hexdigest()}
(r/(label+'-binding.json')).write_text(json.dumps(b,indent=2));print(json.dumps(b));sys.exit(code)
