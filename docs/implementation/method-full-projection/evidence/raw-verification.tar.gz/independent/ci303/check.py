import pathlib,re,json,hashlib,datetime
D=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-full-projection-20261029');C=D/'control';O=D/'independent/ci303'
raw=(C/'ci303.log').read_bytes();text=raw.decode();clean=re.sub(r'(?:\x1b\[|\^\[\[)[0-9;]*[A-Za-z]','',text);rows={};steps={};checkout=[]
for i,l in enumerate(clean.splitlines(),1):
 parts=l.split('\t',2)
 if len(parts)!=3:continue
 job,step,tail=parts
 if job=='check' and step=='Test':
  m=re.search(r'packages/([^ ]+) test:\s+Tests\s+(.+)$',tail)
  if m:
   assert m[1] not in rows,'duplicate package summary'
   fields={label:int(v) for v,label in re.findall(r'(\d+) (passed|skipped|failed)',m[2])}
   rows[m[1]]={'passed':fields.get('passed',0),'skipped':fields.get('skipped',0),'failed':fields.get('failed',0),'line':i,'text':l}
 if job=='check':
  m=re.search(r'# (tests|pass|fail|skipped) (\d+)\s*$',tail)
  if m:steps.setdefault(step,{})[m[1]]=int(m[2])
 if step.startswith('Run actions/checkout@') and 'HEAD is now at' in tail:checkout.append({'job':job,'line':i,'text':l})
assert len(rows)==22
sums={key:sum(r[key] for r in rows.values()) for key in ['passed','skipped','failed']};assert sums=={'passed':7142,'skipped':7,'failed':0}
summary=json.loads((C/'ci303-summary.json').read_text());assert all(sums[k]==summary[k] for k in sums)
pr=json.loads((C/'pr303-ready.json').read_text());head='d05c9d91a79d8198e671452ebc96b3d3fcc34602';base='493caa4e46e616b1d7e9e1c87ed0a5775eae3ad1'
assert pr['headRefOid']==head and pr['baseRefName']=='main'
assert len([c for c in pr['statusCheckRollup']if c['conclusion']=='SUCCESS'])==5
assert all(head in c['text'] and base in c['text'] for c in checkout) and len(checkout)==5
for name,expected in [('Method export contracts',{'tests':94,'pass':93,'fail':0,'skipped':1}),('Method material pagination contracts',{'tests':14,'pass':14,'fail':0,'skipped':0})]:assert steps[name]==expected
result={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'confirmed_from_supplied_raw_logs_and_ready_snapshot','run':40833415091,'pr':303,'head':head,'base_at_checkout':base,'tested_object':'GitHub synthetic merge b2d2085e (raw checkout), not a claim that plain head itself was checked out','checkout_lines':checkout,'unique_package_summaries':rows,'totals':sums,'package_count':22,'node_test_step_summaries':steps,'checks':[{'name':c['name'],'conclusion':c['conclusion'],'completedAt':c['completedAt']}for c in pr['statusCheckRollup']],'source_files':[{'path':str(C/n),'sha256':hashlib.sha256((C/n).read_bytes()).hexdigest()}for n in ['ci303.log','ci303-summary.json','ci303-parser-initial-invalid.json','pr303-ready.json']],'limitations':['No artifacts downloaded or inspected.','Readiness is supplied snapshot, not a fresh network read.','No test rerun, model call or PR action.','Synthetic merge relation is observed in raw checkout text; not independently fetched Git object.','Initial zero-count parser output retained and invalid; corrected parser strips literal caret ANSI without modifying original log.']}
(O/'report.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'report.md').write_text('# PR303 independent CI closeout\n\nConfirmed run 40833415091 for head `d05c9d91a79d8198e671452ebc96b3d3fcc34602`. Raw checkout records show GitHub synthetic merge `b2d2085e` into base `493caa4e`, rather than plain head. Supplied Ready snapshot has five applicable SUCCESS checks; paid smoke SKIPPED.\n\nExactly 22 unique `check / Test` package summaries total **7,142 passed / 7 skipped / 0 failed**, matching corrected summary. Export contracts: **94 total, 93 passed, 1 skipped**. Reader pagination contracts: **14 passed**. Other distinct check-step results include decision smoke 27, skills verification 25, journey contracts 25 and projection contracts 49 passed. These are separate steps, not added into the package total.\n\nOriginal zero-count ANSI parser failure remains preserved. This independent parser strips literal caret ANSI and verifies unique package summaries directly from the original log. No artifacts were downloaded, no fresh network snapshot was taken, and no tests/models/PR actions were run.\n')
print(hashlib.sha256((O/'report.json').read_bytes()).hexdigest());print(hashlib.sha256((O/'report.md').read_bytes()).hexdigest())
