# Full five-case projection independent criteria

Frozen before independent candidate inspection; author was requested to wait. Applies only to this optional projection slice. Model/native/principal/runtime qualification remains unclaimed.

**FP01** Default project and check retain existing v1 two-case contract. For identical retained default input compare old/new packet bytes, not only exit. New full support must not silently upgrade default version or accept five cases without explicit full.

**FP02** Explicit --scope full produces new self-describing version/scope and exact five IDs/order healthy,missing-ref,drift,mixed,empty. Product exits0/1/2/1/0 and product statuses healthy/failed/drift/failed/empty remain distinct from verification passed and driver0. Omitted/reordered/extra cases rejected; full option cannot relabel two rows.

**FP03** Passed full input must validate recorded source shapes/cardinality, refs, current/old blessed SHA and raw outcomes, input hashes, command/detail/receipt/run identities and digests. A resealed wrong old/current SHA, duplicate/missing mixed source, added empty source, contradictory count/raw row cannot become passed merely because expected exit matches.

**FP04** Actual closed failure histories preserve failed/not_run and unknown/not_started cleanup, nullable verified product vs reported product/cleanup. Driver-passed but enclosing verifier-failed remains unverified; doctor failure without case evidence remains representable. No omission of failed row or inference of health/removal.

**FP05** Whole journey passed requires all five passed with matching source/build binding digests. Legitimate global failed after individually passed observations may preserve different bindings and per-row results; do not reject/erase valid recorded failure merely to impose overall success invariants.

**FP06** Input manifests, member bytes/hash/inventory and case manifest index are checked before output. Missing member, unsealed tamper, resealed identity/receipt/source contradiction or unexpected case directory rejected. Input bytes stay unchanged on success and rejection.

**FP07** Output exactly packet.json+manifest.json with bounded closed schemas/logical IDs and hashes; no arbitrary origin/path/argv/env/credentials/raw error or free text crosses. Drift snippets only fixed known line shape, not arbitrary origin/ref/path. Original raw data is retained outside packet, never rewritten or falsely described as absent.

**FP08** --check recognizes supported versions from packet; rejects version/scope confusion, unknown fields/versions, contradictory passed/not_run cleanup/exit/status, malformed references/streams, extra file, symlink, stale manifest hash. Consistent resealing does not authenticate a fabricated packet: reported validation is byte/schema consistency only.

**FP09** Unknown/duplicate/missing scope and --check mixed with scope/project flags fail. Direct API unknown scope fails before output. Rejection never acquires new output; existing sentinel stays intact; input/output overlap and unsafe directory/symlink boundaries remain enforced.

**FP10** Real default and full retained journeys independently project/check; reuse existing immutable actual inputs rather than rerun drivers unnecessarily. Full failure cases and bounded adverse copies have separately attributed results. Binding claims are retained bytes, not new live-runtime/source/compile revalidation.

**FP11** Bounded input/packet/stream resources remain explicit; five-case reference/stream extension does not widen arbitrary field allowance or accidentally use two-case limits to reject valid full packet. Targeted size/count/extra-member refusal preserved without requiring generic sandbox.

**FP12** Documentation/result scope accurately says optional full safe projection, not live verification, semantic comprehension, native host execution or formal principal/gate. No old host calls/LIMITED results rewritten, no model call required; tests and fault copies are not model-observed behavior.

Use retained actual default/full and four failure histories. New adverse copies are explicitly test-generated; full global failure may preserve individual passed observations. `--check` proves retained schema/hash consistency, never origin authenticity.
