import pathlib,json,hashlib,datetime,subprocess
S=pathlib.Path(__file__).resolve().parent;I=S.parent
J=lambda p:json.loads(p.read_bytes());H=lambda b:hashlib.sha256(b).hexdigest()
a=J(S/'actual-results.json');v=J(S/'adversarial-results.json');r=J(S/'revision-9ed/result.json');finding=J(S/'cleanup-conflict-result.json');assert all(x['passed']for x in v['rows']);assert all(x['unexpected_acceptance']for x in finding['results'])
criteria=J(I/'criteria.json')
for p in [S/'full-packet/packet.json',S/'revision-9ed/full-packet/packet.json']:
 packet=J(p);assert packet['schema_version']==2;assert [x['case_id']for x in packet['features']]==['healthy','missing-ref','drift','mixed','empty'];assert [x['product_exit']for x in packet['features']]==[0,1,2,1,0];assert [x['product_status']for x in packet['features']]==['healthy','failed','drift','failed','empty'];assert len(packet['references'])==52 and len(packet['streams'])==10
 assert not any(t in p.read_text()for t in ['/Volumes/','/Users/','OSSTACK_HOME','"environment"','"argv"','PRIVATE_SENTINEL'])
packet=J(S/'revision-9ed/fault-cross-binding-packet/packet.json');assert packet['journey_status']=='failed' and [x['verification']for x in packet['features']]==['passed','passed','passed','not_run','not_run'];assert packet['features'][0]['bindings']!=packet['features'][2]['bindings']
packet=J(S/'revision-9ed/fault-verifier-packet/packet.json');assert packet['features'][2]['verification']=='failed' and packet['features'][2]['product_exit']is None and packet['features'][2]['cleanup']['status']=='unknown'
axis={
'FP01':'Old/new same retained default packet and manifest exact-byte equal, including revision9ed.',
'FP02':'Explicit full schema2, ordered5 and exits/statuses; default/full mismatch refused; --check self-describes version.',
'FP03':'Resealed old/current/source/count/receipt/detail contradictions refused. Post-audit fixture-identity contradiction initially accepted, fixed9ed and exact original inputs now refused.',
'FP04':'Three legitimate retained failure shapes represented with original states; malformed no-evidence reported product remains refused (old/new equivalentlegacycontrol bothreject).',
'FP05':'Passed full equalbindings; packet conflictingbindings refused; legitimate globalfailed crossbinding retains individualpassed rows.',
'FP06':'Inputhash/inventory and caseindex mutations checked before output; all six immutable original histories unchanged through revision.',
'FP07':'Two-file closed packets52logicalrefs10streams; failed raw private marker omitted, refs only hashes/IDs; no originalpaths/env/argv in actual full packets.',
'FP08':'Version/scope/fields/product/status/cleanup/refs/snippets/extra-file/symlink/stalehash check mutations refused; this is schema/byte validation not provenance.',
'FP09':'Scope parser/API invalids, existing-output sentinel and overlap refused; rejectedproject cases acquire no output. These negatives are API/parser observations, not all separate CLIspawns.',
'FP10':'Actualproject/check invocations reuse retained real default/full/failure histories. No driver/model replay; testcopy and faultseam lineage explicit.',
'FP11':'Actual52refs/10streams fit bounds; >8MiBinput, >8selectedlines and oversizedref refused. Not an exhaustive resourcebenchmark or OSsandbox.',
'FP12':'B e603 documentation statically reviewed, versions/boundaries accurate; full failure representation is bounded by completeness/consistency, not universal. OldLIMITED unchanged.'}
report={'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'confirmed_defect_fixed_bounded_revision_verified','criteria_sha256':H((I/'criteria.json').read_bytes()),'initial_candidate':'2fa5b2cc759a23ace3afb40f71601742c85b0ec0','final_candidate':r['commit'],'final_source_sha256':r['source_sha256'],'initial_composition':a['source']['head'],'fixed_finding':{'id':'C-F1','description':'Full passed fixture identity could disagree across receipt/feature/cleanup yet projection labelled cleanup consistent.','initial_proof':'cleanup-conflict-result.json','initial_unexpected_acceptance_count':2,'fix':'9ed86675 checks exact raw fixture identity before path omission for full passed only; v1 unchanged.','replay':'revision-9ed/result.json','four_revision_negatives':'two exact original contradictory inputs plus two missing-identity counterparts refused cleanup_fixture_identity','timing':'Concrete probes were added after audit, under preexisting FP03/06 consistency criterion; not represented as prefrozen concrete vectors.'},'axes':[{'id':x,'status':'passed_with_stated_scope','evidence':axis[x]}for x in axis],'initial_adversarial_observations':len(v['rows']),'revision_project_invocations':len(r['commands']),'default_v1_byte_equal':r['default_v1_bytes_unchanged'],'valid_full_packet_byte_equal_to_initial':r['valid_full_bytes_unchanged'],'original_inputs_unchanged':r['original_inputs_unchanged'],'evidence_files':{str(p.relative_to(S)):H(p.read_bytes())for p in [S/'actual-results.json',S/'adversarial-results.json',S/'cleanup-conflict-result.json',S/'wrapper-cleanup-control.json',S/'failure-baseline-result.json',S/'revision-9ed/result.json']},'limitations':['45 original adverse observations remain bound2fa; final9ed reran bounded fix-specific negatives and 5 positive project/check controls rather than falsely claiming entire matrix rerun.','No model/native/fullsuite/productiondriver run or formal gate/principal certification.','Hash/schema checks cannot authenticate a wholly fabricated but internally consistent packet.','Copied/resealed negative inputs and injected failure histories are disclosed; no natural productfailure claimed.','Only static Bdocs review here; B own export results are not called independent executions.','Initial wrapper comparison used wrong repository dirname depth and failed product_entry; preserved, followed by corrected cleanup_claim comparison.']}
(S/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(S/'report.md').write_text('''# Independent full projection verification

**One confirmed consistency defect was found and fixed.** Initial `2fa5b2cc` accepted a passed row whose receipt or journey feature named a different cleanup fixture, then emitted `receipt_cleanup_consistent:true`. The two original resealed inputs and incorrectly accepted packets are retained. Concrete probes were added after the audit, under the already-frozen FP03/FP06 consistency requirements.

Final `9ed86675` rejects both exact original inputs and missing-identity counterparts with `cleanup_fixture_identity`. The fix checks raw fixture identity before omitting paths, for full/v2 passed rows only. Corrected wrapper comparison rejects the receipt contradiction with `cleanup_claim`; its earlier harness target-depth error (`product_entry`) is preserved and not treated as product evidence.

For the same retained real default journey, old185d/new2fa/final9ed packet and manifest bytes are identical. Explicit full projection produces v2 with ordered healthy/missing-ref/drift/mixed/empty, product exits **0/1/2/1/0**, statuses healthy/failed/drift/failed/empty, 52 logical references and 10 bounded streams. Its valid packet bytes are unchanged by the repair. `--check` accepts both versions without a scope option. Default/full input mismatches reject before output.

45 initial bounded adverse/interface observations covered source cardinality and SHA/ref mismatch, raw counts, receipt/detail/run/binding consistency, input integrity, cases, packet fields/versions/status/cleanup, private strings, resource limits and filesystem boundaries. They remain bound to 2fa. The final small delta reran ten project invocations: four cleanup-identity negatives; default/full plus three represented failed-history positives (each checked); and one malformed-history refusal. No claim is made that all 45 were rerun on9ed.

Representable doctor/verifier/cross-binding failures preserve failed/not_run/unknown and individually passed rows. Global cross-binding failure legitimately retains differing per-row digests. The prior fault-drive seam reported a product result without creating any case evidence; it is not a natural driver failure and is correctly refused `not_created_claim`. A separately labeled derived two-case shape is refused identically by old and new code. Failure preservation does not imply every incomplete/unsealed history can be projected.

All six original retained input directories stayed byte-identical. Failed-record private marker data was omitted from the packet while remaining in the original test record. These checks establish retained consistency, not compiler/source authenticity, live cleanup, model comprehension or an independently authenticated oracle. No models, drivers, full suite or old host experiments were run. B e603 references were reviewed statically; author export results are not relabeled independent execution.

Raw results, commands, sparse mutation inputs, original accepted-bad packets and repaired results are retained beneath this directory. See `report.json` and `revision-9ed/result.json`.
''')
files=[]
for p in sorted(I.rglob('*')):
 if p.is_symlink():raise RuntimeError('unexpected archive symlink '+str(p))
 if p.is_file()and p.name!='final-manifest.json':
  b=p.read_bytes();files.append({'path':str(p.relative_to(I)),'bytes':len(b),'sha256':H(b),'mode':oct(p.stat().st_mode&0o777)})
(I/'final-manifest.json').write_text(json.dumps({'files':files,'count':len(files),'payload_bytes':sum(x['bytes']for x in files)},indent=2)+'\n')
for p in [S/'report.json',S/'report.md',I/'final-manifest.json']:print(p,H(p.read_bytes()))
print('members',len(files),'payload',sum(x['bytes']for x in files))
