import pathlib,json,subprocess,hashlib,time,shutil
S=pathlib.Path(__file__).resolve().parent;D=S/'revision-9ed';D.mkdir();P=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-full-journey-20261029/independent/validation');R=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-projection-author').resolve();script=R/'scripts/project-method-journey-evidence.mjs';N='/opt/homebrew/opt/node@22/bin/node';commit='9ed86675b3c100a245e21ba7fc0a1b8d4dbcdd19'
def h(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==commit
assert subprocess.check_output(['git','show',commit+':scripts/project-method-journey-evidence.mjs'],cwd=R)==script.read_bytes()
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(S/'home'),'OSSTACK_HOME':str(S/'home/osstack'),'OSSTACK_SCRATCH_ROOT':str(S),'LANG':'C','LC_ALL':'C'};rows=[]
def run(label,inp,expected,full=True,reason=None):
 out=D/(label+'-packet');argv=[N,str(script),'--input',str(inp),'--output',str(out)]+(['--scope','full']if full else[]);start=time.time();p=subprocess.run(argv,cwd=R,env=env,capture_output=True,timeout=20);(D/(label+'.stdout')).write_bytes(p.stdout);(D/(label+'.stderr')).write_bytes(p.stderr);r={'label':label,'argv':argv,'cwd':str(R),'exit_code':p.returncode,'expected_exit':expected,'elapsed_seconds':time.time()-start,'stdout_sha256':h(p.stdout),'stderr_sha256':h(p.stderr)};rows.append(r);save(D/(label+'.command.json'),r);print(label,p.returncode,flush=True);assert p.returncode==expected,(label,p.stderr)
 if reason:assert reason.encode()in p.stderr
 if expected:assert not out.exists()
 else:
  c=subprocess.run([N,str(script),'--check',str(out)],cwd=R,env=env,capture_output=True,timeout=15);(D/(label+'.check.stdout')).write_bytes(c.stdout);(D/(label+'.check.stderr')).write_bytes(c.stderr);assert c.returncode==0;r['check_exit']=c.returncode
 return out
for mode in ['receipt','feature']:run('replay-'+mode,S/('cleanup-conflict-'+mode+'-input'),1,reason='cleanup_fixture_identity')
default=run('default',P/'actual-default',0,full=False);assert (default/'packet.json').read_bytes()==(S/'old-default-packet/packet.json').read_bytes();assert (default/'manifest.json').read_bytes()==(S/'old-default-packet/manifest.json').read_bytes()
full=run('full',P/'actual-full',0);assert (full/'packet.json').read_bytes()==(S/'full-packet/packet.json').read_bytes()
for name in ['fault-doctor','fault-verifier','fault-cross-binding']:run(name,P/name,0)
run('fault-drive-refused',P/'fault-drive',1,reason='not_created_claim')
# Missing raw identity is also a contradiction for a passed full row, rather than silently normalized away.
for mode in ['receipt','feature']:
 d=D/('missing-'+mode+'-input');shutil.copytree(P/'actual-full',d)
 if mode=='receipt':
  c=d/'cases/healthy';x=J(c/'receipt.json');del x['cleanup']['fixture_path'];save(c/'receipt.json',x)
  m=J(c/'manifest.json');m['files']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for p in sorted(c.iterdir())if p.is_file()and p.name!='manifest.json'];save(c/'manifest.json',m)
  m=J(d/'journey-manifest.json');next(x for x in m['case_manifests']if x['case_id']=='healthy')['sha256']=h((c/'manifest.json').read_bytes());save(d/'journey-manifest.json',m)
 else:
  x=J(d/'journey.json');del x['features'][0]['cleanup']['fixture_path'];save(d/'journey.json',x)
 m=J(d/'journey-manifest.json');m['files']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for p in sorted(d.iterdir())if p.is_file()and p.name!='journey-manifest.json'];save(d/'journey-manifest.json',m)
 run('missing-'+mode,d,1,reason='cleanup_fixture_identity')
# Hash original immutable inputs again against pre-first-run inventory.
old=J(S/'actual-results.json')['original_input_inventory']
for name,files in old.items():
 current={str(p.relative_to(P/name)):{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for p in sorted((P/name).rglob('*'))if p.is_file()}
 assert current==files,name
save(D/'result.json',{'commit':commit,'source_sha256':h(script.read_bytes()),'commands':rows,'status':'confirmed_cleanup_identity_gap_closed','default_v1_bytes_unchanged':True,'valid_full_bytes_unchanged':True,'original_inputs_unchanged':True,'post_audit_vectors':['receipt/feature fixture identity contradictions; missing identity counterparts'],'prior_initial_failure_preserved':True,'limits':'Only bounded revision checks, original45observations remain bound2fa; no driver/model/fullsuite rerun.'});print(h((D/'result.json').read_bytes()))
