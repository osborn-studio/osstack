import {readFile,writeFile,readdir,cp,mkdir,rm,lstat,realpath} from 'node:fs/promises';import{createHash}from'node:crypto';import{join,dirname}from'node:path';import{fileURLToPath,pathToFileURL}from'node:url';
const S=dirname(fileURLToPath(import.meta.url)),P='/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-full-journey-20261029/independent/validation/actual-full',R=await realpath('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-projection-control');
const{projectJourney}=await import(pathToFileURL(join(R,'scripts/project-method-journey-evidence.mjs'))),{verifyCaseEvidence}=await import(pathToFileURL(join(R,'scripts/method-verification-journey.mjs')));
const H=b=>createHash('sha256').update(b).digest('hex'),J=async p=>JSON.parse(await readFile(p)),save=(p,x)=>writeFile(p,JSON.stringify(x,null,2)+'\n');
async function edit(p,f){const x=await J(p);f(x);await save(p,x);}async function seal(d,name){const m=await J(join(d,name));m.files=[];for(const n of(await readdir(d)).sort()){const p=join(d,n);if(n!==name&&(await lstat(p)).isFile()){const b=await readFile(p);m.files.push({path:n,bytes:b.length,sha256:H(b)});}}await save(join(d,name),m);}
const results=[];
for(const mode of ['receipt','feature']){
 const d=join(S,'cleanup-conflict-'+mode+'-input'),out=join(S,'cleanup-conflict-'+mode+'-packet');await cp(P,d,{recursive:true});const c=join(d,'cases/healthy');
 // Relocate receipt evidence path so the wrapper positive control would not stop on copy identity.
 await edit(join(c,'receipt.json'),x=>{x.evidence.directory=c;if(mode==='receipt')x.cleanup.fixture_path='/foreign/contradictory-fixture';});
 if(mode==='feature')await edit(join(d,'journey.json'),x=>x.features[0].cleanup.fixture_path='/foreign/contradictory-fixture');
 await seal(c,'manifest.json');const h=H(await readFile(join(c,'manifest.json')));await edit(join(d,'journey-manifest.json'),x=>x.case_manifests.find(x=>x.case_id==='healthy').sha256=h);await seal(d,'journey-manifest.json');
 let projectionError=null,wrapperError=null;try{await projectJourney({input:d,output:out,scope:'full'});}catch(e){projectionError=e.message;}
 const command=await J(join(c,'healthy.command.json'));const target=dirname(dirname(dirname(command.argv[0])));
 try{await verifyCaseEvidence({directory:c,scratch:join(P,'scratch'),caseId:'healthy',repository:target,stdout:await readFile(join(c,'receipt.json')),driverExit:0});}catch(e){wrapperError=e.message;}
 const packet=projectionError?null:await J(join(out,'packet.json'));
 results.push({mode,expected:'reject contradictory retained cleanup fixture identity',projection_error:projectionError,wrapper_error:wrapperError,unexpected_acceptance:projectionError===null,packet_cleanup:packet?.features[0].cleanup,receipt_cleanup_consistent:packet?.features[0].receipt_cleanup_consistent,input:d,output:out});
}
await save(join(S,'cleanup-conflict-result.json'),{origin:'Post-audit explicit probe of frozen FP03/FP06 receipt/claim consistency; not claimed as preselected concrete vector.',candidate:'2fa5b2cc759a23ace3afb40f71601742c85b0ec0',results});console.log(JSON.stringify(results,null,2));
