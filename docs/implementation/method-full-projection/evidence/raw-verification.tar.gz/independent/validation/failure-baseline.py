import pathlib,json,shutil,hashlib,subprocess,os
S=pathlib.Path(__file__).resolve().parent;P=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-full-journey-20261029/independent/validation/fault-drive');D=S/'legacy-not-created-comparison'
def h(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
shutil.copytree(P,D);j=J(D/'journey.json');healthy=j['features'][0];failed=j['features'][2];failed['case_id']='missing-ref';j['features']=[healthy,failed];j['scope']='Derived legacy two-case shape for unchanged not_created_claim predicate comparison';save(D/'journey.json',j)
shutil.rmtree(D/'cases/missing-ref')
m=J(D/'journey-manifest.json');m['case_manifests']=[x for x in m['case_manifests']if x['case_id']=='healthy'];m['files']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':h(p.read_bytes())}for p in sorted(D.iterdir())if p.is_file()and p.name!='journey-manifest.json'];save(D/'journey-manifest.json',m)
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(S/'home'),'OSSTACK_HOME':str(S/'home/osstack'),'OSSTACK_SCRATCH_ROOT':str(S)}
rows=[]
for label,script in [('old',S.parent/'original-source/scripts/project-method-journey-evidence.mjs'),('new',pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-projection-control/scripts/project-method-journey-evidence.mjs'))]:
 argv=['/opt/homebrew/opt/node@22/bin/node',str(script),'--input',str(D),'--output',str(S/(label+'-not-created-output'))];p=subprocess.run(argv,env=env,capture_output=True,timeout=15);(S/(label+'-not-created.stdout')).write_bytes(p.stdout);(S/(label+'-not-created.stderr')).write_bytes(p.stderr);assert p.returncode==1 and b'not_created_claim' in p.stderr;assert not (S/(label+'-not-created-output')).exists();rows.append({'label':label,'argv':argv,'exit_code':p.returncode,'stderr_sha256':h(p.stderr)})
record={'status':'unchanged_legacy_predicate_confirmed','source_history':str(P),'source_is':'Independent prior fault injection returned synthetic product report actual_exit=2 without creating a case evidence directory. It is not a natural driver failure.','derived_control':'Two-case-shaped adapter of same failed-row claim, not an executed two-case journey; healthy original evidence retained. Both old/new projectors reject identical derived bytes.','actual_full_candidate_error':'not_created_claim','reason':'not_created evidence cannot support a non-null reported_product_exit/reported cleanup. Supporting failed histories does not mean fabricating absent evidence.','commands':rows};save(S/'failure-baseline-result.json',record)
link=S/'mutation-records/packet-symlink-member/packet.json'
if link.is_symlink():
 save(link.with_name('symlink-input-description.json'),{'path':'packet.json','type':'symlink','target':os.readlink(link),'note':'Actual symlink used for check and raw ELOOP preserved; removed after test to avoid unsafe archive link.'});link.unlink()
print('old/new derived not_created_claim confirmed; own test link removed')
