import pathlib,hashlib,json,subprocess,time,os
S=pathlib.Path(__file__).resolve().parent;I=S.parent;R=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-full-projection-control').resolve();P=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-full-journey-20261029/independent/validation');N='/opt/homebrew/opt/node@22/bin/node'
def h(b):return hashlib.sha256(b).hexdigest()
def inv(d):return {str(p.relative_to(d)):{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())} for p in sorted(d.rglob('*'))if p.is_file()}
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(S/'home'),'OSSTACK_HOME':str(S/'home/osstack'),'OSSTACK_SCRATCH_ROOT':str(S),'LANG':'C','LC_ALL':'C'};(S/'home').mkdir(exist_ok=True)
old=I/'original-source/scripts/project-method-journey-evidence.mjs';scratch=I/'original-source/scripts/lib/scratch.mjs';scratch.write_bytes(subprocess.check_output(['git','show','185d283af23683ad084f81a6b049fcaab251a68f:scripts/lib/scratch.mjs']))
new=R/'scripts/project-method-journey-evidence.mjs'
source={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'author':'2fa5b2cc759a23ace3afb40f71601742c85b0ec0','candidate_file_sha256':h(new.read_bytes()),'old_file_sha256':h(old.read_bytes())};assert subprocess.check_output(['git','show',source['author']+':scripts/project-method-journey-evidence.mjs'])==new.read_bytes();(S/'source-binding.json').write_text(json.dumps(source,indent=2)+'\n')
rows=[]
def run(label,args,expected):
 argv=[N,*map(str,args)];t=time.time();p=subprocess.run(argv,cwd=R,env=env,capture_output=True,timeout=20);(S/(label+'.stdout')).write_bytes(p.stdout);(S/(label+'.stderr')).write_bytes(p.stderr);row={'label':label,'argv':argv,'cwd':str(R),'environment':env,'exit_code':p.returncode,'expected_exit':expected,'started_unix':t,'elapsed_seconds':time.time()-t,'stdout_sha256':h(p.stdout),'stderr_sha256':h(p.stderr)};(S/(label+'.command.json')).write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print(label,p.returncode,flush=True);assert p.returncode==expected,(label,p.stderr);return p
names=['actual-default','actual-full','fault-doctor','fault-drive','fault-verifier','fault-cross-binding'];before={n:inv(P/n)for n in names}
run('old-default',[old,'--input',P/'actual-default','--output',S/'old-default-packet'],0)
run('new-default',[new,'--input',P/'actual-default','--output',S/'new-default-packet'],0)
assert (S/'old-default-packet/packet.json').read_bytes()==(S/'new-default-packet/packet.json').read_bytes()
assert (S/'old-default-packet/manifest.json').read_bytes()==(S/'new-default-packet/manifest.json').read_bytes()
run('new-full',[new,'--input',P/'actual-full','--output',S/'full-packet','--scope','full'],0)
for label in ['new-default-packet','full-packet']:run('check-'+label,[new,'--check',S/label],0)
for name in names[2:]:
 expected=1 if name=='fault-drive' else 0
 run('project-'+name,[new,'--input',P/name,'--output',S/(name+'-packet'),'--scope','full'],expected)
 if expected==0:run('check-'+name,[new,'--check',S/(name+'-packet')],0)
 else:assert not (S/(name+'-packet')).exists()
for label,inp,flags in [('default-refuses-full',P/'actual-full',[]),('full-refuses-default',P/'actual-default',['--scope','full'])]:
 run(label,[new,'--input',inp,'--output',S/(label+'-packet'),*flags],1);assert not (S/(label+'-packet')).exists()
after={n:inv(P/n)for n in names};assert before==after
result={'source':source,'original_inputs':str(P),'original_input_inventory':before,'original_inputs_unchanged':True,'default_packet_and_manifest_byte_equal':True,'commands':rows,'failure_note':'fault-drive seam reported product exit with no case evidence; preserved original history is intentionally unverifiable and correctly refused (not_created_claim), not relabeled successful projection'}
(S/'actual-results.json').write_text(json.dumps(result,indent=2)+'\n');print('COMPLETE')
