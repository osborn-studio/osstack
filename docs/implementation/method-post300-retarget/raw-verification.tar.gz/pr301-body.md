Adds a coordinator guide for required coverage, exclusive resources, stale or missing worker results, unknown process liveness and composed-candidate verification. Improves existing evidence and PR-readiness reports so concise summaries retain failures and bind corrective checks to the resulting candidate. The four Codex/Claude entries still expose thirteen named methods; this is supporting guidance, not a scheduler or new runtime permission.

#300 merged into main `e26f6d2c`. This PR now targets main; candidate `50ed89fb` merges that main and has exactly the same file tree as the prior `4b7b0585` candidate. The parent's pagination repair is already in main, not part of this PR's remaining changes. Remains Draft until new-head CI completes.

Validation:
- Final methods `898033af`:92 exporter tests; independent exports84files/302local links per host, four entries reach all thirteen methods plus the guide, and a missing-guide negative rejects before output creation.
- Actual Claude CLI Sonnet5.5: initial attribution finding corrected, limited closure PASS. Original opinions retained.
- Full package suite on `c174598e`:7144passed/5skipped/0failed across22packages, with four explicitly hashed fresh generated knowledge/dist files unchanged during the run. Final241document tests and1hygiene test passed.
- Earlier local full failed after the coordinator restored stale generated files; original88failures, incremental-rebuild failures, force-build correction,45focused passes and finalfull are all preserved. No runtime source, timeout or assertion was weakened to address this validation error.

No new host experiment ran. Prior CodexLIMITED and ClaudeFAILED results remain unchanged; exporter success does not establish improved model behavior. Human approval/merge and formal J01/J11 boundaries remain unchanged. Evidence: `docs/implementation/method-parallel-reporting`.
Main retarget validation on `50ed89fb`: 92/92 local exporter tests, 241 document tests, two fresh host exports independently verified (84 payload files plus manifest, 302 local links each), actual Claude CLI Sonnet5.5 static PASS with two diff-external assumptions separately checked. CI run40815575324 is in progress; prior CI results are not relabeled as this run.
