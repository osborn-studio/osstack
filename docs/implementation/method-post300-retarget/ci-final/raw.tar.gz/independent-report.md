# PR301 final CI independent log check

Run40815575324 completed successfully for head50ed89fbe1fa9e7ebba520214390f97725164728 and saved PR base main/e26f6d2ca81628b565d2db0fd047fcb041fa8a45. Five applicable jobs succeeded; paid DeepSeek was skipped. Saved PR state is MERGEABLE / REVIEW_REQUIRED, no review threads, still Draft before owner Ready action.

Independent recount of exactly22 unique check/Test package summaries:7142 passed,7 skipped,0failed. Exporter92total=91passed+1skipped (global Codex home absent). Engineering27, skills25, journey25 and projection49 contract cases passed. Actual logged smoke receipts retain applied/observed_turn, expected missing-ref product exit1 versus driver exit0, owned fixture removal and descendant termination not_attested. Projection/check log same packet hash and formal_gate_pass:false.

Only supplied snapshots/logs were verified. Artifacts were not downloaded or independently rehashed. No claim of paid provider/native model qualification, human approval or merge. No tests, models, reruns or PR/ledger changes were performed. Detailed line pointers, per-package counts and input hashes are in JSON.
