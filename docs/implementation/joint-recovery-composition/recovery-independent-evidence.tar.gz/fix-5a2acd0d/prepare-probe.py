from pathlib import Path
import json,subprocess,shutil,hashlib
r=Path(__file__).resolve().parent
w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition')
sha='5a2acd0d6ddd27e8c572d85e2f7cc99d2e895520'
def raw(p):return subprocess.check_output(['/usr/bin/git','show',sha+':'+p],cwd=w)
p='packages/core/src/state/operator-recovery-spec.test.ts'
s=raw(p).decode();(r/'original-candidate.test.txt').write_text(s)
for a,b in [('../scratch.js','packages/core/src/scratch.ts'),('./migrations.js','packages/core/src/state/migrations.ts'),('./db.js','packages/core/src/state/db.ts')]:s=s.replace("'"+a+"'",repr(str(w/b)))
s=s.replace('import.meta.url',json.dumps((w/p).as_uri()))
needle="new URL('../../../../docs/design/2026-10-27-joint-engineering/execution-gates.json',"+json.dumps((w/p).as_uri())+")"
assert needle in s
s=s.replace(needle,"process.env.INDEPENDENT_GRAPH_PATH!")
(r/'candidate.test.ts').write_text(s)
g=json.loads(raw('docs/design/2026-10-27-joint-engineering/execution-gates.json'))
(r/'baseline-graph.json').write_text(json.dumps(g,indent=2)+'\n')
for name,node,edge in [('missing-schema-producer','J17.schema_spec','J11.scoped'),('missing-recovery-schema','J17.recovery','J17.schema_spec'),('missing-recovery-bootstrap','J17.recovery','J12.scoped')]:
 d=json.loads(json.dumps(g));next(x for x in d['gates'] if x['id']==node)['requires'].remove(edge);(r/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
config="import {defineConfig} from 'vitest/config';export default defineConfig("+json.dumps({'resolve':{'alias':{'better-sqlite3':str(w/'packages/core/node_modules/better-sqlite3'),'@osstack/protocol/joint':str(w/'packages/protocol/src/joint.ts')}},'test':{'include':['candidate.test.ts','independent.test.ts'],'maxWorkers':1,'setupFiles':[str(w/'scripts/vitest-setup-scratch.ts')]},'server':{'fs':{'allow':[str(w),str(w.resolve()),str(r)]}}})+");\n"
(r/'vitest.config.mts').write_text(config)
(r/'node_modules').symlink_to(w/'node_modules',target_is_directory=True)
shutil.copyfile(r/'review-oracle-freeze.json',r/'oracle-freeze.json')
shutil.copyfile('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-nextwave-20261028/independent/run-recorded.py',r/'run-recorded.py')
(r/'probe-inputs.json').write_text(json.dumps({'candidate_sha':sha,'original_test_sha256':hashlib.sha256(raw(p)).hexdigest(),'changes':'absolute source references and external graph input only; no assertion changes','mutants':'delete one producer edge in exact committed graph; runtime source untouched'},indent=2)+'\n')
