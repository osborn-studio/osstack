# Recovery composition independent review

Candidate: `da9a1512b4336a9fb4e7dabd680dfe94d46f9a27`; baseline main `3192b424174e5eb977d640cc0418e67c6b1461d1`.

## Confirmed finding

The committed topology test misses removal of `J12.scoped` from `J17.recovery.requires`. A scratch copy of the exact committed test redirected only the graph input and absolute source/fixture locations. All four original topology tests still passed against that deleted-edge input. The candidate presently has the correct edge; this is a regression-oracle gap, not a product dependency defect. Deleting the other two schema producer edges caused the same test group to fail. The owner/root were notified with the raw inputs and logs. A direct prerequisite assertion is appropriate because ordering alone is not evidence that the bootstrap producer is required.

## Actual observations

- The exact candidate JA20/JA47 test group ran in scratch: **178 passed, 14 unrelated historical tests skipped**. Its fixture calls the actual current `runMigrations` implementation on real `better-sqlite3 :memory:` databases; it does not reconstruct the home catalog from the manifest.
- An independently written check ran current `runMigrations`, compared the full SQLite catalog with the frozen manifest, then added an index while schema version remained 47. Catalog inequality detected this mutation. This rejects a version-number-only interpretation.
- **64 independent tests passed**: the older prospectively recorded receipt/proof/subject required-field inputs, now passed through the actual strict raw `decodeJointContractAs` entry; real proof-join counterexamples; actual migration catalog mutation; explicit missing-bootstrap prerequisite oracle. These reuse previously preserved input bytes, not expected outputs obtained from the candidate.
- A real source mutant was created only in scratch: `RecoveryReceiptShape.operator_ref` changed from required to optional, with all other protocol source bytes copied from the candidate. The unmodified candidate omission assertions rejected the mutant (three relevant omission tests fail because invalid receipts are accepted). This shows real decoder sensitivity, not merely a generated test-name count. It is one sampled field guard, not proof of every guard's mutation coverage.
- The home subject joins and pinned tuple comparisons are test-local illustrative helpers. They are correctly labelled as such, do not authenticate maintenance authority, and do not install a runtime recovery entry. Broker tuple rejection reaches real SQLite constraints. Separate home and broker databases do not prove production atomicity.

## Method and limits

`review-oracle-freeze.json` was recorded before this review read/evaluated B's tests but after the candidate already existed. `original-pre-candidate-oracle.json` preserves the earlier prospective material. Neither authenticates independent principals or issues a formal oracle/gate qualification. No default DB, live provider, OSStack board, product source, worker worktree or central ledger was modified. Tests used Node 22, explicit scratch home, unset socket, and existing read-only worker dependencies. No repository-wide suite ran.

All command argv, exit codes, raw output and hashes are in `*.command.json`, `*.stdout`, `*.stderr`. Two reviewer harness mistakes are retained: attempt 1 catalog mutation referred to nonexistent `sessions` (fixed to actual `attention_actions(scope_id)`); the first optional-field mutant test filter matched zero tests (192 skipped) and is **not** counted as evidence. The subsequent broader filter actually executed the receipt matrix and killed the mutant.

Pending: recheck the owner's exact fix SHA for the topology assertion. Formal J11/J01/O03/O06 status remains unchanged.
