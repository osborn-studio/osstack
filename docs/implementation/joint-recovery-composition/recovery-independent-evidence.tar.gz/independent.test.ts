import {it,expect} from 'vitest';
import {readFileSync} from 'node:fs';
import {RecoveryReceipt,verifyRecoveryProofEnvelopes} from '/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition/packages/protocol/src/joint-recovery.ts';
const read=(p:string)=>JSON.parse(readFileSync(new URL(p,import.meta.url),'utf8'));
const stop=read('./broker-input-5ac176cf/valid-stop-receipt.json');
const preserve=read('./broker-input-5ac176cf/valid-preserve-receipt.json');
const effect=read('./ja47-effect-positive.json');
const required=read('./ja47-required-fields.json');
const clone=(x:any)=>JSON.parse(JSON.stringify(x));
const envelope=()=>({...Object.fromEntries(['subject','owner_generation','binding_generation','support_profile_digest','prior_phase','schema_spec_digest','recovery_build_digest','authorization_ref','observed_at_ms'].map(k=>[k,clone(stop[k])])),kind:'recovery_proof',schema_version:1,proof:clone(stop.proofs[0]),record_ref:stop.proofs[0].record_ref});
it('positive controls keep nullable identities and empty preserve proofs distinct from omission',()=>{for(const r of [stop,preserve,effect]) expect(decodeJointContractAs('recovery_receipt',canonicalJointJson(r))).toEqual(r);expect(verifyRecoveryProofEnvelopes(stop,[envelope()])).toEqual(stop);expect(verifyRecoveryProofEnvelopes(preserve,[])).toEqual(preserve);});
for(const field of required.receipt)it('missing receipt '+field+' rejects',()=>{const r=clone(stop);delete r[field];expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(r))).toThrow();});
for(const field of Object.keys(stop.subject))it('missing subject '+field+' rejects',()=>{const r=clone(stop);delete r.subject[field];expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(r))).toThrow();});
for(const field of required.proof)it('missing proof '+field+' rejects',()=>{const r=clone(stop);delete r.proofs[0][field];expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(r))).toThrow();});
for(const field of required.broker_identity)it('missing broker proof identity '+field+' rejects',()=>{const r=clone(stop);delete r.proofs[0].broker_identity[field];expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(r))).toThrow();});
for(const field of required.envelope)it('missing envelope '+field+' rejects',()=>{const e:any=envelope();delete e[field];expect(()=>verifyRecoveryProofEnvelopes(stop,[e])).toThrow();});
for(const field of ['owner_generation','binding_generation','support_profile_digest','prior_phase','schema_spec_digest','recovery_build_digest'])it('mismatched envelope '+field+' rejects',()=>{const e:any=envelope();e[field]=field==='owner_generation'?3:field==='binding_generation'?1:field==='prior_phase'?'dispatch_committed':'e'.repeat(64);expect(()=>verifyRecoveryProofEnvelopes(stop,[e])).toThrow();});
it('effect omission and fabricated legacy effect identity reject',()=>{const r=clone(effect);delete r.effect_id;expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(r))).toThrow();const b=clone(stop);b.effect_id='invented';expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(b))).toThrow();});
it('stop cannot resolve on receipt file existence or absent proof',()=>{const r=clone(stop);r.proofs=[];r.proof_refs=[];expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(r))).toThrow();expect(()=>verifyRecoveryProofEnvelopes(stop,[])).toThrow();});

import {decodeJointContractAs,canonicalJointJson} from '@osstack/protocol/joint';

import Database from 'better-sqlite3';
import {runMigrations} from '/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition/packages/core/src/state/db.ts';
it('actual latest migrations catalog matches frozen manifest and an added index is observable',()=>{
 const manifest=JSON.parse(readFileSync('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition/packages/core/fixtures/operator-recovery/manifest.json','utf8'));
 const db=new Database(':memory:');try{runMigrations(db);
 const catalog=()=>db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE substr(name,1,7)<>'sqlite_' ORDER BY type,name").all();
 expect(catalog()).toEqual(manifest.source_schema);
 db.exec('CREATE INDEX independent_catalog_probe ON attention_actions(scope_id)');
 expect(catalog()).not.toEqual(manifest.source_schema);
 expect(db.pragma('user_version',{simple:true})).toBe(47);
 }finally{db.close();}
});
it('an independently enumerated producer prerequisite rejects the missing bootstrap input',()=>{
 const baseline=read('./baseline-graph.json');const mutated=read('./missing-recovery-bootstrap.json');
 const mustHave=(d:any)=>['J17.schema_spec','J12.scoped'].every(dep=>d.gates.find((g:any)=>g.id==='J17.recovery').requires.includes(dep));
 expect(mustHave(baseline)).toBe(true);expect(mustHave(mutated)).toBe(false);
});
