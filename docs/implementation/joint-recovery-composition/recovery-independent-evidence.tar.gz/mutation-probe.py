from pathlib import Path
import subprocess,json,os
r=Path.cwd();w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');sha='da9a1512b4336a9fb4e7dabd680dfe94d46f9a27'
files=subprocess.check_output(['/usr/bin/git','ls-tree','-r','--name-only',sha,'packages/protocol/src'],cwd=w,text=True).splitlines()
for p in files:
 out=r/'mutant'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(subprocess.check_output(['/usr/bin/git','show',sha+':'+p],cwd=w))
p=r/'mutant/packages/protocol/src/joint-shapes.ts';s=p.read_text();needle='  operator_ref: z.string().min(1).max(256),';assert s.count(needle)==1;p.write_text(s.replace(needle,needle[:-1]+'.optional(),'))
c=(r/'vitest.config.mts').read_text().replace(str(w/'packages/protocol/src/joint.ts'),str(r/'mutant/packages/protocol/src/joint.ts'));(r/'mutant.config.mts').write_text(c)
e=os.environ.copy();e.pop('OSSTACK_SOCKET',None);e.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(r/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack',INDEPENDENT_GRAPH_PATH=str(r/'baseline-graph.json'))
cmd=['/usr/bin/python3','run-recorded.py','--label','optional-operator-mutant','--cwd',str(r),'--code-sha',sha,'--','node',str(w/'node_modules/vitest/vitest.mjs'),'run','--config','mutant.config.mts','candidate.test.ts','-t','receipt omission operator_ref']
x=subprocess.run(cmd,env=e);print('expected nonzero from three survived invalid omissions:',x.returncode)
