from pathlib import Path
import shutil,json
r=Path(__file__).resolve().parent;old=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-nextwave-20261028/independent');w=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition')
for p in ['broker-input-5ac176cf/valid-stop-receipt.json','broker-input-5ac176cf/valid-preserve-receipt.json','ja47-effect-positive.json','ja47-required-fields.json']:
 (r/p).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/p,r/p)
s=(old/'ja47.test.ts').read_text().replace('joint-broker-spec','joint-recovery-composition')
s=s.replace("import {RecoveryReceipt,verifyRecoveryProofEnvelopes}","import {RecoveryReceipt,verifyRecoveryProofEnvelopes}")
s+="\nimport {decodeJointContractAs,canonicalJointJson} from '@osstack/protocol/joint';\n"
s=s.replace('RecoveryReceipt.parse(r)',"decodeJointContractAs('recovery_receipt',canonicalJointJson(r))").replace('RecoveryReceipt.parse(b)',"decodeJointContractAs('recovery_receipt',canonicalJointJson(b))")
s+="""
import Database from 'better-sqlite3';
import {runMigrations} from 'WORKTREE/packages/core/src/state/db.ts';
it('actual latest migrations catalog matches frozen manifest and an added index is observable',()=>{
 const manifest=JSON.parse(readFileSync('WORKTREE/packages/core/fixtures/operator-recovery/manifest.json','utf8'));
 const db=new Database(':memory:');try{runMigrations(db);
 const catalog=()=>db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE substr(name,1,7)<>'sqlite_' ORDER BY type,name").all();
 expect(catalog()).toEqual(manifest.source_schema);
 db.exec('CREATE INDEX independent_catalog_probe ON sessions(status)');
 expect(catalog()).not.toEqual(manifest.source_schema);
 expect(db.pragma('user_version',{simple:true})).toBe(47);
 }finally{db.close();}
});
it('an independently enumerated producer prerequisite rejects the missing bootstrap input',()=>{
 const baseline=read('./baseline-graph.json');const mutated=read('./missing-recovery-bootstrap.json');
 const mustHave=(d:any)=>['J17.schema_spec','J12.scoped'].every(dep=>d.gates.find((g:any)=>g.id==='J17.recovery').requires.includes(dep));
 expect(mustHave(baseline)).toBe(true);expect(mustHave(mutated)).toBe(false);
});
""".replace('WORKTREE',str(w))
(r/'independent.test.ts').write_text(s)
