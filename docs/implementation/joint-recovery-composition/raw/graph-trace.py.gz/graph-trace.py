from pathlib import Path
import json,copy,hashlib,subprocess
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/recovery-composition')
p=root/'docs/design/2026-10-27-joint-engineering/execution-gates.json';data=json.loads(p.read_text());g={x['id']:list(x['requires']) for x in data['gates']};g.update({'artifact:joint-recovery-contracts':[],'artifact:home47-catalog':[],'fixture:home-spec':['artifact:joint-recovery-contracts','artifact:home47-catalog'],'fixture:broker-spec':['artifact:joint-recovery-contracts']});g['J11.scoped']+=['fixture:home-spec','fixture:broker-spec']
def order(graph):
 done=set();active=[];result=[]
 def visit(n):
  if n in active:raise ValueError('RECOVERY_PRODUCER_CYCLE: '+' -> '.join(active[active.index(n):]+[n]))
  if n in done:return
  if n not in graph:raise ValueError('MISSING_PRODUCER: '+n)
  active.append(n)
  for dep in graph[n]:visit(dep)
  active.pop();done.add(n);result.append(n)
 for n in graph:visit(n)
 return result
result={'code_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'kind':'author_generated_material_graph_trace_not_formal_gate_evidence','gates':g,'topological_order':order(g),'negative_traces':[]}
for a,b in [('fixture:broker-spec','J17.schema_spec'),('J11.scoped','J17.schema_spec'),('J12.scoped','J14.scoped'),('J12.scoped','J17.scoped')]:
 mutant=copy.deepcopy(g);mutant[a].append(b)
 try:order(mutant);raise AssertionError('cycle not rejected')
 except ValueError as e:result['negative_traces'].append({'injected_edge':[a,b],'error':str(e)})
(out/'producer-graph-trace.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'nodes':len(g),'negative_traces':result['negative_traces']}))
