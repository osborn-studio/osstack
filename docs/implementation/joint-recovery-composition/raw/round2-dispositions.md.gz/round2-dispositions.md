# Round 2 P2 closure on 6ea2cebc

1. Added legacy schema/home/broker/compatibility and J12.full_recovery roots to ancestor boundary; docs name exact activation set. Three legacy acyclic injected-edge negatives added.
2. Manifest requires compare sorted copies (order-independent). Missing J17.scoped→J12 negative and cloned controller-required flag both exercise precise branch errors.
3. Each live-row perturbation now verifies unperturbed home facts first; added genuine FK-valid action_scope perturbation. Receipt-mutant errors are exact HOME or SYNTHETIC context errors. Docs explicitly exclude wait-item equality/action or mission state/completion absence; raw SQL bypass is the host-obligation control.
4. Docs explicitly say test-local pin comparator, not J12 admission or authenticated build. Synthetic pins remain labeled.
5. Nested-envelope/converse exhaustive matrix and schema/Zod drift are clearly separate future coverage. Existing matrix wording stays top-level. zod ^3.25.76 is declared core dependency; tracked-baseline-recheck records this fact.
6. Actual git ls-tree base graph blob b432c83265bd790ecbe0c514c6facc3b28d9d72f, working graph exact bytes; fresh ls-remote main at18:08:00.998232Z remains3192. Future merge refresh still required.
7. Docs explicitly call side-by-side different homes, not a shared-home join.

No runtime, SQL, fixture, protocol or central gate changes. One authoring failure during finite refinements expected an exact full trace prefix; expanded roots legitimately prepended J12.full_recovery. Fixed assertion requires category plus exact injected edge, retains full raw failed run. Final targeted315+protocol4+hygiene1/build/typecheck/lint/changeset passed.

Full suite started5a2 but tests/docs were revised after core had completed1295. This full run is explicitly a mixed-working-tree observation, not fixed-SHA or final6ea proof. Final targeted records are exact6ea. Remaining whole-repo execution is not claimed by this audit or its inputs.
