from pathlib import Path
import os,json,subprocess,datetime,hashlib,re
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/recovery-composition')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_HOME']=str(out/'home');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack';env.pop('OSSTACK_SOCKET',None)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();m={'base_sha':'3192b424174e5eb977d640cc0418e67c6b1461d1','code_sha':sha,'commands':[],'status':'running'}
for name,cmd in [('full-build',['pnpm','build']),('knowledge-smoke',['node','--input-type=module','-e',"const m=await import('./packages/knowledge/dist/index.js');for(const k of ['executionContextDigest','assembleExecutionContext']){console.log(k,typeof m[k]);if(typeof m[k]!=='function')process.exitCode=1}" ]),('test-full',['pnpm','test'])]:
 print(name,'started',flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 m['commands'].append({'name':name,'command':cmd,'code_sha':sha,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':name+'.log','sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()});m['status']='failed' if r.returncode else 'running';(out/'full-verification.json').write_text(json.dumps(m,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
lines=re.findall(r'^packages/[^ ]+ test:\s+Tests\s+(.+)$',(out/'test-full.log').read_text(),re.M);m['packages']=len(lines);m['test_counts']={k:sum(int(n) for line in lines for n,kind in re.findall(r'(\d+) (passed|skipped|failed)',line) if kind==k) for k in ['passed','skipped','failed']};m['status']='passed';(out/'full-verification.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m['test_counts']),flush=True)
