No P0/P1 findings and no bounded P2 needed. The 5a2→6ea diff closes the supplied P2 dispositions, and I found no new regression. This is a static read; I ran nothing and relied on the supplied validation record for the pass counts.

**Disposition closure**

1. **Recovery-boundary roots: closed.**
   - The roots now include `J12.full_recovery` and the legacy `C03` and `X03` schema-spec producers.
   - They also include `I04.recovery_home`, `I04.recovery_broker` and `I04.compat_recovery`, and the doc states the activation set `{J13.scoped, J14.scoped, J17.scoped}`.
   - Each injected `X -> J14.scoped` edge is acyclic, because `J14.scoped`'s ancestors (`J13`, `J02`, `J23`, `J01.scoped` and so on) never reach those nodes. Each negative asserts `producerOrder` does not throw, so it cannot be a cycle rejection.
   - The ancestor walk runs before the required-edge check, so a missing edge cannot cause the rejection. For `J17.recovery` the trace now begins at `J12.full_recovery` (an earlier root), so asserting the category plus the exact injected edge as substrings is the correct fix.
   - On the real graph, none of the added roots reach an activation gate, which matches the passing positive path.
2. **Manifest binding: closed.**
   - Deleting `J12.scoped` from `J17.scoped` reaches `BROKER_MANIFEST_DEPENDENCY_MISMATCH: J17.scoped`. Those edges are in neither `requiredProducerEdges` nor the earlier mapping entries, so no other check masks the rejection.
   - The cloned controller flag, with an unmodified graph, reaches `BROKER_RECOVERY_REQUIRES_CONTROLLER`.
   - The reversed-list positive test kills the old order-sensitive comparison, because `J17.recovery`'s reversed list would mismatch without sorting.
3. **Home perturbation hygiene: closed.**
   - The unperturbed control uses the same receipt as the perturbed call.
   - `action_scope` is now killable by the `row.scope_id` predicate alone, and the test asserts `foreign_key_check` is empty.
   - The receipt-mutant assertions are exact: `SYNTHETIC_MAINTENANCE_CONTEXT_MISMATCH` for owner and tenant, `HOME_LIVE_SUBJECT_MISMATCH` otherwise. That ordering holds because the live-subject check runs before the maintenance pin.
   - The doc states the helper's unchecked predicates and says the nonexistent-home bypass control is the real evidence.
4. **Pin comparator wording: closed.** The doc now says "test-local pin comparator … not J12 admission or build authentication".
5. **Conditional fields and matrix source: closed as an explicit deferral.** The doc keeps the "top-level" wording and lists nested-envelope omissions, converse unexpected identities and schema/Zod drift as separate coverage. I accept this as a boundary statement rather than a gap.
6. **Baseline evidence: closed.**
   - The `git ls-tree` blob `b432c832…` at the base is recorded, with `graph_bytes_match_base: true`.
   - The `ls-remote` observation is timestamped after the targeted run, and the future merge refresh stays explicit.
   - `zod ^3.25.76` is recorded as declared. The record does not say which package declares it, so the "core dependency" attribution rests on the disposition text.
7. **Doc wording: closed.** The doc names `fixture-home` and `home-a` and says "side-by-side separation, not a shared-home join".

**Factual boundaries**

- The diff is test and doc only, matching "no runtime, SQL, fixture, protocol or central gate changes".
- The targeted record (315 + 4 + 1) is bound to `6ea2cebc`.
- The full run is correctly labelled a mixed-working-tree observation, not final-SHA proof.
- The doc still disclaims authority, CAS, effect-store joins and J12 admission, and still marks O03, O06 and `J01.contracts` as open.
- One trivial imprecision: "unordered sets" in the doc is really a sorted multiset comparison. It has no effect on the test outcomes and needs no change.

VERDICT: PASS
END_AUDIT