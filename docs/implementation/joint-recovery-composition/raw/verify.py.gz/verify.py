from pathlib import Path
import os,json,subprocess,hashlib,datetime,re
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/recovery-composition')
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:'+env['PATH'];env['OSSTACK_HOME']=str(out/'home');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack';env.pop('OSSTACK_SOCKET',None)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();record={'base_sha':'3192b424174e5eb977d640cc0418e67c6b1461d1','code_sha':sha,'status':'running','commands':[],'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'environment':{'OSSTACK_HOME':env['OSSTACK_HOME'],'OSSTACK_SCRATCH_ROOT':env['OSSTACK_SCRATCH_ROOT'],'OSSTACK_SOCKET':'unset'},'scope':'targeted only; full repository not run by this worker'}
cmds=[('build',['pnpm','--filter','@osstack/core...','build']),('composition',['pnpm','--filter','@osstack/core','exec','vitest','run','src/state/operator-recovery-spec.test.ts','src/state/broker-recovery-spec.test.ts']),('protocol',['pnpm','--filter','@osstack/protocol','exec','vitest','run','src/joint-schemas.test.ts','src/joint-reference.test.ts']),('typecheck',['pnpm','--filter','@osstack/core','exec','tsc','--noEmit']),('lint',['pnpm','exec','biome','check','packages/core/src/state/operator-recovery-spec.test.ts']),('changeset',['node','scripts/check-changeset-coverage.mjs','--base',record['base_sha']]),('hygiene',['pnpm','--filter','@osstack/governance','exec','vitest','run','src/knowledge-hygiene/osstack-config.test.ts'])]
for name,cmd in cmds:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(name,'started',flush=True)
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 record['commands'].append({'name':name,'command':cmd,'code_sha':sha,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':name+'.log','log_sha256':hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest()});record['status']='failed' if r.returncode else 'running';(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
record['test_counts']={}
for name in ['composition','protocol','hygiene']:
 line=re.findall(r'^\s*Tests\s+(.+)$',(out/(name+'.log')).read_text(),re.M)[-1];record['test_counts'][name]={k:int(n) for n,k in re.findall(r'(\d+) (passed|skipped|failed)',line)}
record['status']='passed';(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['test_counts']),flush=True)
