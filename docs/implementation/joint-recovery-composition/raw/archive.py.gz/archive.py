from pathlib import Path
import subprocess,json,hashlib,gzip,shutil,re,datetime
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/recovery-composition');archive=root/'docs/implementation/joint-recovery-composition'
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();base='3192b424174e5eb977d640cc0418e67c6b1461d1';digest=lambda b:hashlib.sha256(b).hexdigest()
full=json.loads((out/'full-verification.json').read_text());target=json.loads((out/'verification.json').read_text());audit=json.loads((out/'round3-manifest.json').read_text());raw=(out/'round3-raw.md').read_text();verdicts=re.findall(r'^VERDICT: (PASS|REVISE)\s*$',raw,re.M)
assert full['status']=='passed' and full['classification']=='mixed-working-tree observation' and full['packages']==22
assert target['status']=='passed' and target['code_sha']==sha
assert audit['exit_code']==0 and audit['is_error'] is False and audit['code_sha']==sha and verdicts[-1]=='PASS'
assert 'claude-sonnet-5-5' in audit['modelUsage']
for p,h in audit['reviewed_files'].items():assert digest((root/p).read_bytes())==h,p
archive.mkdir(parents=True,exist_ok=True)
# Lossless raw payloads: no home DB, credentials, socket or symlink is archived.
selected=[p for p in out.iterdir() if p.is_file() and p.name not in ['pr-body.md']]
for folder in ['historical-40df','historical-da9a','historical-5a2a']:
 selected.extend(p for p in (out/folder).rglob('*') if p.is_file() and not p.is_symlink())
raw_index=[]
for p in sorted(selected):
 rel=p.relative_to(out);b=p.read_bytes();dest=archive/'raw'/str(rel)
 dest=dest.with_name(dest.name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(b,mtime=0);dest.write_bytes(packed)
 raw_index.append({'source_path':str(rel),'path':str(dest.relative_to(archive)),'bytes':len(b),'sha256':digest(b),'compressed_sha256':digest(packed)})
for name,args in [('candidate.diff',['git','diff',base,sha]),('round1-fix.diff',['git','diff','da9a1512b4336a9fb4e7dabd680dfe94d46f9a27',sha])]:
 b=subprocess.check_output(args,cwd=root);dest=archive/'raw'/f'{name}.gz';dest.write_bytes(gzip.compress(b,mtime=0));raw_index.append({'source_path':name,'path':str(dest.relative_to(archive)),'bytes':len(b),'sha256':digest(b),'compressed_sha256':digest(dest.read_bytes())})
independent=out.parent/'recovery-independent-evidence.tar.gz';assert digest(independent.read_bytes())=='ae4ecc5c6a05cb86859e8d4092985d85f0270718600c6d5e4036abbae91257fa';shutil.copy2(independent,archive/independent.name)
supplement=out.parent/'recovery-independent-6ea-supplement.tar.gz';assert digest(supplement.read_bytes())=='6790871b214897dab51c120df520e2b7a911cc9fa8844f2131a8b59988a4b04d';shutil.copy2(supplement,archive/supplement.name)
(archive/'raw-index.json').write_text(json.dumps(raw_index,indent=2)+'\n')
(archive/'verification.json').write_text(json.dumps({'base_sha':base,'code_sha':sha,'targeted':target,'final_core':json.loads((out/'final-core-verification.json').read_text()),'full':full,'scope':'test/spec only; no formal gate assertion; runtime and fixtures unchanged'},indent=2)+'\n')
rounds=[]
for n in [1,2,3]:
 m=json.loads((out/f'round{n}-manifest.json').read_text());r=(out/f'round{n}-raw.md').read_bytes();v=re.findall(r'^VERDICT: (PASS|REVISE)\s*$',r.decode(),re.M)
 rounds.append({'round':n,'code_sha':m['code_sha'],'base_sha':m['base_sha'],'exit_code':m['exit_code'],'is_error':m['is_error'],'model_usage':m['modelUsage'],'verdict':v[-1],**{kind+'_sha256':digest((out/f'round{n}-{suffix}').read_bytes()) for kind,suffix in [('raw_report','raw.md'),('input','input.txt'),('response','response.json')]}})
binding={'base_sha':base,'reviewed_base':base,'code_sha':sha,'model':'claude-sonnet-5-5','verdict':'PASS','rounds':rounds,'reviewed_files':audit['reviewed_files'],'validation':{'passed':315,'skipped':0,'failed':0},'packages':2,'full_observation':full,'limitations':['model review is not execution evidence','independent agent authorship is not authenticated principal qualification','J01.contracts/O03/O06 and runtime gates remain open']}
(archive/'audit-code-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
passed=full['test_counts']['passed'];skipped=full['test_counts']['skipped']
readme=f'''# Home and broker recovery composition investigation

Base: `{base}`. Frozen test/spec candidate: `{sha}`. This is investigation material for JA20/JA47, not formal J01/J11/J17 acceptance or a runtime recovery implementation.

## What changed

The existing home47 catalog and held Attention action are instantiated alongside the separate broker orphan fixture. Required producer edges cover home bootstrap, broker qualification and legacy recovery. Every required edge has a deletion counterexample. Broker manifest dependencies are compared with the real graph; cyclic and acyclic recovery-to-activation dependencies are rejected. Raw contract/catalog artifacts are distinct from formal gate completion.

Receipt tests remove required fields through the actual decoder, distinguish absent values from allowed nulls, and exercise FK-valid live-row association failures through the same illustrative validation-and-write path. SQL and fixtures are unchanged. A raw home SQL bypass control demonstrates why live association remains a host obligation.

## Validation and audit

- Exact candidate targeted: 224 operator + 91 broker tests = 315 passed; 4 protocol tests and 1 document-hygiene test passed. Protocol/core build, core typecheck, scoped Biome, changeset coverage and inventory check passed. Final core full package: 1,301 passed, 0 skipped, 0 failed.
- Full build and knowledge export smoke passed at the run start; the full `pnpm test` mixed-working-tree observation completed: 22 packages, {passed} passed, {skipped} skipped, 0 failed. Raw commands, exits and SHA bindings are in [verification.json](verification.json).
- Actual tool-less Claude CLI `claude-sonnet-5-5`: round 1 REVISE, round 2 PASS, then a small P2 closure round 3 PASS on the final candidate. Full input, raw response and report are losslessly archived; [audit binding](audit-code-binding.json) binds all three review rounds. The reviewer did not execute the tests.
- Independent evidence: original 64 raw/catalog observations on the first candidate are inherited only by verified unchanged fixture bytes. New candidate composition was actually re-executed: 204 passed and 14 pre-existing tests deliberately skipped on 5a2a; final6ea independently re-executed 12 selected tests (212 deliberately skipped) plus 1 manifest positive control. Three legacy acyclic mutations and both graph/manifest missing-edge directions were rejected. The [45-payload final supplement](recovery-independent-6ea-supplement.tar.gz) is separate from the original package; its complete manifest was verified. The previously escaping J17.recovery → J12.scoped deletion now fails with the exact missing-edge diagnostic. All 127 independent payload hashes were verified before copying the [complete independent archive](recovery-independent-evidence.tar.gz), including initial false-negative evidence, later fix and harness errors.

## Confirmed issues and disposition

Round 1 and independent review found that traversal order could conceal a missing prerequisite. Explicit edges and deletion tests now close that gap. The review also identified incomplete home association coverage and potentially vacuous omission assertions; these are replaced by real row perturbations, shared illustrative persistence, preconstructed mutants and Zod-specific failures. See the complete [raw index](raw-index.json), including the original audit and every historical run. The first authoring failure used an incorrect `resolution` SQL column; it was corrected to the actual `disposition`. It is retained as test-author error, not a product defect. Earlier green snapshots are historical and do not replace current evidence. During the full run, core1295 had finished before the final test/doc refinements were written; exact write-time bounds and the diff are retained in full-run-working-tree-caveat.json. The full run is a mixed-working-tree observation, not a fixed5a or final6ea full-suite proof. Final core/targeted/hygiene checks independently bind the final candidate. One later authoring assertion expected a cycle trace prefix that expanded roots legitimately changed; it now checks category and the exact injected edge, with the failed run preserved.

## Remaining limits and next step

The Git comparison from the historical home fixture base `69859eecfcc84af9d6eff755ed41243ca5f51f95` to reviewed main changes only test files under `packages/core/src/state`; migration implementation and source catalog remain identical. O03 is still open: home48 and broker0→1 are unreserved candidates. O06 has a scoped author baseline check only; future main must be checked again. J01.contracts has not formally passed.

Home association examples are bounded to the committed abandoned-unknown Attention fixture. Owner7, tenant, grant, candidate/build and proof inputs are synthetic; they do not establish authority. Effect coverage is structural only. No process-crash, operator authentication, proof provenance, live CAS, cross-database atomicity or completion/release implementation is claimed. Formal oracle custody, exact qualified recovery builds and remaining gate prerequisites are still required. No central acceptance ledger or runtime registration was changed.

## Reproduce and inspect evidence

Use Node22 with explicit scratch `OSSTACK_HOME` and unset outer `OSSTACK_SOCKET`. Build first; retain generated knowledge dist until tests finish. Targeted command: `pnpm --filter @osstack/core exec vitest run src/state/operator-recovery-spec.test.ts src/state/broker-recovery-spec.test.ts`. Full commands/environment are preserved in raw verification records. Each raw payload is gzip-compressed without rewriting its bytes; `raw-index.json` records uncompressed and compressed SHA256. `manifest.json` covers every archive file except this README and the manifest itself. Historical timestamps and paths are provenance, not instructions to access a default DB.
'''
(archive/'README.md').write_text(readme)
files=[]
for p in sorted(archive.rglob('*')):
 if p.is_file() and p.name not in ['README.md','manifest.json']:files.append({'path':str(p.relative_to(archive)),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())})
(archive/'manifest.json').write_text(json.dumps({'base_sha':base,'code_sha':sha,'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files},indent=2)+'\n')
(out/'pr-body.md').write_text(f'''## Problem and change

The joined recovery design had no executable check that current home47 holds and the offline broker orphan could be investigated together without creating a schema/recovery dependency cycle. This adds real SQLite composition and receipt association tests, explicit producer prerequisites with missing-edge negatives, manifest-to-graph dependency checks, and bounded recovery documentation.

Only specification tests and documentation change. The recovery fixtures, protocol, migration runner and runtime remain unchanged. Home48 and broker0→1 stay unreserved; this PR does not pass J01/J11/J17 or authorize recovery.

## Validation

- Frozen candidate `{sha}` on main `{base}`.
- Final core1,301 and targeted315 home/broker, 4 protocol and 1 hygiene tests pass; core typecheck, scoped lint, changeset coverage and inventory pass.
- Full build/export smoke pass; mixed-working-tree full-suite observation (not fixed-SHA proof): 22 packages, {passed} passed / {skipped} skipped / 0 failed.
- Actual Claude CLI Sonnet5.5 review: REVISE → PASS → small closure PASS after confirmed fixes. Independent review reproduced and then killed the missing-prerequisite mutant; 204 candidate composition tests passed on5a (14 existing tests intentionally skipped); final6ea independently re-executed12 selected cases plus1 manifest positive, retaining both evidence packages.
- Original audit input/response, failure history, independent raw evidence and SHA256 manifest: `docs/implementation/joint-recovery-composition/`.

O03/O06 and formal qualification limits are recorded explicitly. Human approval and merge remain separate.
''')
print(json.dumps({'code_sha':sha,'archive_files':len(files),'archive':str(archive),'full':full['test_counts']}))
