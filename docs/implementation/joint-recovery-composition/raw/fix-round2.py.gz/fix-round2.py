from pathlib import Path
import shutil
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/recovery-composition');hist=out/'historical-5a2a';hist.mkdir(exist_ok=True)
for name in ['verification.json','build.log','composition.log','protocol.log','typecheck.log','lint.log','changeset.log','hygiene.log','producer-graph-trace.json']:
 if (out/name).exists():shutil.copy2(out/name,hist/name)
p=root/'packages/core/src/state/operator-recovery-spec.test.ts';s=p.read_text();s=s.replace('function validateProducerGraph(gates: Gate[]): string[] {', '''type BrokerDependencies = {schema_qualification_requires:string[];recovery_qualification_requires:string[];runtime_storage_requires:string[];recovery_requires_runtime_controller:boolean};
function validateProducerGraph(gates: Gate[], dependencies:BrokerDependencies=composedBrokerSpec.dependencies): string[] {''')
s=s.replace("['J12.bootstrap_preflight','J12.scoped','J17.schema_spec','J17.recovery'])walk(recovery,[])","['J12.bootstrap_preflight','J12.scoped','J12.full_recovery','J17.schema_spec','J17.recovery','legacy:C03.schema_spec','legacy:X03.schema_spec','legacy:I04.recovery_home','legacy:I04.recovery_broker','legacy:I04.compat_recovery'])walk(recovery,[])")
s=s.replace("canonicalJointJson(graph.get(id))!==canonicalJointJson(composedBrokerSpec.dependencies[key])", "canonicalJointJson([...(graph.get(id)??[])].sort())!==canonicalJointJson([...dependencies[key]].sort())").replace("if(composedBrokerSpec.dependencies.recovery_requires_runtime_controller!==false)","if(dependencies.recovery_requires_runtime_controller!==false)")
s=s.replace("  it('rejects an acyclic recovery dependency on start admission', () => {\n    const graph=compositionGraph();graph.find(g=>g.id==='J17.recovery')!.requires.push('J14.scoped');", "  it.each(['J17.recovery','legacy:I04.recovery_home','legacy:I04.recovery_broker','legacy:I04.compat_recovery'])('rejects an acyclic %s dependency on start admission', recovery => {\n    const graph=compositionGraph();graph.find(g=>g.id===recovery)!.requires.push('J14.scoped');").replace(".toThrow('RECOVERY_REQUIRES_ACTIVATION: J17.recovery -> J14.scoped');", ".toThrow('RECOVERY_REQUIRES_ACTIVATION: '+recovery+' -> J14.scoped');")
a=s.index("  it('pins the receipt required-field")
s=s[:a]+'''  it('rejects a missing runtime manifest prerequisite and a recovery-controller requirement', () => {
    const graph=compositionGraph();const storage=graph.find(g=>g.id==='J17.scoped')!;
    storage.requires=storage.requires.filter(id=>id!=='J12.scoped');
    expect(()=>producerOrder(graph)).not.toThrow();expect(()=>validateProducerGraph(graph)).toThrow('BROKER_MANIFEST_DEPENDENCY_MISMATCH: J17.scoped');
    const dependencies=structuredClone(composedBrokerSpec.dependencies) as BrokerDependencies;
    dependencies.recovery_requires_runtime_controller=true;
    expect(()=>validateProducerGraph(compositionGraph(),dependencies)).toThrow('BROKER_RECOVERY_REQUIRES_CONTROLLER');
  });
  it('compares manifest prerequisite sets independently of list ordering', () => {
    const graph=compositionGraph();for(const g of graph)g.requires.reverse();
    expect(()=>validateProducerGraph(graph)).not.toThrow();
  });
''' + s[a:]
s=s.replace("expect(()=>persistHomeExample(home,r)).toThrow(/MISMATCH/);", "expect(()=>persistHomeExample(home,r)).toThrow(bad==='owner'||bad==='tenant'?'SYNTHETIC_MAINTENANCE_CONTEXT_MISMATCH':'HOME_LIVE_SUBJECT_MISMATCH');")
s=s.replace("['session','mission_scope','wait_state','action_message']", "['session','mission_scope','action_scope','wait_state','action_message']")
s=s.replace("const home=fixture();try{home.exec(ddl);\n      if(mutation==='session')", "const home=fixture();try{home.exec(ddl);\n      expect(()=>homeAttentionFacts(home,composedReceipt('attention_action',false))).not.toThrow();\n      if(mutation==='session')")
s=s.replace("      if(mutation==='wait_state')", "      if(mutation==='action_scope')home.exec(\"INSERT INTO attention_scopes(scope_id,task_id,repo_path,generation) VALUES('scope2','t','/fixture2',1); UPDATE attention_actions SET scope_id='scope2' WHERE action_id='action'\");\n      if(mutation==='wait_state')")
p.write_text(s)
p=root/'docs/design/operator-recovery-schema.md';s=p.read_text().replace('An additional acyclic J17.recovery → J14.scoped counterexample is rejected by an explicit recovery-versus-activation ancestor boundary.', 'Additional acyclic J17 and legacy home/broker/compatibility recovery → J14.scoped counterexamples are rejected by an explicit ancestor boundary. Its activation set is `{J13.scoped, J14.scoped, J17.scoped}` and its roots include J12 bootstrap/full recovery, J17 schema/recovery and legacy schema/recovery producers. Manifest prerequisite comparisons use unordered sets; missing storage prerequisites and a cloned controller-required flag have negative tests.')
s=s.replace('The composition test opens two separate in-memory databases.', 'The composition test opens two separate in-memory databases: home `fixture-home` and broker lease home `home-a`. This is side-by-side separation, not a shared-home join.')
s=s.replace('actual home mission/action/message/home/scope/phase/disposition tuple','actual home identity, mission/action/message, scope, phase and disposition tuple')
s=s.replace('FK-valid live-row perturbations independently exercise', 'FK-valid live-row perturbations first verify the unperturbed fixture, then independently exercise')
s=s.replace('still fail when schema, DDL, fixture, candidate or recovery-build identity differs from the pinned input.', 'still fail against the test-local pin comparator when schema, DDL, fixture, candidate or recovery-build identity differs from its input; this is not J12 admission or build authentication.')
s=s.replace('The home association helper is an executable test oracle only.', 'The home association helper is an executable test oracle only. It does not check wait/action item equality, action or mission state, or completion absence on a stopped receipt. The nonexistent-target raw-SQL bypass control establishes the separate host-check obligation; unchanged rows on rejection alone do not prove that SQL would reject the receipt. The omission matrix is sourced from the committed JSON schema, not introspected Zod keys: schema/Zod drift review, converse unexpected identities and all nested-envelope combinations remain separate coverage work.')
p.write_text(s)
