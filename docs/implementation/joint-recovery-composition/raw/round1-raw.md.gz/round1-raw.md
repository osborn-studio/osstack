# Adversarial review: JA20/JA47 home + broker composition candidate (`da9a1512`)

This is a static read of the diff and the pasted material. I ran nothing. The only recorded test run is for `40df2714`, not `da9a1512`, so I treat green status as unproven for this SHA.

## P0

None found.

## P1: confirmed blockers

**P1-A. The raw-material-node argument is tautological, and the real JA20 bad variants are not rejected.**
Anchors: `compositionGraph()`, the test "orders the actual producer graph…", and `it.each` "rejects reverse dependency".
- `fixture:home-spec` and `fixture:broker-spec` are injected with `requires: []`, and the test then asserts `J11.scoped.requires` equals the list it just built. A leaf node cannot create a cycle, so this proves nothing about "not qualified through J17.schema_spec".
- The broker manifest's `dependencies` block is never read. It declares `candidate_material_requires: ["joint recovery contracts"]`, which contradicts the `requires: []` the test (and the doc's "no formal acceptance prerequisites") assumes. It also declares `schema_qualification_requires`, `recovery_qualification_requires` and `runtime_storage_requires`. None of these are compared to the gate graph.
- The negative that actually matters is missing. If `fixture:broker-spec` required `J17.schema_spec`, then `J11.scoped → fixture:broker-spec → J17.schema_spec → J11.scoped` is a cycle. The three listed negatives are direct gate-to-gate edges and do not cover it.
- The JA20 bad variant is "recovery back-depends on the controller that starts the migration". For J17 this is `J17.recovery → J14.scoped`, which is acyclic in this graph (`J14.scoped → J13.scoped → J12.scoped`, with no path to `J17.recovery`). A cycle detector cannot reject it, so the cycle-only negatives are not sufficient for this bad variant.

Minimal remedy:
1. Derive the two material nodes' `requires` from each manifest (`candidate_material_requires` mapped to `J01.contracts`).
2. Assert each manifest's `schema_qualification_requires`, `recovery_qualification_requires` and `runtime_storage_requires` are exactly the corresponding gate-graph edges.
3. Add a negative: push `J17.schema_spec` onto `fixture:broker-spec` and expect a cycle trace containing `fixture:broker-spec`.
4. Add an ancestor-closure assertion: the transitive ancestors of `J12.scoped`, `J17.schema_spec` and `J17.recovery`, including the material nodes, contain none of `J14.scoped`, `J13.scoped`, `J17.scoped`.

**P1-B. JA20's "home and broker each first have a schema spec and a recovery build" is only asserted for the broker half, and the order check can pass vacuously.**
Anchor: the pair list in the order test.
- The home side is not asserted at all. The graph has `J11.scoped → J12.bootstrap_preflight → J12.scoped`, `legacy:C03.schema_spec → legacy:I04.recovery_home`, `legacy:X03.schema_spec → legacy:I04.recovery_broker`, and `legacy:I04.compat_recovery` needing both.
- `expect(order.indexOf(before)).toBeLessThan(order.indexOf(after))` passes if `before` is misspelled, because `-1 < k`.
- Minimal remedy: add the home chain and the `legacy:I04.recovery_*` and `compat_recovery` pairs, and assert every index is `>= 0`.

**P1-C. The doc claims rejection against "mission/action/message/session/scope/phase/disposition/wait rows", but the test cannot show that for session, wait, or mission-vs-action scope.**
Anchors: `homeAttentionFacts()`, and `it.each([...'mission','action','message'...])`.
- Every mutated case changes only the receipt, and the DB holds exactly one action/mission/message/session. So mission, action and message mutations all collapse to "no row" (`!row`). The test cannot tell which join predicate does the work.
- Oracle predicates that are unkillable as written:
  - `row.session_id!==row.message_session`
  - `row.wait_state!=='delivery_unknown'`
  - `row.mission_scope!==r.scope_id` (indistinguishable from `row.scope_id`)
  - `w.mission_id=p.mission_id` and `a.message_id=p.message_id`
- `owner` and `tenant` are compared to literals (7 and `'fixture-tenant'`), not rows. The doc is honest about the synthetic pins, but the test names "unjoined home owner/tenant" imply a join.
- The inner `JOIN attention_receipt_resolutions` makes `prior_resolution: 'none'` unrepresentable, because "no resolution" and "no subject" both yield no row. If the intended oracle accepts only this one fixture shape, say so.
- Minimal remedy, either:
  - Add FK-valid DB perturbation cases, each with an otherwise-valid receipt expected to be rejected: a second action/message/session so a real but cross-wired tuple exists, wait `state≠delivery_unknown`, an action scope differing from the mission scope, and an existing `engineering_completions` row for `proven_stopped`. Use a `LEFT JOIN` with `COALESCE(res.disposition,'none')`.
  - Or narrow the doc sentence to what is actually exercised: home, phase, resolution and action/mission/message existence.

## P2: scoped fixes and limitations

1. **Omission matrix hygiene** (`omissionCases`, `withoutField`, the two omission `it.each` blocks).
   - `withoutField` runs inside the `expect(() => …)` closure. A bad path would throw a `TypeError` and pass `.toThrow()`. A missing leaf key would silently produce an unchanged object. Build the mutant outside the closure and assert the key existed.
   - The "27 required fields" figure is never asserted. Add `expect(receiptShape.required).toHaveLength(27)`, or cross-check against the non-optional keys of `RecoveryReceiptShape.shape`, since the matrix is driven by the JSON schema file rather than the Zod decoder.
   - Bare `.toThrow()` accepts any failure. Envelope omissions are rejected by the strict Zod parse before the context-comparison loop. The test title "through the real proof join" is only partly true.
   - Envelope nested conditional fields (`proof.effect_id`, `proof.broker_identity.*`, `subject.*`) are not omitted. The doc says "top-level", which is accurate, but this is the same conditional-field area as the receipt matrix.

2. **Vacuous "without changing holds".** The unjoined-home cases never attempt a write, so `legacy(home)` equality and `COUNT = 0` are trivially true. Either drop them or add a control showing the same wrong receipt would be accepted by the home SQL ledger (it should be, since SQL cannot see those rows). That control makes it explicit that the oracle is the only barrier.

3. **"Mutually agreeing" pinned-tuple test** (`wrong pinned %s`). The envelope carries only `schema_spec_digest` and `recovery_build_digest`. For `ddl_digest`, `fixture_digest`, `actual_target_schema` and `candidate_sha` there is nothing to "agree", so reword the title. Only the attention subject is exercised, so broker and effect variants are untested. Nothing pins the broker `ddl_digest`/`fixture_digest` to `sha256(schema.sql)`/`sha256(held-orphan.sql)`, nor `schema_spec_digest` to `schemaSpecDigest(MigrationSpec.parse(spec))`, in this file.

4. **Broker SQL negatives** (`keeps a broker decision confined…`).
   - `broker_id` and `lease_id` columns are fixed at `'broker-fixture'`/`'lease-a'` in all cases. The `lease` and `broker` mutations therefore only trip the JSON-vs-column CHECK, never the FK or trigger.
   - Every case asserts only `SQLITE_CONSTRAINT*`, so the test cannot tell which guard fired. Assert the message, or pair each negative with a single-field positive control.
   - `pinnedReceipt(valid,false)` throwing is a trivial target-mismatch check.
   - `user_version===1` for the broker is not asserted.
   - Broker `proven_stopped` is not exercised here. The doc says only preserve-unknown is retained, which is accurate.

5. **Cycle-trace assertions are loose** (substring checks on `from` and `to`). Assert the literal `${from} -> ${to}` edge. For `J12→J17.scoped` the printed trace goes via `J14`, while the doc attributes it to `J17.scoped → J12.scoped`. Both are true; keep the doc's rationale distinct from the trace.

6. **Doc claims to tighten.**
   - "The Git comparison … changes only the two state specification test files" should read "under `packages/core/src/state`". The evidence supplied covers only state files. Hashes of the compared (older) commit are absent, and nothing shows that the protocol schema and recovery sources are unchanged between `69859ee` and `3192b42`.
   - "O06 has a fresh review" is an author-run impact check, not a closed independent review.
   - "27 receipt fields" should be backed by the pin in item 1.

7. **Verification is stale.** Rerun the targeted set on `da9a1512`: both spec tests, protocol, tsc, biome and changeset. Record its logs before merge.

8. **Optional, non-blocking.**
   - Converse conditional-field cases (`UNEXPECTED_EFFECT_ID`, `UNEXPECTED_BROKER_PROOF`).
   - `applied_observed` with and without an `engineering_completions` row.
   - A home receipt into the broker ledger, and the reverse.

## Verified positives

- The decoder-level matrix uses a positive control per case, and the null-vs-absent split is explicit.
- Broker SQL has a positive insert after the negatives.
- Test-local helpers are labelled as unqualified oracles, and the doc consistently disclaims authority, CAS and effect-store joins.
- The real graph (not just the injected nodes) is acyclic in the topological order provided.

VERDICT: REVISE
END_AUDIT