from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/recovery-composition');base='3192b424174e5eb977d640cc0418e67c6b1461d1';old='69859eecfcc84af9d6eff755ed41243ca5f51f95'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
changed=git('diff','--name-only',old,base,'--','packages/core/src/state').decode().splitlines();assert all(p.endswith('.test.ts') for p in changed)
paths=['packages/core/src/state/'+p for p in ['db.ts','migrations.ts','schema.ts','source-observations-ddl.ts','engineering-ddl.ts','follow-up-delivery-ddl.ts','follow-up-obligations-ddl.ts']]
inputs={}
for p in paths:
 a=git('show',old+':'+p);b=git('show',base+':'+p);assert a==b;inputs[p]=hashlib.sha256(b).hexdigest()
readonly={p:hashlib.sha256(git('show',base+':'+p)).hexdigest() for p in git('ls-tree','-r','--name-only',base,'packages/core/fixtures/operator-recovery','packages/core/fixtures/broker-recovery','packages/protocol/fixtures/joint/reference-vectors.json').decode().splitlines()}
for p,h in readonly.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h
unknowns=json.loads(git('show',base+':docs/design/2026-10-27-joint-engineering/unknowns.json'))
record={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current_main':base,'remote_main_observation':git('ls-remote','origin','refs/heads/main').decode().strip(),'old_home_manifest_base':old,'state_files_changed':changed,'non_test_state_implementation_changes':[],'migration_closure_raw_sha256':inputs,'readonly_inputs_sha256':readonly,'unknowns_at_base':[x for x in unknowns['items'] if x['id'] in ['O03','O06']],'disposition':{'O03':'Actual home47 catalog revalidated by current runMigrations.48 and broker0-to1 remain candidate/unreserved. No schema queue allocation or runtime recovery certificate.','O06':'This candidate is checked against exact main3192; no global close, any changed main/contract inputs require renewed impact review.','J01.contracts':'Not formally passed; JA20/JA47 material does not sign J11 or waive prerequisites.'}}
(out/'baseline-inspection.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'main':base,'remote':record['remote_main_observation'],'readonly_inputs':len(readonly),'non_test_state_changes':0}))
