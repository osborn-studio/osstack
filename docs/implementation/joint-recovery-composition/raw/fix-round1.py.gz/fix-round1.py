from pathlib import Path
import shutil
root=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition');out=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/recovery-composition')
hist=out/'historical-da9a';hist.mkdir(exist_ok=True)
for name in ['verification.json','build.log','composition.log','protocol.log','typecheck.log','lint.log','changeset.log','hygiene.log','producer-graph-trace.json']:
 if (out/name).exists():shutil.copy2(out/name,hist/name)
p=root/'packages/core/src/state/operator-recovery-spec.test.ts';s=p.read_text().replace("import { describe, expect, it } from 'vitest';","import { describe, expect, it } from 'vitest';\nimport { ZodError } from 'zod';")
s=s.replace("for(const part of parts.slice(0,-1))cursor=cursor[part] as Record<string,unknown>;\n  delete cursor[parts.at(-1)!];return result;", "for(const part of parts.slice(0,-1)){expect(cursor).toHaveProperty(part);cursor=cursor[part] as Record<string,unknown>;}\n  const key=parts.at(-1)!;expect(Object.hasOwn(cursor,key)).toBe(true);delete cursor[key];return result;")
a=s.index('function compositionGraph(): Gate[] {');b=s.index('function brokerFixture()',a)
s=s[:a]+'''// Direct producer prerequisites are contract claims; insertion order alone cannot
// prove them. Keep the home/legacy edges explicit and broker lists manifest-bound.
const requiredProducerEdges: [string,string][] = [
  ['J11.scoped','J01.contracts'],['J12.bootstrap_preflight','J11.scoped'],
  ['J12.scoped','J11.scoped'],['J12.scoped','J12.bootstrap_preflight'],
  ['J17.schema_spec','J11.scoped'],['J17.recovery','J17.schema_spec'],['J17.recovery','J12.scoped'],
  ['legacy:C03.schema_spec','J11.scoped'],['legacy:X03.schema_spec','J17.schema_spec'],
  ['legacy:I04.recovery_home','J12.scoped'],['legacy:I04.recovery_home','legacy:C03.schema_spec'],
  ['legacy:I04.recovery_home','legacy:DEBT02.recovery_contract'],
  ['legacy:I04.recovery_broker','J17.recovery'],['legacy:I04.recovery_broker','legacy:X03.schema_spec'],
  ['legacy:I04.recovery_broker','legacy:DEBT02.recovery_contract'],
  ['legacy:I04.compat_recovery','J12.full_recovery'],['legacy:I04.compat_recovery','legacy:I04.recovery_home'],
  ['legacy:I04.compat_recovery','legacy:I04.recovery_broker'],
];
function compositionGraph(): Gate[] {
  const input=JSON.parse(readFileSync(new URL('../../../../docs/design/2026-10-27-joint-engineering/execution-gates.json',import.meta.url),'utf8'));
  const gates=(input.gates as Gate[]).map(g=>({id:g.id,requires:[...g.requires]}));
  const rawInputs: Record<string,string>={'joint recovery contracts':'artifact:joint-recovery-contracts'};
  const material=(composedBrokerSpec.dependencies.candidate_material_requires as string[]).map(name=>{
    const id=rawInputs[name];if(!id)throw Error('UNKNOWN_MATERIAL_INPUT: '+name);return id;
  });
  // Raw contracts/catalog are files, not formal J01/J17 acceptance. Home has no
  // dependencies block; its source catalog is independently instantiated below.
  gates.push({id:'artifact:joint-recovery-contracts',requires:[]},{id:'artifact:home47-catalog',requires:[]},
    {id:'fixture:home-spec',requires:['artifact:joint-recovery-contracts','artifact:home47-catalog']},
    {id:'fixture:broker-spec',requires:material});
  gates.find(g=>g.id==='J11.scoped')!.requires.push('fixture:home-spec','fixture:broker-spec');return gates;
}
function validateProducerGraph(gates: Gate[]): string[] {
  const order=producerOrder(gates);const graph=new Map(gates.map(g=>[g.id,g.requires]));
  const activation=new Set(['J13.scoped','J14.scoped','J17.scoped']);
  const walk=(id:string,path:string[]):void=>{
    if(activation.has(id))throw Error('RECOVERY_REQUIRES_ACTIVATION: '+[...path,id].join(' -> '));
    for(const dep of graph.get(id)??[])walk(dep,[...path,id]);
  };
  for(const recovery of ['J12.bootstrap_preflight','J12.scoped','J17.schema_spec','J17.recovery'])walk(recovery,[]);
  for(const [id,dependency] of requiredProducerEdges)if(!graph.get(id)?.includes(dependency))throw Error('MISSING_PRODUCER_EDGE: '+id+' -> '+dependency);
  const mapping=[['J17.schema_spec','schema_qualification_requires'],['J17.recovery','recovery_qualification_requires'],['J17.scoped','runtime_storage_requires']] as const;
  for(const [id,key] of mapping)if(canonicalJointJson(graph.get(id))!==canonicalJointJson(composedBrokerSpec.dependencies[key]))throw Error('BROKER_MANIFEST_DEPENDENCY_MISMATCH: '+id);
  if(composedBrokerSpec.dependencies.recovery_requires_runtime_controller!==false)throw Error('BROKER_RECOVERY_REQUIRES_CONTROLLER');
  return order;
}
''' + s[b:]
a=s.index("  it('orders the actual producer graph");b=s.index('  it.each(omissionCases)',a)
s=s[:a]+'''  it('orders and binds actual home, broker and legacy producer prerequisites without qualifying raw material', () => {
    const graph=compositionGraph();const order=validateProducerGraph(graph);
    expect(graph.find(g=>g.id==='J11.scoped')!.requires).toEqual(['J01.contracts','fixture:home-spec','fixture:broker-spec']);
    expect(graph.find(g=>g.id==='fixture:broker-spec')!.requires).toEqual(['artifact:joint-recovery-contracts']);
    for(const [after,before] of [...requiredProducerEdges,['J11.scoped','fixture:broker-spec'],['J11.scoped','fixture:home-spec'],['J17.scoped','J17.recovery']]){
      expect(order.indexOf(before!)).toBeGreaterThanOrEqual(0);expect(order.indexOf(after!)).toBeGreaterThanOrEqual(0);
      expect(order.indexOf(before!)).toBeLessThan(order.indexOf(after!));
    }
  });
  it.each([['J11.scoped','J17.schema_spec'],['fixture:broker-spec','J17.schema_spec'],['J12.scoped','J14.scoped'],['J12.scoped','J17.scoped']])('rejects reverse dependency %s -> %s with its exact edge in the cycle trace', (from,to) => {
    const graph=compositionGraph();graph.find(g=>g.id===from)!.requires.push(to);
    expect(()=>validateProducerGraph(graph)).toThrow('RECOVERY_PRODUCER_CYCLE');
    expect(()=>validateProducerGraph(graph)).toThrow(from+' -> '+to);
  });
  it.each(requiredProducerEdges)('rejects deletion of required producer edge %s -> %s even if traversal order stays plausible', (from,to) => {
    const graph=compositionGraph();const gate=graph.find(g=>g.id===from)!;expect(gate.requires).toContain(to);
    gate.requires=gate.requires.filter(dep=>dep!==to);expect(()=>producerOrder(graph)).not.toThrow();
    expect(()=>validateProducerGraph(graph)).toThrow('MISSING_PRODUCER_EDGE: '+from+' -> '+to);
  });
  it('rejects an acyclic recovery dependency on start admission', () => {
    const graph=compositionGraph();graph.find(g=>g.id==='J17.recovery')!.requires.push('J14.scoped');
    expect(()=>producerOrder(graph)).not.toThrow();
    expect(()=>validateProducerGraph(graph)).toThrow('RECOVERY_REQUIRES_ACTIVATION: J17.recovery -> J14.scoped');
  });
  it('pins the receipt required-field matrix cardinality independently of generated cases', () => {
    expect(receiptShape.required).toHaveLength(27);expect(new Set(receiptShape.required).size).toBe(27);
    expect(omissionCases).toHaveLength(115);
  });
''' + s[b:]
s=s.replace("expect(()=>decodeJointContractAs('recovery_receipt',canonicalJointJson(withoutField(r,path)))).toThrow();", "const mutant=withoutField(r,path);const raw=canonicalJointJson(mutant);\n    expect(()=>decodeJointContractAs('recovery_receipt',raw)).toThrow(ZodError);")
s=s.replace("through the real proof join',", "through the real envelope parser before proof joining',")
s=s.replace("expect(()=>verifyRecoveryProofEnvelopes(r,[withoutField(envelope,path)])).toThrow();", "const mutant=withoutField(envelope,path);expect(()=>verifyRecoveryProofEnvelopes(r,[mutant])).toThrow(ZodError);")
a=s.index("describe('JA20/JA47")
s=s[:a]+'''function insertHomeExample(db:Database.Database, r:RecoveryReceipt): void {
  db.prepare('INSERT INTO operator_recovery_decisions VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(r.operator_ref,r.request_id,'a'.repeat(64),r.subject_digest,canonicalJointJson(r.subject),r.if_revision,r.owner_generation,r.decision,r.decision==='preserve_unknown'?'unresolved':'resolved_stopped',canonicalJointJson(r),r.observed_at_ms);
}
function persistHomeExample(db:Database.Database, r:RecoveryReceipt): void {
  const verified=verifyRecoveryProofEnvelopes(pinnedReceipt(r,false),r.proofs.length?[composedEnvelope(r)]:[]);
  homeAttentionFacts(db,verified);insertHomeExample(db,verified);
}

''' + s[a:]
s=s.replace("const verified=verifyRecoveryProofEnvelopes(pinnedReceipt(r,false),[composedEnvelope(r)]);homeAttentionFacts(home,verified);\n      home.prepare('INSERT INTO operator_recovery_decisions VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(r.operator_ref,r.request_id,'a'.repeat(64),r.subject_digest,canonicalJointJson(r.subject),r.if_revision,r.owner_generation,r.decision,'resolved_stopped',canonicalJointJson(r),r.observed_at_ms);", "persistHomeExample(home,r);")
s=s.replace("expect(()=>homeAttentionFacts(home,r)).toThrow(/MISMATCH/);", "expect(()=>persistHomeExample(home,r)).toThrow(/MISMATCH/);")
a=s.index("  it.each(['schema_spec_digest'")
s=s[:a]+'''  it.each(['session','mission_scope','wait_state','action_message'])('rejects FK-valid live-row %s cross-wiring before the shared illustrative write', mutation => {
    const home=fixture();try{home.exec(ddl);
      if(mutation==='session')home.exec("INSERT INTO agent_sessions SELECT 's2',task_id,run_id,agent_id,request_sha256,state,resume_supported,version,updated_at,repo_path,resume_handle_json,policy_digest,created_at,head_turn_id,closed_at FROM agent_sessions WHERE session_id='s'; UPDATE engineering_missions SET session_id='s2' WHERE mission_id='mission'");
      if(mutation==='mission_scope')home.exec("INSERT INTO attention_scopes(scope_id,task_id,repo_path,generation) VALUES('scope2','t','/fixture2',1); UPDATE engineering_missions SET scope_id='scope2' WHERE mission_id='mission'");
      if(mutation==='wait_state')home.exec("UPDATE engineering_waits SET state='cleared' WHERE wait_id='wait'");
      if(mutation==='action_message')home.exec("INSERT INTO session_messages SELECT 'msg2',session_id,turn_id,direction,kind,payload_json,state,created_at,applied_at FROM session_messages WHERE message_id='msg'; UPDATE attention_actions SET message_id='msg2' WHERE action_id='action'");
      expect(home.pragma('foreign_key_check')).toEqual([]);const before=legacy(home);
      expect(()=>persistHomeExample(home,composedReceipt('attention_action',false))).toThrow('HOME_LIVE_SUBJECT_MISMATCH');
      expect(legacy(home)).toEqual(before);expect(home.prepare('SELECT COUNT(*) AS n FROM operator_recovery_decisions').get()).toEqual({n:0});
    }finally{home.close();}
  });
  it('demonstrates raw home ledger storage alone accepts a nonexistent target that the illustrative host rejects', () => {
    const home=fixture();try{home.exec(ddl);const original=composedReceipt('attention_action',false);
      const subject={...original.subject,home_id:'nonexistent-home'};
      const r=RecoveryReceipt.parse({...original,subject,target_home_id:subject.home_id,subject_digest:recoverySubjectDigest(subject)});
      expect(()=>persistHomeExample(home,r)).toThrow('HOME_LIVE_SUBJECT_MISMATCH');
      expect(()=>insertHomeExample(home,r)).not.toThrow();expect(home.prepare('SELECT COUNT(*) AS n FROM operator_recovery_decisions').get()).toEqual({n:1});
    }finally{home.close();}
  });
''' + s[a:]
s=s.replace('rejects a mutually agreeing proof/receipt with wrong pinned %s','rejects a structurally consistent receipt/envelope with wrong pinned %s')
s=s.replace("const parameters=[bad.operator_ref,bad.request_id,'a'.repeat(64),'broker-fixture','lease-a',0,bad.owner_generation,bad.decision,canonicalJointJson(bad)];", "const parameters=[bad.operator_ref,bad.request_id,'a'.repeat(64),subject.broker_id,subject.lease_id,0,bad.owner_generation,bad.decision,canonicalJointJson(bad)];")
s=s.replace("expect(error).toMatchObject({code:expect.stringMatching(/^SQLITE_CONSTRAINT/)});", "expect(error).toMatchObject({code:'SQLITE_CONSTRAINT_TRIGGER',message:'broker recovery request, identity, owner or revision conflict'});")
s=s.replace("expect(catalog(broker)).toEqual(JSON.parse(brokerRead('catalog.json')));", "expect(catalog(broker)).toEqual(JSON.parse(brokerRead('catalog.json')));expect(broker.pragma('user_version',{simple:true})).toBe(1);\n      expect(sha(readFileSync(new URL('schema.sql',brokerPath)))).toBe(composedBrokerSpec.spec.ddl_digest);\n      expect(sha(readFileSync(new URL('held-orphan.sql',brokerPath)))).toBe(composedBrokerSpec.spec.fixture_digest);\n      expect(schemaSpecDigest(MigrationSpec.parse(composedBrokerSpec.spec))).toBe(composedBrokerSpec.schema_spec_digest);")
p.write_text(s)
