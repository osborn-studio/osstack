# Adversarial review: JA20/JA47 home + broker composition, `5a2acd0d`

Static read only; I ran nothing. The attached verification record is for this exact SHA (`5a2acd0d`). It is a prior-run record, not something I reproduced.

## P0 / P1

None confirmed. I checked the earlier P1s independently:

- **Graph (was P1-A): resolved.**
  - `fixture:broker-spec` now derives its `requires` from `candidate_material_requires`.
  - The injected `fixture:broker-spec -> J17.schema_spec` edge is asserted as an exact substring. The recorded trace shows `J11.scoped -> fixture:broker-spec -> J17.schema_spec -> J11.scoped`.
  - The acyclic `J17.recovery -> J14.scoped` variant is rejected by the ancestor walk. It is checked with `producerOrder` not throwing first, so the rejection is not cycle-based.
  - Each of the 18 required edges has a deletion negative that proves traversal order alone would not catch it.
- **Order check (was P1-B): resolved.** Home, legacy and compat edges are listed. The `>= 0` guards close the `-1 < k` hole. The `[after, before]` destructuring matches the `[requirer, dependency]` tuple order.
- **Home DB association (was P1-C): resolved for the four FK-valid cases.** I traced each perturbation against the SQL:
  - `session` is rejected by `row.session_id !== row.message_session` only.
  - `mission_scope` is rejected by `row.mission_scope !== r.scope_id` only.
  - `wait_state` is rejected by `row.wait_state !== 'delivery_unknown'`.
  - `action_message` is rejected by the `a.message_id = p.message_id` join, which yields no row.
  - Each case asserts `foreign_key_check === []` and the exact `HOME_LIVE_SUBJECT_MISMATCH` message. The raw-insert bypass control shows the SQL ledger alone accepts the same receipt.
- **Matrix cardinality:** I recomputed 27 required receipt fields and 115 cases. By kind that is 37 (attention) + 37 (effect) + 41 (broker). The pin is correct.
- **Provenance:** the "state-files-only" wording now matches `state_files_changed` and `non_test_state_implementation_changes: []`.

## P2: scoped fixes

1. **Recovery-boundary roots omit the legacy recovery builds** (`validateProducerGraph`, the `for (const recovery of [...])` loop).
   - Roots are `J12.bootstrap_preflight`, `J12.scoped`, `J17.schema_spec` and `J17.recovery`. The nodes that actually are "the home/broker recovery build" are `legacy:I04.recovery_home` and `legacy:I04.recovery_broker`.
   - `legacy:I04.recovery_home -> J14.scoped` is acyclic and would pass, because nothing under `J14` reaches those nodes.
   - Remedy: add `legacy:C03.schema_spec`, `legacy:X03.schema_spec`, `legacy:I04.recovery_home`, `legacy:I04.recovery_broker`, `legacy:I04.compat_recovery` and `J12.full_recovery` to the roots, with one more negative.
   - The doc should also name the activation set `{J13.scoped, J14.scoped, J17.scoped}`.

2. **Manifest-binding branches have no negative.**
   - `BROKER_MANIFEST_DEPENDENCY_MISMATCH` and `BROKER_RECOVERY_REQUIRES_CONTROLLER` never fire in any test.
   - `J17.scoped`'s edges are in neither `requiredProducerEdges` nor any deletion test, so only the mapping loop protects them.
   - Remedy: delete `J12.scoped` from `J17.scoped` and expect the mismatch. Parameterise `dependencies` so the controller flag can be flipped on a clone.
   - The comparison is order-sensitive via `canonicalJointJson`. Compare sorted copies.

3. **Home perturbation hygiene.**
   - There is no unperturbed control inside the perturbation tests. The only positive is the `stopped=true` case. It shares the same facts, but call `homeAttentionFacts` on the unmutated DB first and assert it does not throw.
   - The doc claims "mission/action scopes", but the action-scope predicate (`row.scope_id`) is redundant in this fixture and cannot be killed. Add a case: insert `scope2`, then `UPDATE attention_actions SET scope_id='scope2'`. Or narrow the wording to mission scope.
   - `/MISMATCH/` in the "unjoined home %s" test also matches `PINNED_RECOVERY_TUPLE_MISMATCH` and `PROOF_CONTEXT_MISMATCH`. Assert `SYNTHETIC_MAINTENANCE_CONTEXT_MISMATCH` for owner and tenant, and `HOME_LIVE_SUBJECT_MISMATCH` otherwise.
   - The helper does not check `w.item_id = a.item_id`, `a.state`, mission state, or absence of an `engineering_completions` row on a `proven_stopped` receipt. That is acceptable for a bounded fixture. Add one sentence saying so.
   - "Without changing holds" and `COUNT = 0` are trivially true when no write was attempted. The nonexistent-home bypass control is the real evidence, so say that.

4. **Pinned-tuple test is self-referential.**
   - `pinnedReceipt` compares against the same synthetic literals (`'c'.repeat(40)`, `'c'.repeat(64)`) that `composedReceipt` uses. The only non-tautological content is that protocol validation accepts the wrong tuple.
   - The envelope carries only `schema_spec_digest` and `recovery_build_digest`.
   - The doc sentence "still fail when schema, DDL…" needs "against the test-local pin comparator, not J12 admission".

5. **Conditional fields and matrix source.**
   - Only omissions are tested. The converse cases (`UNEXPECTED_EFFECT_ID` on an attention receipt, `UNEXPECTED_BROKER_PROOF` on a home proof) are cheap and sit in the area the scope names.
   - Nested envelope omissions (`proof.effect_id`, `proof.broker_identity.*`, `subject.*`) are not covered. The doc's "top-level" wording is accurate.
   - The matrix comes from the JSON schema, not the Zod shape. If the two drift, the Zod side goes untested. Cross-check keys or note the limitation.
   - Confirm `zod` is a declared dependency of `@osstack/core`. `toThrow(ZodError)` relies on a single zod instance.

6. **Baseline evidence.**
   - There is no `git ls-tree` anchor showing `execution-gates.json` is tracked at `3192b42`. The trace has only a `source_sha256`.
   - The main observation is at 17:47 and the verification at 18:00. Re-observe at merge. The O06 wording already allows for this.

7. **Doc wording.** "mission/action/message/home/scope" repeats "home". The home fixture is `fixture-home` and the broker lease is `home-a`, so the composition is side-by-side separation, not a shared-home join. Say so.

## Verified positives

- Mutants are built outside the `expect` closure.
- `withoutField` asserts the key exists.
- `ZodError` is required, with a per-case decode control.
- The null-versus-absent split is explicit for attention, broker and effect.
- Broker SQL negatives now use matching identity columns. Each negative is pinned to the exact trigger message, and one full positive insert follows.
- Bootstrap digests, `user_version = 1` and the spec digest are asserted for the broker.
- O03, O06 and `J01.contracts` remain explicitly open. The doc consistently disclaims authority, CAS, effect-store joins and product safety.

VERDICT: PASS
END_AUDIT