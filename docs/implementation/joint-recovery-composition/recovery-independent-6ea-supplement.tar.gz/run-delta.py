from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;g=json.loads((r/'baseline-graph.json').read_text());e=os.environ.copy();e.pop('OSSTACK_SOCKET',None);e.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(r/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
inputs=[('baseline-graph','orders and binds actual|acyclic|runtime manifest|prerequisite sets|FK-valid',0)]
for name,node in [('legacy-home','legacy:I04.recovery_home'),('legacy-broker','legacy:I04.recovery_broker'),('legacy-compat','legacy:I04.compat_recovery')]:
 d=json.loads(json.dumps(g));next(x for x in d['gates']if x['id']==node)['requires'].append('J14.scoped')
 # Independently use Kahn readiness elimination, not author's DFS.
 pending={x['id']:set(x['requires']) for x in d['gates']};done=set()
 while pending:
  ready={n for n,deps in pending.items()if deps<=done}
  if not ready:raise ValueError('unexpected actual graph cycle '+name)
  for n in ready:del pending[n]
  done.update(ready)
 (r/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');inputs.append((name,'orders and binds actual',1))
d=json.loads(json.dumps(g));next(x for x in d['gates']if x['id']=='J17.scoped')['requires'].remove('J12.scoped');(r/'missing-runtime-bootstrap.json').write_text(json.dumps(d,indent=2)+'\n');inputs.append(('missing-runtime-bootstrap','orders and binds actual',1))
for name,filter,expected in inputs:
 e['INDEPENDENT_GRAPH_PATH']=str(r/(name+'.json'));cmd=['/usr/bin/python3',str(r/'run-recorded.py'),'--label',name,'--cwd',str(r),'--code-sha','6ea2cebc8420a1f26b7aff820f7997c0cbba61ad','--','node','/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-recovery-composition/node_modules/vitest/vitest.mjs','run','--config','vitest.config.mts','candidate.test.ts','-t',filter]
 x=subprocess.run(cmd,cwd=r,env=e,capture_output=True,text=True);print(name,x.returncode);print((r/(name+'.stdout')).read_text()[-300:]);assert x.returncode==expected
