# B final bounded delta review

Exact candidate `6ea2cebc8420a1f26b7aff820f7997c0cbba61ad` versus prior independently checked `5a2acd0d6ddd27e8c572d85e2f7cc99d2e895520` changes only the specification test and its document. Actual runtime, protocol, SQL, manifests and fixtures are unchanged. Prior 35 SQL/64 independent cases are **not rerun** or relabelled as fresh runs.

Actual targeted delta run: **12 passed / 212 skipped**, covering producer positive, acyclic activation negatives, runtime manifest/controller flag checks, order independence and five FK-valid home perturbations. An additional separately redirected real-manifest positive control passed.

Independent input mutations redirected into the exact committed candidate test:

- Add J14.scoped to each legacy home/broker/compatibility recovery root: independent Kahn elimination first proves each actual mutated graph remains acyclic; candidate positive graph check nevertheless rejects all three with RECOVERY_REQUIRES_ACTIVATION.
- Remove J12.scoped from actual J17.scoped graph dependencies: candidate positive rejects with BROKER_MANIFEST_DEPENDENCY_MISMATCH.
- Keep the graph unchanged but remove J12.scoped from the actual broker manifest runtime dependency list (scratch copy): positive control passes unchanged manifest, the mutated manifest is rejected with the same mismatch class. This checks both inputs to the comparator, not just one cloned graph.

All five negative mutations produced expected assertion/test failure for the declared boundary, not setup errors. Raw inputs/commands/outputs remain separate. No further confirmed issue in this limited delta. Manifest comparisons now ignore ordering but still detect removed requirements. Documentation explicitly distinguishes separate home identifiers, test-local pin comparison and unimplemented wait/item/state/completion checks; it makes no new recovery authority or qualification claim.

No worker source or central data modified; Node22, explicit scratch home, socket unset. No full suite, paid provider or OSStack CLI. Formal gate/principal status remains unchanged.
