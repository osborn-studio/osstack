import pathlib,subprocess,os,json,hashlib,datetime,sys
r=pathlib.Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-verification-composition');s=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-host-effects-20261028/composition')
sha=lambda b:hashlib.sha256(b).hexdigest()
env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(s/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack',OSSTACK_UPDATE_CHECK='0');env.pop('OSSTACK_SOCKET',None)
commands=[]
def run(label,argv,timeout=600):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (s/(label+'.stdout')).open('wb') as out,(s/(label+'.stderr')).open('wb') as err:
  p=subprocess.run(argv,cwd=r,env=env,stdout=out,stderr=err,timeout=timeout)
 record={'label':label,'argv':argv,'cwd':str(r),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'environment_override':{k:env[k] for k in ['PATH','OSSTACK_HOME','OSSTACK_SCRATCH_ROOT','OSSTACK_UPDATE_CHECK']},'unset':['OSSTACK_SOCKET'],'stdout':label+'.stdout','stdout_sha256':sha((s/(label+'.stdout')).read_bytes()),'stderr':label+'.stderr','stderr_sha256':sha((s/(label+'.stderr')).read_bytes())};commands.append(record);(s/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(label,'exit',p.returncode,flush=True)
 if p.returncode:raise RuntimeError(label+' failed; no retry')
 return (s/(label+'.stdout')).read_bytes()
initial=run('initial-status',['git','status','--porcelain']);assert initial==b''
head=run('head-binding',['git','show','-s','--format=%H%n%P%n%T','HEAD']).decode().strip().splitlines();assert head[1]=='48f5a9f1a6bfc5c4a82645dfd8bcc96a3125c69e 10629495aafe7b3aca0de4c920bcaec40b083d7b'
merge=run('merge-tree',['git','merge-tree','--write-tree','48f5a9f1a6bfc5c4a82645dfd8bcc96a3125c69e','10629495aafe7b3aca0de4c920bcaec40b083d7b']).decode().strip();assert merge==head[2]
(s/'composition.json').write_text(json.dumps({'head':head[0],'parents':head[1].split(),'tree':head[2],'merge_tree_equal':True,'initial_clean':True,'initial_node_modules_present':(r/'node_modules').exists(),'scope':'fresh install/build; 27 script regression tests and actual engineering smoke, not combined whole-repository suite'},indent=2)+'\n')
assert not (r/'node_modules').exists()
paths=subprocess.run(['git','ls-files','packages/knowledge/dist'],cwd=r,capture_output=True,check=True).stdout.decode().splitlines();backups={p:(r/p).read_bytes() for p in paths};(s/'knowledge-before.json').write_text(json.dumps({p:sha(b) for p,b in backups.items()},indent=2)+'\n')
built={};failure=None
try:
 run('install',['pnpm','install','--frozen-lockfile'])
 run('build',['pnpm','build'])
 built={p:sha((r/p).read_bytes()) for p in paths};(s/'knowledge-after-build.json').write_text(json.dumps(built,indent=2)+'\n')
 run('script-tests',['node','--test','scripts/smoke-engineering-decision.test.mjs'],180)
 run('live-smoke',['node','scripts/smoke-engineering-decision.mjs','--evidence-dir',str(s/'live-evidence')],150)
 receipt=json.loads((s/'live-smoke.stdout').read_text());e=s/'live-evidence';saved=json.loads((e/'receipt.json').read_text());ri=json.loads((e/'run.json').read_text());manifest=json.loads((e/'manifest.json').read_text());cleanup=json.loads((e/'cleanup.json').read_text())
 checks={'receipt_stdout_equal':receipt==saved,'passed':receipt['status']=='passed','applied':receipt['action_receipt']=='applied','observed_turn':receipt['completion_level']=='observed_turn','provider_unqualified':receipt['provider_qualified'] is False,'fixture_removed':not pathlib.Path(ri['fixture_root']).exists(),'cleanup_removed':cleanup['scratch_removed'] is True,'process_exit_confirmed':cleanup['process_exit_confirmed'] is True,'bindings_unchanged':ri['bindings_unchanged'] is True,'expected_git_head':ri['bindings']['git_head']==head[0]}
 filechecks=[]
 for f in manifest['files']:
  assert pathlib.PurePosixPath(f['path']).name==f['path']
  data=(e/f['path']).read_bytes();filechecks.append({'path':f['path'],'hash_matches':sha(data)==f['sha256'],'bytes_match':len(data)==f['bytes']})
 checks['manifest_files_verified']=all(x['hash_matches'] and x['bytes_match'] for x in filechecks)
 (s/'evidence-verification.json').write_text(json.dumps({'checks':checks,'manifest_files':filechecks},indent=2)+'\n');assert all(checks.values()),checks
except Exception as ex:
 failure=str(ex);print('FAILURE',failure,flush=True)
finally:
 restored=[];blocked=[]
 for p,b in backups.items():
  current=(r/p).read_bytes()
  if current==b:continue
  if p in built and sha(current)==built[p]:(r/p).write_bytes(b);restored.append(p)
  else:blocked.append(p)
 (s/'knowledge-cleanup.json').write_text(json.dumps({'restored_owned_build_outputs':restored,'refused_unknown_changes':blocked},indent=2)+'\n')
 final=run('final-status',['git','status','--porcelain'])
 (s/'result.json').write_text(json.dumps({'status':'failed' if failure or blocked else 'passed','failure':failure,'knowledge_unknown_changes':blocked,'final_worktree_clean':not final,'limitations':['not a combined whole-repository test run','not runtime/provider/principal/gate qualification']},indent=2)+'\n')
 if failure or blocked:sys.exit(1)
print('COMPOSITION PASSED',flush=True)
