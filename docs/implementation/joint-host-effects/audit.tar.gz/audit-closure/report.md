# B closure review: PASS

I found no confirmed remaining blocker within B. I took the author's statements as given: the archive and outer manifest are tracked, the 40 Codex members are byte-equal to the originals, and the host reports are unchanged. I did not treat the absence of those files from the prompt as a defect.

## Disposition of the prior B report

| # | Prior finding | Disposition |
|---|---|---|
| 1 | Missing-evidence taxonomy applied to Claude only | **Closed.** The README now classifies Codex's "actual manifests" gap as the fixture's `skills.config.yaml` files, absent from its supplied inputs. It classifies Codex's `input-manifest.json` as supplied but unread, which matches `result.json` carrying `input_manifest_sha256`. This is consistent with Codex's own wording, "输入文件清单未提供实际 fixture/manifest". |
| 2 | Codex row omitted unfavorable qualifiers | **Closed.** The README now states C5 is bounded and C7 has a scope limit, and it describes the state-db and `falling_back` warnings. It adds an execution / behavior / harness / cleanup / coverage table for both hosts and notes that the last invocation ran multiple utilities. |
| 3 | "Recorded before invocation" supported for Claude only | **Closed.** The freeze at `07:18:14.991Z` precedes the start at `07:18:15.073Z`. The hash `46e0b3d7…ad54` in the README matches `result.json`'s `expectations_sha256`. The README says these are not external timestamp attestations. |
| 4 | "Read-only" enforced for one host, observed for the other | **Closed.** The wording is now "all observed commands read-only". The README cites `--sandbox read-only` in the argv and says it does not prove the CLI's internal state was untouched. |
| 5 | Confounds and evaluator not disclosed | **Closed.** The README discloses that the prompts directed evidence discipline, that the task measures comprehension of supplied evidence, and that the authoring team froze and evaluated its own experiments. |
| 6 | "Method use" and "useful" overreach | **Closed.** The title is now "observed method reading", "useful" is gone, and the README says there is no control. |
| 7 | `host-usage.md` cells did not say what was tested | **Closed.** The cells name the `inputs/` copy and the differing entries. The text says both hosts read the pre-change evidence guidance and neither tested the checkout template or the new guidance. |
| 8 | Artifacts and redaction effects | **Closed.** The README names the archive and manifest as tracked. It lists exactly the three redacted Claude files, which match the outer-manifest redacted entries. It states that inner hashes bind originals while the outer manifest binds published bytes, and that the Codex files are unchanged, including those whose hashes its transcript checked. |
| 9 | Template lacked the new evidence states | **Closed.** The template now has an "Input evidence inventory / explicit paths / read status / verified predicates" line. |
| 10 | Next experiment could not test the change | **Closed.** It is reframed as a queued outline, not an executable or validated specification, with nothing scheduled. The vague "after the current PRs settle" trigger is gone. The README lists the old/new guidance arms, the absent versus supplied-but-unread control, a no-material control, and open decisions on model identity, repetitions and token budgets. It makes no comparative claim. |

## Non-blocking notes

- The `host-usage.md` cells say "read-only report" for both hosts. The README qualifies this: enforced by tool allowlist for Claude, observed commands plus the sandbox flag for Codex. Optionally echo that in the cells.
- The README does not say who scores a future experiment. A one-line "scoring independent of the method author" would help, but a queued outline does not need it.
- The gloss that Codex's "actual manifests" means `skills.config.yaml` can't be confirmed from the projected text. It is consistent with the Codex response, and the README keeps the supplied-but-unread inventory distinction separate.