# Claude shared-method read-only consumption observation

One fresh bounded call used actual Claude CLI 2.1.291 with requested and observed `claude-sonnet-5-5`. Exit 0; 29 successful read-only tool calls (28 Read, one Glob). The stream records both requests and tool results. This is observed file consumption and a substantive diagnosis, not test execution, automatic skill routing, authenticated independence or a causal method-benefit experiment.

Inputs: exact PR288 method commit `10629495aafe7b3aca0de4c920bcaec40b083d7b`; old source `fd9cac8127dbfa5660d9c45e58a42da5ed642073`; copied original PR289 RED/GREEN and compiled CLI evidence. `expectations.json` was frozen before dispatch; all 36 input payload hashes were checked unchanged afterwards.

## Read the evidence

- `report.md`: unedited Claude answer. Diagnosis is correct, but it mistakenly calls the supplied, unread `input-manifest.json` unavailable and overstates two-file hash evidence as whole-source equivalence. See `evaluation.json` for precise corrections.
- `response.stream.jsonl`: original verbose stream including read calls/results.
- `response.json`: exact final result object, including actual modelUsage.
- `read-evidence.json`: call/result references and input-file hashes.
- `command.json`, `invocation-binding.json`, `input.txt`, `version.stdout`, `stderr.txt`: invocation and runtime binding.
- `input-manifest.json`, `expectations.json`, `pre-call-binding.json`: immutable input provenance and pre-call checklist.

No second model attempt, source edits, product test runs, PR updates or ledger updates were performed by this worker. The skill wrapper's usual session-marker/telemetry writes were deliberately not run because this delegated task allowed writes only under this scratch directory and explicitly required preserved raw records. This is a fresh consult with no resumed session.
