from pathlib import Path
import subprocess,json,hashlib,datetime,os,signal
r=Path(__file__).parent
args=['/opt/homebrew/bin/claude','-p','--model','claude-sonnet-5-5','--effort','high','--output-format','stream-json','--verbose','--disable-slash-commands','--tools','Read,Grep,Glob','--allowedTools','Read,Grep,Glob','--disallowedTools','Bash,Edit,Write','--strict-mcp-config','--mcp-config',str(r/'empty-mcp.json'),'--safe-mode','--no-session-persistence','--permission-mode','dontAsk','--setting-sources','','--settings',str(r/'settings.json'),'--max-turns','18']
version=subprocess.run([args[0],'--version'],capture_output=True,text=True)
(r/'version.stdout').write_text(version.stdout);(r/'version.stderr').write_text(version.stderr)
record={'argv':args,'cwd':str(r),'stdin':'input.txt','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':600,'version_exit':version.returncode,'model_requested':'claude-sonnet-5-5','call_count':1}
(r/'command.json').write_text(json.dumps(record,indent=2)+'\n')
with (r/'input.txt').open() as inp,(r/'response.stream.jsonl').open('w') as out,(r/'stderr.txt').open('w') as err:
 p=subprocess.Popen(args,cwd=r,stdin=inp,stdout=out,stderr=err,start_new_session=True)
 try:code=p.wait(timeout=600)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  code=124
record.update(exit_code=code,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
records=[]
for line in (r/'response.stream.jsonl').read_text().splitlines():
 try:records.append(json.loads(line))
 except Exception:pass
results=[x for x in records if x.get('type')=='result']
if results:
 final=results[-1];(r/'response.json').write_text(json.dumps(final,indent=2)+'\n');(r/'report.md').write_text(final.get('result','')+'\n');record.update(modelUsage=final.get('modelUsage'),is_error=final.get('is_error'),subtype=final.get('subtype'))
tools=[]
for rec in records:
 for block in rec.get('message',{}).get('content',[]) if isinstance(rec.get('message',{}).get('content'),list) else []:
  if block.get('type')=='tool_use':tools.append(block)
(r/'tool-uses.json').write_text(json.dumps(tools,indent=2)+'\n')
record['tool_use_count']=len(tools);record['tool_names']=sorted(set(x['name'] for x in tools))
record['hashes']={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in ['input.txt','expectations.json','input-manifest.json','response.stream.jsonl','stderr.txt','version.stdout','tool-uses.json']}
(r/'invocation-binding.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record.get(k) for k in ['exit_code','tool_use_count','tool_names','modelUsage','subtype','is_error']},indent=2))
