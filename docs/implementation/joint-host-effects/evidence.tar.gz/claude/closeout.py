from pathlib import Path
import json,hashlib,datetime,tarfile
r=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((r/'input-manifest.json').read_text());inv=json.loads((r/'invocation-binding.json').read_text());freeze=json.loads((r/'pre-call-binding.json').read_text())
assert all(sha(r/x['path'])==x['sha256'] for x in manifest['files'])
assert inv['started_at']>freeze['frozen_at'];assert sha(r/'expectations.json')==freeze['expectations_sha256'];assert sha(r/'input.txt')==freeze['input_sha256']
stream=[json.loads(s) for s in (r/'response.stream.jsonl').read_text().splitlines()]
uses=[];results={}
for n,ev in enumerate(stream):
 for b in ev.get('message',{}).get('content',[]) if isinstance(ev.get('message',{}).get('content'),list) else []:
  if b.get('type')=='tool_use':uses.append((n,b))
  if b.get('type')=='tool_result':results[b['tool_use_id']]=(n,b)
reads=[]
for n,b in uses:
 result=results.get(b['id']);entry={'tool_use_id':b['id'],'name':b['name'],'input':b['input'],'stream_event_index':n,'result_event_index':result[0] if result else None,'is_error':result[1].get('is_error',False) if result else None}
 if b['name']=='Read':
  p=Path(b['input']['file_path']);assert p.is_relative_to(r/'inputs');entry.update(file_sha256=sha(p),bytes=p.stat().st_size)
 if result:entry['tool_result_sha256']=hashlib.sha256(json.dumps(result[1],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
 reads.append(entry)
assert all(x['name'] in ['Read','Grep','Glob'] and x['is_error'] is False for x in reads)
(r/'read-evidence.json').write_text(json.dumps(reads,indent=2)+'\n')
old=sha(r/'inputs/old-source/skills-command.ts');red=json.loads((r/'inputs/evidence/red.json').read_text());assert old==red['source_sha256']['packages/cli/src/skills-command.ts']
eval={'evaluated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'observed_read_only_consumption_with_report_caveats','formal_gate_pass':False,'tests_executed_by_claude':False,'independent_qualified':False,'causal_method_benefit_established':False,'model_requested':'claude-sonnet-5-5','model_observed':list(inv['modelUsage']),'exit_code':inv['exit_code'],'calls':1,'tools_used':sorted(set(x['name'] for x in reads)),'tool_uses':len(reads),'read_calls':sum(x['name']=='Read' for x in reads),'tool_errors':0,'inputs_unchanged_verified':len(manifest['files']),'expectations_sha256':freeze['expectations_sha256'],'criteria':[{'id':'C1','observation':'Met: actual Read of SKILL, investigation, bug-fix and evidence guidance.'},{'id':'C2','observation':'Met: actual Read of old CLI, watcher, manifest, tests, RED/GREEN originals and compiled records.'},{'id':'C3','observation':'Met for main diagnosis: !ok branch continues without counter, exit only depends on drift; proposed failure1/drift2/healthy-empty0 with failure precedence.'},{'id':'C4','observation':'Met for actionable criteria: negative/positive, mixed/drift/empty, raw exits/commands/environment/source-build bindings. No new execution.'},{'id':'C5','observation':'Met for scope disclaimers, with report factual caveats below. Model explicitly says it executed nothing and does not claim installation/automatic trigger/causal benefit/independence/runtime gate.'},{'id':'C6','observation':'Met: init tools Glob/Grep/Read only, actual Glob+Read, no MCP, success result actual modelUsage claude-sonnet-5-5.'}],'report_corrections':[{'claim':'input-manifest.json was not among the supplied files; old source hash was not given.','correction':'Incorrect: prompt explicitly named input-manifest.json and it was present. Claude did not read it. Manifest binds old source bytes; host checked old source SHA256 '+old+' equals RED metadata source hash. This is a missed provided provenance check, not unavailable provenance.'},{'claim':'Only that source file differs between the two runs.','correction':'The two listed source hash entries show unchanged test and changed command source, but are not a whole-working-tree equivalence proof. Narrow the claim to those recorded files.'}],'limits':['Existing evidence and expected behavior were supplied; no blinded or no-method control. Self-reported method influence is not causal evidence.','Only one read-only Claude host call; no test execution, task implementation, automatic skill routing or installation is established.','Input manifest was supplied but unread; all raw observations and inaccuracies remain in report.md unchanged.','Bounded selected test/runtime records do not prove whole-project or live-provider qualification.']}
(r/'evaluation.json').write_text(json.dumps(eval,indent=2)+'\n')
(r/'README.md').write_text('''# Claude shared-method read-only consumption observation

One fresh bounded call used actual Claude CLI 2.1.291 with requested and observed `claude-sonnet-5-5`. Exit 0; 29 successful read-only tool calls (28 Read, one Glob). The stream records both requests and tool results. This is observed file consumption and a substantive diagnosis, not test execution, automatic skill routing, authenticated independence or a causal method-benefit experiment.

Inputs: exact PR288 method commit `10629495aafe7b3aca0de4c920bcaec40b083d7b`; old source `fd9cac8127dbfa5660d9c45e58a42da5ed642073`; copied original PR289 RED/GREEN and compiled CLI evidence. `expectations.json` was frozen before dispatch; all 36 input payload hashes were checked unchanged afterwards.

## Read the evidence

- `report.md`: unedited Claude answer. Diagnosis is correct, but it mistakenly calls the supplied, unread `input-manifest.json` unavailable and overstates two-file hash evidence as whole-source equivalence. See `evaluation.json` for precise corrections.
- `response.stream.jsonl`: original verbose stream including read calls/results.
- `response.json`: exact final result object, including actual modelUsage.
- `read-evidence.json`: call/result references and input-file hashes.
- `command.json`, `invocation-binding.json`, `input.txt`, `version.stdout`, `stderr.txt`: invocation and runtime binding.
- `input-manifest.json`, `expectations.json`, `pre-call-binding.json`: immutable input provenance and pre-call checklist.

No second model attempt, source edits, product test runs, PR updates or ledger updates were performed by this worker. The skill wrapper's usual session-marker/telemetry writes were deliberately not run because this delegated task allowed writes only under this scratch directory and explicitly required preserved raw records. This is a fresh consult with no resumed session.
''')
files=[]
for p in sorted(r.rglob('*')):
 if p.is_file() and p.name not in ['archive-manifest.json','claude-consumption-evidence.tar.gz']:
  files.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)})
(r/'archive-manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n')
with tarfile.open(r/'claude-consumption-evidence.tar.gz','w:gz') as tar:
 for x in files:tar.add(r/x['path'],arcname=x['path'])
 tar.add(r/'archive-manifest.json',arcname='archive-manifest.json')
print(json.dumps({'evaluation':eval['status'],'reads':eval['read_calls'],'archive_sha256':sha(r/'claude-consumption-evidence.tar.gz'),'archive_bytes':(r/'claude-consumption-evidence.tar.gz').stat().st_size,'manifest_sha256':sha(r/'archive-manifest.json')},indent=2))
