# Why old `osstack skills check` exits 0 on a bad source or ref

I executed nothing. This report comes only from reading files with Read, Grep and Glob.

## 1. Diagnostic findings

**Facts from the old source**

- `inputs/old-source/skills-command.ts:57-61` prints `✗ <id> unreachable: <reason>` for an entry with `!entry.ok`, then `continue`s. It increments nothing.
- The only counter is `drifted` (`:56`, `:63`). The summary prints only `N source(s) drifted from blessed_sha.` (`:71`).
- The exit code is `drifted > 0 ? 2 : 0` (`:72`). A failed check therefore contributes nothing to the exit status, and a run where every source failed returns 0.
- `old-source/watcher.ts:25-27` builds failed entries as `{ok:false, drifted:false, reason}`, so a failure is never counted as drift.
- `watcher.ts:61` (non-zero git exit), `:66` (`no_matching_ref`), `:50` (timeout), `:56` (spawn failure) and `:71` (unparseable SHA) all produce `ok:false`.
- `git ls-remote <origin> <ref>` exits 0 with empty output when the ref doesn't exist. This is my inference about git behaviour, not something in the evidence. It matches the `:64-67` handling, which maps empty output to `no_matching_ref`.
- `old-source/manifest.ts` is not involved. `checkAll` only reads the manifest. The `check` branch never calls `saveManifest`.

**Observed in the baseline compiled CLI** (`inputs/baseline/results.json`, `commands.json`, `negative.stdout`)

- The negative case printed `✗ owned-fixture unreachable: no_matching_ref` followed by `0 source(s) drifted…`, and the exit code was 0. The positive case also exited 0.
- `results.json` records `"reproduced": true` and `manifest_unchanged: true`.
- `commands.json` shows direct `node …/dist/bin.js skills check` with an isolated `OSSTACK_HOME`. `environment.json` shows isolated git config, `GIT_ALLOW_PROTOCOL=file` and a local-origin fixture.

**Competing explanations I can rule out or bound**

| Explanation | Verdict |
| --- | --- |
| The watcher fails to detect the problem. | Ruled out. The failure is detected and printed (`watcher.ts:66`, `negative.stdout:2`). It is only discarded from the exit code. |
| The pnpm/vitest wrapper or environment masks the exit code. | Ruled out for the compiled path. Baseline ran `node bin.js` directly and still got 0. |
| Network or auth flakiness. | Ruled out. The origin is a local file fixture, and the positive case resolved the same fixture to `ceab03089c21`. |
| A stale or mutated manifest. | Ruled out. `manifest_unchanged: true` in each case. |
| `bin.js` drops exit codes. | Strongly bounded. The candidate binary returned 1 and 2 in `real-candidate-final/results.json:18` and `real-extra/results.json:7`. I did not read `bin.js` itself. |
| The mocks hide it and the real CLI is fine. | Ruled out by the baseline compiled run. |
| Exit 0 on unreachable is intended. | Not ruled out from the source alone. No contract document was given. `help` says only "Compare blessed_sha vs origin HEAD" (`skills-command.ts:139`). The expectation of exit 1 comes from the test author's own scenarios (`tests/skills-command.test.ts:125-133`). |

**Adjacent behaviours I noticed and consider out of scope**

- `watcher.ts:33` makes an unblessed source (`blessed_sha === null`) count as drifted, which gives exit 2.
- `watcher.ts:64` takes only the first `ls-remote` line, which could be ambiguous for a partial ref name.
- `bless` already rejects `!ok` entries (`skills-command.ts:117-119`).

## 2. Smallest justified correction and validation criteria

**Correction (a prediction for a separate task, not something I implemented):** change only the `check` branch in `skills-command.ts`.

- Count `!ok` entries.
- Print `N source(s) failed to check.` alongside the existing drift line.
- Return 1 if any source failed, otherwise 2 if any drifted, otherwise 0.

The watcher, manifest and `bless` stay unchanged. The tests at `:125-133` also make failure outrank drift (exit 1 when a drift and a failure coexist). That precedence is a design choice made by the tests, not something the source evidence forces.

The tests also require the summary to print a `0 source(s) failed to check.` line on healthy runs (`:165`). That is a presentation addition beyond the exit code. It is reasonable, but it is a wider change than the exit-code fix alone.

**Positive criteria** (all on the compiled CLI, in an isolated environment)

- A reachable source whose ref matches HEAD and equals `blessed_sha` gives exit 0, `✓ … up-to-date`, `0 failed`, `0 drifted` and empty stderr.
- Drift only gives exit 2.
- An empty manifest gives exit 0.
- The manifest hash is unchanged after every run.

**Negative criteria**

- A reachable local origin with a nonexistent ref gives exit 1 and `✗ … unreachable: no_matching_ref`. It must also show `1 source(s) failed to check.`
- The same fixture, command and environment must give exit 0 on the baseline build. This is the discriminating observation.
- A mixed run (one drift, one failure) gives exit 1 and both counts.
- Other failure classes need separate evidence. These are a bad origin path (git stderr reason), a missing git binary (`spawn_failed`) and a timeout.

**Command, environment and evidence requirements** (from `evidence.md` and the baseline record)

- Build baseline and candidate separately. Record each commit, the build command and log, and the `dist/bin.js` hash tied to the source hash.
- Use an isolated `OSSTACK_HOME` and cwd, a local git fixture with a recorded commit, `GIT_CONFIG_*` isolation, `GIT_ALLOW_PROTOCOL=file` and a fixed PATH.
- Capture argv, cwd, exit code, stdout/stderr hashes and manifest hashes.
- Record execution, behaviour, harness, cleanup and coverage as separate axes.
- Confirm cleanup of owned directories and that the evidence survives.
- Run the neighbouring checks: the full cli package tests, typecheck, and the skill-registry watcher tests.

## 3. What the existing records establish and what they leave open

**RED/GREEN unit records** (`evidence/red.*`, `green.*`)

- RED: `exit_code: 1`, 12 tests of which 9 failed and 3 passed (`red.stdout:4`).
  - The six failure-bearing scenarios fail on exit code (0 or 2 where 1 was expected).
  - The three healthy or drift-only scenarios fail only on the missing `failed to check` text.
  - The original three tests pass.
- GREEN: `exit_code: 0`, 12 of 12 passed, empty stderr.
- The test file hash is identical in both (`c776…`). `skills-command.ts` hash changed (`850c…` → `79a5…`). Only that source file differs between the two runs, so the change in outcome tracks the source change.
- I cannot confirm that `old-source/skills-command.ts` is the `850c…` file, because no hash was given for it. The behaviour in the RED output is consistent with what I read (for example the old summary text at `red.stderr:53-58`).
- The red-to-green change is established for mocked `checkAll` and `handleSkillsCommand`. It also checks that `writeManifest` is not called (`test:172`).
- It establishes nothing about real git behaviour, packaging, or `bin.js`.

**Compiled-CLI records**

- Baseline negative and positive both exited 0 (above).
- `real-candidate-final/results.json:3-43` records, for candidate `9a063b97…`:
  - negative: exit 1 against baseline 0, with `assertion_passed: true` and an unchanged manifest.
  - positive: exit 0 with an unchanged manifest.
  - Candidate stdout carries the new failed-count line (`negative.stdout:4`).
- `real-extra/results.json` shows drift → 2, mixed → 1 and empty → 0. These are stdout and exit codes only. That file has no argv, cwd or environment, and I did not see its manifests.
- Taken together, these support that for this candidate, a nonexistent ref on a local reachable origin now exits 1. They also support that healthy, drift-only, mixed and empty cases behave as the tests expect, on the compiled CLI.

**Unverified or limited**

- **Build provenance.** The baseline binary came from a different worktree (`verification-kit`) than the candidate (`skills-check-exit`). I did not read `candidate-head.stdout` or the baseline commit. The candidate's `dist/bin.js` hash is recorded, but I saw no build log tying it to the source hash. I read only the first 100 lines of the `real-candidate-final/results.json` build manifest, so the rest is unread. `input-manifest.json` was not among the supplied files.
- **Manifest contents.** The manifests behind the hashes were not shown, so I can't confirm how the nonexistent ref was configured.
- **Other failure classes.** Timeout, git spawn failure, bad-origin stderr reasons, SSH/HTTPS and real GitHub remotes are covered only by mocks, or not at all. Multiple live failures are untested.
- **Wider checks.** I saw no full-package test run, typecheck or lint. I also saw no exercise of `bless`, `list` or `add` on the candidate, and no evidence about downstream scripts that might rely on exit 0.
- **Candidate source.** The candidate source was not available, so I couldn't confirm the diff is minimal. I can say only that the `skills-command.ts` hash changed and the outputs fit the predicted change.
- **Path aliases.** `red.json` cwd uses `/Users/osborn/…` while its stdout uses `/Volumes/AIMATE_WORK/…`. This is probably a mount alias, but I can't confirm it.

**What file consumption does not establish.** My having read these files is not:

- skill-picker installation or availability,
- an automatic trigger of the method,
- causal proof that the method improved the outcome,
- authenticated reviewer independence (these records look like same-author work with no pre-frozen oracle, and I do not treat them as independent),
- runtime activation of any host feature, or
- a complete gate pass.

## 4. Method instructions that changed my approach

- **SKILL.md ("separate a source-based prediction from an executed observation").** I labelled the git empty-output behaviour and the proposed correction as inferences, and I kept observed outputs apart from them.
- **`investigation.md` steps 3-4 (competing explanation, facts/inferences/unknowns).** I built the exclusion table. That table also forced me to say that "exit 0 is intended" is not eliminated by the source and rests on the test author's expectation.
- **`investigation.md` step 5 and `bug-fix.md` opening ("explanation only → investigation").** I stayed in investigation mode and described the scope for a separate fix task instead of drafting a patch.
- **`bug-fix.md` steps 4-5 (preserve failing-before/passing-after; recheck on the same surface).** I judged the unit RED/GREEN pair as only the cheap-regression half, and I treated the compiled before/after pair as the real-trigger half.
- **`evidence.md`.** An exit code alone isn't the predicate, so I also checked output text and the manifest hash. A source commit doesn't identify a binary, so I flagged the missing build tie. Cleanup and coverage are separate axes, and I noted what was not recorded. The independence and `observed_turn` warnings shaped the closing limits.
