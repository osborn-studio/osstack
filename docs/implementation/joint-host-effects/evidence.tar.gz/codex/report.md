# Codex explicit material consumption experiment

Completed one actual Codex CLI 0.160.1 call, 2026-10-28 07:18:15–07:19:04 UTC, exit 0, no timeout or retry. CLI default model was not overridden; resolved model identity is not attested by the JSONL. User config ignored, ephemeral session, read-only sandbox, explicit unused scratch OSSTACK_HOME.

Materials were extracted exactly from PR288 commit 10629495aafe7b3aca0de4c920bcaec40b083d7b. Old source is fd9cac8127dbfa5660d9c45e58a42da5ed642073. Historical candidate evidence names 9a063b97a06dfb46fdb20f77a6e984b4206518e6. Input hashes and provenance are in input-manifest.json. Expectations were frozen before invocation (expectations.freeze.json); author is not an authenticated independent principal.

The actual JSONL records five completed read-only shell commands: method files, source, logs, JSON summaries/full originals, line citations and SHA-256 checks. The host correctly diagnosed failure entries being skipped before the drift-only exit calculation, distinguished no matching ref from network failure, and explained why candidate exit1 is regression success while the source remains unavailable. It accurately limited the claim to two historical cases and noted missing actual manifests, candidate source, build verification and cleanup evidence.

This is a useful observed investigation outcome, not proof of causal improvement from materials: no no-material control was run, and the task prompt also specified evidence discipline. No product commands/tests/provider actions were rerun. No MethodBinding, J gate, provider equivalence or principal qualification is established. Inputs remained byte-identical.

Original response.jsonl, stderr.txt, command.json, result.json, CLI help/version, prompt, frozen expectations, input manifest and final-response.md are retained. stderr includes rollout state database warning messages; completion remained successful. Reading the full 2335-entry build binding list produced a high token count (see assessment.json); future experiments should provide a deliberately bounded projection while preserving the original separately.
