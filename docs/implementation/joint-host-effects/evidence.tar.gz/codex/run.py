from pathlib import Path
import subprocess,json,hashlib,datetime,os,signal,time
root=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-host-effects-20261028/codex'); inp=root/'inputs';inp.mkdir(exist_ok=True)
repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack'; pin='10629495aafe7b3aca0de4c920bcaec40b083d7b'; base='fd9cac8127dbfa5660d9c45e58a42da5ed642073'
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
records=[]
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',pin,'osstack-methods-skill/'],cwd=repo,text=True).splitlines():
 data=subprocess.check_output(['git','show',pin+':'+path],cwd=repo); dst=inp/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);records.append({'path':str(dst.relative_to(root)),'git':pin+':'+path,'sha256':sha(data)})
for path in ['packages/cli/src/skills-command.ts','packages/skill-registry/src/watcher.ts']:
 data=subprocess.check_output(['git','show',base+':'+path],cwd=repo);dst=inp/'old-source'/Path(path).name;dst.parent.mkdir(exist_ok=True);dst.write_bytes(data);records.append({'path':str(dst.relative_to(root)),'git':base+':'+path,'sha256':sha(data)})
for label,src in [('baseline',Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/verification-kit-20261028/next-baseline')),('candidate',Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/skills-check-exit-20261028/real-candidate-final'))]:
 dst=inp/label;dst.mkdir(exist_ok=True)
 for name in ['negative.stdout','negative.stderr','positive.stdout','positive.stderr','results.json']:
  data=(src/name).read_bytes();(dst/name).write_bytes(data);records.append({'path':str((dst/name).relative_to(root)),'source':str(src/name),'sha256':sha(data)})
 # Small projection, explicitly not replacing the full raw result
 d=json.loads((src/'results.json').read_text()); projection={k:v for k,v in d.items() if k not in ['bindings','bindings_before','bindings_after']};(dst/'summary.json').write_text(json.dumps(projection,ensure_ascii=False,indent=2))
 records.append({'path':str((dst/'summary.json').relative_to(root)),'projection_of':str(src/'results.json'),'sha256':sha((dst/'summary.json').read_bytes())})
(root/'input-manifest.json').write_text(json.dumps(records,indent=2))
expect={'frozen_at':now(),'author':'parent task subagent; no independent authenticated principal','scope':'One read-only Codex CLI investigation of supplied historic evidence, no test rerun','criteria':['actual file-read events for SKILL.md, investigation.md, evidence.md, old-source and both evidence summaries','diagnose ok:false continue then drift-only exit zero','separate source unavailable from product exit-code defect','baseline negative exit0 -> candidate negative exit1 is regression success while source remains unavailable','positive unchanged exit0 and same-input manifest hashes acknowledged','state evidence is historical, no fresh test/provider execution','no claim MethodBinding/J gate or authenticated independent oracle'],'counterfactual_control':'none; cannot attribute improvement causally to material','timeout_seconds':240,'retries':0}
(root/'expectations.freeze.json').write_text(json.dumps(expect,indent=2))
prompt='''Perform a read-only investigation in this directory. First read inputs/osstack-methods-skill/SKILL.md, references/investigation.md and references/evidence.md, then inputs/old-source/*.ts and inputs/baseline/summary.json, inputs/candidate/summary.json and their negative/positive stdout/stderr. Paths under references are relative to inputs/osstack-methods-skill/. The full original results.json files and material files are also available for checking. These are historical records, not a request to run tests. Do not execute product commands, invoke other models/subagents, access services, or write/edit anything. Use only read-only file inspection under inputs; do not read outside this experiment directory. Diagnose the skills check behavior, give concrete verification criteria, assess what the provided RED/GREEN records support, and state limitations. Cite input files and exact facts. Distinguish observation from inference and missing evidence. Return a concise Chinese report on stdout; do not create a file. Do not inspect the experiment evaluator files outside inputs.'''
(root/'prompt.txt').write_text(prompt)
for label,args in [('cli-version',['/opt/homebrew/bin/codex','--version']),('cli-help',['/opt/homebrew/bin/codex','exec','--help'])]:
 p=subprocess.run(args,capture_output=True);(root/(label+'.stdout')).write_bytes(p.stdout);(root/(label+'.stderr')).write_bytes(p.stderr)
argv=['/opt/homebrew/bin/codex','exec','--ignore-user-config','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--color','never','--json','-C',str(root),'-']
env=os.environ.copy();env['OSSTACK_HOME']=str(root/'unused-osstack-home');env['OSSTACK_SCRATCH_ROOT']='/Volumes/AIMATE_WORK/tmp/osstack';env.pop('OSSTACK_SOCKET',None)
meta={'argv':argv,'cwd':str(root),'started_at':now(),'model':'not overridden; CLI default','prompt_sha256':sha(prompt.encode()),'expectations_sha256':sha((root/'expectations.freeze.json').read_bytes()),'input_manifest_sha256':sha((root/'input-manifest.json').read_bytes()),'environment_overrides':{'OSSTACK_HOME':env['OSSTACK_HOME'],'OSSTACK_SCRATCH_ROOT':env['OSSTACK_SCRATCH_ROOT']},'timeout_seconds':240}
(root/'command.json').write_text(json.dumps(meta,indent=2))
with (root/'response.jsonl').open('wb') as out,(root/'stderr.txt').open('wb') as err:
 p=subprocess.Popen(argv,cwd=root,env=env,stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True)
 try:p.communicate(prompt.encode(),timeout=240);meta['timed_out']=False
 except subprocess.TimeoutExpired:
  meta['timed_out']=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.communicate(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.communicate()
meta.update({'exit_code':p.returncode,'ended_at':now(),'stdout_sha256':sha((root/'response.jsonl').read_bytes()),'stderr_sha256':sha((root/'stderr.txt').read_bytes()),'inputs_unchanged':all(sha((root/r['path']).read_bytes())==r['sha256'] for r in records)})
(root/'result.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
