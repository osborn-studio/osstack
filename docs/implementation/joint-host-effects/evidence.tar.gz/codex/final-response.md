结论：旧版 `skills check` 会把“检查失败且没有已知漂移”报告为退出码 0。历史记录支持候选版修复了这个具体场景，但不足以证明全部检查分支正确。

1. **源码观察与诊断**  
   [skills-command.ts](inputs/old-source/skills-command.ts:52) 中，`!entry.ok` 只打印 `unreachable` 后跳过；最终仅按 `drifted > 0 ? 2 : 0` 返回。因此失败项未参与退出状态判定，存在自动化误判成功的风险。  
   [watcher.ts](inputs/old-source/watcher.ts:24) 将查询失败表示为 `ok:false, drifted:false`；第 65–66 行把 Git 成功退出但没有非空输出解释为 `no_matching_ref`。所以日志中的 `unreachable` **不能直接证明网络故障**，缺失匹配 ref 也是解释。

2. **RED/GREEN 实际支持的范围**  
   
   | 历史用例 | baseline | candidate |
   |---|---|---|
   | negative | `no_matching_ref`，退出 0 | 同样失败原因，退出 1；新增失败计数 1 |
   | positive | `up-to-date (ceab03089c21)`，退出 0 | 相同 SHA，退出 0；失败计数 0 |

   来源：[baseline summary](inputs/baseline/summary.json)、[candidate summary](inputs/candidate/summary.json) 及各自 `negative.stdout`、`positive.stdout`。四份 stderr 均为 0 字节；候选 stdout/stderr 的实际 SHA-256 与摘要吻合。两组均记录 `manifest_unchanged:true`。  
   **推断：**负例 RED 是“应非零却返回零”，GREEN 是“失败被正确传递为非零”，并非源查询恢复成功。正例支持这个正常路径未发生退出码回归。

3. **具体核验标准（未执行）**  
   - 无匹配 ref：保留原因、失败计数为 1、退出码为 1，manifest 字节不变。
   - 可解析且等于 blessed SHA：失败和漂移计数均为 0，退出码为 0。
   - 可解析但 SHA 不同，或未 blessed：应报告漂移；旧源码约定退出 2。
   - 补齐失败与漂移混合、多源、空清单、Git 非零退出、启动失败、超时和无法解析 SHA；明确混合场景的退出码优先级。现有两例不能验证这些条件。

4. **证据限制**  
   [candidate results](inputs/candidate/results.json) 记录候选提交 `9a063b97a06dfb46fdb20f77a6e984b4206518e6`、2335 项文件哈希及 `bindings_unchanged:true`；这些是身份记录，不能替代候选源码、构建过程和制品内容核验。其 `scope` 声称沿用本地 Git fixture、隔离环境且无网络，但输入文件清单未提供实际 fixture/manifest 或候选源码，无法独立确认全部绑定与因果关系。也没有清理完成、独立复现或完整覆盖证据。

依照 [evidence.md](inputs/osstack-methods-skill/references/evidence.md)，应将其表述为历史两例的行为证据、覆盖局部、清理未知；不能升级为整体资格认证。本次仅只读检查 inputs，未运行产品或测试、调用其他模型或服务、写入文件。