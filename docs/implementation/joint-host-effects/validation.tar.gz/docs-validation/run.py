from pathlib import Path
import subprocess,os,json,hashlib,datetime,sys
r=Path(__file__).parent;repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-host-effects')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
env=os.environ.copy();env['PATH']='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
removed=[]
for k in list(env):
 if k.startswith('OSSTACK_'):removed.append(k);del env[k]
env.update(OSSTACK_HOME=str(r/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack')
head=git('rev-parse','HEAD');paths=['packages/knowledge/dist/index.d.ts','packages/knowledge/dist/index.d.ts.map','packages/knowledge/dist/index.js','packages/knowledge/dist/index.js.map']
original={}
for p in paths:
 b=(repo/p).read_bytes(); committed=subprocess.check_output(['git','show',head+':'+p],cwd=repo);assert b==committed,'preexisting generated modification:'+p
 original[p]={'git_blob':git('rev-parse',head+':'+p),'sha256':sha(b)}
def binding():
 tracked=git('ls-files').splitlines();files=[]
 for p in tracked:
  if (p.startswith('packages/') and '/dist/' not in p) or p.startswith('scripts/') or p in ['package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.base.json']:
   fp=repo/p
   if fp.is_file():files.append({'path':p,'sha256':sha(fp.read_bytes())})
 return {'git_head_observed':git('rev-parse','HEAD'),'files':files,'digest':sha(json.dumps(files,sort_keys=True).encode())}
start=binding();(r/'source-start.json').write_text(json.dumps(start,indent=2)+'\n')
meta={'started_at':now(),'initial_head':head,'repo':str(repo),'path':env['PATH'],'osstack_home':env['OSSTACK_HOME'],'scratch_root':env['OSSTACK_SCRATCH_ROOT'],'removed_outer_osstack_keys':removed,'original_knowledge_dist':original,'commands':[]}
def save():(r/'validation.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,args):
 info={'name':name,'argv':args,'cwd':str(repo),'started_at':now(),'head_at_start':git('rev-parse','HEAD'),'log':name+'.log'};meta['commands'].append(info);save()
 with (r/(name+'.log')).open('w') as out:code=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
 info.update(exit_code=code,ended_at=now(),head_at_end=git('rev-parse','HEAD'),log_sha256=sha((r/(name+'.log')).read_bytes()));save();print(name,code,flush=True);return code
save()
for name,args in [('node-version',['node','--version']),('pnpm-version',['pnpm','--version']),('install',['pnpm','install','--frozen-lockfile']),('build',['pnpm','build'])]:
 if run(name,args):meta['status']='failed_'+name;meta['ended_at']=now();save();sys.exit(1)
check="const m=await import('./packages/knowledge/dist/index.js'); if(typeof m.executionContextDigest!=='function'||typeof m.assembleExecutionContext!=='function')process.exit(1); console.log('executionContextDigest=function assembleExecutionContext=function')"
if run('knowledge-exports',['node','--input-type=module','-e',check]):meta['status']='failed_exports';save();sys.exit(1)
test_start=binding();(r/'source-test-start.json').write_text(json.dumps(test_start,indent=2)+'\n');meta['test_source_start_digest']=test_start['digest'];save()
code=run('test-full',['pnpm','test'])
end=binding();(r/'source-end.json').write_text(json.dumps(end,indent=2)+'\n');meta['test_source_end_digest']=end['digest'];meta['product_source_unchanged']=test_start['digest']==end['digest'];meta['source_start_to_end_unchanged']=start['digest']==end['digest']
meta['knowledge_dist_after_build']={p:{'sha256':sha((repo/p).read_bytes()),'changed_from_start':sha((repo/p).read_bytes())!=original[p]['sha256']} for p in paths};save()
# All tests finished. Only restore our initially-clean generated tracked files.
restore=run('restore-knowledge-dist',['git','restore','--source',head,'--',*paths]);assert restore==0
meta['knowledge_dist_restored']={p:{'git_blob':git('hash-object',p),'sha256':sha((repo/p).read_bytes()),'matches_original_blob':git('hash-object',p)==original[p]['git_blob']} for p in paths}
assert all(x['matches_original_blob'] for x in meta['knowledge_dist_restored'].values())
meta['status']='passed' if code==0 and meta['product_source_unchanged'] else 'failed_or_changed_source';meta['ended_at']=now();save();print(meta['status'],flush=True)
