from pathlib import Path
import json,re,hashlib,subprocess,datetime
r=Path(__file__).parent;repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-host-effects');meta=json.loads((r/'validation.json').read_text());log=(r/'test-full.log').read_text()
rows=[]
for line in log.splitlines():
 m=re.match(r'^(packages/\S+) test:\s+Tests\s+(.*)$',line)
 if m:
  row={'package':m.group(1),'raw_summary':line}
  for field in ['passed','skipped','failed','todo']:row[field]=int((re.search(r'(\d+) '+field,m.group(2)) or [None,'0'])[1])
  rows.append(row)
completed=re.findall(r'^(packages/\S+) test: Done$',log,re.M)
summary={'started_head':meta['initial_head'],'test_command':next(c for c in meta['commands'] if c['name']=='test-full'),'product_source_unchanged':meta['product_source_unchanged'],'packages_with_test_summary':len(rows),'packages_done':len(completed),'total':{field:sum(row[field] for row in rows) for field in ['passed','skipped','failed','todo']},'rows':rows,'scope':'Full raw pnpm test observation. Product-source digest is frozen and checked; central docs/ledger may change during run. Do not relabel as verification of a later docs commit.'}
# Methods source may be checked against the initial commit without attributing later docs to test start.
methods=subprocess.check_output(['git','ls-tree','-r','--name-only',meta['initial_head'],'osstack-methods-skill'],cwd=repo,text=True).splitlines();checks=[]
for p in methods:
 old=subprocess.check_output(['git','show',meta['initial_head']+':'+p],cwd=repo);current=(repo/p).read_bytes();checks.append({'path':p,'initial_sha256':hashlib.sha256(old).hexdigest(),'current_sha256':hashlib.sha256(current).hexdigest(),'unchanged':old==current})
summary['methods_unchanged_from_initial_head']=all(x['unchanged'] for x in checks);summary['method_files']=checks
(r/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=[p for p in r.iterdir() if p.is_file() and p.name not in ['manifest.json']]
(r/'manifest.json').write_text(json.dumps({'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)]},indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['packages_with_test_summary','packages_done','total','product_source_unchanged','methods_unchanged_from_initial_head']},indent=2))
