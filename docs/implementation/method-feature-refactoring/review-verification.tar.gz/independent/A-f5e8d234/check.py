from pathlib import Path
import subprocess,os,hashlib,json,datetime,re,urllib.parse,time,shutil
W=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/independent/A-f5e8d234/git-snapshot');G=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack');O=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/independent/A-f5e8d234');C='f5e8d234a604ba39d78dfed21ae072d6ef2e3cca';B='ca95aba1c186d9c3a9e70a45143b7a277db84404';NODE='/opt/homebrew/opt/node@22/bin/node';sha=lambda b:hashlib.sha256(b).hexdigest()


env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(O/'home'),'OSSTACK_HOME':str(O/'unused-osstack-home'),'OSSTACK_SCRATCH_ROOT':str(O/'scratch'),'LANG':'en_US.UTF-8'}
(O/'home').mkdir(exist_ok=True);(O/'scratch').mkdir(exist_ok=True)
cmds=[]
def run(label,argv,timeout=30):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();p=subprocess.run(argv,cwd=W,env=env,capture_output=True,timeout=timeout)
 (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 r={'label':label,'argv':argv,'cwd':str(W),'environment':env,'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'duration_seconds':time.monotonic()-t,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)}
 (O/(label+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');cmds.append(r);return p
changes=subprocess.check_output(['git','diff','--name-only','10281aba06fb845188917ec32dd41488844d50c2',C],cwd=G,text=True).splitlines()
changes=[p for p in changes if p.startswith('osstack-methods-skill/') or p=='scripts/export-osstack-methods.test.mjs']
for p in ['scripts/export-osstack-methods.mjs','scripts/lib/osstack-method-export.mjs']:
 assert subprocess.check_output(['git','show',B+':'+p],cwd=G)==subprocess.check_output(['git','show',C+':'+p],cwd=G)
files=subprocess.check_output(['git','ls-tree','-r','--name-only',C,'osstack-methods-skill'],cwd=G,text=True).splitlines();source={}
for f in files:
 b=subprocess.check_output(['git','show',C+':'+f],cwd=G);assert(W/f).read_bytes()==b;source[f]=sha(b);dest=O/'candidate'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
old=['bug-fix','investigation','create-verification','maintain-verification','evidence','feature-map-template']
for name in old:
 p='osstack-methods-skill/references/'+name+'.md';assert subprocess.check_output(['git','show',B+':'+p],cwd=G)==(W/p).read_bytes()
checks=[]
for host,namespace in [('codex','.agents/skills'),('claude','.claude/skills')]:
 dest=O/('actual-export-'+host);p=run('export-'+host,[NODE,str(W/'scripts/export-osstack-methods.mjs'),'--host',host,'--output',str(dest)])
 assert p.returncode==0 and p.stderr==b'';receipt=json.loads(p.stdout);m=json.loads((dest/'manifest.json').read_text());assert receipt['exported']and not receipt['installed']and not receipt['host_discovery_verified'];assert len(m['files'])==48
 for f in m['files']:
  b=(dest/f['path']).read_bytes();assert len(b)==f['bytes']and sha(b)==f['sha256']
 roots=['osstack-mode','osstack-help','setup-osstack','osstack-agent'];graph={};edges=[]
 for f in m['files']:
  path=dest/f['path'];txt=path.read_text();targets=[]
  for target in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)',txt):
   u=urllib.parse.urlsplit(target)
   if u.scheme or u.netloc or not u.path:continue
   resolved=(path.parent/urllib.parse.unquote(u.path)).resolve();assert resolved.is_relative_to(dest.resolve()) and resolved.is_file(),(path,target)
   targets.append(resolved);edges.append({'from':str(path.relative_to(dest)),'to':str(resolved.relative_to(dest.resolve()))})
  graph[path.resolve()]=targets
 reachable=[]
 for name in roots:
  entry=(dest/namespace/name/'SKILL.md').resolve();queue=[entry];seen=set()
  while queue:
   n=queue.pop(0)
   if n in seen:continue
   seen.add(n);queue.extend(graph.get(n,[]))
  for method in ('feature','refactoring'):
   own=(dest/namespace/name/'references'/f'{method}.md').resolve();assert own.read_bytes()==(W/'osstack-methods-skill/references'/f'{method}.md').read_bytes()
   hits=[n for n in seen if n.name==method+'.md' and n.parent.name=='references'];assert hits
   reachable.append({'entry':name,'method':method,'own_copy_exact':True,'reachable_method_paths':sorted(str(n.relative_to(dest.resolve()))for n in hits)})
 checks.append({'host':host,'files':48,'export_exit':0,'manifest_all_bytes_hashes_verified':True,'local_edges_checked':len(edges),'entry_method_reachability':reachable,'edges':edges})
 # Independent missing-file falsifier against an exported real artifact: reachability validator rejects disappearance.
 victim=dest/namespace/'osstack-mode/references/refactoring.md';original=victim.read_bytes();victim.unlink()
 try:
  assert any(not (dest/e['to']).is_file()for e in edges if e['to'].endswith('/references/refactoring.md'))
 finally:victim.write_bytes(original)
 assert sha(victim.read_bytes())==sha(original)
p=run('focused-author-tests',[NODE,'--test','--test-name-pattern=D2a|document-named source router|source and mode routers','scripts/export-osstack-methods.test.mjs'],60);assert p.returncode==0

result={'candidate':C,'baseline':B,'criteria_sha256':'4017c621bcc8f0e60e6bec25fc0bd2a0677fa6aba24dc3f75863ab51e8139a51','source_files':source,'allowed_changed_paths':changes,'exporter_production_unchanged':True,'six_existing_method_evidence_templates_unchanged':True,'commands':cmds,'exports':checks,'missing_export_reference_falsifier':'both host layouts: removed own mode refactoring file only in scratch; independent graph existence check rejected; exact bytes restored','working_tree_unchanged':True,'runtime_model_calls':0,'formal_gate_issued':False}
(O/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'candidate':C,'hosts':[{'host':x['host'],'files':x['files'],'local_edges':x['local_edges_checked'],'entry_method_pairs':len(x['entry_method_reachability'])}for x in checks],'commands_exit':[x['exit_code']for x in cmds],'checks_sha256':sha((O/'checks.json').read_bytes())},indent=2))
