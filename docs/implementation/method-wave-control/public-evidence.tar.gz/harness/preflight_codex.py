from common import ROOT,H,env,save,now,sha,inventory,stop
from pathlib import Path
import subprocess,shutil,json,queue,threading,sys

def main(phase):
 case=ROOT/'runs'/('codex-'+phase);ev=case/'evidence';ws=case/'workspace';(case/'private-home').mkdir()
 record={'at':now(),'phase':phase,'user_turns':0,'model_calls':0,'status':'preflight_started'};p=None
 try:
  resolve_js="const {createRequire}=require('module');const path=require('path');const r=createRequire('/opt/homebrew/lib/node_modules/@openai/codex/bin/codex.js');const dir=path.dirname(r.resolve('@openai/codex-darwin-arm64/package.json'));console.log(path.join(dir,'vendor/aarch64-apple-darwin/bin/codex'));"
  vendor=Path(subprocess.check_output(['/opt/homebrew/opt/node@22/bin/node','-e',resolve_js],text=True).strip()).resolve(strict=True)
  record['binaries']=[{'path':str(x.resolve()),'bytes':x.stat().st_size,'sha256':sha(x)}for x in [Path('/opt/homebrew/bin/codex'),vendor]]
  e=env(case,'codex',True);v=subprocess.run([str(vendor),'--version'],env=e,cwd=ws,capture_output=True,timeout=10);record['version']=v.stdout.decode().strip();record['version_exit']=v.returncode
  schema=ev/'schema';q=subprocess.run([str(vendor),'app-server','generate-json-schema','--out',str(schema)],env=e,cwd=ws,capture_output=True,timeout=20);(ev/'schema.stdout').write_bytes(q.stdout);(ev/'schema.stderr').write_bytes(q.stderr)
  if q.returncode:raise RuntimeError('local schema generation failed')
  auth=subprocess.run([str(vendor),'login','status'],env=e,cwd=ws,capture_output=True,timeout=20);record['authenticated']=auth.returncode==0 and b'Logged in'in(auth.stdout+auth.stderr)
  if not record['authenticated']:raise RuntimeError('isolated existing authentication unavailable')
  before=inventory(ws);save(ev/'catalog-before.json',before)
  argv=[str(vendor),'app-server','--listen','stdio://'];record.update(argv=argv,cwd=str(ws),process_started_at=now(),native_catalog_process_separate_from_exec=True)
  with(ev/'catalog.jsonl').open('xb')as out,(ev/'catalog.stderr').open('xb')as err:
   p=subprocess.Popen(argv,cwd=ws,env=e,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,start_new_session=True)
   record['pid']=p.pid;lines=queue.Queue()
   def reader():
    try:
     for line in p.stdout:lines.put(line)
    finally:lines.put(None)
   threading.Thread(target=reader,daemon=True).start()
   def send(x):p.stdin.write((json.dumps(x)+'\n').encode());p.stdin.flush()
   def receive(id):
    import time
    end=time.monotonic()+20
    while time.monotonic()<end:
     try:line=lines.get(timeout=max(0,end-time.monotonic()))
     except queue.Empty:break
     if line is None:break
     out.write(line);out.flush();x=json.loads(line)
     if x.get('id')==id:
      if'error'in x:raise RuntimeError('native RPC error')
      return x['result']
    raise TimeoutError('native catalog deadline')
   send({'id':0,'method':'initialize','params':{'clientInfo':{'name':'osstack_verification_journey','version':'1'}}});receive(0);send({'method':'initialized','params':{}})
   send({'id':1,'method':'skills/list','params':{'cwds':[str(ws)],'forceReload':True}});catalog=receive(1);save(ev/'catalog.json',catalog)
   send({'id':2,'method':'model/list','params':{}});models=receive(2);save(ev/'models.json',models)
   skills=[s for x in catalog.get('data',[])for s in x.get('skills',[])];wanted=[s for s in skills if s.get('name')in ['osstack-mode','osstack-help','setup-osstack','osstack-agent']]
   if len(wanted)!=4 or any(not s.get('path','').startswith(str(ws/'z').removesuffix('z')+'.agents/skills/')for s in wanted):raise RuntimeError('native target catalog missing/overridden')
   default=[x for x in models.get('data',[])if x.get('isDefault')is True]
   if len(default)!=1:raise RuntimeError('default model not uniquely established')
   record.update(status='catalog_auth_schema_observed',model=default[0].get('model',default[0].get('id')),target_skills=[{'name':x['name'],'path':x['path']}for x in wanted])
  after=inventory(ws);save(ev/'catalog-after.json',after);record['complete_workspace_inventory_unchanged']=before==after
 except Exception as ex:record.update(status='blocked',error=str(ex))
 finally:
  if p:
   p.stdin.close();stop(p);record.update(exit_code=p.returncode,process_finished_at=now())
  if(case/'private-home').exists():shutil.rmtree(case/'private-home')
  record.update(finished=now(),private_home_removed=not(case/'private-home').exists());save(ev/'preflight.json',record)
 print(json.dumps(record,indent=2))
if __name__=='__main__':
 if len(sys.argv)!=2 or sys.argv[1]not in ['phase1','phase2']:raise SystemExit('phase1|phase2')
 main(sys.argv[1])
