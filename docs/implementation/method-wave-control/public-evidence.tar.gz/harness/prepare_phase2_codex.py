from common import ROOT,save,sha,now
from pathlib import Path
import json,shutil
case=ROOT/'runs/codex-phase2';ws=case/'workspace';dest=ws/'inputs';original=ROOT/'coordinator/codex';copied=dest/'coordinator'
if copied.exists():raise RuntimeError('phase2 inputs already prepared')
shutil.copytree(original,copied)
source=ROOT/'runs/codex-phase1/evidence/final-response.txt';shutil.copyfile(source,dest/'phase1-response.txt')
journey=copied/'journey';verified=[]
for base,manifest in [(journey,journey/'journey-manifest.json')]+[(journey/'cases'/c,journey/'cases'/c/'manifest.json')for c in ['healthy','missing-ref']]:
 for row in json.loads(manifest.read_text())['files']:
  p=base/row['path']
  if p.stat().st_size!=row['bytes']or sha(p)!=row['sha256']:raise RuntimeError('retained bytes mismatch')
 verified.append({'manifest':str(manifest.relative_to(ws)),'sha256':sha(manifest),'member_count':len(json.loads(manifest.read_text())['files']),'member_bytes_checked_by':'coordinator preparation script, not model'})
projection=[]
for c in ['healthy','missing-ref']:
 p=journey/'cases'/c/'bindings.json';d=json.loads(p.read_text());projection.append({'case_id':c,'original_path':str(p.relative_to(ws)),'original_bytes':p.stat().st_size,'original_sha256':sha(p),'groups':{k:{'declared_digest':v.get('digest'),'file_count':len(v.get('files',[]))}for k,v in d.items()if isinstance(v,dict)},'limits':'Projection of driver-declared binding groups only. Retained-file bytes checked by coordinator. No independent post-closeout live-file rehash or compiler attestation.'})
save(dest/'coordinator-evidence-index.json',{'at':now(),'actor':'coordinator actually executed one fixed wrapper; model did not execute','driver_source_commit':'66ad1daa229101e4501392bbe1d6b4d86b7ca16b','execution_result':'inputs/coordinator/result.json','stdout':'inputs/coordinator/stdout','stderr':'inputs/coordinator/stderr','journey_receipt':'inputs/coordinator/journey/journey.json','journey_manifest':'inputs/coordinator/journey/journey/journey-manifest.json'.replace('/journey/journey/','/journey/'),'per_case':[{ 'case_id':c,'receipt':f'inputs/coordinator/journey/cases/{c}/receipt.json','cleanup':f'inputs/coordinator/journey/cases/{c}/cleanup.json','manifest':f'inputs/coordinator/journey/cases/{c}/manifest.json','raw_command':f'inputs/coordinator/journey/cases/{c}/{c}.command.json','raw_stdout':f'inputs/coordinator/journey/cases/{c}/{c}.stdout','raw_stderr':f'inputs/coordinator/journey/cases/{c}/{c}.stderr'}for c in ['healthy','missing-ref']],'retained_bytes_verified':verified,'bindings_projection':projection,'path_mapping':'Original absolute paths inside receipts identify the real coordinator execution. For this model call read only corresponding copied files under inputs/coordinator; originals remain outside allowed workspace. Absolute paths are not rewritten inside raw receipts.','reading_strategy':'Start small receipts/cleanup and pertinent original command outputs. Full binding lists remain available but are large; reading this projection does not establish that you read or verified those full lists.'})
files=[{'path':str(p.relative_to(ws)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(dest.rglob('*'))if p.is_file()and p.name!='index.json']
save(dest/'index.json',{'phase':'evidence_read_only','material_source_commit':'f5e8d234a604ba39d78dfed21ae072d6ef2e3cca','driver_source_commit':'66ad1daa229101e4501392bbe1d6b4d86b7ca16b','phase1_response':'inputs/phase1-response.txt','evidence_index':'inputs/coordinator-evidence-index.json','scope':['healthy','missing-ref'],'files':files,'limits':'Coordinator execution only. Model is read-only. No source repair or omitted-case execution. Wrapper native-host/model not_run fields describe the auth-free wrapper, separately from this read-only host experiment.'})
print(json.dumps({'copied_files':len(files),'retained_manifests_checked':len(verified),'model_calls':0}))
