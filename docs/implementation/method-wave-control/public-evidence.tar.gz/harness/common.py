from pathlib import Path
import os,json,hashlib,subprocess,datetime,selectors,time,signal,shutil
ROOT=Path(__file__).resolve().parent.parent
H=ROOT/'harness';USER=Path('/Users/osborn')
PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def env(case,host,auth=False):
 home=case/'private-home';tmp=home/'tmp';tmp.mkdir(exist_ok=True)
 result={'PATH':PATH,'HOME':str(home),'TMPDIR':str(tmp),'LANG':'en_US.UTF-8','OSSTACK_HOME':str(home/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}
 if host=='codex':
  private=home/'.codex';private.mkdir(exist_ok=True);result['CODEX_HOME']=str(private)
  if auth:
   destination=private/'auth.json'
   if not destination.exists():
    with destination.open('xb') as f:f.write((USER/'.codex/auth.json').read_bytes())
    destination.chmod(0o600)
 else:
  private=home/'.claude';private.mkdir(exist_ok=True);result['CLAUDE_CONFIG_DIR']=str(private)
  if auth:
   key=subprocess.run(['/usr/bin/security','find-generic-password','-s','Claude Code-credentials','-w'],capture_output=True,timeout=10)
   if key.returncode:raise RuntimeError('existing Claude credential unavailable; raw credential output suppressed')
   credential=json.loads(key.stdout).get('claudeAiOauth',{});token=credential.get('accessToken')
   if not token:raise RuntimeError('existing Claude access token absent')
   if credential.get('expiresAt',0)<=time.time()*1000:raise RuntimeError('existing Claude access token expired; do not refresh default credentials')
   result['CLAUDE_CODE_OAUTH_TOKEN']=token
 return result

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def inventory(root):
 import stat
 root=Path(root); result={}
 def visit(path):
  st=path.lstat();rel=str(path.relative_to(root));row={'length':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
  if stat.S_ISDIR(st.st_mode):row['type']='directory'
  elif stat.S_ISREG(st.st_mode):row.update(type='file',sha256=sha(path))
  elif stat.S_ISLNK(st.st_mode):row.update(type='symlink',target=os.readlink(path))
  else:raise RuntimeError('unhandled filesystem type: '+rel)
  result[rel]=row
  if row['type']=='directory':
   for child in sorted(path.iterdir()):visit(child)
 visit(root);return result

def stop(p):
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
