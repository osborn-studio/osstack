"""Prepare immutable phase1 copies and UNAPPROVED root dispatch templates. No host calls."""
from common import ROOT,H,save,now,sha,inventory
from pathlib import Path
import subprocess,json,sys
REPO=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack')
MATERIAL='f5e8d234a604ba39d78dfed21ae072d6ef2e3cca'
CRITERIA=ROOT.parent/'independent/host-journey/criteria-prefreeze.json'
CRITERIA_SHA='43089390e2d7344fe2690d297d2381a8ca3bfa381a50d79596503567e005829b'
INPUTS=['scripts/method-verification-journey.mjs','scripts/smoke-skills-check.mjs','scripts/lib/skills-check-verification.mjs','scripts/lib/scratch.mjs','docs/implementation/method-verification-journey/README.md','docs/implementation/skills-check-verification/spec.md']
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def file(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def main(commit,checkout):
 if sha(CRITERIA)!=CRITERIA_SHA:raise RuntimeError('independent criteria mismatch')
 commit=git('rev-parse',commit+'^{commit}').decode().strip();checkout=Path(checkout).resolve()
 if subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD']).decode().strip()!=commit:raise RuntimeError('driver checkout mismatch')
 dest=ROOT/'phase1-final-binding';dest.mkdir() # exclusive: preserve prior preparations
 for host in ['codex','claude']:
  case=ROOT/'runs'/(host+'-phase1');ws=case/'workspace'
  if (case/'evidence/run-before.json').exists():raise RuntimeError('phase1 already used')
  original=ws/'inputs/index.json';(dest/(host+'-index-before.json')).write_bytes(original.read_bytes())
  rows=[]
  for name in INPUTS:
   data=git('show',commit+':'+name);p=ws/'inputs/driver'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
   rows.append({'path':str(p.relative_to(ws)),'source_path':name,'bytes':len(data),'sha256':sha(p)})
  save(original,{'experiment':'host-assisted verification journey','phase':'plan_only_no_execution','material_source_commit':MATERIAL,'driver_source_commit':commit,'fixed_scope':['healthy','missing-ref'],'files':rows,'coordinator_execution':{'status':'not_run','checkout':str(checkout),'argv':['/opt/homebrew/opt/node@22/bin/node',str(checkout/'scripts/method-verification-journey.mjs'),'--output','<new coordinator-owned evidence directory>'],'full_test_queue':'root must release execution after its full tests finish','build_status':'root reported fresh frozen install/build; this input does not independently attest compiler invocation'},'reading_boundary':'Only supplied workspace files; do not access the real checkout or execute driver. Native host skills are separate from these task inputs. No completed behavior evidence exists yet.'})
 protocol=json.loads((ROOT/'protocol.json').read_text());save(dest/'protocol-before.json',protocol)
 protocol.update(status='phase1_inputs_bound_awaiting_independent_check_and_root_dispatch',driver_source_commit=commit,driver_hint='exact root delivery candidate; phase1 read-only, actual coordinator execution requires separate approval after root full tests',binding_at=now())
 save(ROOT/'protocol.json',protocol)
 binding={'at':now(),'material_source_commit':MATERIAL,'driver_source_commit':commit,'driver_tree':git('rev-parse',commit+'^{tree}').decode().strip(),'driver_checkout':str(checkout),'criteria':file(CRITERIA),'model_calls_performed':0,'driver_runs_performed':0,'inputs':INPUTS,'scope':'Preparation only. Templates require root approval. No runtime/provider/J gate.'}
 save(dest/'source-binding.json',binding)
 for host in ['codex','claude']:
  case=ROOT/'runs'/(host+'-phase1');ws=case/'workspace';paths=set()
  for base in [ROOT/'source',H,ROOT/'identity',case/'workspace',case/'state']:
   for p in base.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith('dispatch-'):paths.add(p)
  for p in [ROOT/'protocol.json',ROOT/'plan.md',ROOT/'material-binding.json',dest/'source-binding.json',CRITERIA,case/'evidence/export-manifest.json']:paths.add(p)
  if host=='codex':
   preflight=case/'evidence/preflight.json';paths.add(preflight)
   for p in (case/'evidence/schema').rglob('*'):
    if p.is_file():paths.add(p)
   for row in json.loads(preflight.read_text())['binaries']:paths.add(Path(row['path']))
   model=json.loads(preflight.read_text())['model']
  else:
   paths.add(case/'evidence/catalog-final-result.json');paths.add(case/'evidence/catalog-final.jsonl')
   paths.add(Path(json.loads((ROOT/'identity/claude.json').read_text())['binary']['path']))
  guard={'approved':False,'approval_owner':'root','phase':'phase1','host':host,'material_source_commit':MATERIAL,'driver_source_commit':commit,'runner_sha256':sha(H/('run_'+host+'.py')),'prompt_sha256':sha(H/'phase1-prompt.txt'),'criteria_sha256':CRITERIA_SHA,'workspace_inventory':inventory(ws),'frozen_files':[file(p)for p in sorted(paths)],'maximum_calls_this_guard':1,'automatic_retry':False}
  if host=='codex':guard['codex_model']=model
  save(dest/(host+'-dispatch-template.json'),guard)
 save(dest/'manifest.json',{'at':now(),'files':[file(p)for p in sorted(dest.iterdir()) if p.is_file()],'root_live_guard_paths':[str(H/('dispatch-'+host+'-phase1.json'))for host in ['codex','claude']],'commands':[['python3',str(H/'run_codex.py'),'phase1'],['python3',str(H/'run_claude.py'),'run','phase1']],'model_calls_performed':0})
 print(json.dumps({'binding':str(dest),'model_calls_performed':0}))
if __name__=='__main__':
 if len(sys.argv)!=3:raise SystemExit('FINAL_DRIVER_COMMIT BUILT_CHECKOUT')
 main(*sys.argv[1:])
