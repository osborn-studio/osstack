"""One explicitly authorized coordinator run, never model-generated shell."""
from common import ROOT,PATH,now,save,sha,stop
from pathlib import Path
import os,json,subprocess,signal,shutil
CHECKOUT=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-verification-journey')
COMMIT='66ad1daa229101e4501392bbe1d6b4d86b7ca16b'
base=ROOT/'coordinator';base.mkdir(exist_ok=True)
ev=base/'codex';ev.mkdir() # exclusive no retry
home=ev/'private-home';home.mkdir();(home/'tmp').mkdir()
output=ev/'journey';node=Path('/opt/homebrew/opt/node@22/bin/node')
args=[str(node),str(CHECKOUT/'scripts/method-verification-journey.mjs'),'--output',str(output)]
env={'PATH':PATH,'HOME':str(home),'TMPDIR':str(home/'tmp'),'LANG':'en_US.UTF-8','OSSTACK_HOME':str(home/'unused-osstack'),'OSSTACK_SCRATCH_ROOT':'/Volumes/AIMATE_WORK/tmp/osstack'}
record={'at':now(),'actor':'coordinator operating fixed predeclared argv, not model','host_journey':'codex','driver_source_commit':COMMIT,'argv':args,'cwd':str(CHECKOUT),'environment':env,'timeout_seconds':420,'retry':False,'model_auth_environment_present':False,'model_calls':0,'node_binary_sha256':sha(node),'source_before':[]};p=None
try:
 actual=subprocess.check_output(['git','-C',str(CHECKOUT),'rev-parse','HEAD']).decode().strip()
 if actual!=COMMIT:raise RuntimeError('source HEAD mismatch')
 for rel in ['scripts/method-verification-journey.mjs','scripts/smoke-skills-check.mjs','scripts/lib/skills-check-verification.mjs','scripts/lib/scratch.mjs']:
  path=CHECKOUT/rel;expected=subprocess.check_output(['git','-C',str(CHECKOUT),'show',COMMIT+':'+rel])
  if path.read_bytes()!=expected:raise RuntimeError('driver source bytes changed: '+rel)
  record['source_before'].append({'path':str(path),'sha256':sha(path)})
 save(ev/'command.json',record)
 with(ev/'stdout').open('xb')as out,(ev/'stderr').open('xb')as err:
  p=subprocess.Popen(args,cwd=CHECKOUT,env=env,stdout=out,stderr=err,start_new_session=True);record['pid']=p.pid
  try:p.wait(timeout=420);record['timed_out']=False
  except subprocess.TimeoutExpired:
   record['timed_out']=True;os.killpg(p.pid,signal.SIGTERM);stop(p)
 record.update(exit_code=p.returncode,status='observed_pending_independent_verification'if p.returncode==0 and not record['timed_out']else'failed_no_retry')
except Exception as ex:record.update(status='blocked_no_retry',error=str(ex))
finally:
 if p and p.poll()is None:os.killpg(p.pid,signal.SIGTERM);stop(p)
 record['source_after']=[{'path':r['path'],'sha256':sha(r['path'])}for r in record['source_before']]
 record['source_unchanged']=record['source_before']==record['source_after']
 if home.exists():shutil.rmtree(home)
 record.update(finished=now(),private_home_removed=not home.exists(),retained_output=str(output),descendant_termination='not_attested')
 save(ev/'result.json',record)
print(json.dumps(record,indent=2))
