from common import ROOT,H,save,sha,inventory,now
from pathlib import Path
import json
case=ROOT/'runs/codex-phase2';ws=case/'workspace';dest=ROOT/'phase2-final-binding';dest.mkdir()
criteria=ROOT.parent/'independent/host-journey/criteria-prefreeze.json'
grade=ROOT.parent/'independent/host-journey/phase1-graded-results.json'
assert sha(criteria)=='43089390e2d7344fe2690d297d2381a8ca3bfa381a50d79596503567e005829b'
assert sha(grade)=='64d4c5be384b179b2f916de8090afd4842cd1edaaebe3d357db711e80d0f2434'
def file(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
paths=set()
for base in [ROOT/'source',H,ROOT/'coordinator/codex',case/'workspace',case/'state',case/'evidence/schema']:
 for p in base.rglob('*'):
  if p.is_file()and '__pycache__'not in p.parts and not p.name.startswith('dispatch-'):paths.add(p)
for p in [ROOT/'protocol.json',ROOT/'plan.md',ROOT/'material-binding.json',ROOT/'phase1-final-binding/source-binding.json',criteria,grade,case/'evidence/export-manifest.json',case/'evidence/preflight.json',ROOT/'runs/codex-phase1/evidence/final-response.txt',ROOT/'runs/codex-phase1/evidence/run-result.json',ROOT/'runs/codex-phase1/evidence/run.jsonl']:paths.add(p)
preflight=json.loads((case/'evidence/preflight.json').read_text())
for row in preflight['binaries']:paths.add(Path(row['path']))
guard={'approved':False,'approval_owner':'root','host':'codex','phase':'phase2','material_source_commit':'f5e8d234a604ba39d78dfed21ae072d6ef2e3cca','driver_source_commit':'66ad1daa229101e4501392bbe1d6b4d86b7ca16b','runner_sha256':sha(H/'run_codex.py'),'prompt_sha256':sha(H/'phase2-prompt.txt'),'criteria_sha256':sha(criteria),'codex_model':preflight['model'],'workspace_inventory':inventory(ws),'frozen_files':[file(p)for p in sorted(paths)],'maximum_calls_this_guard':1,'automatic_retry':False,'actual_model':'not_attested_unless_execution_stream_exposes_it'}
save(dest/'codex-dispatch-template.json',guard)
save(dest/'manifest.json',{'at':now(),'files':[file(dest/'codex-dispatch-template.json')],'model_calls_performed_so_far':2,'driver_runs_performed':1,'claude':'stopped_after_phase1_507_over_500_no_retry','command':['python3',str(H/'run_codex.py'),'phase2'],'live_guard_path':str(H/'dispatch-codex-phase2.json'),'status':'await_independent_binding_check_and_root_dispatch'})
print(json.dumps({'manifest':str(dest/'manifest.json'),'manifest_sha256':sha(dest/'manifest.json'),'template_sha256':sha(dest/'codex-dispatch-template.json'),'frozen_files':len(paths),'inventory_entries':len(guard['workspace_inventory']),'approved':False}))
