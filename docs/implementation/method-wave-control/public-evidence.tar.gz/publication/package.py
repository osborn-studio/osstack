"""Lossless owned-scratch archive. No model/driver calls, no transcript edits."""
from pathlib import Path
import hashlib,json,stat,tarfile,re,datetime,shutil,os
R=Path(__file__).resolve().parent.parent;P=R/'publication';I=R.parent/'independent/host-journey'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
if not (I/'phase2-graded-results.json').exists():raise SystemExit('Await final independent phase2 grading')
if any(R.rglob('private-home')):raise SystemExit('Private authentication home still present')
copy=P/'independent';copy.mkdir()
independent=[]
for p in sorted(I.rglob('*')):
 if p.is_file()and '__pycache__' not in p.parts:
  dst=copy/p.relative_to(I);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
  independent.append({'source_path':str(p),'archive_path':str(dst.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)})
save(P/'independent-copy-manifest.json',{'files':independent,'byte_changes':False})
excludes={'member-manifest.json','public-evidence.tar.gz','public-evidence.sha256','package-result.json'}
patterns={'anthropic_token':rb'sk-ant-(?:oat|api)[A-Za-z0-9_-]{12,}','openai_key':rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{40,}','jwt_token':rb'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}'}
rows=[];hits=[]
for p in sorted(R.rglob('*')):
 if '__pycache__'in p.parts:continue
 if p.parent==P and p.name in excludes:continue
 if p.name in ['auth.json','.credentials.json']:raise RuntimeError('Authentication file must not be archived')
 st=p.lstat();row={'source_path':str(p),'archive_path':str(p.relative_to(R)),'length':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
 if stat.S_ISDIR(st.st_mode):row['type']='directory'
 elif stat.S_ISREG(st.st_mode):
  row.update(type='file',sha256=sha(p));data=p.read_bytes()
  for name,pattern in patterns.items():
   if re.search(pattern,data):hits.append({'path':row['archive_path'],'pattern':name})
 elif stat.S_ISLNK(st.st_mode):row.update(type='symlink',target=os.readlink(p))
 else:raise RuntimeError('Unsupported file type')
 rows.append(row)
if hits:raise RuntimeError('Credential-like values detected; do not publish')
manifest={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(R),'members':rows,'excluded':'Python bytecode caches and package self artifacts only; no auth homes/files present','credential_pattern_hits':hits,'screening_limit':'Pattern screening not a complete secret or process audit','original_model_or_evidence_bytes_changed':False,'model_calls':3,'coordinator_calls':1,'overall_experiment_pass':False}
save(P/'member-manifest.json',manifest)
archive=P/'public-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for row in rows:t.add(row['source_path'],arcname=row['archive_path'],recursive=False)
 t.add(P/'member-manifest.json',arcname='publication/member-manifest.json',recursive=False)
with tarfile.open(archive)as t:
 for row in rows:
  info=t.getmember(row['archive_path'])
  if row['type']=='file':
   data=t.extractfile(info).read()
   if len(data)!=row['length']or hashlib.sha256(data).hexdigest()!=row['sha256']:raise RuntimeError('Archive member mismatch')
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'manifest_sha256':sha(P/'member-manifest.json'),'members':len(rows)+1,'archive_file_bytes_verified':True,'auth_homes_present':False,'model_calls':3,'coordinator_calls':1,'workspace_cleanup':'not_performed; awaiting_root_instruction_after_independent_reading'}
save(P/'package-result.json',result);(P/'public-evidence.sha256').write_text(result['sha256']+'  public-evidence.tar.gz\n');print(json.dumps(result,indent=2))
