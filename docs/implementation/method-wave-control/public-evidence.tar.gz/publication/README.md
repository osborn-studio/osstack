# Native-method host-assisted verification journey: bounded observations and failures

This archive preserves a new experiment with native exported OSStack methods, source materials at `f5e8d234a604ba39d78dfed21ae072d6ef2e3cca`, and the fixed verification wrapper at `66ad1daa229101e4501392bbe1d6b4d86b7ca16b`. It does not revise the earlier native-help experiment or qualify any formal J gate.

Three model calls were made with no retry: Codex phase1, Claude phase1, Codex phase2. One separate coordinator invocation ran the actual healthy/missing-ref wrapper. Claude phase2 was not called. The models had read-only tasks; neither executed the product driver. Original phase preparation documents retain their original zero-call status and are historical, not current execution totals.

| Observation axis | Result and limit |
| --- | --- |
| Codex phase1 | Native mode/create-verification/evidence reads observed; 407-word plan accepted for the next stage with limits. |
| Claude phase1 | Native Skill mode and create-verification/evidence reads observed; actual modelUsage reports claude-sonnet-5-5. Final 507 words exceeded the frozen 500-word cap. Host stopped: no driver, no phase2, no retry. |
| Coordinator | One fixed, auth-free invocation exited 0. Healthy product exit 0/driver exit 0; missing-ref product exit 1/driver exit 0. Missing-ref remained an unrecovered failed source. Original doctor/command/receipt/manifests/cleanup and full source/build lists are preserved. |
| Codex phase2 | Final 364-word report distinguished the two behaviors and evidence limits. It read provided environment records despite the frozen no-environment-inspection instruction. Preserve this boundary failure/limited result; do not call the whole journey PASS. This was recorded environment data in supplied files, not an observed query of the live environment or credential read. |
| Identity | Codex explicitly requested the isolated catalog default gpt-6.1-sol; the execution stream did not attest its resolved model. Codex catalog and exec were different processes. Actual vendor/launcher fingerprints, catalog PID/timing, local schemas and raw stream are retained. |
| Filesystem/cleanup | All three model calls reported complete before/after workspace inventory equality including .git, type, length, mode and hashes. Private authentication homes were removed after each attempt. Coordinator owned fixtures were removed; descendant termination remains not_attested. Workspace retention/cleanup is a separate later operation. |
| Scope | No autonomous driver execution, source repair, drift/mixed/empty coverage, cross-provider equivalence, causal improvement, authenticated oracle/principal, compiler attestation, provider/runtime qualification or formal gate pass. |

## Evidence map

- `harness/`: exact prompts, runners and dependencies, root dispatch guards and authorization records. Guards bind inputs and before inventories; they do not authorize replay. Exclusive per-run markers prevent reuse.
- `source/` and `material-binding.json`: exact material Git copies and original exporter sources. Native exports live in each owned workspace; no skill body was inserted into the user prompt.
- `phase1-final-binding/` and `phase2-final-binding/`: unapproved templates, full file hashes and workspace inventories; root live approvals are separate under harness.
- `runs/*/evidence/`: raw model streams, stderr, catalog/preflight/schema, original before/after inventories, status and responses. Claude's initialize account identity was redacted by the original runner; model/tool lines were retained as emitted. No later transcript redaction or rewriting was performed.
- `coordinator/codex/`: actual fixed command/environment, raw stdout/stderr/result and all original journey evidence. `runs/codex-phase2/workspace/inputs/` contains byte-identical copies plus the disclosed compact binding projection. The projection does not replace the retained full lists or attest live files.
- `publication/independent/`: unchanged independent prefreeze, binding checks and grading, copied with original hashes.
- `publication/member-manifest.json`: each archive member's original absolute path, relative archive path, type, length, mode, file hash or symlink target. The archive excludes only Python bytecode caches and its own generated package/checksum artifacts. Authentication homes and auth files must be absent before packaging.

Absolute execution paths inside original records remain unchanged. Copies in the archive are evidence, not executable installations. Original inventories describe the original filesystem; extraction on another filesystem may change directory sizes or metadata.

## Follow-up improvements, not retroactive fixes

For a separately authorized future experiment, prepare the model-facing receipt view before freezing criteria. Either omit environment values and retain hash-bound raw originals outside the model workspace, or explicitly permit inspection of designated non-secret recorded fields. Do not silently relax the current prohibition. Keep model response length comfortably below the cap; do not truncate the original 507-word response to make it pass. Explicitly retain independent scoring and actual model identity limits. No such follow-up was run in this batch.

Publication screening checks known credential patterns and absence of authentication filenames; it is not proof of complete secret absence or a whole-process security audit. Original auth-free environment records are intentionally retained. No secrets were copied to this archive.
