from pathlib import Path
import json,hashlib,stat,datetime
H=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/host-journey');O=H.parent/'independent/host-journey';C=H/'coordinator/codex';J=C/'journey';W=H/'runs/codex-phase2/workspace';sha=lambda b:hashlib.sha256(b).hexdigest();get=lambda p:json.loads(p.read_text())
def members(root,manifest):
 m=get(root/manifest);seen=set()
 for f in m['files']:
  p=Path(f['path']);assert not p.is_absolute() and '..'not in p.parts and str(p)not in seen;seen.add(str(p));t=root/p;assert t.is_file()and not t.is_symlink();b=t.read_bytes();assert len(b)==f['bytes']and sha(b)==f['sha256']
 return m
run=get(C/'result.json');assert run['exit_code']==0 and not run['timed_out'] and run['model_calls']==0 and not run['model_auth_environment_present'];assert run['source_before']==run['source_after'];assert not Path(run['environment']['HOME']).exists();assert not any('TOKEN'in k or 'KEY'in k or k in ['CODEX_HOME','CLAUDE_CONFIG_DIR','OSSTACK_SOCKET']for k in run['environment'])
journey=get(J/'journey.json');assert(C/'stdout').read_bytes()==(J/'journey.json').read_bytes();assert(C/'stderr').read_bytes()==b'';assert journey['status']=='passed';jm=members(J,'journey-manifest.json');observations=[]
for id,exit in [('healthy',0),('missing-ref',1)]:
 d=J/'cases'/id;m=members(d,'manifest.json');assert len(m['files'])==29;assert set(p.name for p in d.iterdir())==set(x['path']for x in m['files'])|{'manifest.json'}
 r=get(d/'receipt.json');detail=get(d/f'{id}.json');cmd=get(d/f'{id}.command.json');cleanup=get(d/'cleanup.json');inp=get(d/f'{id}.input.json');expected=get(d/'expectations.json')['definitions'][0]
 assert(J/f'{id}-drive.stdout').read_bytes()==(d/'receipt.json').read_bytes();assert r['status']=='passed'and r['driver_exit']==0 and r['cases'][0]['actual_exit']==exit and cmd['exit_code']==exit;assert r['cleanup']==cleanup and cleanup['status']=='passed'and cleanup['fixture_removed']and cleanup['descendant_termination']=='not_attested';fixture=Path(cleanup['fixture_path']);assert fixture.parent==J/'scratch/smoke'and not fixture.exists();assert expected['sources']==inp['sources'];assert inp['sources'][0]['origin']==(fixture/'origin').as_uri()
 raw=(d/f'{id}.stdout').read_text();assert(d/f'{id}.stderr').read_bytes()==b'';assert f'{exit} source(s) failed to check.'in raw and '0 source(s) drifted from blessed_sha.'in raw;assert('unreachable: no_matching_ref'in raw)==(id=='missing-ref');assert('up-to-date'in raw)==(id=='healthy');assert detail['manifest_before_sha256']==detail['manifest_after_sha256']==sha((d/f'{id}.input.json').read_bytes());assert expected['current_sha']==(d/'git-05.stdout').read_text().strip();assert expected['sources'][0]['blessed_sha']==expected['current_sha']
 for row in get(d/'run.json')['commands']:
  cr=get(d/row['record']);assert cr['exit_code']==row['exit_code'];assert cr['direct_child_exit_confirmed']and not cr['signal']and not cr['timed_out'];
  for stream in ['stdout','stderr']:assert sha((d/cr[stream+'_path']).read_bytes())==cr[stream+'_sha256']
 doctor=get(J/f'{id}-doctor.command.json');drive=get(J/f'{id}-drive.command.json');assert doctor['exit_code']==drive['exit_code']==0 and doctor['ended_at']<=drive['started_at'];do=get(J/f'{id}-doctor.stdout');assert do['ready']and not do['executed']and do['cases']==[id]
 assert any(x['case_id']==id and x['verified']and x['sha256']==sha((d/'manifest.json').read_bytes())for x in jm['case_manifests']);observations.append({'case_id':id,'product_exit':exit,'driver_exit':0,'members_verified':29,'fixture_absent':True,'manifest_sha256':sha((d/'manifest.json').read_bytes())})
assert [x.name for x in(J/'scratch').iterdir()]==['smoke'];assert not list((J/'scratch/smoke').iterdir());assert (J/'cases/healthy/bindings.json').read_bytes()==(J/'cases/missing-ref/bindings.json').read_bytes()
manifest=H/'phase2-final-binding/manifest.json';assert sha(manifest.read_bytes())=='5df365bc52037379f15e09711c9328e62dbbcde42f2a1b00ecc6ffe80dd03eb5'
for f in get(manifest)['files']:assert sha(Path(f['path']).read_bytes())==f['sha256'] and Path(f['path']).stat().st_size==f['bytes']
t=get(H/'phase2-final-binding/codex-dispatch-template.json');assert not t['approved']and t['maximum_calls_this_guard']==1 and not t['automatic_retry'];assert t['criteria_sha256']=='43089390e2d7344fe2690d297d2381a8ca3bfa381a50d79596503567e005829b'
for f in t['frozen_files']:
 p=Path(f['path']);assert p.name!='auth.json'and'private-home'not in p.parts;assert sha(p.read_bytes())==f['sha256']and p.stat().st_size==f['bytes']
inventory={}
for p in [W]+sorted(W.rglob('*')):
 st=p.lstat();r={'length':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
 if stat.S_ISREG(st.st_mode):r.update(type='file',sha256=sha(p.read_bytes()))
 elif stat.S_ISDIR(st.st_mode):r['type']='directory'
 else:raise AssertionError('nonregular path')
 inventory[str(p.relative_to(W))]=r
assert inventory==t['workspace_inventory']
idx=get(W/'inputs/index.json')
for f in idx['files']:
 p=W/f['path'];assert len(p.read_bytes())==f['bytes']and sha(p.read_bytes())==f['sha256']
 if f['path'].startswith('inputs/coordinator/'):assert p.read_bytes()==(C/Path(f['path']).relative_to('inputs/coordinator')).read_bytes()
assert(W/'inputs/phase1-response.txt').read_bytes()==(H/'runs/codex-phase1/evidence/final-response.txt').read_bytes()
proj=get(W/'inputs/coordinator-evidence-index.json')
for row in proj['bindings_projection']:
 b=(W/row['original_path']).read_bytes();assert len(b)==row['original_bytes']and sha(b)==row['original_sha256'];groups=json.loads(b)
 for k,v in row['groups'].items():assert v['declared_digest']==groups[k]['digest']and v['file_count']==len(groups[k]['files'])
assert not(H/'harness/dispatch-codex-phase2.json').exists();assert not(H/'runs/codex-phase2/evidence/run-before.json').exists()
out={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'criteria_sha256':t['criteria_sha256'],'phase2_manifest_sha256':sha(manifest.read_bytes()),'coordinator_result_sha256':sha((C/'result.json').read_bytes()),'coordinator_observations':observations,'journey_members_verified':len(jm['files']),'copied_inputs_verified':len(idx['files']),'guard_frozen_files_verified':len(t['frozen_files']),'complete_inventory_entries':len(inventory),'projection_matches_full_retained_originals':True,'recommendation':'Root may dispatch Codex phase2 once with exact reviewed template; Claude remains stopped.','limits':['No compiler proof or complete live source/build rehash; declarations and retained bytes are checked.','No model call or guard approval by reviewer.','No descendant termination attestation or formal J gate.']};(O/'phase2-binding-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));print('report_sha256',sha((O/'phase2-binding-check.json').read_bytes()))
