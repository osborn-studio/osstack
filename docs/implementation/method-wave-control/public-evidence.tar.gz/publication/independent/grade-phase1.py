from pathlib import Path
import json,hashlib,stat,re,datetime
H=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/host-journey');O=H.parent/'independent/host-journey';sha=lambda b:hashlib.sha256(b).hexdigest()
def inventory(root):
 d={}
 for p in [root]+sorted(root.rglob('*')):
  s=p.lstat();v={'length':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISREG(s.st_mode):v.update(type='file',sha256=sha(p.read_bytes()))
  elif stat.S_ISDIR(s.st_mode):v['type']='directory'
  else:raise AssertionError('unexpected nonregular path')
  d[str(p.relative_to(root))]=v
 return d
results=[];artifacts=[]
for host in ['codex','claude']:
 case=H/f'runs/{host}-phase1';ev=case/'evidence';ws=case/'workspace';raw=(ev/'run.jsonl').read_bytes();events=[json.loads(x)for x in raw.splitlines()];run=json.loads((ev/'run-result.json').read_text());before=json.loads((ev/'run-before.json').read_text());after=json.loads((ev/'run-after.json').read_text());assert before==after==inventory(ws);assert not(case/'private-home').exists()
 reads=[];tool_trace=[]
 if host=='codex':
  final=[x['item']['text']for x in events if x.get('type')=='item.completed'and x.get('item',{}).get('type')=='agent_message'][-1]
  for i,x in enumerate(events,1):
   t=x.get('item',{})
   if x.get('type')=='item.completed'and t.get('type')=='command_execution':
    command=t['command'];tool_trace.append({'line':i,'command':command,'exit':t['exit_code']});assert t['exit_code']==0
    if command.startswith("/bin/zsh -lc "):
     match=re.fullmatch(r'''/bin/zsh -lc ['"]cat ['"]?([^'" ]+)['"]?['"]''',command)
     if match:
      p=ws/match[1];b=t['aggregated_output'].encode();reads.append({'line':i,'path':match[1],'sha256':sha(b),'complete_bytes_equal':b==p.read_bytes()})
  assert all(r['complete_bytes_equal']for r in reads)
  assert any(r['path']=='.agents/skills/osstack-mode/SKILL.md'for r in reads)
  for name in ['create-verification','evidence']:assert any(r['path']==f'.agents/skills/osstack-mode/references/{name}.md'for r in reads)
  actual_model='not_attested';catalog='separate app-server helper observed exact four entries; actual execution consumed their material via read-only shell; no native Skill event claimed'
 else:
  finals=[x for x in events if x.get('type')=='result'];assert len(finals)==1;final=finals[0]['result'];assert list(finals[0]['modelUsage'])==['claude-sonnet-5-5'];actual_model='claude-sonnet-5-5, confirmed by system init/message/modelUsage'
  tool_inputs={}
  for i,x in enumerate(events,1):
   for b in x.get('message',{}).get('content',[]) if isinstance(x.get('message',{}).get('content'),list)else []:
    if b.get('type')=='tool_use':tool_inputs[b['id']]=b;tool_trace.append({'line':i,'tool':b['name'],'input':b['input']});assert b['name']in ['Skill','Read','Glob','Grep']
    if b.get('type')=='tool_result':
     assert not b.get('is_error');req=tool_inputs.get(b['tool_use_id'])
     if req and req['name']=='Read':
      p=Path(req['input']['file_path']);assert p.is_relative_to(ws);content=b['content'];assert isinstance(content,str)
      text='\n'.join(re.sub(r'^\d+\t','',l)for l in content.splitlines())+'\n';same=text.rstrip('\n')==p.read_text().rstrip('\n');reads.append({'line':i,'path':str(p.relative_to(ws)),'read_content_sha256':sha(content.encode()),'complete_numbered_text_equal':same});assert same
  body=events[5]['message']['content'][0]['text'];expected=(ws/'.claude/skills/osstack-mode/SKILL.md').read_text().split('---',2)[2].lstrip();assert expected.rstrip() in body
  catalog='same-process initialize exact catalog then native Skill(osstack-mode) success and full body expansion lines4-6'
 words=len(final.split());assert words==(407 if host=='codex'else 507)
 r={'host':host,'phase':'phase1','verdict':'accepted_for_next_stage_with_limits'if host=='codex'else'failed_answer_limit_stop_host','final_whitespace_words':words,'word_limit':500,'route':'create-verification','route_status':'passed','catalog':catalog,'reads':reads,'tool_trace':tool_trace,'answer':{'plan_scope':'fixed healthy/missing-ref; no execution claimed','word_limit':'passed'if words<=500 else'failed','product_driver_distinction':'explicit products0/1 versus driver0'if host=='codex'else'products0/1 versus overall wrapper0; per-child driver0 not explicit','cleanup_precision':'empty smoke subdirectory and descendant not attested'if host=='codex'else'says scratch directory empty; actual wrapper retains empty smoke child, so wording is imprecise','source_read_scope':'source sections plus relevant methods/documents; do not infer compiler or runtime check'if host=='codex'else'four scripts explicitly unread; methods and documents read','retry_wording':'generic fresh-output retry mention is not experiment authorization; no retry permitted'},'model':{'requested':'gpt-6.1-sol'if host=='codex'else'claude-sonnet-5-5','actual':actual_model},'boundary_trace':'only allowed workspace material reads observed; no product execution/write/network tool/credentials/agent use','workspace_inventory':{'before_equals_after_and_current':True,'entries':len(before),'includes_git':'.git'in before},'cleanup':{'private_home_absent':True,'workspace':'retained for this byte check; later cleanup requires separate receipt','descendants':'not_attested'},'exit_code':run['exit_code'],'execution':'model read/plan call only; coordinator driver not_run','next_step':'root may release coordinator run after full-test queue, then separately freeze phase2'if host=='codex'else'no coordinator run or phase2 for this host; do not retry or waive limit'}
 results.append(r)
 for n in ['run.jsonl','run-result.json','run-before.json','run-after.json']:
  b=(ev/n).read_bytes();artifacts.append({'path':str(ev/n),'bytes':len(b),'sha256':sha(b)})
report={'criteria_sha256':'43089390e2d7344fe2690d297d2381a8ca3bfa381a50d79596503567e005829b','graded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results,'raw_bindings':artifacts,'limits':['Independent agent review, not formal independent principal.','No causal, cross-host equivalence, runtime or all-entry qualification.','Codex actual resolved model unavailable remains not_attested; separate helper catalog is not execution invocation.','Claude length failure retained without retry; old experiment unchanged.']};(O/'phase1-graded-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'reports':[{'host':r['host'],'verdict':r['verdict'],'words':r['final_whitespace_words'],'reads':len(r['reads'])}for r in results],'sha256':sha((O/'phase1-graded-results.json').read_bytes())},indent=2))
