# New host-assisted verification journey — preparation, zero model calls

Card `card_c165fc78`. This is a new actual-use experiment, not a retry of the earlier help task. Old 350-word criteria and limited/inconclusive results remain unchanged. The new final-answer limit is 500 whitespace-separated words per call. Visible intermediate commentary remains archived separately.

## Fixed journey

The predeclared accepted route is create-verification. A maintain-verification or investigation choice is recorded as route mismatch/limited and stops that host; it is not accepted after seeing the answer.

Each host receives two read-only calls, at most 180 seconds each, no retry. Total budget is four calls: Codex phase1/phase2 and Claude phase1/phase2. Phase1 asks native `osstack-mode` to establish a verification seed for exactly `healthy` and `missing-ref`, using the relevant method plus supplied real driver sources. It does not inject any skill body or skill path into the prompt. A coordinator then executes one fixed B wrapper invocation per host. That wrapper owns the two doctor checks and two actual cases. Phase2 receives that host's original receipts and reports a two-row feature map. The model never executes the verification driver or repairs a source.

`harness/phase1-prompt.txt` and `phase2-prompt.txt` contain exact proposed messages. Read-only file inspection is permitted; product execution, edits, installation, credentials, outside-workspace reading, network tools and agent spawning are not. We never evaluate model-written shell text. A missing skill has no explicit-body fallback labeled native discovery.

## Current binding and remaining prerequisite

Material snapshot: `f5e8d234a604ba39d78dfed21ae072d6ef2e3cca`, stored from exact Git objects with source hashes in `material-binding.json`. It supersedes the earlier c099 preparation hint. Four fresh exports have 48 files each; ordinary Git workspaces use an empty Git template. Final driver source is `66ad1daa229101e4501392bbe1d6b4d86b7ca16b` in the author checkout `method-verification-journey`. Root reports its frozen install/build completed, with generated dist retained; this is not an independent compiler attestation. Earlier bfa4/17c5 candidates are not the execution binding. `phase1-final-binding/` binds the exact six Git source/spec inputs, existing exports, local schemas, host binaries, runners, settings and criteria. Root authorization remains required. The separately running full suite uses another checkout and does not write this author build.

B interface reported by its owner: `node scripts/method-verification-journey.mjs --output ABSOLUTE_NEW_ROOT`. There is no wrapper `--doctor` or `--dry-run` flag. Invoke once per host, not once per case. Final CLI interface, receipt schemas and build bindings must be verified from final B Git objects before freeze. No unstable B output has been used as an observation.

## Model and process evidence

Codex uses the isolated authenticated unique default from `model/list`, currently `gpt-6.1-sol`, passed explicitly. If the execution stream does not expose the resolved model, it remains not attested. The native catalog is a separate process; `preflight_codex.py` records its exact native vendor argv, PID, start/end, exit, launcher hash and actual vendor binary hash. Local app-server schema is generated with this binary. This repairs the new experiment's observation plan; it does not change old evidence.

Claude requests `claude-sonnet-5-5`. Its model must be verified from actual init/message/modelUsage records. Its initialize and user turn share one process. The installed version's native outside-workspace read fence is used, without restricted or safe-mode settings that suppress project skills. Permissions expose Skill/Read/Glob/Grep only, allow the four adapted skills, explicitly deny the observed 53 non-target catalog commands, and abort on catalog drift. This is a bounded observed-surface rule, not a universal proof about hidden native skills.

Private HOME/host config contains only the necessary selected existing authentication. Codex copies only auth.json. Claude passes the existing selected OAuth token in memory. Neither copies all host settings. Private state is deleted after every preflight or model attempt. Model-service transport is necessary; no model web tool is exposed. No claim is made about whole-process I/O, credential rotation outside visible artifacts, or OS-wide sandbox equivalence.

Every model call has a complete before/after inventory including .git, directory/file/symlink types, lengths, modes, hashes and symlink targets. Read/stat errors fail closed. Fresh inputs reject symlinks. Phase2 has a separate workspace. Copying actual evidence and phase1 output into it is an explicit coordinator action with a new inventory; the experiment does not claim immutability across that input transition.

## Data supplied to models

Phase1 index: exact material/driver source identities; original wrapper, smoke driver and relevant spec files copied from final Git; the fixed two-case scope; actual execution entry and its existing flags. No prepared answer or independent scoring criteria enter the prompt/workspace. This is an informed use task, not a blind benchmark.

Phase2 index: host's phase1 response, wrapper stdout/stderr/exit, journey.json, feature-map.md, journey-manifest.json, both original child receipts/manifests and relevant original command outputs/cleanup. Keep full originals when feasible. For large source/build lists, retain the original hash and a clearly labeled coordinator-verified projection; a model cannot claim it independently checked unread full lists. The frozen projection procedure selects fields, not successes, and retains failed outcomes.

Expected-negative product failure and successful verification are separate. Driver cleanup preserves `descendant_termination:not_attested`. Unrun drift/mixed/empty and provider/runtime qualification remain unverified. Stop that host's execution on failed prerequisites or unexpected behavior; retain the failure, do not change predicates or fix the product inside this experiment.

## Dispatch and exact command templates

No model-dispatch guard exists yet. Root must approve after independent prefreeze. Each guard binds the applicable final commits, runner/common helpers, prompt, native schema/binaries, exported materials, settings, input inventory and independent criteria. Phase2 additionally binds the actual coordinator evidence. An exclusive before-run marker prevents retry. Four allowed case names are fixed in runners.

```text
python3 harness/preflight_codex.py phase1
python3 harness/run_claude.py catalog phase1
# Repeat no-model preflight for phase2 after its real evidence is supplied.
python3 harness/run_codex.py phase1
python3 harness/run_claude.py run phase1
# Coordinator executes fixed B wrapper once for each accepted host phase1.
# Freeze actual phase2 input hashes, then root grants phase2 dispatch.
python3 harness/run_codex.py phase2
python3 harness/run_claude.py run phase2
```

All commands run with this scratch directory as context; absolute script paths are also valid. Product execution uses final frozen target checkout and a distinct minimal environment without model credentials, default OSStack home or OSSTACK_SOCKET. Its new output and scratch roots are owned by this experiment. Root or this worker will record the executor identity and constructed argv. The proposed 420-second wrapper outer limit covers its two cases plus doctors; confirm against final B bounds before dispatch. Timeout terminates only the owned process group and preserves uncertain cleanup as unknown.

After independent byte checking, remove the owned workspaces, preserve secret-free exports/evidence, and create new cleanup receipts. Original failed probes and call records are immutable. This batch can show one bounded host-assisted user journey; it does not establish autonomous model execution, causal improvement, cross-provider equivalence, independent principal identity or any formal J gate.
