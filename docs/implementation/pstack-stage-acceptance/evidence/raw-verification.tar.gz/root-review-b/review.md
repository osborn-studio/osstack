# W13 范围澄清与当前汇总复核

确认纠正我前份报告的潜在歧义：**W13 不要求持续 watcher。** 它的原验收是只读 observation classifier 的非许可语义、不完整读回 unknown/freshness、无 push/merge 调用，A27/A28没有轮询/rearm要求。现有单PR工具可按这些原门槛单独验收；本次不代替逐项证据判定，也不自动签PASS。

PS18比W13更广，持续观察未做可以列为PS18边界，不能追加成W13阻塞项。冻结原报告不改，本文件是追加澄清。

当前root README S3允许候选观察单独验收，C0/C1/C2没有添加持续watcher前置。CAPABILITIES PS18应明确上述区别；建议表头区分“原验收欠账”与“未纳入的较广功能”，避免通用benchmark服务、持久调度/broker或全API覆盖被误当所有方法材料验收统一门槛。特别是PS14，正确否定不可靠性能提升本身也是有效结果，不要求必有提升或新benchmark服务。

原W08真实集成与C1/C2的材料消费/准入义务保持；这份澄清不把其转移给Firstmate，不删除原欠账。详见 supplement.json 的固定源码与未提交README/CAPABILITIES hash。本轮无任何新产品/模型/全仓执行。
