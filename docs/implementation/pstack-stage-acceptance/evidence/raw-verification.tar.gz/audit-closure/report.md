# Verdict: PASS (report corrections R1–R7 only)

This is a text-only review of the supplied documents and `source-proof.json`/`supplement.json`. I ran nothing, and I did not re-read the underlying Git objects or raw logs. It is not a runtime, host or user qualification, and it does not turn any gate into a pass.

## Closure by item

| # | Result | Basis |
|---|---|---|
| R1 | Closed | ORIGINAL-ACCEPTANCE now states the rule: W labels are "有明确范围的人工工程判断，不是A状态取最差或通过比例". It explains W05/W09/W11 as 部分 and W01/W03/W08 as 未实现. REVIEW-CORRECTIONS adds that a W label does not waive any A assertion. The 10/31/4/3 A counts re-tally against the A table (10 未实现, 4 直接, 3 未知, so 31 部分). |
| R2 | Closed | README now names W10 method decision trace and recovery reconcile as original pstack scope. It lists the reconcile rules: old pin kept, unknown not treated as complete, no `cancelled` without stop proof, ended plans leave current retrieval. PS22/W16 fixed-event intake is listed under pstack follow-up capabilities and is explicitly not transferred to Firstmate. |
| R3 | Closed | The C0 row now includes A39 cold-reader success and error recovery, and says "部分具备", matching ORIGINAL-ACCEPTANCE. The C1 row names W01→W02 and A01/A02/A04 and says the J02 inspector does not substitute for them. C2 follows C1 in the chain. |
| R4 | Closed | README and JOINT-DEPENDENCIES name the specific joint items: J09.scoped→J08.scoped, its five direct prerequisites, SupportProfile/TrialPermit, `createAndConsumeTrial` (single root plus permit consumed in one FULL transaction), and the local J11→J12→J08 schema/recovery path. They state that full supervisor/remote recovery is not pulled into C2. The gate IDs and `requires` lists match `supplement.json`, whose evidence state is `specified_not_run`. |
| R5 | Closed | README, the ORIGINAL-ACCEPTANCE W13 row, REVIEW-CORRECTIONS R5 and SOURCE-COMPARISON all say the same thing. W10 does not gate A27/A28 slice acceptance, but the full W13→W10 plan chain cannot be signed. A continuous watcher is not a prerequisite. The A27/A28 "未闭合" labels are now "边界（非本切片新增门槛）". |
| R6 | Closed | A26 stays 部分. Its support is now only main's `joint-final-ci-composition` record. `source-proof.json` shows head `d31dc0b6`, parents `2b8ef9b7`/`fe9079a1`, tree `9efad98d`, and all 7 retained commands bound to that head. The `8e830561` frontier README is tagged `candidate_only_frontier_context_not_A26_evidence`. The doc also states the gap: no consumer that rejects stale method-candidate tickets. |
| R7 | Closed | The 69 is now scoped as the new JA scenarios in the 2026-10-27 joint audit (`claude-audit.md:109`, exact quote and blob hash in `supplement.json`). It is kept separate from the 114 inherited cases (66+48). Current main has 72 JA, and the historical figure is not rewritten. The arithmetic checks out. |

## Non-blocking residuals

- **R1:** The W16 table cell still shows a single "未知". The two axes (formal 未实现, intake 证据不足) are given in the paragraph above the table and in REVIEW-CORRECTIONS, not in the row. Readers need that text to avoid misreading it.
- **R2:** The Firstmate bullet still says "恢复与操作员处置". It is now contrasted with the pstack-owned method-level reconcile, but the line between the two is implied rather than stated.
- **R6:** `source-proof.json` records `reexecuted: false` and `raw_archive_revalidated_this_turn: false`. It also records `descendant_termination: not_attested` and `full_suite: not_run`. REVIEW-CORRECTIONS does not repeat the last two. The sentence "这证明一次新身份上的工程复验" is best read as "该保留记录显示", since nothing was re-run here.
- **R7:** Two different files are both named `acceptance-cases.json`. The joint one under `docs/design/` has 72 cases, and the pstack one under `docs/reports/` has 48. JOINT-DEPENDENCIES cites only the short name, so a reader could confuse them.

## Not verifiable from the supplied text

- That the "stale summaries for PS08/09/13/17/18 and J30 were fixed".
- The truth of cited anchors, hashes and "direct evidence" claims beyond what `source-proof.json` and `supplement.json` record.
- Any cited source line that is not itself included, such as `claude-audit.md:109` (the quote is in the supplement, not the file).
- Whether the J01.scoped→J08.admission_boundary inclusion is as stated. The gate JSON for J01.scoped is not supplied, only the scope note.

The optional items from my first report (CAPABILITIES column split, check-plan catalog-only wording, PS11 wording, D2a definition) are partly addressed, and none of them affects this verdict.