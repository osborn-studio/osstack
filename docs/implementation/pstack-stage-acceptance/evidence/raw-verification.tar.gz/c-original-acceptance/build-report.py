import json,subprocess,hashlib,datetime,collections,pathlib,re
ROOT=pathlib.Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/pstack-stage-acceptance-20261030')
OUT=ROOT/'c-original-acceptance'
MAIN='e4643324b9de1d2db51c744e59ccd7c05146b0a6'; CAND='8e830561e09f4754d3410003c24216d8db49aa6c'
def git(p,rev=CAND):return subprocess.check_output(['git','show',rev+':'+p])
def obj(p,rev=CAND):return json.loads(git(p,rev))
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v): (OUT/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n' if not isinstance(v,str) else v)
base='docs/reports/2026-10-26-pstack/'
joint='docs/design/2026-10-27-joint-engineering/'
cases=obj(base+'acceptance-cases.json')['cases']; caps=obj(base+'capability-map.json')['capabilities']; works=[x for x in obj(joint+'legacy-work-map.json')['items'] if x['id'].startswith('PS:')]
# Each evidence group is independently addressable at exact Git objects. Reading these now is not a new test execution.
groups={
 'source': ['packages/skill-registry/src/manifest.ts','packages/skill-registry/src/source-snapshot.ts','packages/skill-registry/src/source-snapshot.test.ts','packages/skill-registry/src/watcher.ts','docs/implementation/joint-source-inspection/README.md','docs/implementation/joint-source-inspection/validation.md'],
 'contracts':['docs/implementation/joint-contract-acceptance/README.md','docs/implementation/joint-foundation/README.md'],
 'graph':['packages/cli/src/graph-delivery-contract.ts','docs/implementation/graph-admission-evidence/README.md','docs/implementation/graph-verification-evidence/README.md'],
 'driver':['scripts/smoke-engineering-decision.test.mjs','scripts/smoke-skills-check.test.mjs','docs/implementation/verification-kit/README.md','docs/implementation/skills-check-verification/README.md','docs/implementation/method-full-journey/README.md'],
 'map':['scripts/maintain-skills-check-map.mjs','docs/implementation/skills-check-map-maintenance/README.md','osstack-methods-skill/references/skills-check-journey.md'],
 'projection':['scripts/project-method-journey-evidence.mjs','docs/implementation/method-full-projection/README.md'],
 'pr':['packages/github/src/pr-candidate-snapshot.ts','packages/github/src/pr-candidate-snapshot.test.ts','docs/implementation/pr-candidate-snapshot/README.md','docs/implementation/stack-checkrun-state/README.md'],
 'frontier':['packages/github/src/pr-stack-candidate.ts','docs/implementation/pr-stack-candidate/README.md'],
 'methods':['osstack-methods-skill/SKILL.md','osstack-methods-skill/entries/osstack-mode/SKILL.md','osstack-methods-skill/references/sources.md','osstack-methods-skill/references/parallel-work.md','osstack-methods-skill/references/architecture-design.md','osstack-methods-skill/references/task-framing.md'],
 'reader':['scripts/read-method-material.mjs','docs/implementation/method-material-reader/README.md'],
 'hostrepair':['docs/implementation/pstack-current-repair/README.md','docs/implementation/pstack-export-repair/README.md'],
 'hostreview':['docs/implementation/method-review-behavior/README.md','docs/implementation/method-pr-readiness-delivery/host-report.md'],
 'hostframing':['docs/implementation/method-continuity-delivery/host-report.md'],
 'continuity':['osstack-methods-skill/references/session-continuity.md','docs/implementation/joint-recovery-composition/README.md','docs/implementation/joint-broker-spec/README.md'],
 'lessons':['osstack-methods-skill/references/skill-authoring.md','docs/implementation/method-skill-authoring/README.md'],
 'performance':['osstack-methods-skill/references/performance-measurement.md','docs/implementation/method-impact-performance/README.md'],
}
bindings=[]
for gid,ps in groups.items():
 for p in ps:
  rev=CAND if gid=='frontier' else MAIN
  b=git(p,rev)
  bindings.append({'group':gid,'git_commit':rev,'path':p,'bytes':len(b),'sha256':sha(b),'evidence_kind':'current_source_or_retained_report_read_only','new_test_execution':False})
# assessment applies the whole original case, not merely a related component.
rows=[
('未实现','source','旧 manifest 仍无 subdir 字段；现有读取兼容不等于规范表示补默认 .。','W01 兼容表示与未知字段策略未交付。'),
('部分','source','固定 Git SourceSnapshot 对路径、对象身份、链接与上限有实际拒绝组件证据。','W01 manifest 接线与完整原入口尚未具备，不把 inspector 单独通过升级整场景。'),
('有直接证据','source','固定对象快照有确定性、未跟踪文件排除和无脚本执行的真实 Git fixture/来源复算证据。','证据限 source inspector；不认证调用者 repo identity，不构成 W02 candidate 激活全链路。'),
('部分','source','来源检查和 watcher 已能比较 pin/远端 SHA，检查器不安装或执行来源。','相关子树内容变化→candidate、无关子树不变及 active 生命周期没有该链路证据。'),
('未实现','contracts,methods','已有 recipe/proposal 协议组件及四种方法文稿。','未发现接入实际四 recipe 的纯编译器；schema/digest 测试不能替代确定性编译。'),
('未实现','contracts','严格字段/摘要组件有负例。','原场景需要 recipe 编译入口拒绝未知检查和引用命令，尚无该执行入口证据。'),
('未实现','contracts','SupportProfile 有组件表示。','required unsupported 与 optional 降级尚未由 recipe 编译器实际判定。'),
('部分','graph,contracts','旧 Graph admission/授权边界有既有实现和回归。','方法 proposal→admission 的新权限不扩张通路尚未接通。'),
('部分','graph,contracts','旧 Graph 冻结合同和新 Binding/Recipe schema 均存在。','新方法 check registry 映射先于 freeze 的实际链路未证明。'),
('部分','graph','现有 Graph 检查数量、命令预算、primary 和 local_verified 边界仍在源码中。','没有新 recipe admission 通过该入口的对应17项/超预算/merged终态完整反例执行记录。'),
('未实现','reader,contracts','材料 reader 可逐页返回完整字节；协议能表示材料绑定。','没有方法上下文遗漏时 METHOD_CONTEXT_OMITTED 且 adapter invoke=0 的实际 wrapper。'),
('部分','hostrepair,reader','实际宿主实验有原材料分页送达、输入哈希与工具 trace，原文权限限制明确。','宿主显式读取不等于注册 adapter 的 prepared/observed 双阶段 task receipt 与 trust enforcement。'),
('有直接证据','driver','真实 CLI→daemon/SQLite smoke 及隔离 skills-check 五例有行为谓词、明确 scratch home 和证据/清理。','仅命名 fixture 和确定性适配器；不外推真实 provider、正式 gate 或所有功能。'),
('部分','driver','预检、timeout、清理错误、owned 路径拒绝和失败留存已有实际记录。','不声称穷尽无关进程保持/所有后代终止；完整原故障交叉场景未作为 A14 整体验收。'),
('部分','pr,projection,contracts','快照检查 head/base bracket；驱动/投影记录源码构建绑定和一致性。','方法验证票据对 head/base/env/check/contract 所有维度的 stale consumer 尚未闭合。'),
('部分','contracts,graph','既有验证 host 与新组件区分角色/身份；raw report 未签发正式通过。','新方法可信 verifier producer/consumer join 及伪造 worker 的拒绝链路未完成。'),
('部分','hostreview,contracts','真实审计保留阻塞意见与处置；只读 PR 报告不产生 merge permit。','不等于 method review 产物消费者拒无依据 dismiss/阻止 approved 的原场景。'),
('未实现','hostrepair,contracts','真实宿主修复已执行同测试 RED→fix→GREEN。','缺 recipe→proposal→合同→执行→独立验证→local_verified 的方法接入链；宿主修复不能替代 W08。'),
('部分','driver,graph','现有默认 CLI/启动预算 CI 和无新增常驻服务有历史工程证据。','没有 W08 新 recipe 开关的关闭兼容对照，因此不证明原可选能力开关契约。'),
('部分','methods,contracts','investigation 文稿明确调查不等于交付。','recipe 的 Graph scout unsupported 运行拒绝未实现。'),
('未知','continuity','历史报告/纠正/审计原文被保留。','本次未取得 method 决策权威 supersedes 与编辑导出不改权威状态的实际端到端证据；不以文件留存代替。'),
('部分','continuity','连续性文稿与恢复离线规格保持 unknown/hold、旧 pin、停止证明边界。','新方法进程/恢复运行时没有实际完成；会话结束不等于 fencing。'),
('部分','map,hostrepair','固定地图维护有真实 docs drift RED→单格修正→同入口 GREEN；工具失败与产品状态分轴。','未闭合 recipe qualification 对全部 doc/harness/product 分类及自动晋升拒绝。'),
('未实现','source,continuity','来源/方法材料未自动激活，旧实验独立保留。','新 candidate 测量失败→禁止 active、旧 in-flight run 保持身份的运行时资格系统未实现。'),
('部分','methods,contracts','parallel-work 材料区分竞争/覆盖；协议可表示候选。','method-candidate 聚合与冻结竞赛规则的实际拒绝消费者尚未验证。'),
('部分','contracts,frontier','实际 PR/worktree 合成验证曾重新绑定 tree 与检查；frontier 当前为候选。','不等于 arena artifact 合成的新身份/旧票据拒用完整实现。'),
('有直接证据','pr','已合并只读 PR snapshot 对 BLOCKED/REVIEW_REQUIRED/unknown 保守输出，merge_authorized 恒 false。','只读一次性 observation；不证明 watcher、merge policy 全发现或 W13 所有依赖完成。'),
('有直接证据','pr','分页/timeout/错误/partial GraphQL/缺失结果离线反例及一次真实只读调用留 raw、query 时间、unknown。','没有 push/merge；非原子读取，forge 权限/规则集覆盖与身份认证未声称。'),
('部分','lessons','skill-authoring 方法与有限单文件维护试用有材料/写边界证据。','历史坏例/合法例校准的 lesson draft→gate 晋升完整运行流程未交付。'),
('未实现','performance,hostrepair','性能方法保留样本/失败/分母规则；宿主实验保留失败。','没有同任务/模型/预算的盲化公平价值对照和 gate epoch 试点，不能推导收益。'),
('未实现','contracts','协议形式约束和组件摘要测试已存在。','原要求的单不变量 formal 工具链、源码映射、坏模型与超时 unknown 试点未交付；schema 测试不是形式化试点。'),
('未知','contracts','本阶段未新增外部通知/事件权限。','未取得 W16 固定事件 fake connector 幂等/readback/部分成功补偿试点；不能据此断言全仓无通用事件能力。'),
('部分','driver,map','固定 doctor/drive/observe 结果、JSON 回执与地图工具可用。','完整登记恢复动作、渐进 help、cold caller 恢复闭环只在有限命名工具体现，未整体验收原接口。'),
('部分','driver','doctor/dry-run 有不建 fixture/证据、不启动子进程的实际负例。','不把该结果扩展到所有 setup/cleanup、Git refs/网络资源组合；原完整场景未统一实测。'),
('未实现','map,methods','固定五行地图和四入口链接图存在。','按用户路径检索相关叶子、跨两个真实产品入口的功能地图加载器尚未交付。'),
('部分','map','固定地图 invalid/漂移 mismatch/unknown 保留、禁止删行降谓词，有实际两次 full drive。','地图路径检索和数据/授权不足跨表面阻断未覆盖。'),
('部分','hostframing,methods','task-framing 有实际两宿主 prompt-only 观察，目标/假设/授权区分可读。','两宿主原结论均 LIMITED；没有 recipe intent frame 与纠正后重新编译/材料变更的完整证明。'),
('部分','continuity,methods','连续性/调查材料要求当前事实优先、授权核实。','没有原场景有限历史检索→当前源码校准的完整执行记录，不称支持任意会话回忆。'),
('部分','driver,map','已有可运行教程、真实命令和错误回执。','作者/协调者运行不能代替指定冷读者只看教程完成成功与错误恢复的验收。'),
('部分','methods,performance','architecture-design 有两个结构方案、caller/lifecycle 合成 walkthrough；不产生正式票据。','原要求两个实现影响未知的有预算可运行原型与实际环境观察尚未验收。'),
('部分','methods,hostreview','设计/审查方法要求偏差重审；实际审计后修订留存。','未针对原重复workaround/type逃逸场景执行完整行为验收，文稿不能证明自动遵守。'),
('部分','hostreview','小 Git A/B 代码审查识别可触发 bug/拒风格问题有实际观察，过度断言/漏读保留。','两宿主 LIMITED；不证明一般评审质量或可信 method review consumer。'),
('部分','hostrepair,contracts','工程 self-check、driver 与 formal gate 明确分离，真实修复没有自签 local_verified。','没有新方法接入后 self-check 冒充正式receipt被consumer拒绝的端到端负例。'),
('部分','driver,methods','scratch ownership、限并发材料与真实隔离fixture已有。','worktree/路径隔离不证明共享端口、DB、账号、全进程/远端容量隔离的完整矩阵。'),
('部分','map,driver','实际 fixed-map 维护两次五例、三轴状态/源码构建哈希留存；未启用周期任务。','跨工具 health/owner/version/last-drive 可查询服务与完整三类自动分诊未实现；固定工具不等于 W19 全部。'),
('部分','continuity','方法材料禁止旧计划作为当前授权，历史及纠正报告保留。','当前检索自动过滤 completed/superseded 战术计划的真实机制未验证。'),
('未知','performance,driver','有真实终点与工具/产品失败分开，报告没有 PR 数当 ROI。','未完成固定冷用户、介入成本、首次就绪时间/恢复成本的价值基线测量；收益未知。'),
('部分','methods,reader,hostframing','四入口、14方法与导出图可用；实际显式/native材料送达有 trace。','透明纠正→新的 recipe/相关地图检索→必需验证不遗漏的运行合同尚未完成；不能将链接可达当路由效果。'),
]
assert len(rows)==48
records=[]
for original,(status,gs,observed,gap) in zip(cases,rows):
 ws=original['work_packages']; js=sorted({j for w in works if w['id'][3:] in ws for j in w['joint_work_items']})
 records.append({'id':original['id'],'original':original,'work_packages':ws,'joint_work_items':js,'assessment':status,'observed':observed,'remaining_gap':gap,'evidence_groups':gs.split(','),'original_gate_pass_claimed':False,'current_owner':'pstack 方法接入/工具责任方；跨主机权威环节与联合 host 对接，不自动转交 Firstmate','candidate_only_evidence':'frontier' in gs.split(',')})
worknotes=[
('未实现','manifest 缺 subdir 默认表示；inspector 的新对象不是旧manifest接线。'),
('部分','固定Git快照可用；subtree candidate/activation记录仍缺。'),
('未实现','协议组件/方法文稿不等于纯 recipe compiler。'),
('部分','旧Graph可复用，新proposal→admission未闭合。'),
('部分','材料读工具与宿主trace可复用，invoke前遗漏拒绝未实现。'),
('部分','真实命名隔离工具可用；完整恢复接口/故障矩阵/冷用户验收仍缺。'),
('部分','旧host/协议/实际审计可复用；新candidate review artifact可信join未闭合。'),
('未实现','尚无原recipe到local_verified的实际接入试点。'),
('部分','四种方法材料存在，四类可编译可准入recipes未实现。'),
('部分','连续性文稿/离线恢复规格不等于方法权威轨迹与恢复服务。'),
('部分','固定地图漂移维护可用；recipe资格/激活/旧run隔离未实现。'),
('部分','并行方法及协议组件存在；候选聚合消费者/运行级调度未交付。'),
('有直接证据','A27/A28 只读 classifier 核心断言已有直接产品/执行证据。W10 的计划依赖另列未闭合；原 W13 不要求持续 watcher，不能将 PS18 的扩展范围作为本子切片欠账。'),
('部分','技能编写维护有材料与有限试用；结构化lesson晋升链未交付。'),
('未实现','仅方法和合成算术，盲评/价值/预算试点未交付。'),
('未知','两个独立专项试点无直接验收；不把现有全仓其他formal/intake模块宣告不存在。'),
('部分','问题/设计材料和有限宿主试用存在；冷用户、有限原型及价值验证未完整。'),
('部分','固定五场景地图可用；按相关叶子检索与跨入口覆盖未实现。'),
('部分','固定维护工具已真实闭环；通用健康/owner/version/lastdrive查询未全交付。')]
wr=[]
for w,(s,n) in zip(works,worknotes):
 wid=w['id'][3:]; linked=[x['id'] for x in records if wid in x['work_packages']]
 wr.append({'id':wid,'original_crosswalk':w,'assessment':s,'acceptance_cases':linked,'capabilities':[c['id'] for c in caps if wid in c['work_packages']],'note':n,'formal_pass':False,'owner':'pstack（联合 host 接线属于协作依赖，不是 Firstmate 自动接盘）'})
# Source evidence discovery facts: path absence alone is not proof of no equivalent implementation.
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',MAIN]).decode().splitlines()
proposed=['packages/skill-registry/src/recipe-compiler.ts','packages/cli/src/method-admission.ts','packages/cli/src/method-context.ts','packages/cli/src/method-review.ts','packages/cli/src/method-report.ts','packages/skill-registry/src/recipe-qualification.ts','packages/skill-registry/src/candidate-selection.ts','packages/loop/src/lesson-draft.ts','packages/skill-registry/src/method-improvement.ts']
absence=[{'suggested_path':p,'present_at_main':p in tracked,'interpretation':'建议文件名并非强制；判定结合实际source/README明确边界，不仅凭文件名缺失。'} for p in proposed]
# Cross-check the eight supplied baseline files, without changing them.
baseline=json.loads((ROOT/'original-baseline/manifest.json').read_text()); baselinecheck=[]
for x in baseline['files']:
 b=(ROOT/'original-baseline'/x['path']).read_bytes(); baselinecheck.append({'path':x['path'],'matches_manifest':sha(b)==x['sha256'] and len(b)==x['bytes'],'matches_main_git':b==git(x['path'],MAIN),'sha256':sha(b)})
assert all(x['matches_manifest'] and x['matches_main_git'] for x in baselinecheck)
sourcepaths=[base+'acceptance-cases.json',base+'integration-spec.md',base+'capability-map.json',base+'claude-audit.md',joint+'claude-audit.md',joint+'legacy-case-map.json',joint+'legacy-work-map.json']
for p in sourcepaths:
 b=git(p);bindings.append({'group':'original_contract','git_commit':CAND,'path':p,'bytes':len(b),'sha256':sha(b),'same_as_main':b==git(p,MAIN)})
write('source-bindings.json',{'main':MAIN,'candidate':CAND,'files':bindings,'baseline_eight_files':baselinecheck,'suggested_entry_paths':absence})
write('acceptance-48.json',{'kind':'read_only_original_acceptance_trace_not_test_run','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':MAIN,'candidate':CAND,'source_document_executed':False,'new_tests_run':False,'counts':dict(collections.Counter(x['assessment'] for x in records)),'status_meaning':{'有直接证据':'对该场景核心要求有具体产品组件/历史执行证据；不自动补齐依赖或正式gate。','部分':'有实际交付或材料证据，但原场景至少一个必要断言尚未覆盖。','未实现':'本阶段明确未交付该原能力链；不是全仓不存在相似模块的证明。','未知':'现有证据不能判定原要求是否完成；不得改写为未实现或通过。'},'formal_gate_pass':False,'cases':records})
write('work-items-19.json',{'main':MAIN,'candidate':CAND,'work_items':wr,'checkpoints':{'C0':'部分具备：W06固定工具、W17材料/有限试用、W18固定地图、W19固定维护可用；原冷使用/检索/维护全门槛未闭合。','C1':'未闭合：尚无W03真实确定性proposal及原recipe编译负例链。','C2':'未实现：无W08原方法端到端local_verified试点。','C3':'未闭合：四类文稿不等于四类recipe资格、激活和回退。'}})
# 24 original capabilities retained by original W relationships, not renamed into recent tool stages.
write('capabilities-24-crosswalk.json',{'source_commit':CAND,'capabilities':[{'id':c['id'],'title':c['title'],'original_work_packages':c['work_packages'],'original_sources':c['sources'],'related_cases_via_original_work_packages':[x['id'] for x in records if set(c['work_packages'])&set(x['work_packages'])],'mapping_only_not_assertion_equivalence':True,'formal_complete':False} for c in caps]})
pstacknotes={
'AU01':'完整PS→W映射已有；映射修正不是24能力完成。',
'AU02':'仍需exact candidate/expected heads/base/workspace转换依据；不得仅凭相同tree通用放行。',
'AU03':'仓库检查注册项/optional策略需被真实recipe编译与admission消费，不能靠通用check字符串。',
'AU04':'reader及host分页解决字节送达一部分；冻结brief不可追加，必需材料遗漏invoke=0仍未实现。',
'AU05':'固定工具已有failure/cleanup轴；新recipe资格系统仍需稳定失败归属。',
'AU06':'Graph已有primary/registry约束；新方法检查映射与授权来源consumer仍待接入。',
'AU07':'真实隔离driver满足部分语义表面；新方法entry负例仍需对应实际链路。',
'AU08':'目录与来源可追溯已修；原199计数争议不能转化为缺失实现事实。',
'AU09':'host profile改变须重新资格；目前无方法profile激活runtime试点。',
'AU10':'adopted依赖与未采用依赖区分仍需真实closure/升级资格；不能静默重绑旧pin。',
'AU11':'schema含字段不等于producer/locator/digest/trustedconsumer全部存在；该门槛仍有效。',
'AU12':'原判断不是已证缺陷；保留防御性admission错误表示建议，不加新强制审批。',
'CH01':'已有命名CLI/skills-check场景；完整W06使用恢复边界仍只部分交付。',
'CH02':'不能用追加frozen.brief绕过；实际wrapper遗漏拒绝仍是实施条件。',
'CH03':'修复了原PS21等映射空洞；不是其来源资格/激活已经实现。',
'CH04':'早期有预算的价值比较仍待实际测量；旧有限host失败不应剔除，不能补称因果收益。',
'CH05':'原非缺陷：隔离方法选择不等于授权；不因简化文稿删除quarantine语义。',
'CH06':'固定driver动作已命名；完整登记恢复动作/所有权/身份/重试仍需场景验证。',
'CH07':'固定map可维护，但归属不从CODEOWNERS猜测；通用mapwriter/owner仍待明确运行接线。',
'CH08':'新inspector支持固定Git对象、40/64摘要及限额；旧manifest兼容接线仍缺。',
'CH09':'既有primary确定性可复用，不替代新recipe的check映射负例。',
'CH10':'architect来源归属修正已在材料中；正确引用不证明架构方法效果。'}
pa=[]
for f in ['audit-dispositions.json','challenge-dispositions.json']:
 p=base+'evidence/claude-audit-2026-10-27/'+f
 data=obj(p)
 for r in data['rows']:
  pa.append({'id':r['id'],'original':r,'current_assessment':pstacknotes[r['id']],'original_disposition_not_rewritten':True,'formal_product_pass':False})
 b=git(p);bindings.append({'group':'original_audit','git_commit':CAND,'path':p,'bytes':len(b),'sha256':sha(b)})
assert len(pa)==22
jnotes={
'RV01':'canonical/digest组件与独立变异证据已有；正式oracle及全运行绑定未通过。',
'RV02':'schema/host authority定义不等于真实owner写入与持久化consumer。',
'RV03':'permit TTL、原子root消费及内部预算仍属运行接入条件。',
'RV04':'profile试验/qualified区别仍须主机测量，不以材料适配代替。',
'RV05':'schema46/47/48及broker离线迁移有组件证据；真实恢复入口仍不能推定通过。',
'RV06':'host私有immutable配置/重启重算仍属运行条件。',
'RV07':'typed attention/effect/broker恢复proof仍需真实producer和消费路径。',
'RV08':'primary/registry digest组件存在；recipe编译器须实际消费。',
'RV09':'legacy映射修正只补设计追溯；原48与FM66不得被新JA替代。',
'RV10':'负例ID/parentreceipt/release依赖已在规范中；不能以表格存在签通过。',
'RV11':'材料body/角色/producer字段组件可用；完整上下文producer/consumer仍待。',
'RV12':'E0/E1门槛定义不等于价值试验结果。',
'RV13':'没有足够样本/功效就不能声称ROI或降低门槛。',
'RV14':'Firstmate away状态不得产生授权；持续负责依赖真实parent receipts/监督机制。',
'RV15':'来源检查、实际使用、hash语义应继续分开；当前inspector未认证repo声明。',
'RV16':'R04/V01/V02/V05真实产物与owner映射不得用关键词覆盖代替。',
'RV17':'已有组件变异记录仅限实际目标；不能推广为所有运行消费者变异覆盖。',
'RV18':'报告存在/缺失门槛属于文档检查已闭合，不是产品验收。',
'CH01':'phase/decision/typedproof门槛仍需真实权威恢复链。',
'CH02':'白名单ledger bootstrap的durable crash恢复仍为独立运行切片。',
'CH03':'trial profile/scratch/issuer binding须真实闭合，不仅字段齐全。',
'CH04':'一次Graph root原子消费不等于只调用一次API；真实permit实现仍待。',
'CH05':'受限canonical域不是任意JCS，旧hash兼容要保持；组件已有。',
'CH06':'66FM+48PS保留原断言，不以联合JA通过批量升级。',
'CH07':'需要语义反例与真实消费者，不以字段删除/计数覆盖替代。',
'CH08':'命名driver已有D2a工具支持；没有新J09可信receipt链通过。',
'CH09':'E0可先做有限价值试验，不新增独立于原设计的资格阻塞。',
'CH10':'共同oracle/隐藏样例/处理组分母和预算需要实际对照试验。',
'CH11':'预算不可执行时必须unknown/refuse；CLI超时不保证所有后代受限。',
'CH12':'不同agent/model名字不证明独立principal；真实可解析身份不必是人类但需独立性证据。',
'CH13':'迁移重编号/新schema需重新验证；离线fixtures不代替实际home恢复。',
'CH14':'O01–O06未决项可推进隔离研究，不把未知误写已解决或无限新审批。',
'CH15':'builder/reviewer角色材料隔离需真实调用证据；链接图不足。',
'CH16':'trusted host record join必须可执行；schema validation不签发许可。',
'CO01':'恢复后态四列表/unknown hold、resolution独立读；不得合成applied。',
'CO02':'openRecoveryDb与普通pre-migration guard按实际版本验收，不能只看schema spec。',
'CO03':'legacy identity/null scope/broker proof仍需真实恢复路径。',
'CO04':'permit root原子消费/FULL Graph需独立实现与故障验证。',
'CO05':'digest/raw parser/profile黄金向量已有部分组件验证；不自动成为正式host验证。',
'CO06':'私有原子登记/config预算/保留nonterminal/新恢复授权仍为runtime条件。',
'CO07':'local opt-in和full原门槛分开，旧114验收不可通过局部12变体豁免。',
'CO08':'默认关闭/E1可行性/J32价值仍须实际证据，材料不会启用。',
'CO09':'principal任期/freeze/第二评审及集中度需要真实证明；提案不能冒充任命。',
'CO10':'依赖图/文档统计修正已闭合；不能计作运行实现。',
'CF01':'release gate合取全部原case；full_original_completion保持，不接受局部自动晋升。',
'CF02':'JADR15恢复后态、旧root hold/FULL事务要求仍应由实际目标schema/entry证明。',
'CF03':'Profile v2向量同步属于组件设计与验证；不证明真实主机能力。'}
ja=[]
jbase=joint+'evidence/sonnet-audit-2026-10-27/'
for f in ['dispositions.json','closeout-dispositions.json','closeout2-dispositions.json']:
 p=jbase+f
 for r in obj(p)['items']:
  ja.append({'id':r['id'],'original':r,'current_assessment':jnotes[r['id']],'formal_product_pass':False,'original_disposition_not_rewritten':True})
 b=git(p);bindings.append({'group':'joint_original_audit','git_commit':CAND,'path':p,'bytes':len(b),'sha256':sha(b)})
assert len(ja)==47 and len({x['id'] for x in ja})==47
write('audit-conditions.json',{'kind':'original_dispositions_plus_current_conditions_not_new_audit','original_pstack':{'count':22,'items':pa,'HV01_separate_not_in_22':'首次受限试验的bootstrap循环由J08设计拆解；设计解决不等于实际准入已实施。'},'joint':{'count':47,'items':ja},'count_warning':'22与47是设计审查条目，不是22/47已证产品缺陷；77文档、100合同、24摘要设计检查都不是48产品验收。'})
write('source-bindings.json',{'main':MAIN,'candidate':CAND,'files':bindings,'baseline_eight_files':baselinecheck,'suggested_entry_paths':absence})
counts=collections.Counter(x['assessment'] for x in records)
md=['# 原 pstack 48 场景 / 19 工作项独立追溯','',
'结论：**pstack 原验收尚未结束**。本次没有重跑产品、宿主、模型或全仓测试；以下依据固定 Git 源码和保留的实际执行/审计记录做追溯。先前 `c/` 的小阶段建议保留为历史建议，不能代替原报告 C0–C3，也不能把剩余 pstack 工作自动转给 Firstmate。','',
f'基线 main `{MAIN}`；未合并 frontier 候选 `{CAND}`。原八份 baseline 已逐字比对 manifest 与 main。48 个原 given/when/then 和原 W/J 映射完整保存在 JSON。', '',
'“有直接证据”仅表示原场景核心断言有具体产品组件/历史执行证据，不自动补齐工作项依赖或签发正式 gate。没有创建新的通过率，也没有把当前源文件存在当作执行通过。', '',
f'状态计数：'+ '；'.join(f'{k} {v}' for k,v in counts.items())+'。所有正式 gate pass 均未声明。', '',
'## 与原阶段门槛的差异','',
'| 原门槛 | 当前结论 | 不能替代它的近期交付 |','|---|---|---|',
'| C0：工具/使用草图/功能地图/维护边界 | 部分具备；固定工具及五行地图可运行，相关叶子检索、冷用户恢复与通用维护查询未闭合 | 方法数量、导出链接图、作者运行 |',
'| C1：真实纯编译 proposal 与负例 | 未闭合 | 100 schema/24摘要向量或四类方法文稿 |',
'| C2：W08 recipe→admission→实际执行→独立 join→local_verified | 未实现原完整链 | Codex/Claude 修复试验、手工合成验证、单个真实 driver |',
'| C3：四类 recipe、资格升级与回退 | 未闭合 | 四种可读方法、旧 pin 保留的报告约定 |', '',
'原建议文件名不是硬要求；若已有等价模块应复用。本报告的缺口依据实际行为/README边界，不以“没有某个建议文件名”单独证明未实现。原联合映射中 W11 已拆首次受限试验 J08 与后续资格 J10，W09 不再作为首次资格前置；这些合理调整不删除原验收断言。', '',
'## 48 项原验收','', '| ID / W | 原要求 | 状态 | 当前依据与缺口 |','|---|---|---|']
for r in records:
 md.append('| '+r['id']+' / '+','.join(r['work_packages'])+' | '+r['original']['title']+' | '+r['assessment']+' | '+r['observed']+' **未闭合：**'+r['remaining_gap']+' |')
md+=['','逐项 source/evidence 由 `evidence_groups` 关联 `source-bindings.json`，其中 frontier 组只在未合并候选存在；其余证据组选取 main。原始执行 SHA 仍以各保留报告为准，本次读取 main 文件不重标历史运行 SHA。','','## 19 项工作包','','| W / J | 当前状态 | 原验收 | 说明 |','|---|---|---|']
for w in wr:md.append('| '+w['id']+' / '+','.join(w['original_crosswalk']['joint_work_items'])+' | '+w['assessment']+' | '+','.join(w['acceptance_cases'])+' | '+w['note']+' |')
md+=['','## 原审计条件继续有效','','完整逐项 22+47 对照见 `audit-conditions.json`；原 disposition 原样嵌入，不把当时设计闭环改写为当前产品通过。关键条件：','',
'- 原 AU03/06/11、CH06/09 与联合 RV02/03/08/11、CH03/04/16：真实注册检查、授权来源、artifact producer/consumer、permit/可信 join 仍须可执行。',
'- 原 AU04、CH02 与联合 CH15：必需材料不能靠追加 frozen brief；完整送达、真实 adapter task 绑定、遗漏时 invoke=0 是不同断言。reader 和宿主分页只解决部分。',
'- 原 AU09/10、CH08 与联合 CO01–06：来源 pin、依赖 closure、资格升级、恢复 unknown/hold/停止证明仍有运行条件，不归并为“文档已经写好”。',
'- 联合 RV09/10、CH06/07、CO07、CF01：原 66 Firstmate +48 pstack 用例保留，JA/local opt-in/合同字段测试不能替代。',
'- 原 CH04、联合 RV12/13、CH10、CO08：无盲化、公平预算与足够样本不能声称收益；旧失败保持失败，不删除分母。',
'- 联合 CH12、CO09：多模型名不构成独立 principal；真实可解析身份也不强制等于人类/外部组织。当前材料和工程复核不签 formal gate，不额外创设审批门槛。',
'- 原 AU01/08、CH03/10、联合 RV18/CO10：来源/映射/报告存在性修订可完成文档条件，不能换算为产品完成。原 AU12、CH05 的非缺陷处置保持。', '',
'## 旧实际宿主结果必须保留','',
'- task-framing 双宿主均 LIMITED；源码/目标边界语义仍有局限。',
'- code-review 小 Git A/B 主识别有正面观察，但漏读、过度断言及 native/explicit 差异保留，两宿主整体 LIMITED。',
'- 当前 packet 修复：Codex 实际同测试 RED→改一行→GREEN，协调者 holdout 另算；Claude 六个 baseline 后第一复合源码读取实际成功、第二被拒并停止，未修复。不得追溯把未禁止的源码复合命令判成新违规。',
'- 模型字节消费不等于理解；requested/default 模型不等于 resolved 身份；无公平对照，不比较模型优劣或方法因果效果。', '',
'## 建议的下一步及责任','',
'1. 先由用户确认“固定工程工具子集”是否符合日常使用：从干净已构建 checkout，用显式 scratch 跑命名五例旅程、地图维护、投影 check。具体命令沿 main 对应 README，保持旧失败和完整 raw。此使用验收只覆盖 A13、A23/A36/A45 的已交付子集，不能宣布 C2。',
'2. pstack 责任方优先补 C0 的冷用户成功/失败恢复与相关功能叶子检索；在此基础上交付 W03 一个 bug-fix 纯编译 proposal，保留未知检查/宿主不支持的反例，进入 C1。',
'3. 再按 W04/W05/W07/W08 打通授权、必需材料、可信产物消费与本地验证。与联合 host owner 协作，但不能将这些 pstack 自身接入缺口改名 Firstmate 后删除。',
'4. Firstmate 的持续监督/恢复/外部副作用属于其独立范围；待 pstack 子阶段明确验收再推进，不用后台能力掩盖前端方法/编译/地图缺口。W15价值、W16formal/intake按各自独立试点保留，不强行并入此阶段。', '',
'本次只读追溯，不承诺所有原验收都需要新模块；复用已有等价实现并以对应原断言实证，是可接受的交付方式。不同状态不是优先级，也不是失败率。','']
write('report.zh.md','\n'.join(md))
write('verification.json',{'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'case_ids_exact':[x['id'] for x in records]==[f'A{i:02}' for i in range(1,49)],'work_ids_exact':[x['id'] for x in wr]==[f'W{i:02}' for i in range(1,20)],'pstack_audit_count':len(pa),'joint_audit_count':len(ja),'capability_count':len(caps),'all_source_paths_resolve':True,'baseline8_exact':True,'new_model_or_product_test_calls':0,'original_c_report_modified':False,'formal_passes_claimed':0,'raw_archives_reextracted':False,'evidence_limit':'引用既有源码/执行总结/此前独立记录，本轮未重新解包全部历史raw；历史运行身份按保留报告，当前Git读取不重标。'})
files=[]
for p in sorted(OUT.iterdir()):
 if p.name=='manifest.json' or not p.is_file():continue
 b=p.read_bytes();files.append({'path':p.name,'bytes':len(b),'sha256':sha(b)})
write('manifest.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'main':MAIN,'candidate':CAND,'read_only_product':True})
print(json.dumps({'counts':dict(counts),'files':len(files),'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'report_sha256':sha((OUT/'report.zh.md').read_bytes()),'cases_sha256':sha((OUT/'acceptance-48.json').read_bytes())},ensure_ascii=False))
