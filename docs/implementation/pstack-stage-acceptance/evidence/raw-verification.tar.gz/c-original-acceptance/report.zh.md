# 原 pstack 48 场景 / 19 工作项独立追溯

结论：**pstack 原验收尚未结束**。本次没有重跑产品、宿主、模型或全仓测试；以下依据固定 Git 源码和保留的实际执行/审计记录做追溯。先前 `c/` 的小阶段建议保留为历史建议，不能代替原报告 C0–C3，也不能把剩余 pstack 工作自动转给 Firstmate。

基线 main `e4643324b9de1d2db51c744e59ccd7c05146b0a6`；未合并 frontier 候选 `8e830561e09f4754d3410003c24216d8db49aa6c`。原八份 baseline 已逐字比对 manifest 与 main。48 个原 given/when/then 和原 W/J 映射完整保存在 JSON。

“有直接证据”仅表示原场景核心断言有具体产品组件/历史执行证据，不自动补齐工作项依赖或签发正式 gate。没有创建新的通过率，也没有把当前源文件存在当作执行通过。

状态计数：未实现 10；部分 31；有直接证据 4；未知 3。所有正式 gate pass 均未声明。

## 与原阶段门槛的差异

| 原门槛 | 当前结论 | 不能替代它的近期交付 |
|---|---|---|
| C0：工具/使用草图/功能地图/维护边界 | 部分具备；固定工具及五行地图可运行，相关叶子检索、冷用户恢复与通用维护查询未闭合 | 方法数量、导出链接图、作者运行 |
| C1：真实纯编译 proposal 与负例 | 未闭合 | 100 schema/24摘要向量或四类方法文稿 |
| C2：W08 recipe→admission→实际执行→独立 join→local_verified | 未实现原完整链 | Codex/Claude 修复试验、手工合成验证、单个真实 driver |
| C3：四类 recipe、资格升级与回退 | 未闭合 | 四种可读方法、旧 pin 保留的报告约定 |

原建议文件名不是硬要求；若已有等价模块应复用。本报告的缺口依据实际行为/README边界，不以“没有某个建议文件名”单独证明未实现。原联合映射中 W11 已拆首次受限试验 J08 与后续资格 J10，W09 不再作为首次资格前置；这些合理调整不删除原验收断言。

## 48 项原验收

| ID / W | 原要求 | 状态 | 当前依据与缺口 |
|---|---|---|
| A01 / W01 | 旧 manifest 兼容 | 未实现 | 旧 manifest 仍无 subdir 字段；现有读取兼容不等于规范表示补默认 .。 **未闭合：**W01 兼容表示与未知字段策略未交付。 |
| A02 / W01,W02 | 来源路径与身份拒绝 | 部分 | 固定 Git SourceSnapshot 对路径、对象身份、链接与上限有实际拒绝组件证据。 **未闭合：**W01 manifest 接线与完整原入口尚未具备，不把 inspector 单独通过升级整场景。 |
| A03 / W02 | 确定性且无执行的快照 | 有直接证据 | 固定对象快照有确定性、未跟踪文件排除和无脚本执行的真实 Git fixture/来源复算证据。 **未闭合：**证据限 source inspector；不认证调用者 repo identity，不构成 W02 candidate 激活全链路。 |
| A04 / W02 | 来源更新不自动激活 | 部分 | 来源检查和 watcher 已能比较 pin/远端 SHA，检查器不安装或执行来源。 **未闭合：**相关子树内容变化→candidate、无关子树不变及 active 生命周期没有该链路证据。 |
| A05 / W03,W09 | 纯编译与 recipe 区分 | 未实现 | 已有 recipe/proposal 协议组件及四种方法文稿。 **未闭合：**未发现接入实际四 recipe 的纯编译器；schema/digest 测试不能替代确定性编译。 |
| A06 / W03 | 拒绝未知检查与命令注入 | 未实现 | 严格字段/摘要组件有负例。 **未闭合：**原场景需要 recipe 编译入口拒绝未知检查和引用命令，尚无该执行入口证据。 |
| A07 / W03 | 宿主兼容性 | 未实现 | SupportProfile 有组件表示。 **未闭合：**required unsupported 与 optional 降级尚未由 recipe 编译器实际判定。 |
| A08 / W04,W09 | 禁止权限扩张 | 部分 | 旧 Graph admission/授权边界有既有实现和回归。 **未闭合：**方法 proposal→admission 的新权限不扩张通路尚未接通。 |
| A09 / W04 | 冻结之前完成检查绑定 | 部分 | 旧 Graph 冻结合同和新 Binding/Recipe schema 均存在。 **未闭合：**新方法 check registry 映射先于 freeze 的实际链路未证明。 |
| A10 / W04 | Graph 既有边界 | 部分 | 现有 Graph 检查数量、命令预算、primary 和 local_verified 边界仍在源码中。 **未闭合：**没有新 recipe admission 通过该入口的对应17项/超预算/merged终态完整反例执行记录。 |
| A11 / W05 | 必需上下文不能被静默裁剪 | 未实现 | 材料 reader 可逐页返回完整字节；协议能表示材料绑定。 **未闭合：**没有方法上下文遗漏时 METHOD_CONTEXT_OMITTED 且 adapter invoke=0 的实际 wrapper。 |
| A12 / W05 | 真实 adapter 输入与来源信任 | 部分 | 实际宿主实验有原材料分页送达、输入哈希与工具 trace，原文权限限制明确。 **未闭合：**宿主显式读取不等于注册 adapter 的 prepared/observed 双阶段 task receipt 与 trust enforcement。 |
| A13 / W06 | 空环境真实表面验证 | 有直接证据 | 真实 CLI→daemon/SQLite smoke 及隔离 skills-check 五例有行为谓词、明确 scratch home 和证据/清理。 **未闭合：**仅命名 fixture 和确定性适配器；不外推真实 provider、正式 gate 或所有功能。 |
| A14 / W06 | 失败与资源清理 | 部分 | 预检、timeout、清理错误、owned 路径拒绝和失败留存已有实际记录。 **未闭合：**不声称穷尽无关进程保持/所有后代终止；完整原故障交叉场景未作为 A14 整体验收。 |
| A15 / W07 | 旧候选证据失效 | 部分 | 快照检查 head/base bracket；驱动/投影记录源码构建绑定和一致性。 **未闭合：**方法验证票据对 head/base/env/check/contract 所有维度的 stale consumer 尚未闭合。 |
| A16 / W07 | worker 不能伪造 verifier | 部分 | 既有验证 host 与新组件区分角色/身份；raw report 未签发正式通过。 **未闭合：**新方法可信 verifier producer/consumer join 及伪造 worker 的拒绝链路未完成。 |
| A17 / W07 | 逐条 review disposition | 部分 | 真实审计保留阻塞意见与处置；只读 PR 报告不产生 merge permit。 **未闭合：**不等于 method review 产物消费者拒无依据 dismiss/阻止 approved 的原场景。 |
| A18 / W08 | 端到端能力接入 | 未实现 | 真实宿主修复已执行同测试 RED→fix→GREEN。 **未闭合：**缺 recipe→proposal→合同→执行→独立验证→local_verified 的方法接入链；宿主修复不能替代 W08。 |
| A19 / W08 | 默认关闭与性能兼容 | 部分 | 现有默认 CLI/启动预算 CI 和无新增常驻服务有历史工程证据。 **未闭合：**没有 W08 新 recipe 开关的关闭兼容对照，因此不证明原可选能力开关契约。 |
| A20 / W09 | 调查不假装交付 | 部分 | investigation 文稿明确调查不等于交付。 **未闭合：**recipe 的 Graph scout unsupported 运行拒绝未实现。 |
| A21 / W10 | 决策记录追加纠错 | 未知 | 历史报告/纠正/审计原文被保留。 **未闭合：**本次未取得 method 决策权威 supersedes 与编辑导出不改权威状态的实际端到端证据；不以文件留存代替。 |
| A22 / W10 | 恢复与停止未知状态 | 部分 | 连续性文稿与恢复离线规格保持 unknown/hold、旧 pin、停止证明边界。 **未闭合：**新方法进程/恢复运行时没有实际完成；会话结束不等于 fencing。 |
| A23 / W11 | 验证漂移分类 | 部分 | 固定地图维护有真实 docs drift RED→单格修正→同入口 GREEN；工具失败与产品状态分轴。 **未闭合：**未闭合 recipe qualification 对全部 doc/harness/product 分类及自动晋升拒绝。 |
| A24 / W11 | 升级隔离与回退 | 未实现 | 来源/方法材料未自动激活，旧实验独立保留。 **未闭合：**新 candidate 测量失败→禁止 active、旧 in-flight run 保持身份的运行时资格系统未实现。 |
| A25 / W12 | 覆盖缺口与竞赛规则 | 部分 | parallel-work 材料区分竞争/覆盖；协议可表示候选。 **未闭合：**method-candidate 聚合与冻结竞赛规则的实际拒绝消费者尚未验证。 |
| A26 / W12 | 候选合成重新验证 | 部分 | 实际 PR/worktree 合成验证曾重新绑定 tree 与检查；frontier 当前为候选。 **未闭合：**不等于 arena artifact 合成的新身份/旧票据拒用完整实现。 |
| A27 / W13 | watcher 阻塞与未知语义 | 有直接证据 | 已合并只读 PR snapshot 对 BLOCKED/REVIEW_REQUIRED/unknown 保守输出，merge_authorized 恒 false。 **未闭合：**只读一次性 observation；不证明 watcher、merge policy 全发现或 W13 所有依赖完成。 |
| A28 / W13 | forge 不完整读回 | 有直接证据 | 分页/timeout/错误/partial GraphQL/缺失结果离线反例及一次真实只读调用留 raw、query 时间、unknown。 **未闭合：**没有 push/merge；非原子读取，forge 权限/规则集覆盖与身份认证未声称。 |
| A29 / W14 | 历史教训晋升 | 部分 | skill-authoring 方法与有限单文件维护试用有材料/写边界证据。 **未闭合：**历史坏例/合法例校准的 lesson draft→gate 晋升完整运行流程未交付。 |
| A30 / W15 | 评测公平性与预算 | 未实现 | 性能方法保留样本/失败/分母规则；宿主实验保留失败。 **未闭合：**没有同任务/模型/预算的盲化公平价值对照和 gate epoch 试点，不能推导收益。 |
| A31 / W16 | 形式化敏感性与边界 | 未实现 | 协议形式约束和组件摘要测试已存在。 **未闭合：**原要求的单不变量 formal 工具链、源码映射、坏模型与超时 unknown 试点未交付；schema 测试不是形式化试点。 |
| A32 / W16 | 事件幂等与部分成功补偿 | 未知 | 本阶段未新增外部通知/事件权限。 **未闭合：**未取得 W16 固定事件 fake connector 幂等/readback/部分成功补偿试点；不能据此断言全仓无通用事件能力。 |
| A33 / W06 | 可组合的验证控制接口 | 部分 | 固定 doctor/drive/observe 结果、JSON 回执与地图工具可用。 **未闭合：**完整登记恢复动作、渐进 help、cold caller 恢复闭环只在有限命名工具体现，未整体验收原接口。 |
| A34 / W06 | dry-run 与 doctor 的实际副作用 | 部分 | doctor/dry-run 有不建 fixture/证据、不启动子进程的实际负例。 **未闭合：**不把该结果扩展到所有 setup/cleanup、Git refs/网络资源组合；原完整场景未统一实测。 |
| A35 / W18,W05 | 功能地图按用户路径检索 | 未实现 | 固定五行地图和四入口链接图存在。 **未闭合：**按用户路径检索相关叶子、跨两个真实产品入口的功能地图加载器尚未交付。 |
| A36 / W18 | 地图过期与前提不足 | 部分 | 固定地图 invalid/漂移 mismatch/unknown 保留、禁止删行降谓词，有实际两次 full drive。 **未闭合：**地图路径检索和数据/授权不足跨表面阻断未覆盖。 |
| A37 / W17,W03 | 意图与根因假设分离 | 部分 | task-framing 有实际两宿主 prompt-only 观察，目标/假设/授权区分可读。 **未闭合：**两宿主原结论均 LIMITED；没有 recipe intent frame 与纠正后重新编译/材料变更的完整证明。 |
| A38 / W17,W03 | 有限历史与当前证据 | 部分 | 连续性/调查材料要求当前事实优先、授权核实。 **未闭合：**没有原场景有限历史检索→当前源码校准的完整执行记录，不称支持任意会话回忆。 |
| A39 / W17 | 调用体验先于接口冻结 | 部分 | 已有可运行教程、真实命令和错误回执。 **未闭合：**作者/协调者运行不能代替指定冷读者只看教程完成成功与错误恢复的验收。 |
| A40 / W17 | 技术未知的有限原型 | 部分 | architecture-design 有两个结构方案、caller/lifecycle 合成 walkthrough；不产生正式票据。 **未闭合：**原要求两个实现影响未知的有预算可运行原型与实际环境观察尚未验收。 |
| A41 / W17 | 实现偏差触发设计重审 | 部分 | 设计/审查方法要求偏差重审；实际审计后修订留存。 **未闭合：**未针对原重复workaround/type逃逸场景执行完整行为验收，文稿不能证明自动遵守。 |
| A42 / W07,W17 | 评审依据与未知分流 | 部分 | 小 Git A/B 代码审查识别可触发 bug/拒风格问题有实际观察，过度断言/漏读保留。 **未闭合：**两宿主 LIMITED；不证明一般评审质量或可信 method review consumer。 |
| A43 / W06,W07,W08 | 开发自验证与正式验收分离 | 部分 | 工程 self-check、driver 与 formal gate 明确分离，真实修复没有自签 local_verified。 **未闭合：**没有新方法接入后 self-check 冒充正式receipt被consumer拒绝的端到端负例。 |
| A44 / W06,W12 | 文件隔离不等于运行隔离 | 部分 | scratch ownership、限并发材料与真实隔离fixture已有。 **未闭合：**worktree/路径隔离不证明共享端口、DB、账号、全进程/远端容量隔离的完整矩阵。 |
| A45 / W19,W11 | 基础设施维护与未启用周期 | 部分 | 实际 fixed-map 维护两次五例、三轴状态/源码构建哈希留存；未启用周期任务。 **未闭合：**跨工具 health/owner/version/last-drive 可查询服务与完整三类自动分诊未实现；固定工具不等于 W19 全部。 |
| A46 / W10,W17 | 文档用途与结束计划 | 部分 | 方法材料禁止旧计划作为当前授权，历史及纠正报告保留。 **未闭合：**当前检索自动过滤 completed/superseded 战术计划的真实机制未验证。 |
| A47 / W17,W15 | 以可复现价值衡量结果 | 未知 | 有真实终点与工具/产品失败分开，报告没有 PR 数当 ROI。 **未闭合：**未完成固定冷用户、介入成本、首次就绪时间/恢复成本的价值基线测量；收益未知。 |
| A48 / W05,W09,W18 | 一个入口与透明渐进路由 | 部分 | 四入口、14方法与导出图可用；实际显式/native材料送达有 trace。 **未闭合：**透明纠正→新的 recipe/相关地图检索→必需验证不遗漏的运行合同尚未完成；不能将链接可达当路由效果。 |

逐项 source/evidence 由 `evidence_groups` 关联 `source-bindings.json`，其中 frontier 组只在未合并候选存在；其余证据组选取 main。原始执行 SHA 仍以各保留报告为准，本次读取 main 文件不重标历史运行 SHA。

## 19 项工作包

| W / J | 当前状态 | 原验收 | 说明 |
|---|---|---|
| W01 / J02 | 未实现 | A01,A02 | manifest 缺 subdir 默认表示；inspector 的新对象不是旧manifest接线。 |
| W02 / J02 | 部分 | A02,A03,A04 | 固定Git快照可用；subtree candidate/activation记录仍缺。 |
| W03 / J05 | 未实现 | A05,A06,A07,A37,A38 | 协议组件/方法文稿不等于纯 recipe compiler。 |
| W04 / J05,J08 | 部分 | A08,A09,A10 | 旧Graph可复用，新proposal→admission未闭合。 |
| W05 / J04 | 部分 | A11,A12,A35,A48 | 材料读工具与宿主trace可复用，invoke前遗漏拒绝未实现。 |
| W06 / J03 | 部分 | A13,A14,A33,A34,A43,A44 | 真实命名隔离工具可用；完整恢复接口/故障矩阵/冷用户验收仍缺。 |
| W07 / J07 | 部分 | A15,A16,A17,A42,A43 | 旧host/协议/实际审计可复用；新candidate review artifact可信join未闭合。 |
| W08 / J09 | 未实现 | A18,A19,A43 | 尚无原recipe到local_verified的实际接入试点。 |
| W09 / J10 | 部分 | A05,A08,A20,A48 | 四种方法材料存在，四类可编译可准入recipes未实现。 |
| W10 / J16,J19 | 部分 | A21,A22,A46 | 连续性文稿/离线恢复规格不等于方法权威轨迹与恢复服务。 |
| W11 / J10 | 部分 | A23,A24,A45 | 固定地图漂移维护可用；recipe资格/激活/旧run隔离未实现。 |
| W12 / J18 | 部分 | A25,A26,A44 | 并行方法及协议组件存在；候选聚合消费者/运行级调度未交付。 |
| W13 / J30 | 有直接证据 | A27,A28 | A27/A28 只读 classifier 核心断言已有直接产品/执行证据。W10 的计划依赖另列未闭合；原 W13 不要求持续 watcher，不能将 PS18 的扩展范围作为本子切片欠账。 |
| W14 / J19 | 部分 | A29 | 技能编写维护有材料与有限试用；结构化lesson晋升链未交付。 |
| W15 / J29 | 未实现 | A30,A47 | 仅方法和合成算术，盲评/价值/预算试点未交付。 |
| W16 / J28,J22 | 未知 | A31,A32 | 两个独立专项试点无直接验收；不把现有全仓其他formal/intake模块宣告不存在。 |
| W17 / J06 | 部分 | A37,A38,A39,A40,A41,A42,A46,A47 | 问题/设计材料和有限宿主试用存在；冷用户、有限原型及价值验证未完整。 |
| W18 / J06 | 部分 | A35,A36,A48 | 固定五场景地图可用；按相关叶子检索与跨入口覆盖未实现。 |
| W19 / J06,J23 | 部分 | A45 | 固定维护工具已真实闭环；通用健康/owner/version/lastdrive查询未全交付。 |

## 原审计条件继续有效

完整逐项 22+47 对照见 `audit-conditions.json`；原 disposition 原样嵌入，不把当时设计闭环改写为当前产品通过。关键条件：

- 原 AU03/06/11、CH06/09 与联合 RV02/03/08/11、CH03/04/16：真实注册检查、授权来源、artifact producer/consumer、permit/可信 join 仍须可执行。
- 原 AU04、CH02 与联合 CH15：必需材料不能靠追加 frozen brief；完整送达、真实 adapter task 绑定、遗漏时 invoke=0 是不同断言。reader 和宿主分页只解决部分。
- 原 AU09/10、CH08 与联合 CO01–06：来源 pin、依赖 closure、资格升级、恢复 unknown/hold/停止证明仍有运行条件，不归并为“文档已经写好”。
- 联合 RV09/10、CH06/07、CO07、CF01：原 66 Firstmate +48 pstack 用例保留，JA/local opt-in/合同字段测试不能替代。
- 原 CH04、联合 RV12/13、CH10、CO08：无盲化、公平预算与足够样本不能声称收益；旧失败保持失败，不删除分母。
- 联合 CH12、CO09：多模型名不构成独立 principal；真实可解析身份也不强制等于人类/外部组织。当前材料和工程复核不签 formal gate，不额外创设审批门槛。
- 原 AU01/08、CH03/10、联合 RV18/CO10：来源/映射/报告存在性修订可完成文档条件，不能换算为产品完成。原 AU12、CH05 的非缺陷处置保持。

## 旧实际宿主结果必须保留

- task-framing 双宿主均 LIMITED；源码/目标边界语义仍有局限。
- code-review 小 Git A/B 主识别有正面观察，但漏读、过度断言及 native/explicit 差异保留，两宿主整体 LIMITED。
- 当前 packet 修复：Codex 实际同测试 RED→改一行→GREEN，协调者 holdout 另算；Claude 六个 baseline 后第一复合源码读取实际成功、第二被拒并停止，未修复。不得追溯把未禁止的源码复合命令判成新违规。
- 模型字节消费不等于理解；requested/default 模型不等于 resolved 身份；无公平对照，不比较模型优劣或方法因果效果。

## 建议的下一步及责任

1. 先由用户确认“固定工程工具子集”是否符合日常使用：从干净已构建 checkout，用显式 scratch 跑命名五例旅程、地图维护、投影 check。具体命令沿 main 对应 README，保持旧失败和完整 raw。此使用验收只覆盖 A13、A23/A36/A45 的已交付子集，不能宣布 C2。
2. pstack 责任方优先补 C0 的冷用户成功/失败恢复与相关功能叶子检索；在此基础上交付 W03 一个 bug-fix 纯编译 proposal，保留未知检查/宿主不支持的反例，进入 C1。
3. 再按 W04/W05/W07/W08 打通授权、必需材料、可信产物消费与本地验证。与联合 host owner 协作，但不能将这些 pstack 自身接入缺口改名 Firstmate 后删除。
4. Firstmate 的持续监督/恢复/外部副作用属于其独立范围；待 pstack 子阶段明确验收再推进，不用后台能力掩盖前端方法/编译/地图缺口。W15价值、W16formal/intake按各自独立试点保留，不强行并入此阶段。

本次只读追溯，不承诺所有原验收都需要新模块；复用已有等价实现并以对应原断言实证，是可接受的交付方式。不同状态不是优先级，也不是失败率。
