import subprocess,json,hashlib,datetime
from pathlib import Path
R=Path('/Volumes/AIMATE_WORK/Developer/CodeX/osstack');W=Path('/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/post307-ci-close');U=Path('/Volumes/AIMATE_WORK/Developer/CodeX/cursor-plugins');O=Path(__file__).parent
ROOT='8e830561e09f4754d3410003c24216d8db49aa6c';MAIN='e4643324b9de1d2db51c744e59ccd7c05146b0a6';UP='99b609a72323b70204eab407c622f436e858e112';D='docs/design/2026-10-27-joint-engineering/'
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(p,ref=ROOT):return git(R,'show',ref+':'+p)
cap=json.loads(blob(D+'capability-map.json'));caps={v['id']:v for v in cap['capabilities']}
rows=[]
def add(n,usable,paths,evidence,missing,phase,stale):
 c=caps['PS'+str(n)];rows.append(dict(id=c['id'],title=c['title'],current_scoped_user_value=usable,source_paths=paths,existing_evidence=evidence,not_implemented_or_not_proven=missing,phase_boundary=phase,stale_text_correction=stale,whole_capability_complete=False,formal_gate_pass=False,source_refs=c['source_refs'],joint_work_items=c['joint_work_items']))
ref=lambda n:'osstack-methods-skill/references/'+n+'.md'
impl=lambda n:'docs/implementation/'+n+'/README.md'
add(13,'用户可保留执行/失败/cleanup各轴及原始证据，输出短结论并定位完整记录；真实两项/五项旅程可产出及核验有限安全证据包。',[ref('evidence'),'scripts/method-verification-journey.mjs','scripts/project-method-journey-evidence.mjs'],[impl('method-full-projection'),impl('pstack-current-repair'),impl('method-parallel-reporting')],['没有证明全局决策历史自动检索/旧战术计划退出当前上下文','hash与manifest不认证身份、历史真实性或判断正确性'], 'pstack本阶段可验收材料+固定旅程证据工具。J16/J19持久恢复与J04/J07资格集成为后续联合/Firstmate运行时工作；不是使用本工具的前置。','PS13 latest_bounded_delivery仍称publication pending、snapshot validated_pending_publication应以305/307已合入当前层覆盖；历史原件不改。')
add(14,'用户可按同工作量、真实结果、交替样本、错误和端到端占比审查性能结论，并用明确synthetic数例学习计算。',[ref('performance-measurement')],[impl('method-performance-measurement'),impl('method-impact-performance')],['未交付通用benchmark服务/自动优化','无真实性能收益或方法因果增益实测'], '这是已可用pstack方法交付，不需Firstmate资格。真实性能效果若被承诺仍需独立实验；不能称为已验证提升。','原capability-map design_only是旧设计快照；当前方法已交付。无需为了证明方法存在强造性能提升。')
add(15,'目前仅能复用测量与证据规范；没有面向用户的hillclimb/盲评完整执行入口。',[ref('performance-measurement'),ref('evidence')],[],['固定harness、单变量keep/revert、预算停止、盲化judge及评测epoch闭环未实现/未验收'], '真正pstack可选后续能力，明确deferred；不能伪装成Firstmate必需事项，也不阻塞已声明有限阶段。若要求吸收全部pstack能力，本项仍欠账。','保留deferred；已有有限host probes不能充当盲评或性能benchmark。')
add(16,'协调者可按自包含brief划定文件/资源/验收/依赖，核对missing lane、旧候选和unknown liveness，不把子代理自报当完成。',[ref('parallel-work'),'osstack-methods-skill/entries/osstack-agent/SKILL.md'],[impl('method-parallel-reporting')],['方法不是持久调度器/锁/租约/隔离执行器','不存在已验证全宿主自主编排或竞争优选闭环'], 'pstack分工指南可用；J17资源broker、J18执行、J19监督/恢复属于联合运行时后续，需Firstmate运行时证据；实际普通委派不必等它们。','保留partial但明确可用是指导与工具使用约定，而非只有设计；既有OSStack功能不冒充本批新增。')
add(17,'main已能读取单PR并绑定head/base、检查/评审/整合事实及unknown。root另有显式1–3 PR顺序前沿报告候选，区分merged前缀与首个未合项。',[ref('pr-readiness'),'scripts/report-pr-candidate.mjs','packages/github/src/pr-candidate-snapshot.ts','scripts/report-pr-stack-candidate.mjs','packages/github/src/pr-stack-candidate.ts'],[impl('pr-candidate-snapshot'),impl('pr-stack-candidate')],['root栈报告尚不在actual main','没有持续watch/自动拓扑修复、推送/合并/重启权限','命名base关系不是完整Git祖先证明；没有全策略发现或原子多PR快照'], 'main单PR报告可阶段验收；栈报告必须单列待发布候选，若纳入本阶段交付则完成正常发布/用户合并。自主执行/lease资格是后续联合工作，不能作为只读报告挡板。','per-capability仍说仅材料/自动服务未接线会掩盖307；更正为单次工具已合入、bounded stack候选已实现未发布，持续服务未实现。')
add(18,'main单次forge读取与纯分类可区分blocked/waiting/unknown；legacy StatusContext和CheckRun导入分类缺陷已修，真实新卡使用修后ci_state。',['packages/github/src/pr-candidate-snapshot.ts','packages/github/src/stack.ts','scripts/report-pr-candidate.mjs'],[impl('pr-candidate-snapshot'),impl('stack-checkrun-state')],['不持续观察/自动重试/rearm','既有卡不自动刷新；detectDrift忽略aggregate unknown的既有界限未修','stack导入保留NEUTRAL/SKIPPED成功政策，snapshot更严格，两者不是同一许可系统'], '可验收一次读取及分类修复，不把完整watch-pr移植说成完成。持续服务为pstack/联合后续范围，不全属于Firstmate；J30和正式发布许可未签。','PS18仍把308/309称候选或说只有方法已过时：两修复已main；保留历史README时态并在当前汇总注明。')
add(19,'用户可依据continuity方法整理最小交接、核当前Git/授权/owner/副作用再继续；显式暂停时保留证据和未知清理义务。',[ref('session-continuity'),'packages/core/src/state/operator-recovery-spec.test.ts','packages/core/fixtures/broker-recovery/manifest.json'],[impl('method-session-continuity'),impl('method-continuity-delivery')],['恢复SQL/fixture/spec不是真实部署broker或runtime恢复入口','未证明跨崩溃重启/owner转移后副作用重发安全和完整进程树清理'], 'pstack人工/agent交接方法可验收。J12/J17/J19在Firstmate/联合运行时继续前必须按真实生产边界处理；不挡普通文件任务交接。','区分方法已可用与恢复规范仅候选；不能写全恢复已完成，也无需将方法降成纯设计。')
add(20,'四入口可自包含导出到Codex/Claude项目；源码checkout分页脚本可绑定文件hash继续到EOF。真实任务曾由Codex与Claude分别完成有限修复，但结果不一致。',['scripts/export-osstack-methods.mjs','scripts/read-method-material.mjs',ref('host-usage')],[impl('method-material-reader'),impl('pstack-real-loops'),impl('pstack-export-repair'),impl('pstack-current-repair')],['不保证自动原生发现、全方法等价或强制读取/理解','最新同packet任务Claude仅baseline后权限拒绝而未修，Codex完成；旧Claude exporter材料漏61–64行仍LIMITED','工具和提示不是OS读取/网络隔离，模型身份不独立认证'], '可阶段验收导出/分页及有界工程观察。若要求两个宿主当前端到端稳定自动修复，尚不能通过；作为Firstmate远端provider资格前还须J10/J23等实证，不能据历史成功推定。','material_delivery_candidate待PR已落后303；currentpacket publication pending落后305。只更新现态，旧失败与LIMITED保持。')
add(21,'源文件固定pin/许可/转换后digest可追踪，导出manifest绑定实际共享材料；source-snapshot组件存在但不等于自动采用资格。',['packages/skill-registry/src/source-snapshot.ts','scripts/export-osstack-methods.mjs',ref('sources')],['docs/reports/2026-10-26-pstack/evidence/source-lock.json'],['完整采用闭包、上游漂移激活、admission与provider资格未闭合'], '固定来源和许可是本阶段必须满足的基础，已可查；完整registry/adoption/qualification是联合运行时后续条件，不应阻塞只读探索/本地材料使用。','保留partial；不能把281组件+导出清单自动升级为J02/J08/J10/J26通过。')
add(22,'无已移植Benny事件intake入口；上游自身是dormant automation setup源。',[],[],['外部报告去重、复现、发帖readback和补偿未实现/启用'], '明确pstack可选扩展deferred；不是Firstmate先行必需能力。未有外部写入需求时不作为当前阶段验收挡板。','保留deferred，不能用本线程任务派发或普通GitHub读取冒充Benny。')
add(23,'caller-first架构方法、真实目标checkout验证教程与功能地图可用；固定skills-check用户路径已有实际驱动与地图维护工具。',[ref('architecture-design'),ref('skills-check-journey'),ref('maintain-verification'),'scripts/maintain-skills-check-map.mjs'],[impl('method-architecture-design'),impl('method-verification-journey')],['未证明三条正式冻结地图/所有冷用户场景或全部API消费者已验收','synthetic架构示例不是实现或崩溃测试'], '可阶段验收方法+明确命名固定验证旅程。J03/J06完整统一地图及qualification是联合后续；不能用它抹掉现有用户路径，也不能把一条旅程当全场景。','原仅caller-first文档描述偏弱，应补已有journey及maintenance实际入口；三地图未全过仍保留。')
add(24,'用户可用连续性方法对照原始记录与当前状态，收到短结论、明确unknown和下一动作；证据摘要不覆盖原件。',[ref('session-continuity'),ref('evidence'),ref('parallel-work')],[impl('method-continuity-delivery'),impl('method-parallel-reporting')],['没有跨项目全局记忆/自动检索/上下文注入保证','视频/Bot/个性化接口未移植；无需默认启用'], '可验收任务范围内交接/解释材料；J16/J19持久恢复与J20检索需后续联合设计和真实验证。视频等pstack可选项目保持deferred，而不是Firstmate硬前置。','保留partial，当前简报材料与全局记忆自动化分开。')
# actual file identity/existence on both immutable trees
paths=set([D+'capability-map.json',D+'delivery-rollup.json',D+'execution-gates.json',D+'pstack-feature-queue.md'])
for row in rows:paths.update(row['source_paths']);paths.update(row['existing_evidence'])
bind=[]
for p in sorted(paths):
 rec={'path':p}
 for key,rev in [('root',ROOT),('main',MAIN)]:
  q=subprocess.run(['git','-C',str(R),'show',rev+':'+p],capture_output=True)
  rec[key]={'present':q.returncode==0,'sha256':sha(q.stdout) if q.returncode==0 else None,'bytes':len(q.stdout) if q.returncode==0 else None}
 bind.append(rec)
# resolve typo by reporting rather than inventing path; correction below handled before delivery
up=[]
for p in sorted({x[3:] for row in rows for x in row['source_refs']}):
 b=git(U,'show',UP+':'+p);up.append({'path':p,'commit':UP,'sha256':sha(b),'bytes':len(b),'url':f'https://github.com/cursor/plugins/blob/{UP}/{p}'})
central=[]
for name in ['delivery-rollup.json','delivery-status.md','execution-ledger.json','execution.md','project-operations.md','pstack-feature-queue.md']:
 p=D+name;b=(W/p).read_bytes();central.append({'path':p,'sha256':sha(b),'bytes':len(b),'differs_from_root_commit':b!=blob(p),'authority':'uncommitted_worktree_observation_not_published'})
(O/'source-bindings.json').write_text(json.dumps({'git':bind,'upstream':up,'uncommitted_central':central},ensure_ascii=False,indent=2)+'\n')
missing=[b['path'] for b in bind if not b['root']['present']];print('MISSING_PATHS',missing)
r={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'PS13–24 only; source/evidence read, no product/host/test rerun','root_commit':ROOT,'actual_main':MAIN,'upstream_pin':UP,'source_bindings':'source-bindings.json','global_judgment':'建议以明确范围的pstack方法/工具阶段验收收口，保留whole_capability_complete=false与运行时未通过；停止新增功能，先补当前汇总与候选发布边界。','not_a_gate':'本文不签发任何J/JA/provider资格，不重评旧宿主试验。','items':rows,'material_staleness':['capability-map.json为初始设计层，全部design_only/specifed_not_run不能直接当现态；建议加current_stage_acceptance引用而非覆写历史。','rollup PS13/17/18 snapshot待发布、PS20 reader待PR/currentpacket待发布落后于main。','PS23当前文档仅说设计，遗漏实际固定旅程与map维护工具。','queue PS18仍将StatusContext/CheckRun修复叫候选；当前main已包含。'],'phase_decision':'用户转Firstmate不要求把所有partial改done。对明确deferred的hillclimb/Benny/视频保留欠账；恢复/资源/身份/资格后续仍须真实合同，不是当前方法工具使用前置。'}
(O/'report.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
md=['# PS13–24 阶段验收核对','',f'固定根候选 `{ROOT[:8]}`；实际 main `{MAIN[:8]}`；上游 `{UP[:8]}`。另读取6份中央工作树未提交文件，具体hash在 source-bindings.json，不能当已发布状态。','','建议现在收口“方法包与有限工程工具可用”这一阶段，再转Firstmate。**不把12项整体改完成，不以方法数、PR数或测试数代替用户结果。** 栈前沿8e830仍是待发布候选；main已有单PR观察、两类状态修复。','','| 项 | 现在用户可用 | 真正缺口/后续边界 |','|---|---|---|']
for x in rows:md.append('| '+x['id']+' '+x['title']+' | '+x['current_scoped_user_value']+' | '+'；'.join(x['not_implemented_or_not_proven'])+' |')
md+=['','当前应修的是汇总层：PS13/17/18的“待发布/仅方法”、PS20的reader/currentpacket候选标签已过时；PS23应列出固定旅程与map维护。历史审计和试验结论原样保留。','','Firstmate后续真正需要的是恢复、资源所有权、执行/监督、来源采用与资格的真实生产证据；普通方法读取、只读PR报告和本地固定验证旅程不用等待这些联合gate。持续watch、hillclimb、Benny和全局记忆仍是明确欠账，不能统称“Firstmate问题”来消掉。','','跨宿主只可接受有界观察：Codex当前packet修复成立，Claude同轮未完成；Claude另一历史exporter修复成立但材料读取不全。分页工具已可用不使旧LIMITED变绿，也不证明全方法稳定自主执行。','','具体原始来源、现有证据路径及逐项phase判断见 report.json；本轮没有模型调用、产品执行、全仓测试或任何共享文件修改。']
(O/'report.md').write_text('\n'.join(md)+'\n')
