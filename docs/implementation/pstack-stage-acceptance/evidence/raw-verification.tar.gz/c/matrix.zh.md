# pstack 阶段独立验收矩阵

**结论：pstack 整体尚未结束；可以结项一个更小、可用且可核验的 D2a 阶段。** 建议暂停扩展，先收口 frontier 候选，再让用户验收“共享方法交付 + 固定验证维护闭环 + 有界 PR 观察”。这不等于 24 项能力、32 项联合里程碑或两宿主全功能通过。

固定主线 `e4643324b9de1d2db51c744e59ccd7c05146b0a6` 已合并 #309；固定候选 `8e830561e09f4754d3410003c24216d8db49aa6c` 含 frontier。此文只读 Git 与既有原始报告，没有重新跑产品、模型、DB、全仓或 CI。

## 可审查的小阶段

| 阶段 | 当前状态 | 可接受的交付 | 不包含 |
|---|---|---|---|
| S1 共享方法材料的可交付与完整读取 | merged_available_user_acceptance_pending | 四入口、14方法及引用真实可达；新目录导出；分页/摘要绑定/EOF；用户能读到完整材料。 | 原生发现、正确路由、理解、全方法效果或J15通过 |
| S2 固定五case验证、地图维护与可分享证据 | merged_available_user_acceptance_pending | 真实0/1/2/1/0产品语义、driver成功与产品失败分开；地图不被自动改写；原始证据保留、cleanup逐项、full v2投影check；默认2/v1兼容。 | 任意项目功能地图生成/所有用户入口覆盖/来源认证 |
| S3 有界候选观察与保守分类 | merged_single_pr_and_classifiers; frontier_candidate_pending_merge | 单PR稳定head/base、完整unknown/failed；StatusContext与CheckRun政策各自准确；显式1–3 PR只越过稳定merged前缀，报告0不等于Ready。 | 自动merge/retarget/watch、全栈原子性、历史比较、旧卡自动刷新 |
| S4 真实宿主任务行为 | partially_observed_not_full_acceptance | 只按各历史任务实际结果结论；若用户要验收真实使用，另选一项用户任务，按当前已授权范围，固定输入/反例/完整材料后观察。 | 两host全面通过、无方法对照的因果收益、模型排名/认证身份 |

S1、S2、S3 的已合并部分有机器验证与真实有限执行证据，可交用户验收；不是要求重跑历年全部回归。frontier 的候选部分必须保持“未合并”，直到 root 的最终 CI/发布与用户合并完成。S4 不纳入“全面通过”的结项声明。

## 最短用户验收流程（本次未执行）

在用户选定的已合并 checkout 中运行。Node 22、pnpm 依赖和当前构建是前置；若已有可信且与当前源码绑定的构建，可复用其记录，否则执行下列 install/build。不要为“保持干净”在验收中途还原生成的 dist。所有运行资料保留在新 scratch；不使用默认 OSStack home。

```sh
set -eu
export PATH=/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin
export OSSTACK_SCRATCH_ROOT=/Volumes/AIMATE_WORK/tmp/osstack
mkdir -p "$OSSTACK_SCRATCH_ROOT/runtime"
ACCEPT="$(mktemp -d "$OSSTACK_SCRATCH_ROOT/runtime/pstack-acceptance-XXXXXX")"
export OSSTACK_HOME="$ACCEPT/home"
unset OSSTACK_SOCKET
git rev-parse HEAD > "$ACCEPT/checkout.txt"
pnpm install --frozen-lockfile > "$ACCEPT/install.log" 2>&1
pnpm build > "$ACCEPT/build.log" 2>&1
node scripts/export-osstack-methods.mjs --host codex --output "$ACCEPT/codex" > "$ACCEPT/export-codex.json"
node scripts/export-osstack-methods.mjs --host claude --output "$ACCEPT/claude" > "$ACCEPT/export-claude.json"
node scripts/read-method-material.mjs --file "$ACCEPT/codex/.agents/skills/osstack-mode/references/evidence.md" --lines 200 > "$ACCEPT/material.json"
cp docs/implementation/skills-check-map-maintenance/map.json "$ACCEPT/map.json"
node scripts/maintain-skills-check-map.mjs --map "$ACCEPT/map.json" --output "$ACCEPT/map-run" > "$ACCEPT/map.stdout" 2> "$ACCEPT/map.stderr"
node scripts/project-method-journey-evidence.mjs --input "$ACCEPT/map-run/journey" --output "$ACCEPT/packet" --scope full > "$ACCEPT/project.stdout" 2> "$ACCEPT/project.stderr"
node scripts/project-method-journey-evidence.mjs --check "$ACCEPT/packet" > "$ACCEPT/check.stdout" 2> "$ACCEPT/check.stderr"
printf "%s\n" "$ACCEPT"
```

验收点：四入口及引用存在；material 的 `eof` 为真、摘要和源文件一致；地图结果 `consistent`，五项 product exits 为 **0/1/2/1/0**，其中 empty 状态仍为 empty，driver 的 0 不掩盖 expected failure/drift；map 前后字节一致，原始 journey/receipt/manifest 保留；已拥有 fixture 清理结果可核；packet 为完整 v2 五行并自检通过。若 material 未到 EOF，必须按返回的 `next_start` 与首个 `sha256` 继续读，不能把第一页当全文。出现 blocked/unknown/缺证据时原样记录，不删行、不改期望翻绿。

最短流程只做一次真实绿色闭环；历史 RED→仅修 map→同入口 GREEN、非法 map 零 drive、默认两行兼容及负例属于已有机器证据，不谎称上述命令重跑了它们。若用户特别要观察维护纠错，另复制 map、仅把 missing-ref 的合法 expected exit 改为 0，使用新 output 应得到 mismatch/exit1；核真实行为后只修 map 回1，再新 output 重跑；不改产品源码或旧结果。

有现成授权 gh 配置时，可选一次单 PR 只读快照：设置真实 `REPO`、`PR` 后运行 `node scripts/report-pr-candidate.mjs --repo "${REPO:?}" --pr "${PR:?}" --output "$ACCEPT/pr-observation"`。固定候选检查还应同时给 `--expect-head` 和 `--expect-base`；已知所需检查才传名称。读 head/base、阻塞/等待/未知，退出0仅报告成功。frontier 合并后，用户自己填写1–3 PR有序 plan，再运行 README 的 stack 命令；不能使用上次308→309历史快照当当前状态。

用户真实工作验收与上述机械验收分开：打开一个导出项目，先确认当前宿主实际目录/入口，再给一项已有授权的小任务（例如只读审查一个真实变更，或在隔离候选修复一个已复现小缺陷），要求展示完整材料读取及实际证据。原生 Skill 与显式读取分别记录；执行权限拒绝就停并报告。当前没有授权新模型预算，本报告不自动派发。用户评的是任务是否有用、是否减少人工跟进，而不是方法数或报告字数。

## 真实宿主结果必须保留

| 证据 | 可承认事实 | 不能升级的部分 |
|---|---|---|
| method-native-discovery / EXPORT | 有双host导出、部分目录与真实读取证据 | Codex旧目录与执行是不同进程、原inventory缺口；不认证App或全方法原生调用 |
| method-review-behavior | 小合成Git样本中两host主要A/B判断正确 | Codex归因未证；Claude漏读并作过宽事实断言；均LIMITED，无因果对照 |
| method-packet-host-consumption | Codex有限解释；Claude v2真实native使用 | Claude515词超硬500失败；初次0turn catalog阻断不是模型失败；旧成绩不改 |
| method-continuity-delivery / host-report | framing实际读取与有限输出 | 两host仍LIMITED；材料送达不等于策略正确或任务收益 |
| method-pr-readiness-delivery / host-report | 四场景主要分类可观察 | Claude578词失败；修后新head绑定遗漏等原评定不补认 |
| pstack-export-repair | Claude真实历史exporter RED→同test修复GREEN | 历史已修缺陷、evidence60/64读取缺口；协议LIMITED，不冒充当前新bug |
| pstack-current-repair | Codex当前packet缺陷真实RED/fix/GREEN与隐藏控制，修复已合并 | Claude6基线后第一复合源读取成功、第二被拒并停，未修；完整16页送达不是理解；宿主权限差异不能作模型排名 |

## 24PS逐组范围

| ID | 当前可用/候选 | 仍缺什么、由谁保留 |
|---|---|---|
| PS01 单入口任务路由与渐进方法组合 | 14共享方法、四入口路由/帮助；没有单一runtime编译/强制执行通道 | 没有持久方法编译/执行与全路由资格；14份材料不等于14项完整产品能力。 owner：pstack能力负责人/root排期。 |
| PS02 代码机制与历史动机取证 | investigation可用；how/why/teach为方法吸收，没有专门历史取证工具或全面效果验证 | 专门历史动机检索工具及普遍解释效果未验收。 owner：pstack能力负责人/root排期。 |
| PS03 意图校准与可纠正的问题模型 | task-framing已合并；实际两宿主均LIMITED，尚非任务执行收益证明 | 真实任务意图校准的收益未证；现有两宿主framing均LIMITED。 owner：pstack能力负责人/root排期。 |
| PS04 从使用草图到原型证据的架构循环 | architecture/feature/refactoring可用；独立多原型arena和完整采纳循环未交付 | 独立多方案原型arena及完整采纳循环未交付。 owner：pstack能力负责人/root排期。 |
| PS05 覆盖式并行与预先声明的竞赛 | PR301已合入并行分工指南；运行时派发、竞赛和完整宿主效果尚未验收。 | 指南之外的运行时并发派发/覆盖竞赛未验收。 owner：pstack能力负责人/root排期。 |
| PS06 独立评审与意见裁决 | code-review材料+本项目独立审查审计实践；产品化跨模型评审/资格未闭合 | 产品化跨模型评审与角色资格未闭合；小样本正确主结论不能替代完整审阅。 owner：pstack能力负责人/root排期。 |
| PS07 影响面与关键前提验证 | change-impact材料/关键前提检查；普遍宿主效果未验证 | 跨项目影响面穷尽性与假设挑战效果未验证。 owner：pstack能力负责人/root排期。 |
| PS08 可操控的验证基础设施与功能地图 | 共享create-verification方法、engineering/skills两类真实验证器、默认2/可选5case旅程已在main。 | 任意项目自动生成完整功能地图/旅程未证明；现有固定OSStack样例可用。 owner：pstack能力负责人/root排期。 |
| PS09 验证基础设施的健康、归属与漂移维护 | maintain方法及固定五case地图命令已合并，真实合法地图→陈旧值RED→仅map修正GREEN证据保留。 | 广义漂移发现/任意项目地图维护未闭合；现有固定五case维护可用。 owner：pstack能力负责人/root排期。 |
| PS10 形式化验证生命周期 | 形式化生成/维护与代码mutation对应尚未作为pstack能力实现 | 形式验证技能生成、维护、模型与实现变异对应未作为pstack切片交付。 owner：pstack能力负责人/root排期。 |
| PS11 状态图与反例解释 | 状态图/反例解释工具未移植，不把普通Mermaid文档当模型检验 | 状态图及可执行模型反例工具未移植；普通图文不作替代。 owner：pstack能力负责人/root排期。 |
| PS12 反思转结构化约束 | skill-authoring第14方法已随PR302合入；反思到技能约束仅材料切片，不是受控经验晋升运行时。 | 反思到受控经验晋升运行时未交付；技能编写材料不自动授权扩写。 owner：pstack能力负责人/root排期。 |
| PS13 决策轨迹与证据归因 | 原始记录、manifest、default v1/full v2安全投影和单PR快照已合并；自签摘要不是身份认证。 | 身份/来源真实性及完整因果归因未认证；manifest只证明所保留字节一致。 owner：pstack能力负责人/root排期。 |
| PS14 性能结论审查 | 性能审查方法与合成数例可用；无因果性能提升结果 | 没有真实性能收益、噪声控制与端到端因果实验。 owner：pstack能力负责人/root排期。 |
| PS15 有预算的 hillclimb 与盲评 | 有预算hillclimb/盲评尚未实现；当前有限host probe不是效果benchmark | 有预算hillclimb及盲评循环未实现；现有host probe不构成benchmark。 owner：pstack能力负责人/root排期。 |
| PS16 自包含单元与协调者边界 | PR301已合入并行分工指南；运行时派发、竞赛和完整宿主效果尚未验收。 | 统一owner/隔离/协调者运行时尚未验收；并行指导本身可用。 owner：pstack能力负责人/root排期。 |
| PS17 栈前沿与候选绑定验证 | PR-readiness材料和单PR只读快照已合并。 8e830中的1–3 PR显式有序前沿报告；独立42场景/58断言和10渲染反例闭环、一次8查询历史观察，不替代最终CI/merge。 | frontier是未合并候选；没有持续watch、自动rebase/retarget、历史比较或完整依赖发现。 owner：pstack能力负责人/root排期。 |
| PS18 forge 观察器分类 | 307单PR快照、308 StatusContext及309异常/不完整CheckRun分类修复均在main e464。 | 单次快照/分类修复已合并；持续forge观察器未移植，existing-card刷新不在现有ingest契约。 owner：pstack能力负责人/root排期。 |
| PS19 暂停与恢复对账 | session-continuity材料可用；恢复schema/spec不等于J12运行态恢复；PR301已合并紧凑报告/证据归因与协调指南，未提供自动forge观察、检索或恢复运行时。 | 连续性材料不提供进程fencing、unknown action补发或锁释放；持久接续链未交付。 owner：pstack能力负责人/root排期。 |
| PS20 跨宿主方法适配 | 四入口、14共享方法、双host导出与有限真实host任务；当前packet任务Codex修复完成，Claude权限拒绝后未修复。 | 四入口导出与部分实际使用不证明Codex App/CLI/Claude全方法同等有效，权限与模型身份仍分轴。 owner：pstack能力负责人/root排期。 |
| PS21 来源快照与能力资格验证 | 更早281来源快照组件与合同、292材料源清单；实际采用闭包/资格/漂移激活未闭合 | 采用闭包/来源资格消费及漂移失效链未闭合。 owner：pstack能力负责人/root排期。 |
| PS22 事件 intake 与补偿模式 | Benny/外部事件intake补偿未启用或移植 | Benny式外部事件intake/补偿未移植；不能因Firstmate有监督定位就宣布此pstack组完成。 owner：pstack能力负责人/root排期。 |
| PS23 使用方式驱动的接口与文档设计 | caller-first architecture、验证材料与文档；三条冻结地图和冷用户验收未全通过 | 冷用户能否独立完成三条冻结功能地图仍未全验收。 owner：pstack能力负责人/root排期。 |
| PS24 历史上下文恢复与可理解的决策说明 | continuity/解释+301已合并简报材料；无全局记忆自动化；视频/Bot/个人风格暂缓；PR301已合并紧凑报告/证据归因与协调指南，未提供自动forge观察、检索或恢复运行时。 | 无全局历史检索/记忆自动化；连续性解释材料不能代替真实检索与恢复。 owner：pstack能力负责人/root排期。 |

这里的“未实现”限原设计或本阶段明确未交付部分；“未验证”限效果/覆盖/资格尚未证明。未证明不一概写成不存在。20组 partial +4组 deferred 的旧分类只是清单状态，不能计算成完成率。

## 32J不能被阶段结项代签

全部 `formal_gate=false`。以下沿用原工作包/gate和既有对账缺口，当前增量另注；不是本轮重新穷尽审计所有代码。完整已交付/待验证/未实现/unknown四轴和原JA IDs在 matrix.json。

| J | 工程范围/本轮澄清 | 尚未交付的声明范围 |
|---|---|---|
| J01 共享身份、完成与资格契约 | component_partial | 计划中的无副作用可信宿主准入入口尚未交付，不能由schema检查代替。 |
| J02 共用来源快照与分型注册 | component_partial | 采用依赖闭包及相应图/漂移失效消费链尚未交付。 |
| J03 session-answer-receipt 驱动夹具 | adjacent_tooling_partial | 计划中的method-control和session-answer-receipt统一驱动尚未交付。 |
| J04 必需方法材料与 v2 调用回执 | material_and_foundation_partial | MethodBinding必需材料装载、方法快照与完整v2调用回执链尚未交付。 |
| J05 检查映射与单方法纯编译 | planned_runtime | 单方法纯编译与check映射输出尚未交付。 |
| J06 使用草图与三条功能地图 | adjacent_tooling_partial | 复现/等待/取消三图及统一usage-sketch回执交付尚未完成。 |
| J07 产物消费与同候选评审 | 单PR/安全投影在main；多PR前沿候选补充有限观察工具，不成为host-authoritative artifact/资格消费者。 | host-authoritative method artifacts及其资格消费链尚未交付。 |
| J08 首次受限试验准入 | design_and_contract_partial | method-host-admission入口及计划的首次受限trial链尚未交付。 |
| J09 首个本地 bug-fix 方法旅程 | material_and_adjacent_tooling_partial | recipe驱动的本地bug-fix旅程与method report尚未交付。 |
| J10 方法资格与激活漂移管理 | contract_only_runtime_planned | 持久qualification、active漂移失效和方法改进晋升链尚未交付。 |
| J11 恢复回执目标 schema 规格 | offline_spec_partial | 这些候选尚未注册运行时迁移；运行恢复属于后续J12，不应列为J11已实现。 |
| J12 目标 schema 恢复与操作员处置 | offline_preparation_partial | operator-recovery host、白名单迁移selector及跨进程原子处置链尚未交付。 |
| J13 主控事件模型与累计预算 | existing_foundation_runtime_planned | 联合controller/planner事件模型和累计预算执行链尚未交付。 |
| J14 Loop/Graph 准入与单次启动 | existing_foundation_runtime_planned | 联合engineering-executor及对应新准入接线尚未交付。 |
| J15 统一入口、范围纠正与路由 | 4入口/14方法已合并，可结项材料导出小切片；持久路由、问题版本/范围纠正、可信答案接线仍未交付。 | 联合持久router、问题版本/纠偏与可信人类答案接线尚未交付。 |
| J16 跨方法与监督的联合旅程 | adjacent_journey_partial | 跨方法与持续监督/恢复的完整joint journey及指定crash集成尚未交付。 |
| J17 容量、写集合与集成候选 | offline_schema_spec_partial | JP-17b恢复与可信proof、JP-17c运行时容量/write-set/integration routing尚未交付。 |
| J18 竞争与覆盖模式的多候选扩展 | planned_runtime | method-candidates与coverage/integration候选选择扩展尚未交付。 |
| J19 上下文恢复与受控经验 | session-continuity/skill-authoring材料已合并；项目隔离检索、有效期、provenance消费和经验晋升仍缺；不归为Firstmate已完成。 | 项目隔离上下文检索、有效期/provenance消费和受控经验晋升尚未交付。 |
| J20 事件监督、低打扰与增量简报 | material_only_runtime_planned | 新联合事件监督、持久未决义务与增量brief运行链尚未交付。 |
| J21 远端子主管与父子回执 | planned_deferred_priority | 远端子主管接线及恢复后的parent receipt处理尚未交付。 |
| J22 外部事件与授权公开承诺 | planned_deferred_priority | external intake及授权公开commitment运行链尚未交付。 |
| J23 宿主与执行器资格测量 | limited_experiments_not_qualification | 计划中的qualify-engineering-host和支持单元测量工具尚未交付。 |
| J24 有效版本、升级与恢复演练 | existing_guard_partial | 指定joint升级smoke与全支持单元有效版本演练尚未交付。 |
| J25 早期方法价值实验 | observational_experiments_not_value_gate | 原方法价值协议与eval执行入口尚未交付。 |
| J26 来源能力与当前交付投影 | documentation_projection_partial | 原计划capabilities validator/capability-delivery模块入口未交付；当前文档投影不能冒充这些实现。 |
| J27 灰度与支持范围内启用 | not_enabled | 原计划分阶段release验证入口与联合运行手册尚未交付。 |
| J28 高后果状态不变量形式化试点 | planned_deferred_priority | 指定joint-effect TLA模型与检查入口尚未交付。 |
| J29 性能与有预算的改进循环 | material_partial_not_performance_experiment | 指定性能eval入口和真实预算改进循环尚未交付。 |
| J30 Forge 观察与栈前沿验证 | 纠正历史rollup的“stack frontier尚未交付”绝对措辞；只读候选不是正式J30通过。 | 持续Forge observer、自动运行接线/完整method report与原JA41/57资格尚未交付；不能再把所有stack frontier一概写成无实现。 |
| J31 清理前保全与应用回执修复 | product_component_partial | DEBT02跨进程unknown producer恢复与全保全清理链尚未交付。 |
| J32 联合四组对照与冷用户验收 | planned_evaluation | 指定联合四臂eval执行入口与完整实验交付尚未完成。 |

## 进入Firstmate之前的最小交接

1. Root收口frontier当前候选，保留原失败/修复/审计/最终CI的各自SHA；用户验收S1–S3限定成果。
2. 将未交付pstack项明确留在pstack backlog：通用项目验证/维护、形式化/状态图、hillclimb/盲评、来源采用与资格、持续forge、真实宿主效果等。它们不是“做Firstmate就自动完成”。
3. Firstmate先解决其主责的持久监督、未决义务、owner/fencing、恢复/补偿；J15、J19、J23和J32为共享接口/验收，写清双方责任。四入口不是持久router，连续性材料不是检索/经验晋升运行时。
4. 当前root rollup的top main_sha/candidate_status存在历史滞后（仍有a250/308 pending），J30也有过宽“stack frontier未实现”旧句。新增按e464/8e830分层的当前快照即可，保留历史记录，不改旧实验成绩。

可以向用户说：“pstack的限定工程工具阶段已具备验收条件，整体能力仍未完成；先验收这个阶段，再优先推进Firstmate，同时保留pstack未交付清单。”不应说“pstack结束，剩下全归Firstmate”。
