from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path(__file__).parent;repo='/Volumes/AIMATE_WORK/Developer/CodeX/osstack';up='/Volumes/AIMATE_WORK/Developer/CodeX/cursor-plugins';main='e4643324b9de1d2db51c744e59ccd7c05146b0a6';root='8e830561e09f4754d3410003c24216d8db49aa6c';pin='99b609a72323b70204eab407c622f436e858e112'
def raw(rev,path,where=repo):return subprocess.check_output(['git','show',rev+':'+path],cwd=where)
def data(rev,path):return json.loads(raw(rev,path))
def exists(rev,path):return subprocess.run(['git','cat-file','-e',rev+':'+path],cwd=repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
h=lambda b:hashlib.sha256(b).hexdigest()
roll=data(root,'docs/design/2026-10-27-joint-engineering/delivery-rollup.json');cap=data(root,'docs/reports/2026-10-26-pstack/capability-map.json');work=data(root,'docs/design/2026-10-27-joint-engineering/work-packages.json')
paths=['docs/design/2026-10-27-joint-engineering/'+x for x in ['delivery-rollup.json','delivery-status.md','pstack-feature-queue.md','work-packages.json','work-package-index.md','execution-gates.json','gate-layers.md']]+['docs/reports/2026-10-26-pstack/capability-map.json','osstack-methods-skill/SKILL.md','osstack-methods-skill/EXPORT.md','package.json']
readmes=['method-native-discovery','method-packet-host-consumption','method-review-behavior','method-material-reader','method-full-journey','method-full-projection','skills-check-map-maintenance','pr-candidate-snapshot','stack-status-context','stack-checkrun-state','pstack-export-repair','pstack-current-repair']
paths += ['docs/implementation/'+x+'/README.md' for x in readmes]+['docs/implementation/method-continuity-delivery/host-report.md','docs/implementation/method-pr-readiness-delivery/host-report.md','docs/implementation/pr-stack-candidate/README.md']
bindings=[]
for p in paths:
 if exists(root,p):bindings.append({'commit':root,'path':p,'sha256':h(raw(root,p)),'exists_at_main':exists(main,p)})
upsource=[]
for x in cap['capabilities']:
 p=x['sources'][0]['path'];b=raw(pin,p,up);upsource.append({'PS':x['id'],'commit':pin,'path':p,'sha256':h(b),'interpretation':'原来源基线；不将原技能存在视为OSStack实现'})
remaining=[
'没有持久方法编译/执行与全路由资格；14份材料不等于14项完整产品能力。',
'专门历史动机检索工具及普遍解释效果未验收。',
'真实任务意图校准的收益未证；现有两宿主framing均LIMITED。',
'独立多方案原型arena及完整采纳循环未交付。',
'指南之外的运行时并发派发/覆盖竞赛未验收。',
'产品化跨模型评审与角色资格未闭合；小样本正确主结论不能替代完整审阅。',
'跨项目影响面穷尽性与假设挑战效果未验证。',
'任意项目自动生成完整功能地图/旅程未证明；现有固定OSStack样例可用。',
'广义漂移发现/任意项目地图维护未闭合；现有固定五case维护可用。',
'形式验证技能生成、维护、模型与实现变异对应未作为pstack切片交付。',
'状态图及可执行模型反例工具未移植；普通图文不作替代。',
'反思到受控经验晋升运行时未交付；技能编写材料不自动授权扩写。',
'身份/来源真实性及完整因果归因未认证；manifest只证明所保留字节一致。',
'没有真实性能收益、噪声控制与端到端因果实验。',
'有预算hillclimb及盲评循环未实现；现有host probe不构成benchmark。',
'统一owner/隔离/协调者运行时尚未验收；并行指导本身可用。',
'frontier是未合并候选；没有持续watch、自动rebase/retarget、历史比较或完整依赖发现。',
'单次快照/分类修复已合并；持续forge观察器未移植，existing-card刷新不在现有ingest契约。',
'连续性材料不提供进程fencing、unknown action补发或锁释放；持久接续链未交付。',
'四入口导出与部分实际使用不证明Codex App/CLI/Claude全方法同等有效，权限与模型身份仍分轴。',
'采用闭包/来源资格消费及漂移失效链未闭合。',
'Benny式外部事件intake/补偿未移植；不能因Firstmate有监督定位就宣布此pstack组完成。',
'冷用户能否独立完成三条冻结功能地图仍未全验收。',
'无全局历史检索/记忆自动化；连续性解释材料不能代替真实检索与恢复。']
ps=[]
for i,x in enumerate(roll['pstack_capabilities']):
 y={'id':x['id'],'title':x['title'],'scope_state':'unimplemented_or_deferred_in_current_pstack_slice' if x['id'] in ['PS10','PS11','PS15','PS22'] else 'merged_partial_available','whole_capability_complete':False,'delivered':x['delivery'],'candidate_not_merged':None,'remaining':remaining[i],'verification_state':'bounded_component_evidence_only_not_whole_capability','owner':'pstack 后续能力 owner；root排期，不自动转交 Firstmate','joint_refs':x['joint_work_items'],'original_source':upsource[i]}
 if x['id']=='PS08':y['delivered']='共享create-verification方法、engineering/skills两类真实验证器、默认2/可选5case旅程已在main。'
 if x['id']=='PS09':y['delivered']='maintain方法及固定五case地图命令已合并，真实合法地图→陈旧值RED→仅map修正GREEN证据保留。'
 if x['id']=='PS13':y['delivered']='原始记录、manifest、default v1/full v2安全投影和单PR快照已合并；自签摘要不是身份认证。'
 if x['id']=='PS17':y['delivered']='PR-readiness材料和单PR只读快照已合并。';y['candidate_not_merged']='8e830中的1–3 PR显式有序前沿报告；独立42场景/58断言和10渲染反例闭环、一次8查询历史观察，不替代最终CI/merge。'
 if x['id']=='PS18':y['delivered']='307单PR快照、308 StatusContext及309异常/不完整CheckRun分类修复均在main e464。'
 if x['id']=='PS20':y['delivered']='四入口、14共享方法、双host导出与有限真实host任务；当前packet任务Codex修复完成，Claude权限拒绝后未修复。'
 ps.append(y)
ms=[]
for x in roll['milestones']:
 w=next(w for w in work['items'] if w['id']==x['id']);dims=x.get('delivery_dimensions',{})
 y={'id':x['id'],'title':x['title'],'formal_gate':False,'original_acceptance_ids':x['acceptance_ids'],'owner_role':w['owner_role'],'engineering_state':x['engineering_classification'],'delivered':dims.get('delivered',x['delivered_or_reusable']),'awaiting_verification':dims.get('awaiting_verification'),'unimplemented_in_declared_joint_scope':dims.get('unimplemented'),'unknown':dims.get('unknown'),'source':'root rollup historical dimensions; checked against original work-package/gate boundaries, not an exhaustive new implementation audit','evidence_paths':[{'path':p,'exists_at_main':exists(main,p)} for p in x['evidence_paths']]}
 if x['id']=='J07':y['current_delta']='单PR/安全投影在main；多PR前沿候选补充有限观察工具，不成为host-authoritative artifact/资格消费者。'
 if x['id']=='J15':y['current_delta']='4入口/14方法已合并，可结项材料导出小切片；持久路由、问题版本/范围纠正、可信答案接线仍未交付。'
 if x['id']=='J19':y['current_delta']='session-continuity/skill-authoring材料已合并；项目隔离检索、有效期、provenance消费和经验晋升仍缺；不归为Firstmate已完成。'
 if x['id']=='J30':
  y['engineering_state']='merged_one_shot_snapshot_and_candidate_frontier_not_persistent_observer';y['delivered']='单PR只读快照、legacy分类两次修复已合并；多PR前沿为8e830候选。';y['unimplemented_in_declared_joint_scope']='持续Forge observer、自动运行接线/完整method report与原JA41/57资格尚未交付；不能再把所有stack frontier一概写成无实现。';y['current_delta']='纠正历史rollup的“stack frontier尚未交付”绝对措辞；只读候选不是正式J30通过。'
 ms.append(y)
stages=[
 {'id':'S1','name':'共享方法材料的可交付与完整读取','state':'merged_available_user_acceptance_pending','PS':['PS01','PS03','PS12','PS20'],'accept':'四入口、14方法及引用真实可达；新目录导出；分页/摘要绑定/EOF；用户能读到完整材料。','machine_evidence':['docs/implementation/method-material-reader/README.md','osstack-methods-skill/EXPORT.md'],'not_claimed':'原生发现、正确路由、理解、全方法效果或J15通过','owner':'方法/导出 owner；用户确认可用性'},
 {'id':'S2','name':'固定五case验证、地图维护与可分享证据','state':'merged_available_user_acceptance_pending','PS':['PS08','PS09','PS13'],'accept':'真实0/1/2/1/0产品语义、driver成功与产品失败分开；地图不被自动改写；原始证据保留、cleanup逐项、full v2投影check；默认2/v1兼容。','machine_evidence':['docs/implementation/method-full-journey/README.md','docs/implementation/method-full-projection/README.md','docs/implementation/skills-check-map-maintenance/README.md'],'not_claimed':'任意项目功能地图生成/所有用户入口覆盖/来源认证','owner':'验证工具 owner；用户审阅地图与实际回执'},
 {'id':'S3','name':'有界候选观察与保守分类','state':'merged_single_pr_and_classifiers; frontier_candidate_pending_merge','PS':['PS17','PS18','PS13'],'accept':'单PR稳定head/base、完整unknown/failed；StatusContext与CheckRun政策各自准确；显式1–3 PR只越过稳定merged前缀，报告0不等于Ready。','machine_evidence':['docs/implementation/pr-candidate-snapshot/README.md','docs/implementation/stack-status-context/README.md','docs/implementation/stack-checkrun-state/README.md','docs/implementation/pr-stack-candidate/README.md'],'not_claimed':'自动merge/retarget/watch、全栈原子性、历史比较、旧卡自动刷新','owner':'github观察工具 owner；root完成frontier最终CI/发布，用户merge'},
 {'id':'S4','name':'真实宿主任务行为','state':'partially_observed_not_full_acceptance','PS':['PS03','PS06','PS20','PS25_not_a_capability_id'],'accept':'只按各历史任务实际结果结论；若用户要验收真实使用，另选一项用户任务，按当前已授权范围，固定输入/反例/完整材料后观察。','machine_evidence':['docs/implementation/method-review-behavior/README.md','docs/implementation/method-packet-host-consumption/README.md','docs/implementation/pstack-export-repair/README.md','docs/implementation/pstack-current-repair/README.md'],'not_claimed':'两host全面通过、无方法对照的因果收益、模型排名/认证身份','owner':'用户验收任务与宿主协议 owner；本轮不自动新增调用'}]
stages[3]['PS'].remove('PS25_not_a_capability_id')
obj={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':main,'root_candidate':root,'source_pin':pin,'decision':'pstack整体未结束；建议停止扩展，仅把S1–S3界定为普通D2a工具小阶段，frontier候选收口后交用户验收。S4保留部分/失败，24PS与32J不作全通过。','no_new_execution':True,'formal_milestones_completed':0,'status_legend':{'merged_available':'Git主线已有相应有限入口，不代表全能力效果','candidate_not_merged':'源码/工程验证存在，不能当主线交付','unimplemented':'本次声明能力切片或原计划明确未交付的部分','unverified':'实现或观察存在，但指定效果/正式验收未证明'},'stages':stages,'pstack24':ps,'joint32':ms,'findings':[{'id':'F1','fact':'root rollup top main_sha仍a250，candidate_status含308 pending；Git实际main e464已合309。','recommendation':'按Git当前快照新增状态说明；保留旧历史观察时间，不抹改原CI/审计。'},{'id':'F2','fact':'J30历史unimplemented笼统包含stack frontier，与新只读候选不再完全一致。','recommendation':'区分已合单次快照、未合frontier、未实现持续observer，正式gate仍false。'},{'id':'F3','fact':'14方法/4入口、20 partial/4 deferred不是完成比例。','recommendation':'S1–S3用独立可运行成果验收；PS/J各保留自己的缺口。'}],'firstmate_boundary':{'pstack_must_keep':['PS10形式验证','PS11状态图/反例','PS15有预算改进/盲评','PS21来源采用与资格','PS08/09通用项目功能地图','PS17/18持续forge能力若仍保留原目标','PS20真实宿主使用效果','PS22原pstack事件intake'],'firstmate_primary':['持久监督/未决义务','恢复/跨进程owner与fencing','外部事件/补偿的联合接线'],'shared_but_not_transfer':['J15路由与可信答案','J19检索/经验晋升','J23宿主资格','J32组合效益对照'],'transition_rule':'用户可以接受限定D2a小阶段后优先做Firstmate；未实现pstack能力仍留pstack backlog/owner，不能改名为Firstmate完成或依赖即可注销。'},'limits':['本次只读Git/既有报告，不重新执行产品/模型/DB/全仓或下载最新CI。','24原能力以固定原始来源索引校准；细读核心create/maintain/stack/pause原文，不声称完整重审上游所有技能。','32J保留原始要求和历史gap维度，补当前有限增量；路径存在不证明运行实现，未全面重新审计所有J代码。','8e830不是main；最终frontier merge/CI和用户实际验收尚待root收口。']}
(r/'matrix.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');(r/'source-bindings.json').write_text(json.dumps({'git':bindings,'upstream_primary24':upsource},ensure_ascii=False,indent=2)+'\n')
print('written',len(ps),len(ms))
