# Verdict: PASS_WITH_CORRECTIONS (report accuracy only)

This is not a formal gate, user acceptance, or runtime release. I read the supplied text only. I did not inspect source, run anything, or read the JSON manifests.

The draft's central claims are supported by the text:
- pstack is not fully integrated.
- The original C0/C1/C2/C3 checkpoints are retained.
- The S1–S3 bounded tools are explicitly "not redefined C0/C1/C2".
- No FAILED/LIMITED was flipped to pass.

## Checked and consistent
- **Counts:** The A-table has 10 not implemented, 31 partial, 4 direct (A03, A13, A27, A28) and 3 unknown (A21, A32, A47), totalling 48. The W→A mappings match `acceptance-cases.json`.
- **Audit indexes:** 12+22+47=81, with HV01 listed separately.
- **Upstream tree counts:** 200−33+406=573.
- **Focus 1:** The README row "原检查点仍差什么" and ORIGINAL-ACCEPTANCE "与原阶段门槛的差异" keep C0–C3 and say bounded tools cannot declare C2.
- **Focus 2:**
  - W13/A27/A28 is scoped to the read-only classifier, with no watcher required.
  - The benchmark/benefit relaxation applies to method material only. W15/A30/A47 stay unimplemented or unknown, so it is not a hidden waiver.
- **Focus 3:** AUDIT-TRACE "不能升级的历史结论" blocks upgrading design audits or tests, and host repair is kept per-experiment.
- **Focus 5:** New upstream orch, statechart, and babysit changes are labeled as upgrade evaluation, not old gates or old debt removal.

## Required corrections
1. **W-level roll-up is inconsistent.** (ORIGINAL-ACCEPTANCE W table)
   - W16 is "unknown" although A31 is "not implemented".
   - W09, W05, and W11 are "partial" although each contains a "not implemented" A-case: A05, A11/A35, and A24.
   - W01, W03, and W08 with a "not implemented" case are rolled up as "not implemented".
   - State the roll-up rule or relabel.
2. **Ownership split omits W10 and event intake.** (README)
   - A21/A22/A46 (W10) and PS19/PS24, and PS22/W16 intake, are not placed in either the pstack list or the follow-up list.
   - The Firstmate bullet "恢复与操作员处置" could absorb A22. The method-level reconcile (old pin kept, unknown not treated as complete, no `cancelled` without stop proof) is an original pstack assertion and should be named as such.
3. **The C0/C1/C2 "minimum closure" understates the original dependency chain.**
   - W03 depends on W02, which depends on W01, and A01 and A04 are still open. Neither the C1 nor the C2 row mentions them, nor says they are substituted by the J02 inspector.
   - The C0 row omits the cold-user check (A39). ORIGINAL-ACCEPTANCE step 2 includes it, so the two documents disagree.
   - "局部产品证据充分" for C0 conflicts with ORIGINAL-ACCEPTANCE's "部分具备". Align the wording.
4. **The C2 row's "联合依赖…恢复/预算等" is open-ended.** Name the specific joint-layer items (the T05 list: trial permit and consumption) and mark them as joint mapping (J08 etc.). As written, this can read as a new blocker or as pulling Firstmate runtime into pstack C2.
5. **W13 and the W10 dependency are ambiguous.** The original spec lists W10 as a dependency, and the draft marks it "未闭合". Say explicitly whether that gates the A27/A28 slice acceptance. The draft implies it does not, but does not say so.
6. **A26 mixes sources.** Its "partial" status cites PR/worktree synthesis evidence and "frontier 当前为候选", i.e. unmerged 8e830. Tag which part rests on main versus the candidate, and downgrade if only the candidate supports it.
7. **"当时69产品场景" in AUDIT-TRACE cannot be reconciled with the other figures in the package.** The 48 pstack cases and the "66 Firstmate + 48 pstack" figure in ORIGINAL-ACCEPTANCE do not produce 69. Cite its source or fix it.

## Optional observations
- **CAPABILITIES gap column:** It mixes original debt with broader boundaries. The header disclaims this, but splitting it into "原必需欠账" and "较广边界" would remove the blocker reading. PS14 and PS18 are the most exposed.
- **"未闭合" labels in A27/A28:** They cover non-scope items (watcher, merge-policy discovery). "Boundary / not this slice" would be clearer.
- **check-plan "不应标 done" (SOURCE-COMPARISON):** Say whether it comes from catalog row 142 only or from a 48A/19W item. If it is catalog-only, it is not an acceptance blocker.
- **PS11 gap wording:** "图转换/工具链复验" reads as the upstream toolchain. Original W16 is a one-invariant pilot.
- **Undefined terms:** "D2a" and "c/" appear without definition in the supplied files.

## Limited (not verifiable from the supplied text)
- The 20 partial / 4 deferred capability split, and the PS→W mapping for PS14.
- That the "stale summaries for PS08/09/13/17/18 and J30 were fixed".
- The truth of every "direct evidence" claim and every cited anchor or hash. I took the draft's descriptions as stated.
- That the S1–S4 deliverables exist as described.