# PS01–12 阶段验收对账

main `e4643324b9de1d2db51c744e59ccd7c05146b0a6`；候选 `8e830561e09f4754d3410003c24216d8db49aa6c`。中央未提交输入另行hash绑定。**建议接受10项的有限材料/工具切片，PS10/11未实现；不是10/12整项完成率。** 所列材料/产品均已在main且与候选同字节。历史FAILED/LIMITED不改；未跑新测试/模型，未重核全部raw归档。

## PS01 单入口任务路由与渐进方法组合

- 可验收：接受四入口、14方法路由/双布局导出与哈希分页这一有限材料工具交付。 完整读取/导出可复现；导出不等于安装，分页EOF不等于模型理解或强制消费。
- 未完成：尚无通用方法编译、准入和强制执行通道。 缺全部路由的实际宿主任务效果；已有原生help及实际修复只能按各实验限定主张。
- 后续归属：普通材料使用无需Firstmate；持久方法准入/权限/主控恢复属于后续联合runtime。
- 依据：`pstack/skills/poteto-mode/SKILL.md`@99b609a；`docs/implementation/osstack-method-entrypoints/README.md`；`docs/implementation/method-material-reader/README.md`（全量路径与hash见JSON）。

## PS02 代码机制与历史动机取证

- 可验收：接受investigation对机制、来源与不确定性的共享方法材料。 两CLI确实读历史缺陷材料并给出诊断，但已提供修复结果、输入不对称且有事实/归属限制。
- 未完成：how/why/teach的多来源历史动机调查、跨来源置信度综合未完整产品化。 缺新调查任务中原始Git/issue/doc证据链、推断与空结果的独立结果核验；不能用旧已知答案研究代替。
- 后续归属：主要是pstack调查流程，不必等待Firstmate恢复/身份runtime。
- 依据：`pstack/skills/how/SKILL.md`@99b609a；`docs/implementation/joint-host-effects/README.md`（全量路径与hash见JSON）。

## PS03 意图校准与可纠正的问题模型

- 可验收：接受task-framing的目标/约束/未知、四深化镜头、仅改写与既有授权执行分流材料。 a9e480d源的一次prompt-only双宿主观察可引用；两者均LIMITED_not_overall_PASS。
- 未完成：没有确认必须新增runtime；方法已实现，尚缺更广实际任务应用。 Claude比较构建工件、缩小未来交付及本地证据措辞有缺陷；Codex原生可用性/实际模型/最终通道未证明。不能称执行收益。
- 后续归属：普通澄清与提示改写属于pstack；持久问答/权限绑定另属联合runtime。
- 依据：`pstack/skills/sharpen/SKILL.md`@99b609a；`docs/implementation/method-framing-architecture/README.md`；`docs/implementation/method-continuity-delivery/host-report.md`（全量路径与hash见JSON）。

## PS04 从使用草图到原型证据的架构循环

- 可验收：接受architecture-design及feature/refactoring的调用者、状态、迁移、行为pin方法材料。 导出与静态反例支持材料可用；合成示例不是实际多原型执行。
- 未完成：未交付arena平行原型、交叉评分、择基融合和完整采纳循环。 缺同一真实需求下不同结构候选、评分依据、融合后行为/迁移验证与收益证据。
- 后续归属：设计方法本身是pstack；持久工作派发/隔离/恢复部分可归Firstmate联合runtime。
- 依据：`pstack/skills/architect/SKILL.md`@99b609a；`docs/implementation/method-framing-architecture/README.md`；`docs/implementation/method-feature-refactoring/README.md`（全量路径与hash见JSON）。

## PS05 覆盖式并行与预先声明的竞赛

- 可验收：接受parallel-work支持指南与osstack-agent委派包装，仍是14方法/四入口。 必需lane、资源写owner、SHA/surface、缺失/过期回报和组合验证均有材料/导出反例；本项目多agent实践不等于新增产品调度器。
- 未完成：未交付自动swarm/race聚合、持久派发/租约/取消确认与恢复。 缺原生多宿主覆盖/竞赛执行的一次完整预声明协议；模型数量/审计轮数不是正确性。
- 后续归属：持久owner、未知liveness、恢复、资源隔离是Firstmate/联合深runtime；一次授权内人工协调不需被其阻塞。
- 依据：`pstack/skills/swarm/SKILL.md`@99b609a；`docs/implementation/method-parallel-reporting/README.md`（全量路径与hash见JSON）。

## PS06 独立评审与意见裁决

- 可验收：接受code-review方法与已有真实独立挑战/实际Sonnet审计原意见和修订证据。 源代码trigger/影响/证据/裁决/无发现限制可验；项目审计有真实发现，不认证独立principal。
- 未完成：跨模型审查调度、可信审查资格和结论采纳仍未作为统一产品闭环。 缺审查方法在未提供答案的真实任务上按缺陷/误报/处置分轴验证；静态导出不证明评审质量。
- 后续归属：审查材料属于pstack；principal/权限/采纳治理可归联合runtime，不能反过来否定普通审查可用性。
- 依据：`pstack/skills/interrogate/SKILL.md`@99b609a；`docs/implementation/method-code-review/README.md`（全量路径与hash见JSON）。

## PS07 影响面与关键前提验证

- 可验收：接受change-impact的调用链、隐含前提、真实入口验证与未知保留材料。 静态源码/反例挑战和双导出成立；没有泛化为实际应用影响面验证。
- 未完成：尚无普遍自动影响分析器，原能力主要是工程流程并非必须新工具。 缺一项真实改动的关键安全前提：旧坏例、真实调用、同表面验证与清除/保留风险的完整独立复验。
- 后续归属：主要pstack工程方法；一般影响分析无需等待Firstmate深runtime。
- 依据：`pstack/skills/blast-radius/SKILL.md`@99b609a；`docs/implementation/method-impact-performance/README.md`（全量路径与hash见JSON）。

## PS08 可操控的验证基础设施与功能地图

- 可验收：接受真实CLI验证套件、默认两例/显式五例journey、功能地图、v1/v2安全投影与分页工具。 五例真实product exits 0/1/2/1/0；driver成功验证预期失败不等于产品全绿。Codex当前checker修复与Claude历史export修复分别有真实RED→同测GREEN。
- 未完成：任意项目的生成式launch/doctor/drive/observe/cleanup和完整feature-map发现未完成。 当前Codex任务有归属限制；当前Claude未完成；历史Claudeexport修复LIMITED因末尾材料未读。工具验证不升级通用宿主效果。
- 后续归属：本地固定验证工具可独立验收；受控执行、自动资格/重放/恢复另属联合runtime。
- 依据：`pstack/skills/create-verification-skill/SKILL.md`@99b609a；`docs/implementation/verification-kit/README.md`；`docs/implementation/method-full-journey/README.md`（全量路径与hash见JSON）。

## PS09 验证基础设施的健康、归属与漂移维护

- 可验收：接受maintain-verification与固定五案例持久地图比较CLI，明确注入漂移→只改地图→同命令新输出GREEN。 PR306真实alias前后五例都执行；非法地图不drive、未知/driver失败退出2、合法错配退出1、完整一致退出0；失败和partial保留。
- 未完成：未覆盖任意项目源码波次发现、所有未映射feature、跨环境健康/归属与广义地图漂移自动发现。 现有真实维护是声明注入的stale map，非自发产品缺陷或模型自主维护。需真实项目自然漂移及工具/文档/产品不同故障分类完整用例才可扩范围。
- 后续归属：固定地图维护属pstack且已可用；跨会话owner/持久执行/恢复才归Firstmate，不能把现有五例路径仍列未实现。
- 依据：`pstack/skills/maintain-verification-skill/SKILL.md`@99b609a；`docs/implementation/skills-check-map-maintenance/README.md`；`docs/implementation/pstack-real-loops/README.md`（全量路径与hash见JSON）。

## PS10 形式化验证生命周期

- 可验收：本阶段不能验收为已实现；仅有原始来源与设计映射。 普通单元/变异测试和闭合schema不等于形式化验证生命周期。
- 未完成：缺目标选择、代码对应模型/证明、固定工具重跑、破坏性变体证伪、范围/假设说明及维护。 无本能力可运行产品与正负验收记录。
- 后续归属：这是独立pstack能力缺口，不能因涉及状态机就笼统划给Firstmate；后续runtime可成为验证对象。
- 依据：`pstack/skills/create-formal-verification-skill/SKILL.md`@99b609a；无实现/执行证据。（全量路径与hash见JSON）。

## PS11 状态图与反例解释

- 可验收：本阶段不能验收为已实现；普通Mermaid与状态schema不替代statechart工具。 上游能力从TLA+模型/约束生成读者可见状态图及反例路径，尚未移植。
- 未完成：缺代码↔模型映射、TLC执行、图转换/反例解释与旧不变量保留。 无可执行statechart正负场景和工具链复验。
- 后续归属：主要pstack可视化/形式化工具能力，非必须等待Firstmate；后续可用于其恢复/并发模型。
- 依据：`pstack/skills/statechart/SKILL.md`@99b609a；无实现/执行证据。（全量路径与hash见JSON）。

## PS12 反思转结构化约束

- 可验收：接受skill-authoring及基于当前任务证据维护技能的结构化方法材料。 94导出测试/88payload每host、缺ref负例、一次非作者限定本地技能编辑记录可验；执行者也准备fixture，非盲测。
- 未完成：没有自动经验提取/存储/隔离检索/晋升或correct通用结构执法系统。 未证明native Codex/Claude技能维护任务普遍成功；有限subagent编辑不是双CLI原生效果、因果收益或身份认证。
- 后续归属：普通授权内技能维护属pstack；J19隔离检索/证据晋升属于联合/Firstmate深runtime，材料不能签其门槛。
- 依据：`pstack/skills/correct/SKILL.md`@99b609a；`docs/implementation/method-skill-authoring/README.md`（全量路径与hash见JSON）。

## 收口修正

- N01：PS01/08 material_delivery_candidate、PS08/09 full_journey_candidate/maintenance_map_candidate 为旧pending字段；303/304/306均已是main祖先。 保留历史并明确superseded，不用旧嵌套状态汇总当前进度。
- N02：PS09 delivery仍称全五case维护路径未闭合，与PR306已合入和latest_merged_slice矛盾。PS08概述也仍只称两行journey。 当前应写默认两例+显式五例journey、固定五例地图已交付；广义漂移发现仍缺。
- N03：PS08最新当前packet说明仍写publication pending，PR305已合入该修复与证据。 合入状态按main证据更新；原实验结论和原SHA不变。
- N04：14方法/导出、模型实际读到、正确使用、真实任务结果、通用资格是不同轴。 不以PR/方法/卡片数折算完成率；所有PS01–12整项均不宣称完整完成。

历史同PR候选对比及卡片刷新提案已封存暂缓，manifest `dd7e1ae4b378d2032fbb2a8fc10293eb854cdf8e8e943fb5763ae83acbdb447e`，没有实现。候选新增stack-frontier属PS17/18，不计PS01–12。主入口可据本对账做范围验收；本报告不签J门槛、不提升host资格、不修改中央状态。
