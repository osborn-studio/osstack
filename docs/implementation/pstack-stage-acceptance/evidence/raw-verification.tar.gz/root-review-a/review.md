# 阶段验收文档只读复核

结论：限定范围通过，无确认的范围替换或历史结果升级。保留两项非阻断表述一致性建议。

- README 明确 S1–S4 是待用户确认的有限交付建议，不替代 C0/C1/C2；原 W08 实际试点仍是“首个能力已集成”的条件。中央 user_accepted/scope_change_approved/formal gate 均 false。
- mandatory 材料、注册检查、候选产物、首次试点、地图与来源资格仍列为 pstack 欠账。只将必要持久运行时依赖安排给联合/Firstmate，没有把 formal/statechart 等 pstack 工作注销。
- 按行为/证据而非建议文件名判定；此次核对不等于重新扫描全部源码。文档保留77/100/24的设计测试边界，旧FAILED/LIMITED未升级，候选8e830未被当main。
- A-N1：中央 pstack_stage_acceptance.scope 仍写S1–S3，README已经S1–S4，建议一致。
- A-N2：顶层 source_snapshot_limit 的“Current projection adds merge301”是旧时态，建议明确标历史或指向当前分层状态；不能误读为本次对账只更新到301。

本次未改原件、中央或此前冻结包；未运行模型/测试/产品。输入具体bytes/hash见review.json。
