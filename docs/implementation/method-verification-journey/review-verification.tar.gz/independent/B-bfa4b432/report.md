# Independent initial journey review

Candidate `bfa4b432a9af52596d0133e46e9fe961a7c91ed2`: **REVISE**. The independent real two-case run passed, retaining healthy product exit 0 and missing-ref product exit 1 while both verification drivers exited 0. The broken source was not repaired.

Nineteen evidence controls/mutations produced fifteen expected results and four unexpected acceptances:

- Removing a Git command still referenced by run.commands was accepted.
- Removing a Git stdout file referenced by its command was accepted.
- Emptying both source/build binding file lists and consistently rehashing the summaries was accepted.
- Changing both expectation/input origin to a network URL and consistently rehashing was accepted, despite the fixed local-only fixture scope. No network operation was performed.

These are confirmed completeness and consistency failures, not a demand for authenticated execution history. Exact mutated inputs, resealed manifests, returned records and script are retained under scratch/challenges and challenge-results.json.

Three separate doctor failure seams each stopped after one call, retained raw output and marked the later feature not_run. Existing output and foreign sentinel checks preserved their files. Original candidate worktree status was unchanged; existing author build outputs were not modified.

This is bounded independent agent engineering validation, not a formal independent principal or runtime gate. No full suite or model was run. Planned prefreeze vectors not represented in this record remain unexecuted here.
