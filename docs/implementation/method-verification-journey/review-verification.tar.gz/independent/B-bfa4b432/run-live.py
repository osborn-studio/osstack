from pathlib import Path
import subprocess,json,datetime,hashlib,os
W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/method-verification-journey');O=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/independent/B-bfa4b432');C='bfa4b432a9af52596d0133e46e9fe961a7c91ed2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==C
before=subprocess.check_output(['git','status','--porcelain'],cwd=W)
(O/'worktree-before.txt').write_bytes(before)
for p in ['scripts/method-verification-journey.mjs','scripts/method-verification-journey.test.mjs','docs/implementation/method-verification-journey/README.md']:
 b=subprocess.check_output(['git','show',C+':'+p],cwd=W);assert(W/p).read_bytes()==b;dest=O/'candidate'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
(O/'host-home').mkdir();(O/'scratch').mkdir()
argv=['/opt/homebrew/opt/node@22/bin/node',str(W/'scripts/method-verification-journey.mjs'),'--output',str(O/'scratch/live')]
env={'PATH':'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin','HOME':str(O/'host-home'),'OSSTACK_HOME':str(O/'unused-home'),'OSSTACK_SCRATCH_ROOT':str(O/'scratch'),'LANG':'en_US.UTF-8'}
r={'candidate':C,'argv':argv,'cwd':str(W),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=subprocess.run(argv,cwd=W,env=env,capture_output=True,timeout=240)
(O/'live.stdout').write_bytes(p.stdout);(O/'live.stderr').write_bytes(p.stderr);r.update(exit_code=p.returncode,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest());(O/'live.command.json').write_text(json.dumps(r,indent=2)+'\n')
assert p.returncode==0 and not p.stderr
x=json.loads(p.stdout);assert x['status']=='passed' and [f['case_id']for f in x['features']]==['healthy','missing-ref'];assert [f['product_exit']for f in x['features']]==[0,1] and [f['driver_exit']for f in x['features']]==[0,0]
for f in x['features']:
 d=Path(f['evidence']);rc=json.loads((d/'receipt.json').read_text());out=(d/(f['case_id']+'.stdout')).read_text();c=json.loads((d/(f['case_id']+'.command.json')).read_text())
 assert c['exit_code']==f['product_exit'] and not Path(f['cleanup']['fixture_path']).exists()
 assert ('unreachable: no_matching_ref'in out) == (f['case_id']=='missing-ref')
 assert rc['cases'][0]['source_check_status']==('healthy' if f['case_id']=='healthy' else 'failed')
 for entry in json.loads((d/'manifest.json').read_text())['files']:
  b=(d/entry['path']).read_bytes();assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256']
after=subprocess.check_output(['git','status','--porcelain'],cwd=W);(O/'worktree-after.txt').write_bytes(after);assert before==after
print(json.dumps({'exit':p.returncode,'features':[(f['case_id'],f['product_exit'],f['driver_exit'])for f in x['features']],'worktree_unchanged':True}))
