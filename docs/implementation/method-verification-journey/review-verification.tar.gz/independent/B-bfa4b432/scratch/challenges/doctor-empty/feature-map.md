# Fixed skills-check journey

Journey status: failed. See journey.json for failure details.

| Feature | Product exit | Driver exit | Verification | Cleanup | Evidence |
|---|---|---|---|---|---|
| healthy | not_observed | not_observed | failed | not_started | cases/healthy/manifest.json |
| missing-ref | not_observed | not_observed | not_run | not_started | not_run |

Expected missing-ref product exit1 is an unrecovered source failure. Driver exit0 means its fixed negative predicate passed. Native selection/model execution: not observed/not run. Descendant termination: not attested. Other cases: not run.
