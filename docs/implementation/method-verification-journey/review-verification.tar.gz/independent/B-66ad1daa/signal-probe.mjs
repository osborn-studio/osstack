import {invokeDriver} from '/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/method-verification-journey/scripts/method-verification-journey.mjs';
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/independent/B-66ad1daa';
const results=[];
for(const ignore of [false,true]){
 const marker=`${root}/scratch/ready-${ignore}`;const controller=new AbortController();
 const code=`const fs=require('node:fs');process.on('SIGTERM',()=>{fs.appendFileSync(process.argv[1],'-term');${ignore?'':'process.exit(23)'}});fs.writeFileSync(process.argv[1],'ready');setInterval(()=>{},1000)`;
 const pending=invokeDriver(['-e',code,marker],{PATH:'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',HOME:`${root}/home`},5000,controller.signal,100);
 try{
  const until=Date.now()+3000;while(await readFile(marker,'utf8').catch(()=>null)!=='ready'){assert(Date.now()<until,'readiness deadline');await new Promise(r=>setTimeout(r,10));}
  controller.abort();const r=await pending;assert.equal(r.interrupted,true);assert.equal(r.timed_out,false);assert.equal(r.direct_child_exit_confirmed,true);assert.equal(await readFile(marker,'utf8'),'ready-term');assert.deepEqual(r.signals_sent,ignore?['SIGTERM','SIGKILL']:['SIGTERM']);assert.equal(r.signal,ignore?'SIGKILL':null);assert.equal(r.exit_code,ignore?null:23);results.push({ignore_term:ignore,record:{...r,stdout:r.stdout.toString(),stderr:r.stderr.toString()}});
 }finally{controller.abort();await pending;}
}
const controller=new AbortController();const exited=await invokeDriver(['-e','process.exit(0)'],{PATH:'/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin'},5000,controller.signal,100);controller.abort();assert.equal(exited.exit_code,0);assert.equal(exited.interrupted,false);assert.equal(exited.killed,false);assert.deepEqual(exited.signals_sent,[]);results.push({abort_after_return:true,record:{...exited,stdout:exited.stdout.toString(),stderr:exited.stderr.toString()}});
await writeFile(`${root}/signal-results.json`,JSON.stringify({candidate:'66ad1daa229101e4501392bbe1d6b4d86b7ca16b',results,scope:'Only directly spawned synthetic Node children; no product driver or descendant assertion.'},null,2)+'\n');console.log(JSON.stringify({checks:3,passed:true}));
