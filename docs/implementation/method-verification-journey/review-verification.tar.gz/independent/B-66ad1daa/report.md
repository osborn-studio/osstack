# Independent final signal delta check

Final candidate 66ad1daa229101e4501392bbe1d6b4d86b7ca16b was compared with independently reviewed 4ad08322. Production delta records signals only when child.kill reports they were sent and the direct child has not exited; abort is checked between doctor/drive and before final pass. No evidence predicate relaxation was introduced.

Ran five relevant shipped tests: internally consistent foreign cleanup paths hit exactly cleanup_ownership; actual timeout TERM; readiness-confirmed ignored TERM escalates KILL; abort is distinguished; abort after doctor prevents drive. All five passed.

An additional independent script spawned three synthetic Node children: (1) readiness file before abort, actual TERM handler writes marker then exits23, signals_sent exactly TERM; (2) readiness before abort, actual TERM handler observes and ignores it, then direct child exits SIGKILL, signals_sent exactly TERM/KILL; (3) successful child exits0 and abort after return adds no false sent-signal/interruption claim. Raw records and marker bytes retained; all three passed.

This is focused delta validation, not a product-driver rerun or full suite. It proves direct synthetic child observations only; no descendant termination claim. The prior 19+3 mutation results remain bound to 4ad, not relabeled as rerun on 66ad. No model call or product/source edit was made.
