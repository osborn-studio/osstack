# Fixed skills-check journey

Journey status: failed. See journey.json for failure details.

| Feature | Product exit | Driver exit | Verification | Cleanup | Evidence |
|---|---|---|---|---|---|
| healthy | reported:0 (unverified) | 1 | failed (journey:failed) | unknown | cases/healthy/manifest.json |
| missing-ref | not_observed | not_observed | not_run (journey:failed) | not_started | not_created |

Expected missing-ref product exit1 is an unrecovered source failure. Driver exit0 means its fixed negative predicate passed. Native selection/model execution: not observed/not run. Descendant termination: not attested. Other cases: not run.
