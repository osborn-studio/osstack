import {readFile,writeFile,cp,mkdir,rm,readdir,lstat,symlink} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {verifyCaseEvidence,runJourney} from '/Users/osborn/Developer/CodeX/.worktrees/osstack/method-verification-journey/scripts/method-verification-journey.mjs';
const O='/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/independent/B-4ad08322';
const W='/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/method-verification-journey';
const live=join(O,'scratch/live');const area=join(O,'scratch/supplement');await mkdir(area);
const sha=b=>createHash('sha256').update(b).digest('hex');const get=async(d,n)=>JSON.parse(await readFile(join(d,n)));const put=async(d,n,x)=>writeFile(join(d,n),JSON.stringify(x,null,2)+'\n');
async function seal(d){const m=await get(d,'manifest.json');const files=[];for(const n of(await readdir(d)).sort()){if(n==='manifest.json')continue;const b=await readFile(join(d,n));files.push({path:n,bytes:b.length,sha256:sha(b)});}await put(d,'manifest.json',{...m,files});}
async function clone(label,id='missing-ref'){const d=join(area,label);await cp(join(live,'cases',id),d,{recursive:true});const r=await get(d,'receipt.json');r.evidence.directory=d;await put(d,'receipt.json',r);await seal(d);return d;}
async function call(d,id='missing-ref',extra={}){return verifyCaseEvidence({directory:d,scratch:join(live,'scratch'),caseId:id,repository:W,stdout:await readFile(join(d,'receipt.json')),driverExit:0,...extra});}
const results=[];
async function trial(name,mutate,{id='missing-ref',reseal=true,reject=true,after}={}){
 const d=await clone(name,id);let extra={};await mutate(d,extra);if(reseal)await seal(d);let actual,err=null;try{actual=await call(d,id,extra);}catch(e){err=e.message;}
 const rec={name,expected:reject?'reject':'accept',actual:err?'rejected':'accepted',error:err,met_expectation:reject?!!err:!err,input_directory:d,manifest_sha256:sha(await readFile(join(d,'manifest.json'))),...(actual?{returned:actual}:{})};results.push(rec);await put(d,'independent-outcome.json',rec);if(after)await after(d);console.log(JSON.stringify({name:rec.name,actual:rec.actual,error:rec.error,met_expectation:rec.met_expectation}));
}

await trial('uuid-all-omitted',async d=>{for(const n of ['manifest.json','receipt.json','run.json']){const x=await get(d,n);delete x.run_id;await put(d,n,x);}});
await trial('git-current-sha-conflict-resealed',async d=>{const b=Buffer.from('a'.repeat(40)+'\n');await writeFile(join(d,'git-05.stdout'),b);const c=await get(d,'git-05.command.json');c.stdout_sha256=sha(b);await put(d,'git-05.command.json',c);});
const residual=join(live,'scratch','unowned-extra');
await trial('scratch-extra-residue',async()=>{await writeFile(residual,'preserve');},{after:async()=>{assert.equal(await readFile(residual,'utf8'),'preserve');await rm(residual);}});
const output=join(area,'failed-with-manifest');let count=0;let savedManifestHash;
const reply=(stdout,exit_code=0)=>({exit_code,signal:null,killed:false,error:null,stdout:Buffer.from(stdout),stderr:Buffer.alloc(0)});
const failure=await runJourney({output},{invoke:async()=>{count++;if(count===1)return reply(JSON.stringify({ready:true,executed:false,cases:['healthy']}));
const d=join(output,'cases/healthy');await cp(join(live,'cases/healthy'),d,{recursive:true});const r=await get(d,'receipt.json');r.evidence.directory=d;r.driver_exit=1;r.status='failed';r.failure='independent simulated cleanup failure';r.cleanup.status='failed';await put(d,'receipt.json',r);await seal(d);savedManifestHash=sha(await readFile(join(d,'manifest.json')));return reply(await readFile(join(d,'receipt.json')),1);}});
assert.equal(count,2);assert.equal(failure.status,'failed');assert.equal(failure.features[1].verification,'not_run');const jm=await get(output,'journey-manifest.json');assert.deepEqual(jm.case_manifests,[{case_id:'healthy',sha256:savedManifestHash,verified:false}]);assert.equal(failure.features[0].reported_product_exit,0);assert.equal(failure.features[0].cleanup.status,'unknown');assert.equal(failure.features[0].verification,'failed');assert((await readFile(join(output,'feature-map.md'),'utf8')).includes('reported:0 (unverified)'));
const priorDoctor=join(O,'scratch/challenges/doctor-ready-false');const map=await readFile(join(priorDoctor,'feature-map.md'),'utf8');assert(!map.includes('cases/healthy/manifest.json'));assert(map.includes('not_created'));
await put(O,'supplement-results.json',{candidate:'4ad0832207ab8d42629a42bd7f7ae9e5e52587d4',criteria_sha256:'4017c621bcc8f0e60e6bec25fc0bd2a0677fa6aba24dc3f75863ab51e8139a51',post_review_supplement:true,results,failed_manifest_hash_bound:true,failed_manifest_verified:false,reported_product_exit_not_promoted:true,doctor_failure_no_phantom_manifest:true});
