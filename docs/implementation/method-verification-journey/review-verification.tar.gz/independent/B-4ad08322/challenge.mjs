import {readFile,writeFile,cp,mkdir,rm,readdir,lstat,symlink} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {verifyCaseEvidence,runJourney} from '/Users/osborn/Developer/CodeX/.worktrees/osstack/method-verification-journey/scripts/method-verification-journey.mjs';
const O='/Volumes/AIMATE_WORK/tmp/osstack/runtime/method-next-wave-20261028/independent/B-4ad08322';
const W='/Volumes/AIMATE_WORK/Developer/CodeX/.worktrees/osstack/method-verification-journey';
const live=join(O,'scratch/live');const area=join(O,'scratch/challenges');await mkdir(area);
const sha=b=>createHash('sha256').update(b).digest('hex');const get=async(d,n)=>JSON.parse(await readFile(join(d,n)));const put=async(d,n,x)=>writeFile(join(d,n),JSON.stringify(x,null,2)+'\n');
async function seal(d){const m=await get(d,'manifest.json');const files=[];for(const n of(await readdir(d)).sort()){if(n==='manifest.json')continue;const b=await readFile(join(d,n));files.push({path:n,bytes:b.length,sha256:sha(b)});}await put(d,'manifest.json',{...m,files});}
async function clone(label,id='missing-ref'){const d=join(area,label);await cp(join(live,'cases',id),d,{recursive:true});const r=await get(d,'receipt.json');r.evidence.directory=d;await put(d,'receipt.json',r);await seal(d);return d;}
async function call(d,id='missing-ref',extra={}){return verifyCaseEvidence({directory:d,scratch:join(live,'scratch'),caseId:id,repository:W,stdout:await readFile(join(d,'receipt.json')),driverExit:0,...extra});}
const results=[];
async function trial(name,mutate,{id='missing-ref',reseal=true,reject=true,after}={}){
 const d=await clone(name,id);let extra={};await mutate(d,extra);if(reseal)await seal(d);let actual,err=null;try{actual=await call(d,id,extra);}catch(e){err=e.message;}
 const rec={name,expected:reject?'reject':'accept',actual:err?'rejected':'accepted',error:err,met_expectation:reject?!!err:!err,input_directory:d,manifest_sha256:sha(await readFile(join(d,'manifest.json'))),...(actual?{returned:actual}:{})};results.push(rec);await put(d,'independent-outcome.json',rec);if(after)await after(d);console.log(JSON.stringify({name:rec.name,actual:rec.actual,error:rec.error,met_expectation:rec.met_expectation}));
}
await trial('clone-positive-missing',async()=>{},{reject:false});await trial('clone-positive-healthy',async()=>{},{id:'healthy',reject:false});
await trial('wrong-driver-exit',async(d,a)=>{a.driverExit=1;});
await trial('stdout-receipt-disagree',async(d,a)=>{a.stdout=Buffer.from('{}');});
await trial('receipt-source-recovered',async d=>{const r=await get(d,'receipt.json');r.cases[0].actual_exit=0;r.cases[0].source_check_status='healthy';await put(d,'receipt.json',r);});
await trial('missing-product-command',async d=>{await rm(join(d,'missing-ref.command.json'));});
await trial('missing-linked-git-command',async d=>{const r=await get(d,'run.json');assert(r.commands.some(x=>x.record==='git-00.command.json'));await rm(join(d,'git-00.command.json'));});
await trial('missing-linked-git-stdout',async d=>{const c=await get(d,'git-00.command.json');await rm(join(d,c.stdout_path));});
await trial('empty-source-build-binding-lists',async d=>{const b=await get(d,'bindings.json');for(const k of['source','build']){b[k].files=[];b[k].digest=sha(Buffer.from('[]'));}await put(d,'bindings.json',b);const hashes={source_digest:b.source.digest,build_digest:b.build.digest};const r=await get(d,'run.json');r.bindings=r.final_bindings=hashes;await put(d,'run.json',r);const rc=await get(d,'receipt.json');rc.binding_digests=hashes;await put(d,'receipt.json',rc);});
await trial('raw-output-hash-mismatch',async d=>{await writeFile(join(d,'missing-ref.stdout'),'fake successful result\n');},{reseal:false});
await trial('raw-output-conflict-resealed',async d=>{const b=Buffer.from('Checking 1 source(s) against their tracked refs...\n  ✓ missing-ref up-to-date\n0 source(s) failed to check.\n0 source(s) drifted from blessed_sha.\n');await writeFile(join(d,'missing-ref.stdout'),b);for(const n of['missing-ref.command.json','missing-ref.json']){const x=await get(d,n);x.stdout_sha256=sha(b);await put(d,n,x);}});
await trial('manifest-duplicate',async d=>{const m=await get(d,'manifest.json');m.files.push(m.files[0]);await put(d,'manifest.json',m);},{reseal:false});
await trial('manifest-traversal',async d=>{const m=await get(d,'manifest.json');m.files[0].path='../outside';await put(d,'manifest.json',m);},{reseal:false});
await trial('manifest-absolute',async d=>{const m=await get(d,'manifest.json');m.files[0].path='/tmp/outside';await put(d,'manifest.json',m);},{reseal:false});
const sentinel=join(area,'outside-sentinel');await writeFile(sentinel,'untouched independent sentinel\n');const sentinelHash=sha(await readFile(sentinel));
await trial('member-symlink',async d=>{await rm(join(d,'missing-ref.stderr'));await symlink(sentinel,join(d,'missing-ref.stderr'));},{reseal:false});assert.equal(sha(await readFile(sentinel)),sentinelHash);
let created;
await trial('fixture-still-exists',async d=>{created=(await get(d,'cleanup.json')).fixture_path;assert(created.startsWith(join(live,'scratch/smoke')+'/skills-check-'));await mkdir(created);},{after:async()=>rm(created,{recursive:true})});
await trial('foreign-cleanup-target',async d=>{for(const n of['receipt.json','cleanup.json']){const x=await get(d,n);if(n==='receipt.json')x.cleanup.fixture_path=sentinel;else x.fixture_path=sentinel;await put(d,n,x);}});assert.equal(sha(await readFile(sentinel)),sentinelHash);
await trial('run-id-swap',async d=>{const r=await get(d,'run.json');r.run_id='old-other-run';await put(d,'run.json',r);});
await trial('origin-network-resealed',async d=>{const x=await get(d,'expectations.json');x.definitions[0].sources[0].origin='https://example.invalid/network-origin';await put(d,'expectations.json',x);const inp=await get(d,'missing-ref.input.json');inp.sources[0].origin='https://example.invalid/network-origin';await put(d,'missing-ref.input.json',inp);const de=await get(d,'missing-ref.json');de.manifest_before_sha256=de.manifest_after_sha256=sha(await readFile(join(d,'missing-ref.input.json')));await put(d,'missing-ref.json',de);});
const orchestration=[];
for(const [label,reply]of [['doctor-ready-false',{exit_code:0,signal:null,killed:false,error:null,stdout:Buffer.from('{"ready":false,"executed":false,"cases":["healthy"]}'),stderr:Buffer.alloc(0)}],['doctor-empty',{exit_code:0,signal:null,killed:false,error:null,stdout:Buffer.alloc(0),stderr:Buffer.alloc(0)}],['doctor-timeout',{exit_code:null,signal:'SIGKILL',killed:true,error:'ETIMEDOUT',stdout:Buffer.alloc(0),stderr:Buffer.from('simulated bounded timeout')}]] ){
 let count=0;const output=join(area,label);const r=await runJourney({output},{invoke:async()=>{count++;return reply;}});assert.equal(count,1);assert.equal(r.status,'failed');assert.equal(r.features[1].verification,'not_run');assert.deepEqual(await readFile(join(output,'healthy-doctor.stdout')),reply.stdout);orchestration.push({label,invocations:count,status:r.status,later:r.features[1].verification,raw_preserved:true});
}
let count=0;const existing=join(area,'existing');await mkdir(existing);await writeFile(join(existing,'sentinel'),'keep');try{await runJourney({output:existing},{invoke:async()=>{count++;throw Error('must not invoke');}});throw Error('accepted existing');}catch(e){assert.match(e.message,/EEXIST/);}assert.equal(count,0);assert.equal(await readFile(join(existing,'sentinel'),'utf8'),'keep');
const summary={candidate:'4ad0832207ab8d42629a42bd7f7ae9e5e52587d4',criteria_sha256:'4017c621bcc8f0e60e6bec25fc0bd2a0677fa6aba24dc3f75863ab51e8139a51',results,orchestration,existing_output_preserved:true,foreign_sentinel_unchanged:sha(await readFile(sentinel))===sentinelHash,unexpected_acceptances:results.filter(x=>!x.met_expectation)};
await writeFile(join(O,'challenge-results.json'),JSON.stringify(summary,null,2)+'\n');
