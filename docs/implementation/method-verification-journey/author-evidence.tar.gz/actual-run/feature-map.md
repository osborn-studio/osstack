# Fixed skills-check journey

Journey status: passed. See journey.json for failure details.

| Feature | Product exit | Driver exit | Verification | Cleanup | Evidence |
|---|---|---|---|---|---|
| healthy | 0 | 0 | passed | passed | cases/healthy/manifest.json |
| missing-ref | 1 | 0 | passed | passed | cases/missing-ref/manifest.json |

Expected missing-ref product exit1 is an unrecovered source failure. Driver exit0 means its fixed negative predicate passed. Native selection/model execution: not observed/not run. Descendant termination: not attested. Other cases: not run.
