# 原生技能发现最小实验预检

状态：**设计完成，未执行**。基线 PR292 `fe9079a1c2f2ea7f9d61030a88bbd58b276ce56b`；本轮只读 Git 对象、CLI help/version 和官方文档，未启动模型、未建工作树、未修改产品或默认 home。精确参数、输入、哈希与待冻结判据见 `protocol.json`。

## 最小交付

四次有界宿主调用：Codex/Claude 各一组有包与无包对照，每次全新 workspace、进程与私有状态目录。只验证 **四个入口可发现，osstack-help 可选用和读取**。不为另外三个入口签发消费证明，不验证隐式自动选择率，不运行验证驱动，也不测代码修复效果。

同一英文任务要求宿主在可用时原生选择 osstack-help，回答“代码变化后验证驱动陈旧，应如何处理、何种证据才可称 green”。最多350词；不注入 SKILL 正文、路径、manifest、预期答案或有包/无包标签。无包组允许给普通建议，但不能虚构已使用 OSStack 包。

[Codex 官方说明](https://learn.chatgpt.com/docs/build-skills)给出项目 `.agents/skills`、名称/描述发现和按需正文读取；[Claude 官方说明](https://code.claude.com/docs/en/skills)给出 `.claude/skills` 和 Skill 调用。当前本地版本为 Codex0.160.1、Claude2.1.291。文档只是预期来源，**真实发现结果必须来自本次宿主记录**。

## 准备与隔离

从精确 Git 对象提取 exporter 两文件及完整 osstack-methods-skill 到自有 scratch 源快照，不读取 dirty primary 作为产品基线。运行现有 exporter，输出新 workspace；将输出 manifest 移到模型不可见的证据目录后保留原哈希。每个 workspace 做普通 `git init`，限定项目祖先扫描范围；不是 git worktree。无包组为空的新 Git 仓库，没有 `.agents/skills` 或 `.claude/skills`。不添加 AGENTS/CLAUDE/README 索引暗示。

```text
/opt/homebrew/opt/node@22/bin/node <snapshot>/scripts/export-osstack-methods.mjs --host codex --output <new-positive-workspace>
/opt/homebrew/opt/node@22/bin/node <snapshot>/scripts/export-osstack-methods.mjs --host claude --output <new-positive-workspace>
git -C <case-workspace> init --quiet
```

每次子进程使用自己的 HOME、CODEX_HOME（Codex）或 Claude 配置目录、OSSTACK_HOME；这些是子进程隔离设置，不改变登录 shell 或默认目录。凭据只能通过已授权的现有认证渠道进入私有状态目录/内存；不要整包复制默认配置，不用指向原认证文件的软链接，不打印密钥或保存进证据包。独立凭据副本若需要刷新，只能改副本。若无法在隔离状态下使用现有认证，记 blocked，不能静默退回默认 home 或另选付费模型。

在启动前核对系统/管理级技能目录与策略；重名覆盖或无包组仍出现目标技能，会使对照污染。管理员策略不通过实验去关闭。额外内置技能可以保留并如实记录，不要求完全没有内置功能。

## 宿主命令与发现证据

Codex：用同一二进制、隔离环境和 workspace 启动一次**不发起模型 turn**的原生 app-server，获取 `skills/list`，有包组必须列出四个目标名称及本次导出路径，无包组不得列出。先用本机 `generate-json-schema` 核对消息字段；按 initialize→initialized→skills/list 顺序发消息，保留原始回复。需要模型时使用 model/list 选取该隔离认证已有的默认型号，冻结具体 ID，不猜最新型号。这个目录探测与后续 exec 是两个进程，报告必须保留这一限制。[协议来源](https://learn.chatgpt.com/docs/app-server)

```text
codex app-server generate-json-schema --out <owned-schema-directory>
codex app-server --listen stdio://
codex -a never exec --ignore-user-config --ignore-rules --ephemeral --sandbox read-only --skip-git-repo-check --color never --json -m <frozen-model-id> -C <case-workspace> -
```

Claude：保留原生技能机制，**不得使用 `--safe-mode`、`--disable-slash-commands` 或 `--bare`**。前两者关闭技能，bare会改变自动上下文/认证路径，不能沿用上轮显式材料实验配置。用 restricted、空 MCP、只读工具集和 dontAsk。`system/init` 的 `skills`、`slash_commands` 字段在上轮2.1.291真实流中确实存在，但这轮内容必须重新观察；字段若消失不能用模型自述代替。

```text
claude -p --model claude-sonnet-5-5 --output-format stream-json --verbose --restricted --tools Skill,Read,Glob,Grep --allowedTools 'Skill(osstack-help),Skill(osstack-mode),Skill(setup-osstack),Skill(osstack-agent),Read,Glob,Grep' --strict-mcp-config --mcp-config <empty-mcp.json> --no-session-persistence --permission-mode dontAsk --permission-prompts none --setting-sources project,local --settings <private-settings.json> --no-chrome
```

两者 stdin 使用完全相同的任务文本；Claude cwd 为各自 workspace。settings 显式拒绝写文件、Bash、代理与联网工具；MCP配置为 `{"mcpServers":{}}`。Codex允许读取命令，但 read-only sandbox 不等于“整个进程只能读取某个目录”；任何越界读、产品/配置写或额外联网工具尝试都要单独判定。模型服务自身请求不算被禁止的研究联网工具。不要声称配置参数自动证明整台机器无副作用。

## 必须事前冻结的判据

独立评估者在响应出现前冻结时间、身份限制、输入哈希和以下判据；不得把作者自测称认证 oracle。

1. **发现**：真实宿主目录含四个入口，路径属于当前包；无包组没有它们。只写“我看到了”不算。
2. **选用**：Claude 原生 Skill 调用或可观察的宿主技能展开；Codex 目录证据加实际读取 SKILL 的执行记录与选用。手工找到一个文件与宿主原生目录发现分开计分。
3. **读取**：原始工具结果/宿主展开与导出正文绑定，并记录实际读了哪个 reference。只读目录名或声称“已阅读”不算。若原生展开不可观察，只能标 catalog_only 或 inconclusive，不能补写成功。
4. **对照**：无包组没有成功的目标技能读取/选用，不安装、不重建、不搜索其他目录找副本。普通建议正确不证明污染；虚构使用包是失败。
5. **边界**：workspace 内容前后哈希不变；只读工具；没有验证驱动、产品测试、子代理或 PR 操作。本实验是实际宿主读取与模拟验证建议，不是实际验证执行。
6. **身份和模型**：保存 CLI版本、二进制身份、请求型号及实际流中的型号/modelUsage；若 Codex不暴露实际解析型号，只写 requested、actual_not_attested。Claude不可静默换模型。模型身份不等于独立可信 principal。

每次最多180秒，无自动重试，超时只终止所属进程组，TERM等待5秒再KILL等待5秒。目录/认证探测失败不消耗模型调用，不拿限额失败算负例通过。固定先 absent 后 present，两个进程不共享上下文；单对照只用于发现机制和污染检查，不推断因果提升。

## 交付、清理与当前未决项

交付 raw JSONL/stdout/stderr、命令/cwd、输入与导出哈希、目录回复、工具调用/结果及行号、耗时/退出码/超时/modelUsage、前后文件清单、独立评分和清理回执。凭据从不入包；只清理本轮明确新建的私有状态与 workspace，不清理全局缓存或原仓库。先确认自有进程结束，先销毁凭据副本，再删私有 home；保留无秘密的材料/证据副本。清理失败如实列出。

待开工核实三点：隔离认证可用；本机 app-server schema兼容；Claude restricted下确实暴露项目技能且可观察选用。它们不是本轮已通过的条件。若失败，先保留 blocked/limited 结果再修实验规格，不能偷偷撤掉隔离或把正文重新塞进 prompt。完成最小实验以后，才考虑另批覆盖其余三个入口或隐式触发。
