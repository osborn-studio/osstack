from pathlib import Path
import os,subprocess,json,datetime,sys,hashlib
root=Path(__file__).resolve().parent
repo=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-final-ci-composition')
commands={'docs':['/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-handoff-20261027/venv/bin/python','-m','unittest','discover','-s','docs/design/2026-10-27-joint-engineering','-p','test_validate_*.py'],'install':['pnpm','install','--frozen-lockfile'],'build':['pnpm','build'],'method-export':['pnpm','test:method-export'],'skills-check':['pnpm','smoke:skills-check'],'headers':['node','--test','scripts/prepare-node-headers.test.mjs'],'hygiene':['pnpm','--filter','@osstack/governance','exec','vitest','run','src/knowledge-hygiene/osstack-config.test.ts']}
key=sys.argv[1];argv=commands[key]
env=dict(os.environ);env.update(PATH='/opt/homebrew/opt/node@22/bin:/opt/homebrew/bin:/usr/bin:/bin',OSSTACK_HOME=str(root/'home'),OSSTACK_SCRATCH_ROOT='/Volumes/AIMATE_WORK/tmp/osstack');env.pop('OSSTACK_SOCKET',None)
row={'key':key,'argv':argv,'cwd':str(repo),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'PATH':env['PATH'],'OSSTACK_HOME':env['OSSTACK_HOME'],'OSSTACK_SCRATCH_ROOT':env['OSSTACK_SCRATCH_ROOT'],'OSSTACK_SOCKET':'unset'}
(root/'home').mkdir(exist_ok=True)
with (root/(key+'.log')).open('xb') as out:
 result=subprocess.run(argv,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
row.update(ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=result.returncode,raw_log_sha256=hashlib.sha256((root/(key+'.log')).read_bytes()).hexdigest())
with (root/(key+'.command.json')).open('x') as out:json.dump(row,out,indent=2);out.write('\n')
print(json.dumps(row));sys.exit(result.returncode)
