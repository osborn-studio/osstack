from pathlib import Path
import json,hashlib,subprocess,datetime,sys,stat,os,tomllib,tarfile,io
W=Path('/Users/osborn/Developer/CodeX/.worktrees/osstack/joint-post284-control');D=W/'docs/design/2026-10-27-joint-engineering';S=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-post284/control')
BASE='3192b424174e5eb977d640cc0418e67c6b1461d1'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def h(b):return hashlib.sha256(b).hexdigest()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=W,text=True).strip()
assert git('ls-remote','origin','refs/heads/main').split()[0]==BASE
start=now();old=(D/'execution-ledger.json').read_bytes();d=json.loads(old)
E=D/'evidence/joint-execution/post284-closeout'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');E.mkdir(parents=True)
def rec(p):return {'path':str(p.relative_to(D)),'sha256':h(p.read_bytes())}
p=E/('ledger-before-'+h(old)+'.json');p.write_bytes(old);d['checkpoint_history'].append(rec(p))
fields='number,url,state,isDraft,baseRefName,headRefName,headRefOid,mergedAt,mergeCommit,mergeable,mergeStateStatus,reviewDecision,statusCheckRollup'
for n in [283,284]:
 v=json.loads(subprocess.check_output(['gh','pr','view',str(n),'--repo','osborn-studio/osstack','--json',fields]));v['observed_at']=now();assert v['state']=='MERGED'
 for name in ['check','graph-macos-fixtures (22)','graph-macos-fixtures (24)','graph-runtime-matrix (20.6.0)','graph-runtime-matrix (22.23.1)']:
  checks=[x for x in v['statusCheckRollup'] if x['name']==name];assert len(checks)==1 and checks[0]['conclusion']=='SUCCESS'
 d['prs']=[x for x in d['prs'] if x['number']!=n]+[v]
assert next(x for x in d['prs'] if x['number']==284)['mergeCommit']['oid']==BASE
assert git('rev-parse',BASE+'^{tree}')=='228b2a0b9ae6708bc68bb3019921198484538320'
d['main_sha']=BASE;d['observed_at']=now()
helper=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/session-debt-20261026/ledger.py');assert h(helper.read_bytes())=='b1449d7b95df5012c9889d4afb2517f42fc7dc72c125948ba1018fbc40379e1e'
ns={'__name__':'pinned_helper'};exec(compile(helper.read_bytes(),str(helper),'exec'),ns);rpc=ns['rpc']
st=Path('/tmp/osstack-debt-ledger.sock').lstat();assert stat.S_ISSOCK(st.st_mode) and st.st_uid==os.getuid() and stat.S_IMODE(st.st_mode)==0o600
m=d['management'];m['board_snapshots']=[]
for b in ['joint-firstmate-pstack','firstmate-upgrade-roadmap','session-pilot-debt']:
 p=E/(b+'.json');write(p,rpc('kanban.board',{'board':b,'include_archived':True}));m['board_snapshots'].append(rec(p))
m['snapshot']=m['board_snapshots'][0]['path'];m['snapshot_sha256']=m['board_snapshots'][0]['sha256']
cfgpath=Path('/Users/osborn/.codex/automations/osstack/automation.toml');cfg=tomllib.loads(cfgpath.read_text());assert cfg['status']=='ACTIVE'
archive=Path('/Volumes/AIMATE_WORK/tmp/osstack/runtime/joint-nextwave-20261028/independent/composition/composition-evidence.tar.gz').read_bytes()
assert h(archive)=='e391070dd0f9f49830b92aaf5d1d02d08e37faa2fca8c4199d3e669bf6bcd13e'
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 manifest=json.load(tar.extractfile('composition-manifest.json'))
 for item in manifest['files']:
  raw=tar.extractfile(item['path']).read();assert len(raw)==item['bytes'] and h(raw)==item['sha256']
 summary=json.load(tar.extractfile('verification-summary.json'))
 assert summary['published_tree']==manifest['published_tree']
main_tree=git('rev-parse',BASE+'^{tree}');assert main_tree==summary['published_tree']
p=E/'previous-composition-evidence.tar.gz';p.write_bytes(archive)
composition_proof={'main_sha':BASE,'main_tree':main_tree,'previous_composition_tree':summary['published_tree'],'same_tree':main_tree==summary['published_tree'],'archive':rec(p),'manifest_members_verified':len(manifest['files']),'scope':'Computed comparison against hash-verified historical archive; original test bindings retained, no new test execution or runtime qualification'}
receipts={
'subagent-dispatch-receipts.json':{'base':BASE,'receipts':[json.loads(p.read_text()) for p in sorted(S.glob('card_*-dispatch.json'))],'scope':'three bounded tasks; no formal gate qualification'},
 'terminal-preflight-receipt.json':composition_proof,
 'board-final-receipts.json':{'observed_at':now(),'boards':m['board_snapshots'],'scope':'post-dispatch read-only board snapshots'},
 'automation-receipt.json':{'observed_at':now(),'config_sha256':h(cfgpath.read_bytes()),'config':cfg,'scope':'owner-observed persisted config following successful automation_update; no scheduler attestation'}}
m['receipts']=[]
for name,v in receipts.items():p=E/name;write(p,v);m['receipts'].append(rec(p))
p=E/'ledger-rpc-helper.py';p.write_bytes(helper.read_bytes());m['rpc_helper']={**rec(p),'socket':'/tmp/osstack-debt-ledger.sock','scope':'pinned helper and observed socket; no development CLI/default DB'}
m['socket_observation']={'uid':st.st_uid,'mode':oct(stat.S_IMODE(st.st_mode)),'observed_at':now()}
m['heartbeat'].update(base_sha=BASE,updated_at=cfg['updated_at'],observed_at=now(),config_sha256=h(cfgpath.read_bytes()),queue='JP01c component acceptance; JA20/47 recovery composition; J02b offline preparation')
m['evidence_scope']='Post-#283/#284 merge and next-batch dispatch. Historical tests remain pinned to original code/base; formal gates remain unqualified.'
d['next_batch']={'id':'joint-post284','base_sha':BASE,'runtime_enabled':False,'workers':[{'agent':'loader_adversarial','scope':'JP01c JA59/70 test/oracle coverage; no formal principal attestation','branch':'codex/joint-contract-acceptance'},{'agent':'terminal_preflight','scope':'JA20/47 home+broker offline composition tests/spec','branch':'codex/joint-recovery-composition'},{'agent':'cleanup_regression','scope':'J02b offline adoption preparation; scratch only'}],'shared_owner':'root: central ledger, execution.md, project-operations.md and PR publishing','full_regression_queue':'root single queue','qualification':'All formal joint gates remain specified_not_run, including J01.contracts and J11/J17; broker deployment not qualified; J02b/J03 product implementation blocked on formal gate; no runtime activation'}
d['observation_window']={'started_at':start,'finished_at':now(),'scope':'Latest #283/#284 and boards observed sequentially; older PRs retain own timestamps; no atomic snapshot claim.'}
write(E/'observation.json',{'main_sha':BASE,'new_prs':[p for p in d['prs'] if p['number'] in [283,284]],'window':d['observation_window']})
assert git('ls-remote','origin','refs/heads/main').split()[0]==BASE
assert (D/'execution-ledger.json').read_bytes()==old
p=D/'execution-ledger.json.tmp';write(p,d);p.replace(D/'execution-ledger.json')
write(S/'closeout-result.json',{'evidence':str(E),'base':BASE,'ledger_sha256':h((D/'execution-ledger.json').read_bytes())});print(E)
